// Local read-only handle diagnostic. No async hooks, VM/global rewrites or refs.
const fs=require('node:fs'),path=require('node:path');
const output=path.join(process.env.POINTER_DIAGNOSTIC_DIR,String(process.pid)+'.jsonl');
const start=process.hrtime.bigint();
function record(phase){
 const row={phase,pid:process.pid,ppid:process.ppid,seconds:Number(process.hrtime.bigint()-start)/1e9,cpu:process.cpuUsage(),memory:process.memoryUsage(),resources:process.getActiveResourcesInfo(),argv:process.argv};
 fs.appendFileSync(output,JSON.stringify(row)+'\n');
}
record('start');const observer=setInterval(()=>record('sample'),500);observer.unref();
process.on('beforeExit',()=>record('beforeExit'));process.on('exit',code=>{record('exit:'+code)});
