from pathlib import Path
import subprocess,json,os,signal,hashlib,re,time,sys
p=Path(__file__).resolve().parent;c=p/'candidate';sdk=sys.argv[1];nodes={'24.19.0':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','26.13.0':'/workspace/shared/node26/node_modules/node/bin/node'};node=nodes[sdk];o=p/('sdk-'+sdk+'-1');o.mkdir(exist_ok=False);start=time.monotonic();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();files=[Path(__file__),p/'leaves.json',Path(node)];rows=[];failure=None
for parent in[c/'src',c/'test',c/'native',c/'evidence',c/'node_modules',Path('/workspace/red-panda/src'),Path('/workspace/red-panda/native')]:files.extend(f for f in parent.rglob('*')if f.is_file())
snap=lambda:{str(f):sha(f)for f in sorted(set(files))};before=snap();(o/'before.json').write_text(json.dumps(before,indent=2)+'\n');assert all(sha(c/n)==h for n,h in json.loads((p/'leaves.json').read_text()).items());env=dict(os.environ,NODE_USE_ENV_PROXY='1');bypass=','.join(filter(None,[env.get('NO_PROXY'),env.get('no_proxy'),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']));env.update(NO_PROXY=bypass,no_proxy=bypass,RED_PANDA_RUNTIME_ADDON=str(c/('native/build/linux-x64/node-'+sdk+'/runtime.node')),RED_PANDA_COLLECTIONS_ADDON=str(c/('native/build/linux-x64/node-'+sdk+'/collections.node')))
def interrupted(number,frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,interrupted)
def run(name,args):
 begin=time.monotonic();cmd=[node,'--experimental-vm-modules',*args]
 with(o/(name+'.stdout')).open('xb')as stdout,(o/(name+'.stderr')).open('xb')as stderr:
  child=subprocess.Popen(cmd,cwd=c,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try:child.wait(timeout=max(.01,25-(time.monotonic()-start)))
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=1)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 row={'name':name,'pid':child.pid,'exit':child.returncode,'seconds':time.monotonic()-begin};rows.append(row)
 if child.returncode:raise RuntimeError('Actual SDK child failed: '+name)
 return(o/(name+'.stdout')).read_text()
try:
 text=run('eight',['--test','--test-reporter=tap','--test-concurrency=1','test/pointer-event-parity.test.js']);counts={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled) (\d+)$',text,re.M)};assert counts=={'tests':8,'pass':8,'fail':0,'skipped':0,'cancelled':0};rows[-1]['counts']=counts
 run('creation',['evidence/creation-proof.mjs',str(o/'physical.json')]);proof=json.loads((o/'physical.json').read_text())['rows'];physical=[r for r in proof if'before'in r];assert len(physical)==51 and all(r['before']and r['after']and not r['host']for r in physical);assert all(r['actual']and r.get('implementation',True)for r in proof if'actual'in r);rows[-1]['physicalRows']=len(physical);rows[-1]['canonicalSetupRows']=len(proof)-len(physical)
except BaseException as e:failure={'type':type(e).__name__,'message':str(e)}
after=snap();(o/'after.json').write_text(json.dumps(after,indent=2)+'\n');report={'sdk':sdk,'rows':rows,'failure':failure,'inputs':len(before),'unchanged':before==after,'seconds':time.monotonic()-start,'RootApplied':False,'regressionTimeoutPreserved':True};(o/'status.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(0 if failure is None and before==after else 1)
