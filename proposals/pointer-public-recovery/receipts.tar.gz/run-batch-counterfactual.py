from pathlib import Path
import subprocess,os,signal,time,json,hashlib,re,sys
p=Path(__file__).resolve().parent;actor=sys.argv[1];assert actor in ['baseline','candidate'];c=p/actor;o=p/('batch-counterfactual-'+actor+'-1');o.mkdir(exist_ok=False);start=time.monotonic();paths=[Path(__file__)];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for parent in[c/'src',c/'native',c/'test',c/'docs',c/'node_modules',Path('/workspace/red-panda/src'),Path('/workspace/red-panda/native')]:paths +=[f for f in parent.rglob('*')if f.is_file()]
snap=lambda:{str(f):sha(f)for f in sorted(set(paths))};before=snap();(o/'before.json').write_text(json.dumps(before,indent=2)+'\n');cmd=['/workspace/shared/rea-tools/node_modules/node/bin/node','--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*['test/'+n+'.test.js'for n in['input','event-idl-realms','event-backend-initialization','event-foundation','event-api-parity','dom-events','private-event-utility-backing']]];failure=None;child=None
env=dict(os.environ,NODE_USE_ENV_PROXY='1');bypass=','.join(filter(None,[env.get('NO_PROXY'),env.get('no_proxy'),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']));env.update(NO_PROXY=bypass,no_proxy=bypass)
def interrupted(number,frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,interrupted)
try:
 with(o/'stdout').open('xb')as stdout,(o/'stderr').open('xb')as stderr:
  child=subprocess.Popen(cmd,cwd=c,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try:child.wait(timeout=35)
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=1)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 text=(o/'stdout').read_text();counts={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled) (\d+)$',text,re.M)}
 if child.returncode or counts.get('fail')!=0 or counts.get('pass')!=counts.get('tests')or counts.get('skipped')!=0 or counts.get('cancelled')!=0:raise RuntimeError('Actual regression failure/count boundary')
except BaseException as e:failure={'type':type(e).__name__,'message':str(e)}
after=snap();(o/'after.json').write_text(json.dumps(after,indent=2)+'\n');result={'actor':actor,'command':cmd,'pid':child.pid if child else None,'exit':child.returncode if child else None,'counts':locals().get('counts'),'failure':failure,'inputs':len(before),'unchanged':before==after,'seconds':time.monotonic()-start,'OriginalBudgetsUnchanged':True,'administrative35s':True,'RootApplied':False};(o/'status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if failure is None and before==after else 1)
