from pathlib import Path
import subprocess,json,hashlib,os,signal,time,re,sys
p=Path(__file__).resolve().parent;actor=sys.argv[1];assert actor in['baseline','candidate'];c=p/actor;o=p/('utility-diagnostic-'+actor+'-1');o.mkdir(exist_ok=False);(o/'resources').mkdir();start=time.monotonic();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();paths=[Path(__file__),p/'resources.cjs',p/'baseline-frozen.json',p/'leaves.json'];failure=None;counts=None;child=None
for parent in[c/'src',c/'test',c/'native',c/'node_modules',Path('/workspace/red-panda/src'),Path('/workspace/red-panda/native')]:paths.extend(f for f in parent.rglob('*')if f.is_file())
snap=lambda:{str(f):sha(f)for f in sorted(set(paths))};before=snap();(o/'before.json').write_text(json.dumps(before,indent=2)+'\n')
if actor=='baseline':assert all(sha(c/n)==h for n,h in json.loads((p/'baseline-frozen.json').read_text())['files'].items())
else:assert all(sha(c/n)==h for n,h in json.loads((p/'leaves.json').read_text()).items())
env=dict(os.environ,NODE_USE_ENV_PROXY='1',POINTER_DIAGNOSTIC_DIR=str(o/'resources'));bypass=','.join(filter(None,[env.get('NO_PROXY'),env.get('no_proxy'),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']));env.update(NO_PROXY=bypass,no_proxy=bypass);cmd=['/workspace/shared/rea-tools/node_modules/node/bin/node','--experimental-vm-modules','--require',str(p/'resources.cjs'),'--test','--test-reporter=tap','--test-concurrency=1','test/private-event-utility-backing.test.js']
def interrupted(number,frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,interrupted)
try:
 with(o/'stdout').open('xb')as stdout,(o/'stderr').open('xb')as stderr:
  child=subprocess.Popen(cmd,cwd=c,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try:child.wait(timeout=35)
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=1)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 counts={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled) (\d+)$',(o/'stdout').read_text(),re.M)}
 if child.returncode or counts!={'tests':2,'pass':2,'fail':0,'skipped':0,'cancelled':0}:raise RuntimeError('Actual diagnostic test failure/count')
except BaseException as e:failure={'type':type(e).__name__,'message':str(e)}
after=snap();(o/'after.json').write_text(json.dumps(after,indent=2)+'\n');result={'actor':actor,'counts':counts,'failure':failure,'pid':child.pid if child else None,'exit':child.returncode if child else None,'seconds':time.monotonic()-start,'inputs':len(before),'unchanged':before==after,'diagnostic':'read-only getActiveResourcesInfo/cpu/memory unref500ms; no VM/async-hook rewrites','OriginalTestUnchanged':True,'administrative35s':True};(o/'status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if failure is None and before==after else 1)
