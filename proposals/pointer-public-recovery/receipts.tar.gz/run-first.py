from pathlib import Path
import json,hashlib,subprocess,os,time,signal,re
p=Path(__file__).resolve().parent;c=p/'candidate';out=p/'first';out.mkdir(exist_ok=False)
node=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');native=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');root=Path('/workspace/red-panda');start=time.monotonic();cap=120;rows=[];failure=None
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
def snapshot():
 files=[node,native,Path(__file__),p/'base.json',p/'leaves.json',p/'integration.patch',p/'provenance.json']
 for parent in [c/'src',c/'native',c/'test',c/'scripts',c/'bin',c/'evidence',c/'node_modules',root/'src',root/'native']:
  files.extend(f for f in parent.rglob('*')if f.is_file())
 return{str(f):sha(f)for f in sorted(set(files))}
def interrupted(number,frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,interrupted)
env=dict(os.environ,NODE_USE_ENV_PROXY='1');aliases='0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]';bypass=','.join(filter(None,[env.get('NO_PROXY'),env.get('no_proxy'),aliases]));env.update(NO_PROXY=bypass,no_proxy=bypass)
before=snapshot();save('before.json',before)
assert sha(native)=='9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f'
for n,h in json.loads((p/'leaves.json').read_text()).items():assert sha(c/n)==h,n
protected=json.loads((p/'provenance.json').read_text())['nativeSourceAnd18Artifacts'];assert all(sha(c/n)==h and sha(root/n)==h for n,h in protected.items())
def run(label,args):
 begin=time.monotonic();cmd=[str(node),*args];child=None;deadline=False
 with(out/(label+'.stdout')).open('xb')as stdout,(out/(label+'.stderr')).open('xb')as stderr:
  child=subprocess.Popen(cmd,cwd=c,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try:child.wait(timeout=max(.01,cap-(time.monotonic()-start)))
  except BaseException:
   deadline=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=1)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
  finally:
   row={'label':label,'command':cmd,'pid':child.pid,'exit':child.returncode,'administrativeStop':deadline,'seconds':time.monotonic()-begin};rows.append(row);save('steps.json',rows);print(json.dumps(row),flush=True)
 if child.returncode:raise RuntimeError('First actual command failure: '+label)
 return(out/(label+'.stdout')).read_text()
try:
 for kind in ['pointer-heldout-values','pointer-heldout-realms']:
  run('Native-'+kind,['evidence/probe.mjs',str(native),kind,str(out/(kind+'-Native.json'))]);raw=json.loads((out/(kind+'-Native.json')).read_text());assert 'exceptionDetails'not in raw['response'],raw
 text=run('candidate-eight',['--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1','test/pointer-event-parity.test.js']);counts={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled) (\d+)$',text,re.M)};assert counts=={'tests':8,'pass':8,'fail':0,'skipped':0,'cancelled':0},counts
 run('actual-creation',['--experimental-vm-modules','evidence/creation-proof.mjs',str(out/'physical.json')]);physical=json.loads((out/'physical.json').read_text())['rows'];assert physical and all(x.get('before')is True and x.get('after')is True and x.get('host')is False for x in physical if 'before'in x),physical
except BaseException as e:failure={'type':type(e).__name__,'message':str(e)}
finally:
 after=snapshot();save('after.json',after);result={'status':'PASS_FIRST_ONLY'if failure is None and before==after else'FAIL_STOP_REMAINING_UNRUN','failure':failure,'steps':rows,'unchanged':before==after,'inputs':len(before),'changed':[n for n in before if before[n]!=after.get(n)],'seconds':time.monotonic()-start,'RootApplied':False,'SDKAndHeldoutComparisons':'UNRUN','driverProducer':'unchangedRootdriver; Nativepoison/wheel controls queued','protectedDraftsUnchanged':True};save('status.json',result);print(json.dumps(result),flush=True)
raise SystemExit(0 if failure is None and before==after else 1)
