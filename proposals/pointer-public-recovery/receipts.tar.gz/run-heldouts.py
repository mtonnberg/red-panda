from pathlib import Path
import subprocess,json,hashlib,time,os,signal
p=Path(__file__).resolve().parent;c=p/'candidate';o=p/'heldouts-1';o.mkdir(exist_ok=False);node='/workspace/shared/rea-tools/node_modules/node/bin/node';started=time.monotonic();rows=[];failure=None
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
files=[Path(__file__),p/'candidate-cli',p/'leaves.json',p/'first/status.json']+list((p/'first').glob('*-Native.json'))
for parent in[c/'src',c/'native',c/'evidence',c/'node_modules',Path('/workspace/red-panda/src'),Path('/workspace/red-panda/native')]:files +=[f for f in parent.rglob('*')if f.is_file()]
files=sorted(set(files));snap=lambda:{str(f):sha(f)for f in files};before=snap();(o/'before.json').write_text(json.dumps(before,indent=2)+'\n');env=dict(os.environ,NODE_USE_ENV_PROXY='1');proxy=','.join(filter(None,[env.get('NO_PROXY'),env.get('no_proxy'),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']));env.update(NO_PROXY=proxy,no_proxy=proxy);env['RED_PANDA_RUNTIME_ADDON']=str(c/'native/build/linux-x64/node-24.22.1/runtime.node');env['RED_PANDA_COLLECTIONS_ADDON']=str(c/'native/build/linux-x64/node-24.22.1/collections.node')
def interrupted(number,frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,interrupted)
try:
 for kind in['pointer-heldout-values','pointer-heldout-realms']:
  out=o/(kind+'-candidate.json');cmd=[node,'evidence/probe.mjs',str(p/'candidate-cli'),kind,str(out)];begin=time.monotonic()
  with(o/(kind+'.stdout')).open('xb')as stdout,(o/(kind+'.stderr')).open('xb')as stderr:
   child=subprocess.Popen(cmd,cwd=c,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   try:child.wait(timeout=max(.01,45-(time.monotonic()-started)))
   except BaseException:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=1)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    raise
  row={'kind':kind,'pid':child.pid,'exit':child.returncode,'seconds':time.monotonic()-begin};rows.append(row)
  if child.returncode:raise RuntimeError('Actual candidate command failure: '+kind)
  actual=json.loads(out.read_text());native=json.loads((p/'first'/(kind+'-Native.json')).read_text());assert 'exceptionDetails'not in actual['response'];row['equal']=actual['response']['result']['value']==native['response']['result']['value'];row['actualRows']=len(actual['response']['result']['value']);row['NativeSHA256']=sha(p/'first'/(kind+'-Native.json'));print(json.dumps(row),flush=True)
  if not row['equal']:raise RuntimeError('Actual heldout contrary: '+kind)
except BaseException as e:failure={'type':type(e).__name__,'message':str(e)}
finally:
 after=snap();(o/'after.json').write_text(json.dumps(after,indent=2)+'\n');result={'rows':rows,'failure':failure,'inputs':len(before),'unchanged':before==after,'changed':[f for f in before if before[f]!=after.get(f)],'seconds':time.monotonic()-started,'RootApplied':False,'SDKRegressionsDriver':'UNRUN'};(o/'status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(0 if failure is None and before==after else 1)
