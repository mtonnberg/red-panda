from pathlib import Path
import hashlib,json,subprocess,os,signal,time
r=Path('/workspace/red-panda');o=Path(__file__).resolve().parent;plan=Path('/workspace/shared/registration455-adapted-plan-20261031');native=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');node=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');files=[Path(__file__),o/'red-panda-launcher',native,node,plan/'harness/scripts/conformance.mjs',plan/'fixtures/adapted/testing.js',plan/'fixtures/adapted/event/pointer.html',plan/'maps/registration-map.json']
for parent in[r/'src',r/'native',r/'node_modules']:files.extend(f for f in parent.rglob('*')if f.is_file())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();snap=lambda:{str(f):sha(f)for f in sorted(set(files))};before=snap();(o/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');env=dict(os.environ,NODE_USE_ENV_PROXY='1');bypass=','.join(filter(None,[env.get('NO_PROXY'),env.get('no_proxy'),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']));env.update(NO_PROXY=bypass,no_proxy=bypass);rows=[];failure=None
try:
 for actor,binary in [('Native',native),('Root',o/'red-panda-launcher')]:
  report=o/(actor+'-source.json');cmd=[str(node),str(plan/'harness/scripts/conformance.mjs'),'--root',str(plan/'fixtures/adapted'),'--binary',str(binary),'--isolate','--fixture-profile','upstream','--source-load-contract','--websocket-port','9584','--registration-map',str(plan/'maps/registration-map.json'),'--runner-global-arg=--ws-max-concurrent','--runner-global-arg=50','--port','9582','--test','event/pointer.html','--report',str(report)];start=time.monotonic()
  with(o/(actor+'-source.log')).open('xb')as out:
   child=subprocess.Popen(cmd,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
   try:child.wait(timeout=19)
   except BaseException:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=1)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    raise
  row={'actor':actor,'pid':child.pid,'exit':child.returncode,'seconds':time.monotonic()-start};rows.append(row);assert child.returncode==0,row
  data=json.loads(report.read_text());assert len(data['results'])==1;value=data['results'][0];assert value['path']=='event/pointer.html'and value['status']=='passed'and value['nativeHarnessBranch']is True;load=value['sourceLoadContract'];assert load['loadBudgetMs']==2000 and load['assertionBudgetMs']==2000 and load['assertionStartedAfterLoad']is True;assert value['sourceProfile']['id']=='fa94522d56ca';row['sourcePassed']=True;print(json.dumps(row),flush=True)
except BaseException as e:failure={'type':type(e).__name__,'message':str(e)}
after=snap();(o/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');result={'rows':rows,'failure':failure,'inputs':len(before),'unchanged':before==after,'scope':'One unchanged original Source fixture, original2sload+fresh2sassertions/WS50. Only disclosed external runner eligibility recognizes RedPanda; actualUA/clientHints/fixtureassertions unchanged. Not a new455census.'};(o/'source-status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if failure is None and before==after else 1)
