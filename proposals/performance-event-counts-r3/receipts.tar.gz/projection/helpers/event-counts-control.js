(()=>{
 const rows=[],phase=(name,fn)=>{try{rows.push({name,value:fn()})}catch(error){rows.push({name,error:{name:error.name,message:error.message}})}};
 const ec=performance.eventCounts,counts=()=>({type:typeof performance.eventCounts,values:Object.fromEntries(['click','keydown','input','pointerdown','load','unknownActual'].map(key=>[key,ec?.get(key)]))});
 phase('surface-and-descriptors',()=>{
  const chain=[];for(let p=ec;p!==null&&p!==undefined&&chain.length<4;p=Object.getPrototypeOf(p))chain.push({tag:Object.prototype.toString.call(p),own:Reflect.ownKeys(p).map(key=>typeof key==='symbol'?{symbol:key.description}:key)});
  const prototype=ec&&Object.getPrototypeOf(ec),fields={};
  if(prototype)for(const key of ['size','get','has','keys','values','entries','forEach']){const d=Object.getOwnPropertyDescriptor(prototype,key);fields[key]=d?{keys:Reflect.ownKeys(d),enumerable:d.enumerable,configurable:d.configurable,writable:d.writable??null,valueType:typeof d.value,getType:typeof d.get,length:d.value?.length??d.get?.length??null}:null;}
  return {exists:ec!==undefined&&ec!==null,type:typeof ec,same:ec===performance.eventCounts,constructorType:typeof EventCounts,instance:typeof EventCounts==='function'?ec instanceof EventCounts:null,isMap:ec instanceof Map,tag:Object.prototype.toString.call(ec),chain,fields,keys:ec?[...ec.keys()]:null,values:ec?[...ec.values()]:null,entries:ec?[...ec.entries()]:null,symbolIteratorAlias:!!ec&&prototype[Symbol.iterator]===prototype.entries};
 });
 phase('actual-untrusted-and-activation-dispatch',()=>{
  const target=document.getElementById('eventTarget'),trace=[],before=counts();
  const record=event=>trace.push({type:event.type,trusted:event.isTrusted,bubbles:event.bubbles,clickCount:ec?.get('click')});
  target.addEventListener('click',record);document.addEventListener('click',record);window.addEventListener('click',record);
  const event=new MouseEvent('click',{bubbles:true});target.dispatchEvent(event);const synthetic=counts();
  target.dispatchEvent(event);const redispatched=counts();target.click();const activation=counts();
  target.disabled=true;target.click();target.disabled=false;const disabled=counts();
  const generic=new EventTarget();generic.dispatchEvent(new Event('click'));const genericTarget=counts();
  target.removeEventListener('click',record);document.removeEventListener('click',record);window.removeEventListener('click',record);
  return {before,synthetic,redispatched,activation,disabled,genericTarget,trace};
 });
 phase('nested-dispatch-and-target-owner',()=>{
  const target=document.getElementById('eventTarget'),before=counts();let nested=false;
  const listener=()=>{if(!nested){nested=true;target.dispatchEvent(new Event('click'));}};
  target.addEventListener('click',listener);target.dispatchEvent(new Event('click'));target.removeEventListener('click',listener);
  const afterNested=counts(),child=document.querySelector('iframe').contentWindow,childBefore=child.performance.eventCounts?.get('click');
  child.document.body.dispatchEvent(new Event('click'));const childAfter=child.performance.eventCounts?.get('click'),parentAfterChild=counts();
  const inert=document.implementation.createHTMLDocument(),button=inert.createElement('button');inert.body.append(button);button.click();
  return {before,afterNested,childBefore,childAfter,parentAfterChild,afterInert:counts()};
 });
 phase('get-has-conversions-and-brands',()=>{
  const output=[],call=(name,fn)=>{try{output.push({name,value:fn()})}catch(error){output.push({name,error:{name:error.name,message:error.message,ownTypeError:error instanceof TypeError}})}};
  for(const method of ['get','has']){
   call(method+' missing',()=>ec[method]());call(method+' undefined',()=>ec[method](undefined));call(method+' null',()=>ec[method](null));
   call(method+' symbol',()=>ec[method](Symbol('click')));call(method+' object',()=>{let calls=0;const result=ec[method]({toString(){calls++;return'click'}});return{result,calls}});
   call(method+' fake',()=>ec[method].call({},'click'));call(method+' inherited',()=>ec[method].call(Object.create(ec),'click'));call(method+' proxy',()=>ec[method].call(new Proxy(ec,{}),'click'));
  }
  call('constructor',()=>{new EventCounts;return 'constructed'});
  call('JS Map intrinsic brand',()=>Map.prototype.get.call(ec,'click'));
  call('size getter fake',()=>Object.getOwnPropertyDescriptor(Object.getPrototypeOf(ec),'size').get.call({}));
  call('clone EventCounts',()=>{const result=structuredClone(ec);return{tag:Object.prototype.toString.call(result),same:result===ec}});
  return output;
 });
 phase('foreach-and-iterator-producers',()=>{
  const context={actual:true},entries=[];ec.forEach(function(value,key,object){'use strict';entries.push({value,key,same:object===ec,thisArg:this===context});},context);
  let throwingCalls=0,throwEscaped=null;try{ec.forEach(()=>{throwingCalls++;if(throwingCalls===1)throw new Error('actual callback throw');});}catch(error){throwEscaped={name:error.name,message:error.message};}
  const iterator=ec.entries(),first=iterator.next();document.getElementById('eventTarget').dispatchEvent(new Event('click'));
  const rest=[];for(let step=iterator.next();!step.done;step=iterator.next())rest.push(step);
  let borrowed;try{borrowed={value:Object.getPrototypeOf(iterator).next.call({})};}catch(error){borrowed={error:{name:error.name,message:error.message}};}
  let selfIterator;try{selfIterator={value:iterator[Symbol.iterator]()===iterator};}catch(error){selfIterator={error:{name:error.name,message:error.message}};}
  return {entries,throwingCalls,throwEscaped,first,rest,done:iterator.next(),iteratorTag:Object.prototype.toString.call(iterator),selfIterator,borrowed};
 });
 globalThis.__actualTrustedEvents=[];
 document.getElementById('eventTarget').addEventListener('click',event=>__actualTrustedEvents.push({type:event.type,trusted:event.isTrusted,count:performance.eventCounts?.get('click')}));
 return {rows,counts:counts(),boundary:'Independent EventCounts observations from real dispatch, DOM, Maplike methods and iterator execution. No synthetic counter implementation.'};
})()
