(()=>{
 const rows=[],ec=performance.eventCounts,p=Object.getPrototypeOf(ec),call=fn=>{try{return{value:fn()}}catch(e){return{error:{name:e.name,message:e.message,ownTypeError:e instanceof TypeError}}}};
 const phase=(name,fn)=>rows.push({name,...call(fn)}),keys=o=>Reflect.ownKeys(o).map(k=>typeof k==='symbol'?{symbol:k.description}:k);
 const descriptor=d=>d?{enumerable:d.enumerable,configurable:d.configurable,writable:d.writable??null,valueType:typeof d.value,getType:typeof d.get,setType:typeof d.set,name:d.value?.name??d.get?.name??null,length:d.value?.length??d.get?.length??null}:null;
 phase('clone-real-and-ordinary-lookalikes',()=>{
  const copied={};Object.defineProperties(copied,Object.getOwnPropertyDescriptors(ec));const fake=Object.create(p),tagged={[Symbol.toStringTag]:'EventCounts'},inherited=Object.create(ec);
  return[['real',ec],['descriptor-copy',copied],['prototype-lookalike',fake],['inherited-real',inherited],['authored-tag',tagged],['proxy',new Proxy(ec,{})],['iterator',ec.entries()]].map(([name,value])=>({name,result:call(()=>{const copy=structuredClone(value);return{tag:Object.prototype.toString.call(copy),keys:keys(copy),same:copy===value,ordinary:Object.getPrototypeOf(copy)===Object.prototype}})}));
 });
 phase('iterator-real-prototypes-and-brands',()=>{
  const result=[];for(const name of ['keys','values','entries',Symbol.iterator]){
   const it=ec[name](),ip=Object.getPrototypeOf(it),chain=[];for(let x=it;x&&chain.length<5;x=Object.getPrototypeOf(x))chain.push({keys:keys(x),tag:Object.prototype.toString.call(x)});
   let traps=0;const proxy=new Proxy(it,{get(){traps++;throw new Error('authored proxy');}}),inherited=Object.create(it),next=ip.next;
   result.push({name:typeof name==='symbol'?'Symbol.iterator':name,method:descriptor(Object.getOwnPropertyDescriptor(p,name)),chain,next:descriptor(Object.getOwnPropertyDescriptor(ip,'next')),self:call(()=>it[Symbol.iterator]()===it),real:call(()=>next.call(it)),fake:call(()=>next.call({})),inherited:call(()=>next.call(inherited)),proxy:call(()=>next.call(proxy)),traps});
  }return result;
 });
 phase('live-conversion-and-callback-policy',()=>{
  const target=document.getElementById('eventTarget'),before=ec.get('click'),conversion=[];
  const convert={ [Symbol.toPrimitive](hint){conversion.push(hint);target.click();return'click';} };
  const getter=call(()=>ec.get(convert)),has=call(()=>ec.has(convert));
  const cases=[['Symbol()',()=>ec.get(Symbol())],['object-returning-symbol',()=>ec.get({[Symbol.toPrimitive](){return Symbol('click')}})],['conversion-throw',()=>ec.get({toString(){throw new RangeError('actual conversion')}})],['get-missing',()=>ec.get()],['has-missing',()=>ec.has()],['forEach-missing',()=>ec.forEach()],['forEach-object',()=>ec.forEach({})]];
  const it=ec.values(),first=it.next();target.click();const second=it.next();let calls=0,identity=true,receiver=true;const receiverValue={};const foreach=call(()=>ec.forEach(function(value,key,object){'use strict';calls++;identity&&=object===ec;receiver&&=this===receiverValue;if(calls===1)target.click();if(calls===2)throw new Error('actual second callback');},receiverValue));
  return{before,getter,has,conversion,cases:cases.map(([name,fn])=>({name,...call(fn)})),first,second,foreach,calls,identity,receiver,after:ec.get('click')};
 });
 phase('borrowed-maplike-prototype-and-constructor',()=>{
  const child=document.querySelector('iframe').contentWindow,other=child.performance.eventCounts,output=[];
  for(const name of ['get','has'])for(const [label,value]of[['real',ec],['other-realm',other],['inherited',Object.create(ec)],['prototype',p],['proxy',new Proxy(ec,{})]])output.push({name,label,...call(()=>p[name].call(value,'click'))});
  const getter=Object.getOwnPropertyDescriptor(Performance.prototype,'eventCounts').get;
  return{output,noNew:call(()=>EventCounts()),withNew:call(()=>new EventCounts()),constructorKeys:keys(EventCounts),prototypeDescriptor:descriptor(Object.getOwnPropertyDescriptor(EventCounts,'prototype')),performanceDescriptor:descriptor(Object.getOwnPropertyDescriptor(Performance.prototype,'eventCounts')),borrowedPerformance:call(()=>getter.call(child.performance)),fakePerformance:call(()=>getter.call({})),sizeFake:call(()=>Object.getOwnPropertyDescriptor(p,'size').get.call({}))};
 });
 return{rows,boundary:'Native-first remaining EventCounts clone, iterator, callback, conversion, borrowed-realm and descriptor controls; no candidate result inference.'};
})()
