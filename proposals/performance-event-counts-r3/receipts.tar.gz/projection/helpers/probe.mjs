import http from 'node:http';
import {once} from 'node:events';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {startReference} from '../candidate/scripts/reference-server.mjs';
import {connect} from '../candidate/test/cdp-client.js';
const [profile,mode]=process.argv.slice(2);
if(!['native','candidate','baseline'].includes(profile)||!['heldouts','counter','identity','baseline-proxy'].includes(mode))throw Error('Use native/candidate heldouts/counter');
const binary=profile==='native'?'/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux':new URL('../candidate-launcher',import.meta.url).pathname;
const out=new URL('../runs/'+(process.env.PROBE_EPOCH??'initial')+'/',import.meta.url);await mkdir(out,{recursive:true});
const expression=await readFile(new URL(mode==='heldouts'?'native-heldouts.js':mode==='identity'?'identity.js':mode==='baseline-proxy'?'baseline-proxy.js':'event-counts-control.js',import.meta.url),'utf8');
const hash=value=>createHash('sha256').update(value).digest('hex');
const record={profile,mode,node:process.version,nodeExecutable:process.execPath,binary,binarySHA256:hash(await readFile(binary)),source:expression,sourceSHA256:hash(expression),args:['--ws-max-concurrent','50','--load-resources','iframe'],rpcMs:3000,loadMs:2000,evalMs:2000,wire:[],stages:[],status:'started'};
let browser,client,server,closed=false,writes=Promise.resolve();
const checkpoint=()=>{const bytes=JSON.stringify(record,null,2)+'\n';writes=writes.then(()=>writeFile(new URL(profile+'-'+mode+'.json',out),bytes));return writes;};
await writeFile(new URL(profile+'-'+mode+'.json',out),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
try{
 server=http.createServer((req,res)=>{
  const body=Buffer.from(mode==='identity'?(req.url==='/child'?'<!doctype html><body>actual child':'<!doctype html><body><button id=target>actual</button><iframe src="/child"></iframe>'):'<!doctype html><meta charset=utf-8><body><button type=button id=eventTarget style="position:absolute;left:10px;top:10px;width:120px;height:40px">actual input</button><input id=actualFile type=file><iframe style="position:absolute;top:150px"></iframe>');
  const row={url:req.url,method:req.method,headers:req.headers,requestHTTPVersion:req.httpVersion,bodyLength:body.length,bodySHA256:hash(body)};record.wire.push(row);
  res.once('finish',()=>{row.actualSerializedHeaders=res._header;void checkpoint();});res.writeHead(200,{'content-type':'text/html;charset=utf-8','content-length':String(body.length)});res.end(body);
 });server.listen(0,'127.0.0.1');await once(server,'listening');record.origin='http://127.0.0.1:'+server.address().port;await checkpoint();
 browser=await startReference(binary,{args:record.args});record.pid=browser.process.pid;await checkpoint();
 client=await connect(browser.endpoint,{timeout:3000});const{targetId}=await client.send('Target.createTarget',{url:'about:blank'}),{sessionId}=await client.send('Target.attachToTarget',{targetId,flatten:true}),send=(method,params)=>client.send(method,params,sessionId);
 await send('Page.enable');await send('Runtime.enable');const before=client.events.length;
 record.navigation=await send('Page.navigate',{url:record.origin+'/main'});await checkpoint();
 const deadline=Date.now()+2000;while(!client.events.slice(before).some(e=>e.sessionId===sessionId&&e.method==='Page.loadEventFired')){if(Date.now()>=deadline)throw Error('Actual load not observed within2000ms');await new Promise(resolve=>setTimeout(resolve,10));}
 record.observations=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true,timeout:2000});await checkpoint();
 if(record.observations.exceptionDetails)throw Error('Actual Runtime exception in '+mode);
 if(mode==='counter'){
  record.trusted={before:await send('Runtime.evaluate',{expression:"({count:performance.eventCounts?.get('click'),rect:(()=>{const r=document.getElementById('eventTarget').getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2,width:r.width,height:r.height}})()})",returnByValue:true}),commands:[]};
  const point=record.trusted.before.result?.value?.rect;record.trusted.status='not-attempted-no-positive-box';
  if(point?.width>0&&point?.height>0){record.trusted.status='real-CDP-input-attempted';for(const type of ['mouseMoved','mousePressed','mouseReleased'])record.trusted.commands.push({type,result:await send('Input.dispatchMouseEvent',{type,x:point.x,y:point.y,button:type==='mouseMoved'?'none':'left',clickCount:1})});}
  record.trusted.after=await send('Runtime.evaluate',{expression:"({count:performance.eventCounts?.get('click'),events:__actualTrustedEvents})",returnByValue:true});await checkpoint();
  record.fileInput={before:await send('Runtime.evaluate',{expression:"(()=>{globalThis.__actualFileDispatch=[];const input=document.getElementById('actualFile');for(const type of ['input','change'])input.addEventListener(type,e=>__actualFileDispatch.push({type:e.type,trusted:e.isTrusted,count:performance.eventCounts?.get('input'),change:performance.eventCounts?.get('change')}));return{count:performance.eventCounts?.get('input')}})()",returnByValue:true})};
  const{root}=await send('DOM.getDocument');const{nodeId}=await send('DOM.querySelector',{nodeId:root.nodeId,selector:'#actualFile'});record.fileInput.nodeId=nodeId;
  const file=new URL('owned-input.txt',import.meta.url).pathname;record.fileInput.source={path:file,sha256:hash(await readFile(file))};record.fileInput.result=await send('DOM.setFileInputFiles',{nodeId,files:[file]});
  record.fileInput.after=await send('Runtime.evaluate',{expression:"({count:performance.eventCounts?.get('input'),events:__actualFileDispatch,files:[...document.getElementById('actualFile').files].map(f=>({name:f.name,size:f.size,type:f.type}))})",returnByValue:true});
 }
 record.status='observed';await checkpoint();
}catch(error){record.status='driver-setup-or-control-failure';record.error={name:error.name,message:error.message};process.exitCode=1;}
finally{
 await client?.close();await browser?.close();record.events=client?.events;record.stderr=browser?.stderr;record.stderrTruncated=browser?.stderrTruncated;record.exitCode=browser?.process.exitCode;
 if(server?.listening){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}closed=true;record.cleanup={clientClosed:true,browserExitObserved:!browser||browser.process.exitCode!==null||browser.process.signalCode!==null,ownedHTTPServerClosed:closed};await checkpoint();
}
console.log(JSON.stringify({profile,mode,status:record.status,pid:record.pid}));
