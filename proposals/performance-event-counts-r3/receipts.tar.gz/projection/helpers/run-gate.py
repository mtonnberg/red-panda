#!/usr/bin/env python3
"""Finite SDK and Root-projection phases; execute only on Parent quiet grant."""
from pathlib import Path
import os,json,hashlib,time,subprocess,signal,sys,re
START=time.monotonic();ROOT=Path(__file__).resolve().parents[1];CANDIDATE=ROOT/'candidate';PHASE=os.environ.get('GATE_PHASE','remaining-sdk')
if PHASE not in ['remaining-sdk','root-focused','root-applied']:raise SystemExit('Unknown phase')
SDKS=[('24.22.1',Path('/workspace/shared/rea-tools/node_modules/node/bin/node')),('24.19.0',Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')),('26.13.0',Path('/workspace/shared/node26/node_modules/node/bin/node'))]
SELECTED=SDKS[1:]if PHASE=='remaining-sdk'else SDKS[:1]
ADMIN=90 if PHASE=='remaining-sdk'else 150;CLEANUP=2;EPOCH=os.environ.get('PROBE_EPOCH','initial-'+PHASE);OUT=ROOT/'runs'/EPOCH;OUT.mkdir(parents=True,exist_ok=False)
TARGET=Path('/workspace/red-panda')if PHASE=='root-applied'else CANDIDATE
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();paths=[]
for directory in ['src','native','bin','scripts','test','oracle','docs']:paths.extend(p for p in (CANDIDATE/directory).rglob('*')if p.is_file())
paths.extend([CANDIDATE/'package.json',CANDIDATE/'package-lock.json',ROOT/'candidate-launcher',ROOT/'manifest.json',Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux'),*[node for _,node in SDKS]])
paths.extend(p for p in (ROOT/'helpers').glob('*')if p.is_file());
for directory in ['oracle','docs']:
 paths.extend(Path('/workspace/red-panda')/p.relative_to(CANDIDATE)for p in (CANDIDATE/directory).rglob('*')if p.is_file())
paths.extend(p for p in (ROOT/'evidence').glob('*')if p.is_file())
for row in json.loads((ROOT/'evidence/source-before.json').read_text())['files']:paths.append(Path('/workspace/red-panda')/row['path'])
for package in (CANDIDATE/'node_modules').iterdir():
 if package.is_dir()and not package.name.startswith('.'):paths.extend(p for p in package.resolve().rglob('*')if p.is_file())
paths=list(dict.fromkeys(p.resolve()for p in paths if p.is_file()));guard=lambda:{str(p):sha(p)for p in paths}
record={'phase':PHASE,'executionTarget':str(TARGET),'scope':'Owned current5adb Root projection, actual same-source remaining SDK conformance','adminSeconds':ADMIN,'cleanupSeconds':CLEANUP,'before':guard(),'commands':[],'status':'started'}
environment=os.environ.copy()
for key in ['NO_PROXY','no_proxy']:
 values=[v for v in environment.get(key,'').split(',')if v];environment[key]=','.join(dict.fromkeys(values+['127.0.0.1','localhost']))
record['ownedLoopbackBypass']={key:environment[key]for key in ['NO_PROXY','no_proxy']}
new_tests=['test/performance-event-counts.test.js','test/performance-event-counts-cross-realm.test.js','test/performance-file-input-dispatch.test.js']
focus_tests=new_tests+['test/input.test.js','test/frame-input.test.js','test/pointer-event-parity.test.js','test/pointer-public-heldouts.test.js','test/file-input-dispatch-recovery.test.js','test/performance.test.js','test/window-clone-transfers.test.js','test/errors.test.js','test/domimplementation-readiness.test.js','test/lifecycle-minimal.test.js','test/private-event-utility-backing.test.js','test/event-backend-initialization.test.js']
def save():(OUT/'controller.json').write_text(json.dumps(record,indent=2)+'\n')
def group_signal(pid,sig):
 try:os.killpg(pid,sig)
 except ProcessLookupError:pass
def run(label,args,cwd,expected_tap=None):
 remaining=ADMIN-(time.monotonic()-START)
 if remaining<=CLEANUP:raise TimeoutError('Administrative phase cap exhausted')
 row={'label':label,'command':[str(x)for x in args],'startedMonotonic':time.monotonic()};record['commands'].append(row);save();child=None
 try:
  with(OUT/(label+'.stdout')).open('wb')as stdout,(OUT/(label+'.stderr')).open('wb')as stderr:
   child=subprocess.Popen(row['command'],cwd=cwd,env=environment,stdout=stdout,stderr=stderr,start_new_session=True);row['pid']=child.pid;save()
   try:row['exitCode']=child.wait(timeout=remaining-CLEANUP)
   except subprocess.TimeoutExpired:
    row['administrativeWatchdog']=True;group_signal(child.pid,signal.SIGTERM)
    try:child.wait(timeout=CLEANUP)
    except subprocess.TimeoutExpired:group_signal(child.pid,signal.SIGKILL);child.wait()
    raise
  if row['exitCode']!=0:raise RuntimeError(label+' failed; later phases UNRUN')
  if expected_tap is not None:
   lines=(OUT/(label+'.stdout')).read_text();matches=re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) ([0-9]+)$',lines,re.M)
   summary={key:int(value)for key,value in matches};row['actualTAPSummary']=summary;row['expectedTAPSummary']=expected_tap
   if len(matches)!=7 or summary!=expected_tap:raise RuntimeError(label+' actual TAP summary mismatch')
 finally:
  if child is not None and child.poll()is None:group_signal(child.pid,signal.SIGKILL);child.wait()
  row['closed']=child is None or child.poll()is not None;row['durationSec']=time.monotonic()-row['startedMonotonic'];save();print(json.dumps(row),flush=True)
def differences(left,right,path='$'):
 if type(left)!=type(right):return[{'path':path,'native':left,'candidate':right}]
 if isinstance(left,dict):
  result=[]
  for key in sorted(left.keys()|right.keys()):
   if key not in left or key not in right:result.append({'path':path+'.'+key,'native':left.get(key),'candidate':right.get(key),'missing':True})
   else:result.extend(differences(left[key],right[key],path+'.'+key))
  return result
 if isinstance(left,list):
  if len(left)!=len(right):return[{'path':path,'native':left,'candidate':right}]
  return[d for i,(a,b)in enumerate(zip(left,right))for d in differences(a,b,path+'['+str(i)+']')]
 return[]if left==right else[{'path':path,'native':left,'candidate':right}]
def tap(passed,skipped=0):return {'tests':passed+skipped,'suites':0,'pass':passed,'fail':0,'cancelled':0,'skipped':skipped,'todo':0}
def verify_actual_root():
 before=json.loads((ROOT/'evidence/source-before.json').read_text())['files'];changes=json.loads((ROOT/'evidence/projection-leaves.json').read_text())['leaves'];allow={row['path']:row for row in changes};actual=Path('/workspace/red-panda');before_paths={row['path']for row in before}
 expected_paths=before_paths|set(allow)
 actual_paths={str(p.relative_to(actual))for directory in ['src','native','bin','scripts','test']for p in (actual/directory).rglob('*')if p.is_file()}|{'package.json','package-lock.json'}
 if actual_paths!=expected_paths:raise RuntimeError('Actual Root source pathset differs outside exact8 allowlist')
 unchanged=0
 for row in before:
  expected=allow[row['path']]['afterSHA256']if row['path']in allow else row['sha256']
  if sha(actual/row['path'])!=expected:raise RuntimeError('Actual Root pre-run byte differs: '+row['path'])
  if row['path']not in allow:unchanged+=1
 for path,row in allow.items():
  if sha(actual/path)!=row['afterSHA256']:raise RuntimeError('Actual Root exact8-leaf byte differs: '+path)
 native=[p for p in (actual/'native/build/linux-x64').glob('*/*')if p.is_file()]
 if len(native)!=18:raise RuntimeError('Actual Root native artifact inventory differs')
 for p in native:
  if sha(p)!=sha(CANDIDATE/p.relative_to(actual)):raise RuntimeError('Actual Root native file differs: '+str(p))
 for directory in ['oracle','docs']:
  for p in (CANDIDATE/directory).rglob('*'):
   if p.is_file()and sha(actual/p.relative_to(CANDIDATE))!=sha(p):raise RuntimeError('Actual Root consumed reference differs: '+str(p.relative_to(CANDIDATE)))
 record['actualRootProjectionVerified']={'baseFileCount':len(before),'exactAllowlist':list(allow),'unchangedOriginalCount':unchanged,'actualDeclaredSourceCount':len(actual_paths),'nativeArtifactCount':18}
 record['beforeActualAddedLeaves']={str(actual/path):sha(actual/path)for path in allow};save()
try:
 if PHASE=='root-applied':verify_actual_root()
 for version,node in SELECTED:
  per_sdk=OUT/version;per_sdk.mkdir();sdk=TARGET/'native/build/linux-x64'/('node-'+version)
  environment.update(EVENT_COUNTS_NODE_BINARY=str(node),RED_PANDA_COLLECTIONS_ADDON=str(sdk/'collections.node'),RED_PANDA_RUNTIME_ADDON=str(sdk/'runtime.node'),EVENT_COUNTS_CREATION_PROOF=str(per_sdk/'actual-creation78.json'),PROBE_EPOCH=EPOCH+'/'+version)
  run(version+'-syntax-creation',[node,'--check','test/performance-event-counts.test.js'],TARGET)
  if PHASE=='remaining-sdk':
   run(version+'-new9',[node,'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*new_tests],TARGET,tap(9))
   baseline=json.loads((ROOT/'evidence/baseline-baseline-proxy.json').read_text())['observations']['result']['value']['rows'][0]['value']
   for mode in ['identity','heldouts']:
    run(version+'-actual-'+mode,[node,'helpers/probe.mjs','candidate',mode],ROOT);raw=json.loads((per_sdk/('candidate-'+mode+'.json')).read_text());reference=json.loads((ROOT/'evidence'/('native-'+mode+'.json')).read_text())
    if raw['node']!='v'+version or raw['nodeExecutable']!=str(node.resolve()):raise RuntimeError('Actual SDK process producer path/version mismatch')
    if raw['sourceSHA256']!=reference['sourceSHA256']or raw['args']!=reference['args']:raise RuntimeError('Native/current authored source or declared flags differ')
    if raw['status']!='observed'or raw['exitCode']!=0 or not raw['cleanup']['browserExitObserved']:raise RuntimeError('Actual candidate profile not observed/closed')
    left=reference['observations']['result']['value'];right=raw['observations']['result']['value'];delta=differences(left,right)
    known=[{'path':'$.rows[0].value[5].result.error.message','native':'#<EventCounts> could not be cloned.','candidate':baseline['result']['error']['message']}]
    comparison={'equal':not delta,'differences':delta,'native':left,'candidate':right,'retainedActualNativeSHA256':sha(ROOT/'evidence'/('native-'+mode+'.json')),'knownExistingProxyTextNegative':mode=='heldouts'and delta==known,'scope':'Full raw comparison remains unequal for the explicit unchanged framework Proxy message; no field filtering'}
    (per_sdk/('full-'+mode+'-comparison.json')).write_text(json.dumps(comparison,indent=2)+'\n')
    if delta and not(mode=='heldouts'and delta==known):raise RuntimeError(version+' '+mode+' unexpected complete-value contrary')
  else:
   run(version+'-focused110',[node,'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*focus_tests],TARGET,tap(110))
   file_pattern='real disk assignment yields exact bytes|a later disk failure preserves actual old File identity|selector precedence and strong private real-Node authority|real stateful iterators reject cloning'
   run(version+'-actual-file4',[node,'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1','--test-name-pattern='+file_pattern,'test/file-input-capability.test.js'],TARGET,tap(4,11))
   codec_pattern='platform clone errors remain atomic|real MessagePort transport preserves'
   run(version+'-actual-codec2',[node,'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1','--test-name-pattern='+codec_pattern,'test/platform-codec.test.js'],TARGET,tap(2,9))
  proof=json.loads((per_sdk/'actual-creation78.json').read_text());rows=proof['rows'];record.setdefault('actualCreationProofs',[]).append({'node':version,'path':str(per_sdk/'actual-creation78.json'),'rowCount':len(rows),'sha256':sha(per_sdk/'actual-creation78.json')})
  if proof['node']!='v'+version or len(rows)!=78 or len({r['label']for r in rows})!=78 or any(not(r['first']and r['after']and r['firstGlobal']and r['afterGlobal']and not r['host'])for r in rows):raise RuntimeError('Actual78-row Context proof contrary')
 record['status']='observed-positive-bounded-'+PHASE+'; explicit-existing-Proxy-message-negative-retained; not-full-source-or-repository-acceptance'
except Exception as error:record['status']='stopped-first-contrary';record['error']={'name':type(error).__name__,'message':str(error)}
finally:
 if PHASE=='root-applied'and 'beforeActualAddedLeaves'in record:record['afterActualAddedLeaves']={p:sha(Path(p))for p in record['beforeActualAddedLeaves']};record['actualAddedLeavesStable']=record['beforeActualAddedLeaves']==record['afterActualAddedLeaves']
 record['after']=guard();record['stable']=record['before']==record['after'];record['durationSec']=time.monotonic()-START;record['browserPIDReadback']=[]
 for f in OUT.rglob('candidate-*.json'):
  raw=json.loads(f.read_text());pid=raw.get('pid')
  if pid:record['browserPIDReadback'].append({'path':str(f),'pid':pid,'procEntryPresent':Path('/proc',str(pid)).exists(),'exitCode':raw.get('exitCode'),'cleanup':raw.get('cleanup')})
 save();print(json.dumps({'phase':PHASE,'status':record['status'],'stable':record['stable'],'durationSec':record['durationSec']}),flush=True)
if not record['stable']or record.get('actualAddedLeavesStable',True)is not True or record['status']=='stopped-first-contrary':sys.exit(1)
