(()=>{
 const rows=[],call=fn=>{try{return{value:fn()}}catch(e){return{error:{name:e.name,message:e.message,mainTypeError:e instanceof TypeError,childTypeError:e instanceof child.TypeError}}}},phase=(name,fn)=>rows.push({name,...call(fn)});
 const child=document.querySelector('iframe').contentWindow,mainEC=performance.eventCounts,childEC=child.performance.eventCounts;
 document.getElementById('target').click();child.document.body.dispatchEvent(new Event('click'));child.document.body.dispatchEvent(new Event('click'));
 phase('borrowed-performance-return-identity-and-error-realm',()=>{
  const mainGetter=Object.getOwnPropertyDescriptor(Performance.prototype,'eventCounts').get,childGetter=Object.getOwnPropertyDescriptor(child.Performance.prototype,'eventCounts').get;
  const describe=(getter,receiver)=>call(()=>{const value=getter.call(receiver);return{isMainCounter:value===mainEC,isChildCounter:value===childEC,click:EventCounts.prototype.get.call(value,'click')};});
  return{mainCount:mainEC.get('click'),childCount:childEC.get('click'),mainGetterMain:describe(mainGetter,performance),mainGetterChild:describe(mainGetter,child.performance),childGetterMain:describe(childGetter,performance),childGetterChild:describe(childGetter,child.performance),mainGetterFake:call(()=>mainGetter.call({})),childGetterFake:call(()=>childGetter.call({})),childMethodFake:call(()=>child.EventCounts.prototype.get.call({},'click'))};
 });
 phase('iterator-constructor-and-cross-kind-real-brands',()=>{
  const names=['keys','values','entries'],its=names.map(name=>mainEC[name]()),prototypes=its.map(it=>Object.getPrototypeOf(it));
  const constructors=prototypes.map((p,index)=>{const d=Object.getOwnPropertyDescriptor(p,'constructor'),c=d?.value,prototype=c&&Object.getOwnPropertyDescriptor(c,'prototype');return{kind:names[index],descriptor:d?{enumerable:d.enumerable,configurable:d.configurable,writable:d.writable,valueType:typeof c}:null,name:c?.name,length:c?.length,constructorPrototypeIsIteratorPrototype:c?.prototype===p,constructorPrototypeDescriptor:prototype?{enumerable:prototype.enumerable,configurable:prototype.configurable,writable:prototype.writable}:null,call:call(()=>c()),new:call(()=>new c())};});
  const matrix=[];for(let i=0;i<3;i++)for(let j=0;j<3;j++)matrix.push({callee:names[i],receiver:names[j],...call(()=>prototypes[i].next.call(mainEC[names[j]]()))});
  const cross=call(()=>{const value=prototypes[2].next.call(childEC.entries());return{...value,pairMainArray:Object.getPrototypeOf(value.value)===Array.prototype,pairChildArray:Object.getPrototypeOf(value.value)===child.Array.prototype};});
  return{samePrototype:{keysValues:prototypes[0]===prototypes[1],keysEntries:prototypes[0]===prototypes[2],valuesEntries:prototypes[1]===prototypes[2]},constructors,matrix,cross};
 });
 phase('foreach-reentrant-count-value-discriminator',()=>{
  const before=mainEC.get('click'),values=[];mainEC.forEach((value,key,object)=>{values.push({value,key,same:object===mainEC});if(key==='auxclick')document.getElementById('target').click();});
  return{before,after:mainEC.get('click'),values,childAfter:childEC.get('click')};
 });
 return{rows,boundary:'Native-only exact returned receiver identity, actual callback value, iterator constructor/type and foreign-brand evidence. No candidate owner policy chosen.'};
})()
