from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time

root=Path('/workspace/red-panda');packet=Path('/workspace/shared/performance-event-counts-root5adb-projection-r1');work=Path(__file__).resolve().parent
original=packet/'runs/initial-root-applied/controller.json';d=json.loads(original.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert d['status']=='stopped-first-contrary'and d['error']['message']=='24.22.1-actual-file4 actual TAP summary mismatch'
assert d['stable']and d['actualAddedLeavesStable']
assert len(d['commands'])==3 and all(c['exitCode']==0 and c['closed']for c in d['commands'])
assert [c['actualTAPSummary']for c in d['commands']if'actualTAPSummary'in c]==[{'tests':110,'suites':0,'pass':110,'fail':0,'cancelled':0,'skipped':0,'todo':0},{'tests':4,'suites':0,'pass':4,'fail':0,'cancelled':0,'skipped':0,'todo':0}]
proof=packet/'runs/initial-root-applied/24.22.1/actual-creation78.json';creation=json.loads(proof.read_text());assert creation['node']=='v24.22.1'and len(creation['rows'])==78 and len({r['label']for r in creation['rows']})==78
assert all(r['first']and r['after']and r['firstGlobal']and r['afterGlobal']and not r['host']for r in creation['rows'])
expected={**d['after'],**d['afterActualAddedLeaves'],str(original):sha(original),str(proof):sha(proof)}
snapshot=lambda:{name:sha(Path(name))for name in expected};assert snapshot()==expected
node='/workspace/shared/rea-tools/node_modules/node/bin/node';command=[node,'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1','--test-name-pattern=platform clone errors remain atomic|real MessagePort transport preserves','test/platform-codec.test.js']
env=os.environ.copy();env['RED_PANDA_COLLECTIONS_ADDON']=str(root/'native/build/linux-x64/node-24.22.1/collections.node');env['RED_PANDA_RUNTIME_ADDON']=str(root/'native/build/linux-x64/node-24.22.1/runtime.node')
started=time.monotonic();expired=False
with(work/'codec2.stdout').open('x')as stdout,(work/'codec2.stderr').open('x')as stderr:
    child=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    try:child.wait(timeout=30)
    except subprocess.TimeoutExpired:
        expired=True;os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=2)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
text=(work/'codec2.stdout').read_text();matches=re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M);counts={k:int(v)for k,v in matches};after=snapshot()
record={'scope':'Separate reporting correction plus previously UNRUN codec2. Original Root controller failure retained immutable. Node test-name-pattern omits unselected cases rather than emitting skipped entries. No110/file4 rerun and no test/assertion/deadline changes.','originalController':str(original),'originalSHA256':sha(original),'originalAdministrativeFailureRetained':True,'alreadyObservedPasses':[110,4],'actualCreationRows':78,'actualCreationSHA256':sha(proof),'command':command,'exit':child.returncode,'expired':expired,'seconds':time.monotonic()-started,'capSeconds':30,'cleanupSeconds':2,'actualTAPSummary':counts,'unchanged':expected==after,'changed':[n for n in expected if expected[n]!=after[n]],'inputs':len(expected)}
record['complete']=not expired and child.returncode==0 and len(matches)==7 and counts=={'tests':2,'suites':0,'pass':2,'fail':0,'cancelled':0,'skipped':0,'todo':0}and record['unchanged']
with(work/'accounting-supplement.json').open('x')as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:record[k]for k in ['complete','exit','expired','seconds','actualTAPSummary','actualCreationRows','inputs','unchanged']}))
raise SystemExit(0 if record['complete']else 1)
