from pathlib import Path
import hashlib,json,subprocess

root=Path('/workspace/red-panda'); packet=Path('/workspace/shared/performance-event-counts-root5adb-projection-r1');out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()=='5adb9b3c4c8f30a9ec89169634cb8c8d6411309e'
assert sha(packet/'manifest.json')=='4f4969297f4e1197e200fd5d630446ea6f08450b16be37e3a9cd37a16e3ca356'
assert sha(packet/'integration.patch')=='f09e39d2b3fb169a2e045f8913d5d91809691ece962b261268a30c8d403ada1c'
receipt=json.loads((packet/'runs/initial-remaining-sdk/controller.json').read_text())
assert receipt['stable'] and receipt['status'].startswith('observed-positive-bounded-remaining-sdk')
assert len(receipt['actualCreationProofs'])==2 and all(row['rowCount']==78 for row in receipt['actualCreationProofs'])
before=json.loads((packet/'evidence/source-before.json').read_text())['files'];leaves=json.loads((packet/'evidence/projection-leaves.json').read_text())['leaves'];allow={row['path']:row for row in leaves};assert len(allow)==8
def paths():return{str(p.relative_to(root))for directory in ['src','native','bin','scripts','test']for p in(root/directory).rglob('*')if p.is_file()}|{'package.json','package-lock.json'}
assert paths()=={row['path']for row in before}
for row in before:assert sha(root/row['path'])==row['sha256'],row['path']
for row in leaves:
    assert sha(packet/'candidate'/row['path'])==row['afterSHA256']
    assert row['beforeSHA256'] is None or sha(root/row['path'])==row['beforeSHA256']
subprocess.run(['git','apply','--check',str(packet/'integration.patch')],cwd=root,check=True)
subprocess.run(['git','apply',str(packet/'integration.patch')],cwd=root,check=True)
assert paths()=={row['path']for row in before}|set(allow)
unchanged=0
for row in before:
    expected=allow[row['path']]['afterSHA256']if row['path']in allow else row['sha256']
    assert sha(root/row['path'])==expected,row['path']
    if row['path']not in allow:unchanged+=1
for row in leaves:assert sha(root/row['path'])==row['afterSHA256']
record={'baseCommit':'5adb9b3c4c8f30a9ec89169634cb8c8d6411309e','patchSHA256':sha(packet/'integration.patch'),'baseFiles':len(before),'actualDeclaredFiles':len(paths()),'unchangedOriginalFiles':unchanged,'leaves':leaves,'runtimeChecks':'UNRUN; separate immutable root-applied controller required before commit'}
with(out/'application.json').open('x')as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'appliedLeaves':len(leaves),'unchangedOriginalFiles':unchanged,'actualDeclaredFiles':len(paths()),'rootGate':'UNRUN'}))
