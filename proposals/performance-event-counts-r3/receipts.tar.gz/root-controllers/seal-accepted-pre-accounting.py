from pathlib import Path
import gzip,hashlib,io,json,tarfile

root=Path('/workspace/red-panda');packet=Path('/workspace/shared/performance-event-counts-root5adb-projection-r1');work=Path(__file__).resolve().parent;gate=packet/'runs/initial-root-applied'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
actual=json.loads((gate/'controller.json').read_text());assert actual['stable']and actual['actualAddedLeavesStable']and actual['status'].startswith('observed-positive-bounded-root-applied')
assert actual['executionTarget']==str(root)
assert [r['actualTAPSummary']['pass']for r in actual['commands']if'actualTAPSummary'in r]==[110,4,2]
assert [r['actualTAPSummary']['skipped']for r in actual['commands']if'actualTAPSummary'in r]==[0,11,9]
assert all(r['exitCode']==0 and r['closed']for r in actual['commands'])
assert actual['actualRootProjectionVerified']['nativeArtifactCount']==18
assert len(actual['actualCreationProofs'])==1 and actual['actualCreationProofs'][0]['rowCount']==78
leaves=json.loads((packet/'evidence/projection-leaves.json').read_text())['leaves']
for row in leaves:assert sha(root/row['path'])==row['afterSHA256']
sdk=json.loads((packet/'runs/initial-remaining-sdk/controller.json').read_text());assert sdk['stable']and sdk['status'].startswith('observed-positive-bounded-remaining-sdk')
dst=root/'proposals/performance-event-counts-r3';dst.mkdir(exist_ok=False)
files={}
for name,directory in [('first-results',Path('/workspace/shared/performance-event-counts-r3-first-results')),('remaining-sdk',Path('/workspace/shared/performance-event-counts-remaining-sdk-results-r1')),('root',gate)]:
    for p in sorted(directory.rglob('*')):
        if p.is_file():files[name+'/'+str(p.relative_to(directory))]=p
for name in ['README.md','manifest.json','integration.patch','runtime.patch','tests.patch','evidence/source-before.json','evidence/projection-leaves.json']:
    files['projection/'+name]=packet/name
for p in sorted((packet/'helpers').iterdir()):
    if p.is_file():files['projection/helpers/'+p.name]=p
for row in leaves:files['accepted/'+row['path']]=root/row['path']
files['root-application.json']=work/'application.json'
for name in ['apply-reviewed.py','seal-accepted.py']:files['root-controllers/'+name]=work/name
manifest={'baseCommit':'5adb9b3c4c8f30a9ec89169634cb8c8d6411309e','scope':'Canonical EventCounts dispatch/VM/clone integration. Strict original Native4 comparison retains one baseline-proved generic Proxy error-message difference. No whole fixture/full-suite/performance equivalence claim.','rootExecutedPass':116,'rootDeliberatelyUnselected':20,'rootSeconds':actual['durationSec'],'rootStableInputs':len(actual['before']),'rootCreationRows':78,'remainingSDKFeaturePassEach':9,'remainingSDKCreationRowsEach':78,'remainingSDKSeconds':sdk['durationSec'],'leaves':leaves,'files':[]}
archive=dst/'receipts.tar.gz'
with archive.open('wb')as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
        with tarfile.open(fileobj=gz,mode='w')as tar:
            for name,p in sorted(files.items()):
                b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b));manifest['files'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(archive,'r:gz')as tar:
    assert tar.getnames()==sorted(files)
    for name,p in files.items():assert tar.extractfile(name).read()==p.read_bytes()
manifest['archive']={'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'allFilesReadBackByteExact':True}
(dst/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
text=f'''Canonical EventCounts now counts actual dispatch once before listeners, with Window-owned state for nested dispatch, redispatch, trusted pointer input and real file-input events. Genuine VM fronts and typed live iterators keep private brands and callee-realm results; forEach snapshots counts before calling callbacks and continues after callback failures.

Actual Root:110 full focused tests plus4 selected real-file tests and2 selected clone/transport tests pass, with20 explicitly unselected cases in those two selections. All78 physical creation-context rows pass before/after prototype removal;18 native artifacts and{len(actual['before'])} monitored inputs remain unchanged. Runtime:{actual['durationSec']:.3f}s.

Node24.19 and26.13 each pass9 feature tests and78 physical creation rows. Full Native3 values match on each; full Native4 retains one existing generic Proxy clone-message difference, proved unchanged in the baseline and retained verbatim. No fields are removed to claim equality. Initial Node24.22 firstgate/raw negatives, trusted input/disk comparisons, controllers and frozen patches are preserved in the archive.

This is an eight-leaf change over5adb9b3. It does not establish whole-source, full-suite, broader Performance Timing, WPT or performance equivalence. The latest complete2043/129/13 suite remains the97bb0ac graph. Keep Red Panda branding and every original upstream assertion/budget unchanged. The manifest byte-verifies every archived source/receipt; original paths remain retained.
'''
(dst/'README.md').write_text(text)
readme=root/'README.md';s=readme.read_text();old='The current checkpoint passes 2,043 JavaScript tests, 129 PureScript Puppeteer';new='The last complete checkpoint at `97bb0ac` passed 2,043 JavaScript tests, 129 PureScript Puppeteer';assert old in s;s=s.replace(old,new,1)
marker='File uploads use real disk bytes and timestamps, atomic path validation and stable\n';assert marker in s
s=s.replace(marker,'`performance.eventCounts` counts real dispatch before listeners, including trusted\ninput and file uploads. Its VM fronts, live iterators and snapshot `forEach` pass\n116 selected Root checks; nine feature checks pass on each remaining Node SDK.\n[Evidence](proposals/performance-event-counts-r3/README.md) retains the existing\ngeneric Proxy clone-message difference and the exact validation boundaries.\n\n'+marker,1);readme.write_text(s)
compat=root/'docs/COMPATIBILITY.md'
with compat.open('a')as f:f.write('\n\n### Canonical EventCounts dispatch and realms\n\n'+text)
print(json.dumps({'archiveFiles':len(files),'archiveBytes':archive.stat().st_size,'RootExecutedPass':116,'RootSeconds':actual['durationSec'],'RootStableInputs':len(actual['before'])}))
