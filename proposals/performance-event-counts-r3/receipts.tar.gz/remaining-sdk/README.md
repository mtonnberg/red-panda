# Actual remaining SDK EventCounts receipt

Root executed frozen remaining-sdk gate during quiet13. Actual duration16.88167862201226s, all guards stable, all8 commands exit0/closed. Source/projection/controller remain immutable. No child-agent runtime or Root edits were performed.

Node24.19.0 and26.13.0 each passed strict explicit TAP9tests/9pass/0suites/0fail/0cancel/0skip/0todo plus one actual JS syntax check. Total18 actual passing test cases on the current5adb owned projection. This is not a claim of running the broader116-case Root suite or original source fixtures.

Each SDK's actual creation proof has78 UNIQUE rows (156 total), every first/after-null actual Context and creation Global check true, every Host-realm check false. The expanded existing test covers main/frame EC fronts/constructors/prototypes/all methods and getters, actual callee-VM errors, distinct typed iterator constructors/prototypes/next/self methods/fronts/result records/initial and second pairs, and foreign next result/pair creation in the callee VM. These are direct public V8 O(1) context observations, not a prototype/tag hint or heap enumeration.

Both actual SDK processes match FULL Native3 authored receiver/typed-iterator/snapshot/error values. Each FULL Native4 authored comparison retains exactly the same single known existing generic Proxy clone error-message difference; the complete raw values and precise difference remain, no filtered equality claim. There were no additional differences. Original real Node versions/executable paths, fixed reference source/flag identities and Native binary inputs were verified by the controller.

Owned browserPIDs773046,773078,773178,773219 all exit0, /proc entries absent, client/HTTP closed. Full before/after sources/dependencies/native artifacts/Root guards, explicit TAP output, all raw wire/Runtime/events and156 physical Context rows are retained under raw/. Actual Root remains unapplied/unrun at this receipt; Parent must first finish the other preapply597-byte gate, apply exactly8 leaves, then use the frozen root-applied controller. No currentRoot regression or full replication claim is inferred from these18 positives.
