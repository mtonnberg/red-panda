// Independent heldouts. Native observations are required before candidate parity.
export async function audioHeldout(name){
 const spin=ms=>{const end=performance.now()+ms;while(performance.now()<end){}},pause=ms=>new Promise(r=>setTimeout(r,ms));
 const fail=e=>({name:e.name,message:e.message,typeError:e instanceof TypeError,rangeError:e instanceof RangeError,domException:e instanceof DOMException});
 if(name==='suspended-all-seven'){
  const rows=[];
  for(const method of['setValueAtTime','linearRampToValueAtTime','exponentialRampToValueAtTime','setTargetAtTime','setValueCurveAtTime','cancelScheduledValues','cancelAndHoldAtTime']){
   const c=new AudioContext(),p=c.createGain().gain;try{
    p.value=.625;if(method.startsWith('cancel')){p.setValueAtTime(.1875,c.currentTime+.008);await pause(24)}else spin(12);
    await c.suspend();const frozen=c.currentTime,before=p.value;if(method.startsWith('cancel'))p.setValueAtTime(.8125,frozen+.25);else p.value=.5625;
    const afterSetter=p.value;let result,failure=null;try{result=method==='setTargetAtTime'?p[method](.3125,0,0):method==='setValueCurveAtTime'?p[method]([.3125,.8125],0,.064):method.startsWith('cancel')?p[method](0):p[method](.3125,0)}catch(e){failure=fail(e)}
    const after=p.value;spin(4);rows.push({method,before,afterSetter,after,frozen,afterTime:c.currentTime,positiveClock:frozen>0,clockFrozen:c.currentTime===frozen,state:c.state,returnedThis:result===p,failure});
   }finally{await c.close()}
  }return{rows};
 }
 if(name==='set-value-conversion-priority'){
  const c=new AudioContext(),rows=[];try{spin(12);await c.suspend();
   for(const kind of['NaN-value-zero-time','NaN-value-negative-time','NaN-value-throwing-time','overflow-value-zero-time','throwing-value-unread-time']){
    const p=c.createGain().gain;p.value=.625;const trace=[],sentinel=new Error('authored conversion sentinel');let failure=null,returnedThis=false;
    const value={valueOf(){trace.push('value');if(kind==='throwing-value-unread-time')throw sentinel;return kind==='overflow-value-zero-time'?1e100:NaN}},time={valueOf(){trace.push('time');if(kind==='NaN-value-throwing-time')throw sentinel;return kind==='NaN-value-negative-time'?-1:0}};
    try{returnedThis=p.setValueAtTime(value,time)===p}catch(e){failure={...fail(e),sameSentinel:e===sentinel}}
    rows.push({kind,trace,failure,returnedThis,after:p.value});
   }return{rows};
  }finally{await c.close()}
 }
 if(name==='duration-coercion-advances-real-clock'){
  const c=new AudioContext(),p=c.createGain().gain,trace=[];try{spin(12);p.value=.625;const before={time:c.currentTime,value:p.value};let failure=null,returnedThis=false;
   try{returnedThis=p.setValueCurveAtTime([.21875,.84375],{valueOf(){trace.push({kind:'time',time:c.currentTime});return 0}},{valueOf(){trace.push({kind:'duration-before',time:c.currentTime});spin(16);trace.push({kind:'duration-after',time:c.currentTime});return .5}})===p}catch(e){failure=fail(e)}
   return{before,trace,after:{time:c.currentTime,value:p.value},failure,returnedThis};
  }finally{await c.close()}
 }
 throw Error('Unknown authored heldout');
}
