"""Test-only comparison. Exact non-clock fields, raw clock fields retained separately."""
import json,math
from pathlib import Path
P=Path(__file__).resolve().parent

def compare(raw,phase):
 x=json.loads(Path(raw).read_text());a=x['actors'][0];omitted=[];differences=[]
 if phase=='baseline':
  old=json.loads((P.parent/'observations-r1/paired.json').read_text())['actors'][0]['groups'][1:]
  new=a['groups'][1:]
 elif phase=='heldouts':
  old=json.loads((P/'observations/native-heldouts-24.22.1/raw.json').read_text())['actors'][0]['groups'];new=a['groups']
 else:return {'differences':[],'omittedActualClockFields':[]}
 def is_clock(name,path):
  if name in ['delayed-all-scheduling','past-cancel-and-hold']:
   return len(path)==5 and path[0]=='rows' and path[2]=='steps' and path[4]=='time' or name=='past-cancel-and-hold' and len(path)==3 and path[0]=='rows' and path[2]=='t'
  if name=='suspended-clock-past-set':return path in [('beforeSuspend',),('frozen',)] or len(path)==3 and path[0]in ['steps','delivery'] and path[2]=='time'
  if name=='invalid-time-and-coercion-order':return len(path)==4 and path[0]=='rows' and path[2]in ['before','after'] and path[3]=='time' or len(path)==4 and path[0:2]==('coercion','trace') and path[3]=='time' or path==('coercion','after','time')
  if name=='suspended-all-seven':return len(path)==3 and path[0]=='rows' and path[2]in ['frozen','afterTime']
  if name=='duration-coercion-advances-real-clock':return path in [('before','time'),('after','time')] or len(path)==3 and path[0]=='trace' and path[2]=='time'
  return False
 def visit(name,l,r,path=()):
  if is_clock(name,path):
   omitted.append({'group':name,'path':list(path),'native':l,'candidate':r,'scope':'Actual monotonic elapsed context clock, not an asserted scheduling argument'})
   for who,value in [('native',l),('candidate',r)]:
    if not isinstance(value,(int,float))or not math.isfinite(value)or value<0 or abs(value*48000/128-round(value*48000/128))>1e-6:differences.append({'group':name,'path':list(path),'invalidClock':who,'actual':value})
   return
  if isinstance(l,dict)and isinstance(r,dict):
   if set(l)!=set(r):differences.append({'group':name,'path':list(path),'nativeKeys':list(l),'candidateKeys':list(r)});return
   for key in l:visit(name,l[key],r[key],path+(key,))
  elif isinstance(l,list)and isinstance(r,list):
   if len(l)!=len(r):differences.append({'group':name,'path':list(path),'nativeLength':len(l),'candidateLength':len(r)});return
   for i,(lv,rv)in enumerate(zip(l,r)):visit(name,lv,rv,path+(i,))
  elif type(l)!=type(r)and not(isinstance(l,(float,int))and isinstance(r,(float,int)))or l!=r:differences.append({'group':name,'path':list(path),'native':l,'candidate':r})
 if len(old)!=len(new):differences.append({'nativeGroups':len(old),'candidateGroups':len(new)})
 for left,right in zip(old,new):
  if left['name']!=right['name']:differences.append({'nativeName':left['name'],'candidateName':right['name']});continue
  visit(left['name'],left['actual']['result']['value'],right['actual']['result']['value'])
 return {'scope':'All non-clock by-value fields exact; all public elapsed times retained raw and separately checked for genuine finite nonnegative 128/48000 quantization. No production value or expected-output rewriting. Offline time and all output samples remain exact.','groupsCompared':min(len(old),len(new)),'differences':differences,'omittedActualClockFields':omitted}
