from pathlib import Path
import os,hashlib,json,resource,signal,subprocess,time,re,sys
sys.dont_write_bytecode=True
from compare import compare
P=Path(__file__).resolve().parent;R=Path('/workspace/red-panda');C=P/'candidate'
SDKS={'24.22.1':Path('/workspace/shared/rea-tools/node_modules/node/bin/node'),'24.19.0':Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'),'26.13.0':Path('/workspace/shared/node26/node_modules/node/bin/node')}
phase,sdk=sys.argv[1:];assert sdk in SDKS and phase in ['native-heldouts','baseline','heldouts','sources','new','regressions']
if phase=='native-heldouts':assert sdk=='24.22.1'
if phase=='heldouts':
 prior=json.loads((P/'observations/native-heldouts-24.22.1/status.json').read_text());assert prior['passed'],'Required actual Native heldouts absent/failed'
def sha(q):
 h=hashlib.sha256()
 with Path(q).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
manifest=P/'inputs.json';expected=json.loads(manifest.read_text());deps=json.loads((P/'dependencies.json').read_text());allpins=expected|deps
changed=lambda:[n for n,h in allpins.items()if not Path(n).is_file()or sha(n)!=h]
assert not changed(),'Frozen source/test/dependency/tool inputs changed'
protection=json.loads((P.parent/'Root645-native18.json').read_text())
protected=lambda:{n:sha(R/n)for n in protection}
before=protected();assert before==protection
out=P/'observations'/f'{phase}-{sdk}';out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in ['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union);env['RED_PANDA_REFERENCE_TESTS_ROOT']='/workspace/red-panda/.cache/lightpanda-reference/browser-948d773786/src/browser/tests'
node=SDKS[sdk];native=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux')
caseCounts={'native-heldouts':3,'baseline':6,'heldouts':3,'sources':2,'new':6,'regressions':44}
admin={'native-heldouts':18,'baseline':33,'heldouts':18,'sources':33,'new':48,'regressions':123}[phase]
if phase in ['new','regressions']:
 files=['test/audio-past-time.test.js']if phase=='new'else[f'test/{name}.test.js'for name in ['audio-core','audio-graph','audio-waves','audio-media','audio-compressor','audio-timeline-performance','audio-curve-quantum','audio-cost-margin']]
 command=[str(node),'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*files]
else:
 driver={'native-heldouts':'heldout-probe.mjs','baseline':'candidate-probe.mjs','heldouts':'heldout-probe.mjs','sources':'additional-source-probe.mjs'}[phase]
 binary=native if phase=='native-heldouts'else P/f'launcher-{sdk}'
 command=[str(node),str(P/driver),str(binary),str(out/'raw.json')]
status={'state':'STARTING','passed':False,'phase':phase,'SDK':sdk,'command':command,'administrativeCapSeconds':admin,'originalRPCMilliseconds':2500,'originalScriptMilliseconds':1000,'originalSourceLoadMilliseconds':2000,'originalFreshSourceAssertMilliseconds':2000,'expectedCasesOrGroups':caseCounts[phase],'inputRows':len(expected),'dependencyRows':len(deps),'inputManifestSHA256':sha(manifest),'dependencyManifestSHA256':sha(P/'dependencies.json'),'managedNODE_PATHPreserved':env.get('NODE_PATH')==os.environ.get('NODE_PATH'),'NODE_PATH_SHA256':hashlib.sha256(env.get('NODE_PATH','').encode()).hexdigest(),'canonicalBypassSHA256':hashlib.sha256(env['NO_PROXY'].encode()).hexdigest(),'inheritedProxyTLSAndOptionsPreserved':all(env.get(n)==os.environ.get(n)for n in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_OPTIONS','NODE_PATH','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR']),'RootProtectionRows':len(protection)}
started=time.monotonic();child=None;known={}
def proc(pid):
 try:
  s=(Path('/proc')/str(pid)/'stat').read_text();v=s[s.rindex(')')+2:].split();return{'pid':pid,'state':v[0],'ppid':int(v[1]),'pgrp':int(v[2]),'startTicks':v[19]}
 except(FileNotFoundError,ProcessLookupError,PermissionError):return None
def observe():
 for q in Path('/proc').iterdir():
  if q.name.isdigit():
   v=proc(int(q.name))
   if v and(v['pid']==child.pid or v['pgrp']==child.pid or v['ppid']in known):known.setdefault(v['pid'],v)
def live():
 result=[]
 for pid,old in known.items():
  now=proc(pid)
  if now and now['startTicks']==old['startTicks']and now['state']not in ['Z','X']:result.append(now)
 return result
def save():status['seconds']=time.monotonic()-started;(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
try:
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  child=subprocess.Popen(command,cwd=C,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);status['childPID']=child.pid;save()
  while child.poll()is None:
   observe()
   if time.monotonic()-started>=admin:
    status['administrativeExpiry']=True
    for v in live():
     try:os.kill(v['pid'],signal.SIGKILL)
     except ProcessLookupError:pass
    child.wait();break
   time.sleep(.05)
  status['exit']=child.returncode
 status['liveBeforeCleanup']=live()
 for v in live():
  try:os.kill(v['pid'],signal.SIGKILL)
  except ProcessLookupError:pass
 status['liveAfterCleanup']=live();status['observedOwnedProcesses']=list(known.values())
 if phase in ['new','regressions']:
  log=(out/'stdout.log').read_text();summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped) (\d+)$',log,re.M)};status['testSummary']=summary;status['actualTestNames']=re.findall(r'^# Subtest: (.*)$',log,re.M);status['observedComplete']=summary.get('tests')==caseCounts[phase]and summary.get('pass')==caseCounts[phase]and all(summary.get(k,1)==0 for k in ['fail','cancelled','skipped'])
 elif(out/'raw.json').exists():
  raw=json.loads((out/'raw.json').read_text());status['rawSHA256']=sha(out/'raw.json');status['actualGroups']=[{'actor':a['name'],'completed':a['completed'],'groups':[{'name':g['name'],'completed':g['completed'],'status':g.get('status')}for g in a['groups']],'pid':a.get('pid'),'exit':a.get('exit'),'signal':a.get('signal')}for a in raw['actors']];status['HTTP']=len(raw['httpReceipts']);status['wire']=len(raw['wire']);status['rawCleanupErrors']=raw['cleanupErrors'];status['rawSocketsRemaining']=raw['fixtureSocketsRemaining'];status['observedComplete']=raw['normal']and not raw['expired']and not raw['cleanupErrors']and raw['fixtureSocketsRemaining']==0 and len(raw['actors'])==1 and all(a['completed']and len(a['groups'])==caseCounts[phase]and all(g['completed']for g in a['groups'])for a in raw['actors'])
  if phase in ['baseline','heldouts']and status['observedComplete']:
   actual=compare(out/'raw.json',phase);(out/'comparison.json').write_text(json.dumps(actual,indent=2)+'\n');status['comparisonDifferences']=len(actual['differences']);status['comparisonSHA256']=sha(out/'comparison.json');status['observedComplete']=not actual['differences']
except BaseException as e:status['controllerFailure']={'type':type(e).__name__,'message':str(e)}
finally:
 if child and child.poll()is None:
  observe()
  for v in live():
   try:os.kill(v['pid'],signal.SIGKILL)
   except ProcessLookupError:pass
  child.wait()
 status['remainingLiveOwnedProcesses']=live();after=protected();status['changedRoot645Native18']=[n for n in before if before[n]!=after[n]];status['changedInputs']=changed();status['passed']=status.get('exit')==0 and status.get('observedComplete',False)and not status.get('administrativeExpiry')and not status.get('liveBeforeCleanup')and not status.get('remainingLiveOwnedProcesses')and not status['changedRoot645Native18']and not status['changedInputs'];status['state']='PASSED_DECLARED_BOUNDED_GATE'if status['passed']else'FAILED_OR_INCOMPLETE';save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['passed']else 1)
