from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time,urllib.request
R=Path('/workspace/red-panda');O=R/'.cache/validation/audio-past-environment';spec=importlib.util.spec_from_file_location('full_helpers',R/'.cache/validation/feature41-full/controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();journal=json.loads(Path('/workspace/shared/audio-context-past-time-r1/root-integration/journal.json').read_text())
assert all(sha(R/n)==h for n,h in journal['RootAfter646'].items());assert sha(R/'docs/reference/audio-past-time/controls.mjs')=='97566cd6a3e2dd21bbcb7ab1ef742f216ce3830c35375c787e223cbe5706df96'
matches=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if(p/'cmdline').read_bytes()==b'node\0--experimental-vm-modules\0bin/red-panda.js\0serve\0'and p.stat().st_uid==os.geteuid():matches.append(m.identity(int(p.name)))
 except OSError:pass
assert len(matches)==1
service={'TTY':66276,'process':matches[0],'argv':['node','--experimental-vm-modules','bin/red-panda.js','serve'],'launcherWorkdir':str(R),'procCwd':'Not independently read','launcherGitHEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'runtimeState':'Accepted audio working tree ahead of metadata850; not code at850','audioSHA256':sha(R/'src/audio-core.js'),'Root646And18Exact':True};(O/'current-service.json').write_text(json.dumps(service,indent=2)+'\n')
health=json.load(urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:9222/health',timeout=5));assert health['status']=='ok'
env=m.environment();before=m.snapshot(env);(O/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');record={'health':health,'sourceEpoch':'Root646+authoredDocControl, actualaudio99ff; GitHEAD850 has3authorizeduncommittedleaves','capSeconds':90};child=None;owned={}
try:
 with(O/'example.log').open('xb')as log:
  start=time.monotonic();child=subprocess.Popen(['npm','run','example:puppeteer'],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,preexec_fn=m.no_core);leader=child.pid
  while child.poll()is None and time.monotonic()-start<90:
   for row in m.members(leader):owned[(row['pid'],row['startTicks'])]=row
   time.sleep(.05)
  record['ownedBeforeCleanup']=m.observed_remainder(leader,owned);record['ownedAfterCleanup']=m.cleanup(leader,owned);record['exampleExit']=child.wait(timeout=5);record['seconds']=time.monotonic()-start
finally:
 if child is not None and child.poll()is None:m.cleanup(child.pid,owned)
 after=m.snapshot(env);(O/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');record['inputsUnchanged']=before==after;record['inputs']=len(before);record['serviceSameStart']=(m.identity(matches[0]['pid'])or{}).get('startTicks')==matches[0]['startTicks'];record['source646Exact']=all(sha(R/n)==h for n,h in journal['RootAfter646'].items());(O/'live-status.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
assert record['exampleExit']==0 and record['seconds']<90 and record['inputsUnchanged']and record['serviceSameStart']and record['source646Exact']and not m.live(record['ownedBeforeCleanup']+record['ownedAfterCleanup'])
