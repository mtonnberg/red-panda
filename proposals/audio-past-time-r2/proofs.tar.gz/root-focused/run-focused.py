from pathlib import Path
import hashlib,importlib.util,json,os,re,signal,subprocess,time
R=Path('/workspace/red-panda');O=R/'.cache/validation/audio-past-root-r1';spec=importlib.util.spec_from_file_location('full_helpers',R/'.cache/validation/feature41-full/controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(R/'src/audio-core.js')=='99ff8fdc1a0d44c96c70db4a7d55f1f6fad4345175cd24c00a12538dee518a9f'
assert sha(R/'test/audio-past-time.test.js')=='111c888b3c1fbbdb710ec085bf556857295b42746af0d1d8983ec65f28d16fec'
assert sha(R/'docs/reference/audio-past-time/controls.mjs')=='97566cd6a3e2dd21bbcb7ab1ef742f216ce3830c35375c787e223cbe5706df96'
env=m.environment();assert not env.get('RED_PANDA_RUNTIME_ADDON')and not env.get('RED_PANDA_COLLECTIONS_ADDON')
files=[f'test/{name}.test.js'for name in ['audio-core','audio-graph','audio-waves','audio-media','audio-compressor','audio-timeline-performance','audio-curve-quantum','audio-cost-margin','audio-past-time']]
steps=[('audio50',[str(m.NODE),'--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap',*files],123),('syntax',['npm','run','check'],180)]
before=m.snapshot(env);(O/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');record={'state':'RUNNING','stages':[],'futureStages':[s[0]for s in steps],'whole2190Suite':'Not rerun; last complete suite remains code917','caseAndAPIAndHeapBudgets':'UNCHANGED'};child=None;owned={}
def save():(O/'status.json').write_text(json.dumps(record,indent=2)+'\n')
def interrupted(signum,frame):raise InterruptedError('Administrative signal '+str(signum))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 for name,command,cap in steps:
  assert m.snapshot(env)==before
  row={'name':name,'command':command,'administrativeCapSeconds':cap};record['stages'].append(row);record['futureStages'].remove(name);start=time.monotonic()
  with(O/(name+'.log')).open('xb')as log:
   child=subprocess.Popen(command,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=m.no_core);row['identity']=m.identity(child.pid);leader=child.pid;owned={(leader,row['identity']['startTicks']):row['identity']};save();print(json.dumps({'running':name,'pid':leader}),flush=True);last=start
   while child.poll()is None:
    for v in m.members(leader):owned[(v['pid'],v['startTicks'])]=v
    if time.monotonic()-start>=cap:row['administrativeExpiry']=True;break
    if time.monotonic()-last>=20:print(json.dumps({'running':name,'seconds':time.monotonic()-start,'logBytes':(O/(name+'.log')).stat().st_size}),flush=True);last=time.monotonic()
    time.sleep(.1)
   row['ownedBeforeCleanup']=m.observed_remainder(leader,owned);row['ownedAfterCleanup']=m.cleanup(leader,owned);row['exit']=child.wait(timeout=5);child=None
  row['seconds']=time.monotonic()-start;row['logSHA256']=sha(O/(name+'.log'));row['inputsUnchanged']=m.snapshot(env)==before;row['passed']=row['exit']==0 and not row.get('administrativeExpiry')and not m.live(row['ownedBeforeCleanup']+row['ownedAfterCleanup'])and row['inputsUnchanged']
  if name=='audio50':
   text=(O/'audio50.log').read_text();summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};row['actualSummary']=summary;row['actualNames']=re.findall(r'^# Subtest: (.*)$',text,re.M);row['passed']=row['passed']and summary=={'tests':50,'pass':50,'fail':0,'cancelled':0,'skipped':0,'todo':0}
  save();print(json.dumps({k:v for k,v in row.items()if k not in ['actualNames','ownedBeforeCleanup','ownedAfterCleanup','command']}),flush=True)
  if not row['passed']:break
 record['state']='PASS'if len(record['stages'])==2 and all(v['passed']for v in record['stages'])else'STOPPED_REST_UNRUN'
except BaseException as error:record.update(state='STOPPED_REST_UNRUN',error={'type':type(error).__name__,'message':str(error)})
finally:
 if child is not None:record['interruptedOwnedAfter']=m.cleanup(child.pid,owned);record['interruptedExit']=child.wait(timeout=5)
 after=m.snapshot(env);(O/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');record['inputsUnchanged']=before==after;record['inputCount']=len(before)
 if before!=after:record['state']='STOPPED_INTEGRITY'
 save();print(json.dumps({'state':record['state'],'inputsUnchanged':record['inputsUnchanged'],'inputCount':len(before),'futureStages':record['futureStages']}),flush=True)
raise SystemExit(0 if record['state']=='PASS'else 1)
