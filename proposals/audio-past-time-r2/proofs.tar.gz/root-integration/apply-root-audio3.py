from pathlib import Path
from collections import Counter
import hashlib,json,os,shutil,signal,tempfile,time
R=Path('/workspace/red-panda');H=Path('/workspace/shared/audio-context-past-time-r1/handoff-r2');O=Path(__file__).parent;B=O/'backup-before';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(H/'integration.patch')=='7de814c22778fbb4b95d48b5eca82d08c8e26109f51b1b80ccac82d7bb4726c1'
assert sha(H/'acceptance-all3.json')=='c2bff04383bc2670d3bb6ee7160cd6c28d83f653e625a403ef51a818e9437f6b'
assert sha(H/'changed-leaves.json')=='4656febecf0a84ebe749962449f7c41c1d2237c7b6720cc3f302a9600c5bb572'
for name,digest in json.loads((H/'inventory.json').read_text()).items():assert sha(H/name)==digest,name
accepted=json.loads((H/'acceptance-all3.json').read_text());counts=Counter()
for row in accepted['actualReceipts']:
 p=Path(row['statusPath']);assert sha(p)==row['statusSHA256'];x=json.loads(p.read_text());assert x['passed']and x['exit']==0 and not x['changedInputs']and not x['changedRoot645Native18']and not x['remainingLiveOwnedProcesses']
 for name,digest in row['evidenceFiles'].items():assert sha(p.parent/name)==digest
 if row['testSummary']:counts[row['SDK']]+=row['testSummary']['pass']
assert counts=={'24.22.1':50,'24.19.0':50,'26.13.0':50}
rows=json.loads((H/'changed-leaves.json').read_text());assert set(rows)=={'src/audio-core.js','test/audio-past-time.test.js','docs/reference/audio-past-time/controls.mjs'}
def graph():return {str(p.relative_to(R)):sha(p)for d in ['src','test','native','bin','scripts']for p in(R/d).rglob('*')if p.is_file()}|{n:sha(R/n)for n in ['package.json','package-lock.json']}
before=json.loads((H/'Root645-native18-before.json').read_text());assert len(before)==645 and graph()==before
for n,row in rows.items():
 target=R/n
 assert sha(H/'leaves'/n)==row['after'] and (sha(target)if target.exists()else None)==row['before']
 for parent in [target,*target.parents]:
  if parent==R.parent:break
  assert not parent.is_symlink(),str(parent)
 if target.exists():assert target.stat().st_uid==os.geteuid() and target.stat().st_gid==os.getegid()
assert not B.exists();assert not(O/'journal.json').exists()
def proc(pid):
 p=Path('/proc')/str(pid)
 try:
  raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split();return {'pid':pid,'startTicks':int(f[19]),'uid':p.stat().st_uid,'argv':(p/'cmdline').read_bytes().split(b'\0')[:-1]}
 except FileNotFoundError:return None
pid=828509;p=proc(pid)
if p:
 assert p['startTicks']==10348802 and p['uid']==os.geteuid() and p['argv']==[b'node',b'--experimental-vm-modules',b'bin/red-panda.js',b'serve']
 os.kill(pid,signal.SIGTERM);deadline=time.monotonic()+3
 while proc(pid)is not None and time.monotonic()<deadline:time.sleep(.02)
 assert proc(pid)is None,'Owned service must fully exit before replacement'
assert graph()==before
B.mkdir();modes={}
for n,row in rows.items():
 target=R/n;modes[n]=(target.stat().st_mode&0o777)if target.exists()else 0o600
 if target.exists():dest=B/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,dest);assert sha(dest)==row['before']
journal={'state':'APPLYING','oldServiceAbsent':True,'oldServicePID':pid,'oldServiceStartTicks':10348802,'procCwd':'not read; exact owned launcher/start/argv/uid verified','RootBefore645':before,'rows':rows,'modes':modes,'committed':[],'acceptedSDKTests':dict(counts)}
def save():
 q=O/'journal.tmp';q.write_text(json.dumps(journal,indent=2)+'\n');os.replace(q,O/'journal.json')
def atomic(target,data,mode):
 target.parent.mkdir(parents=True,exist_ok=True);fd,name=tempfile.mkstemp(prefix='.audio-stage-',dir=target.parent)
 try:
  with os.fdopen(fd,'wb')as f:f.write(data);f.flush();os.fchmod(f.fileno(),mode);os.fsync(f.fileno())
  os.replace(name,target);directory=os.open(target.parent,os.O_RDONLY|os.O_DIRECTORY)
  try:os.fsync(directory)
  finally:os.close(directory)
 finally:
  if os.path.exists(name):os.unlink(name)
save()
try:
 for n,row in rows.items():
  assert proc(pid)is None
  target=R/n;assert (sha(target)if target.exists()else None)==row['before'];atomic(target,(H/'leaves'/n).read_bytes(),modes[n]);journal['committed'].append(n);save()
 after=dict(before)
 for n,row in rows.items():
  assert sha(R/n)==row['after']
  if n.split('/')[0]in ['src','test','native','bin','scripts']:after[n]=row['after']
 assert len(after)==646 and graph()==after
 journal.update(state='APPLIED_EXACT_AUDIO3_ROOT_FOCUSED_VALIDATION_UNRUN',RootAfter646=after,all18NativeArtifactsUnchanged=True);save()
except BaseException as e:
 journal.update(state='ROLLING_BACK',error=str(e));save()
 for n,row in reversed(list(rows.items())):
  target=R/n;actual=sha(target)if target.exists()else None
  if actual==row['before']:continue
  assert actual==row['after'],'Unexpected independent target change; refuse overwrite'
  if row['before']is None:target.unlink()
  else:atomic(target,(B/n).read_bytes(),modes[n])
 assert graph()==before;journal['state']='ROLLED_BACK';save();raise
print(json.dumps({'state':journal['state'],'RootAfter':646,'actualTargets':len(rows),'journal':str(O/'journal.json')}))
