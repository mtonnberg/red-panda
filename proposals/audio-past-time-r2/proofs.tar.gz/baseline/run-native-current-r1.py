from pathlib import Path
import os,hashlib,json,resource,signal,subprocess,time
P=Path(__file__).resolve().parent;R=Path('/workspace/red-panda');NODE=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');NATIVE=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux')
def sha(q):
 h=hashlib.sha256()
 with Path(q).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
manifest=P/'inputs.json';expected=json.loads(manifest.read_text())
def changed():return[n for n,h in expected.items()if not Path(n).is_file()or sha(n)!=h]
assert not changed(),'Frozenactualsource/fixture/tools changed beforefirstactor'
protection=json.loads((P/'Root645-native18.json').read_text())
def protected():return{n:sha(R/n)for n in protection}
before=protected();assert before==protection
out=P/'observations-r1';out.mkdir(exist_ok=False);env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in ['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union)
status={'scope':'Originalsource+actualNative/currentRoot causalobservations; nofix/parityclaim','state':'STARTING','scriptMilliseconds':1000,'RPCMilliseconds':2500,'sourceLoadMilliseconds':2000,'freshSourceAssertMilliseconds':2000,'workSeconds':30,'cleanupGrace':3,'inputs':len(expected),'manifestSHA256':sha(manifest),'protected645Native18Rows':len(protection),'managedNODE_PATHPreserved':env.get('NODE_PATH')==os.environ.get('NODE_PATH'),'NODE_PATHPresent':bool(env.get('NODE_PATH')),'NODE_PATH_SHA256':hashlib.sha256(env.get('NODE_PATH','').encode()).hexdigest(),'canonicalProxyBypassSHA256':hashlib.sha256(env['NO_PROXY'].encode()).hexdigest(),'proxyTLSAndManagedOptionsPreserved':all(env.get(n)==os.environ.get(n)for n in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_OPTIONS','NODE_PATH','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR'])};started=time.monotonic();child=None;known={}
def proc(pid):
 try:
  s=(Path('/proc')/str(pid)/'stat').read_text();v=s[s.rindex(')')+2:].split();return{'pid':pid,'state':v[0],'ppid':int(v[1]),'pgrp':int(v[2]),'startTicks':v[19]}
 except(FileNotFoundError,ProcessLookupError,PermissionError):return None
def observe():
 for q in Path('/proc').iterdir():
  if q.name.isdigit():
   v=proc(int(q.name))
   if v and(v['pid']==child.pid or v['pgrp']==child.pid or v['ppid']in known):known.setdefault(v['pid'],v)
def live():
 result=[]
 for pid,old in known.items():
  now=proc(pid)
  if now and now['startTicks']==old['startTicks']and now['state']not in ['Z','X']:result.append(now)
 return result
def save():status['seconds']=time.monotonic()-started;(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
try:
 command=[str(NODE),str(P/'probe.mjs'),str(NATIVE),str(P/'root-launcher'),str(out/'paired.json')];status['command']=command
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  child=subprocess.Popen(command,cwd=P,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);status['childPID']=child.pid;save()
  while child.poll()is None:
   observe()
   if time.monotonic()-started>=33:
    status['administrativeExpiry']=True
    for v in live():
     try:os.kill(v['pid'],signal.SIGKILL)
     except ProcessLookupError:pass
    child.wait();break
   time.sleep(.05)
  status['exit']=child.returncode
 status['liveBeforeCleanup']=live()
 for v in live():
  try:os.kill(v['pid'],signal.SIGKILL)
  except ProcessLookupError:pass
 status['liveAfterCleanup']=live();status['observedOwnedProcesses']=list(known.values());raw=out/'paired.json'
 if raw.exists():
  x=json.loads(raw.read_text());status.update({'rawSHA256':sha(raw),'normal':x['normal'],'expired':x['expired'],'failure':x.get('failure'),'actors':[{'name':a['name'],'pid':a.get('pid'),'completed':a['completed'],'groups':[{'name':g['name'],'completed':g['completed'],'status':g.get('status')}for g in a['groups']],'exit':a.get('exit'),'signal':a.get('signal')}for a in x['actors']],'HTTP':len(x['httpReceipts']),'wire':len(x['wire']),'rawCleanupErrors':x['cleanupErrors'],'fixtureSocketsRemaining':x['fixtureSocketsRemaining']})
 status['state']='OBSERVED_NOT_A_FIX_ACCEPTANCE'if status.get('exit')==0 and status.get('normal')and not status.get('expired')and len(status.get('actors',[]))==2 and all(a['completed']and len(a['groups'])==6 and all(g['completed']for g in a['groups'])for a in status['actors'])and not status.get('administrativeExpiry')and not status.get('liveBeforeCleanup')and not status.get('liveAfterCleanup')and not status.get('rawCleanupErrors')and status.get('fixtureSocketsRemaining')==0 else'INCOMPLETE_OR_FAILED'
except BaseException as e:status['state']='CONTROLLER_FAILURE';status['failure']={'type':type(e).__name__,'message':str(e)}
finally:
 if child and child.poll()is None:
  observe()
  for v in live():
   try:os.kill(v['pid'],signal.SIGKILL)
   except ProcessLookupError:pass
  child.wait()
 status['remainingLiveOwnedProcesses']=live();after=protected();status['changedRoot645Native18']=[n for n in before if before[n]!=after[n]];status['changedInputs']=changed();save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='OBSERVED_NOT_A_FIX_ACCEPTANCE'and not status['changedRoot645Native18']and not status['changedInputs']and not status['remainingLiveOwnedProcesses']else 1)
