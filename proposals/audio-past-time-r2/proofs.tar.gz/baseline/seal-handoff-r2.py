from pathlib import Path
import json,hashlib,difflib
P=Path('/workspace/shared/audio-context-past-time-r1');D=P/'revision-r2';H=P/'handoff-r2';H.mkdir(exist_ok=False);R=Path('/workspace/red-panda');C=D/'candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
leaves=['src/audio-core.js','test/audio-past-time.test.js','docs/reference/audio-past-time/controls.mjs'];patch='';leafmap={}
for name in leaves:
 old=(R/name).read_text() if (R/name).exists() else '';new=(C/name).read_text();before=sha(R/name) if (R/name).exists() else None
 patch+=f'diff --git a/{name} b/{name}\n'
 if before is None:patch+='new file mode 100644\n'
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=f'a/{name}' if before else '/dev/null',tofile=f'b/{name}'))
 dst=H/'leaves'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((C/name).read_bytes());assert sha(dst)==sha(C/name)
 leafmap[name]={'before':before,'after':sha(dst),'bytes':dst.stat().st_size}
(H/'integration.patch').write_text(patch);(H/'changed-leaves.json').write_text(json.dumps(leafmap,indent=2)+'\n')
receipts=[]
epochs=[('native-heldouts','24.22.1'),('baseline','24.22.1'),('heldouts','24.22.1'),('sources','24.22.1')]+[(phase,sdk)for sdk in ['24.22.1','24.19.0','26.13.0']for phase in ['new','regressions']]
for phase,sdk in epochs:
 O=D/'observations'/f'{phase}-{sdk}';s=json.loads((O/'status.json').read_text());assert s['passed'] and not s['changedInputs'] and not s['changedRoot645Native18'] and not s['remainingLiveOwnedProcesses']
 count=s.get('testSummary',{}).get('tests') or sum(len(a['groups']) for a in s['actualGroups'])
 row={'phase':phase,'SDK':s['SDK'],'actualCount':count,'seconds':s['seconds'],'statusSHA256':sha(O/'status.json'),'statusPath':str(O/'status.json'),'exit':s['exit'],'testSummary':s.get('testSummary'),'comparisonDifferences':s.get('comparisonDifferences'),'allOwnedProcesses':s['observedOwnedProcesses'],'cleanupLive':s['remainingLiveOwnedProcesses'],'changedInputs':s['changedInputs'],'changedRoot645Native18':s['changedRoot645Native18'],'inputRows':s['inputRows'],'dependencies':s['dependencyRows']}
 row['evidenceFiles']={str(p.relative_to(O)):sha(p) for p in sorted(O.rglob('*')) if p.is_file()};receipts.append(row)
assert sum(row['actualCount']for row in receipts if row['testSummary'])==150
protection=json.loads((P/'Root645-native18.json').read_text());assert all(sha(R/n)==h for n,h in protection.items())
acceptance={'state':'ISOLATED ALL3SDK BOUNDED ACCEPTANCE; Root integration UNRUN','RootCode917Metadata850SameSource645':True,'protected645Native18StillExact':True,'runtimePatchSHA256':sha(D/'runtime.patch'),'integrationPatchSHA256':sha(H/'integration.patch'),'runtimeAfterSHA256':sha(C/'src/audio-core.js'),'baselineActualFactSealSHA256':sha(P/'baseline-actual-facts.json'),'retainedNativeBaselineRawSHA256':sha(P/'observations-r1/paired.json'),'originalD41CensusPassSHA256':sha(P/'historical/d41-passed.json'),'original917CensusFailSHA256':sha(P/'historical/917-failed.json'),'historicalFailureNotErased':True,'actualReceipts':receipts,'countsAreDistinctEpochs':{'freshNativeGroups':3,'candidateRawGroupsNode24':11,'candidateControlComparisonsNode24':8,'candidateSourceGroupsNode24':3,'newTestsEachSDK':6,'existingRegressionsEachSDK':44,'all3SDKTestCases':150},'remaining':'Root integration and any composed Root validation UNRUN. Do not represent Node24 raw/control/source groups as executed on other SDKs.','unchangedRuntimeBounds':['No generic pruning','No realtime clock/suspend semantics modification','No offline intrinsic renderedValue cache change','No DSP math/sample/cost shortcut','No original source/assertion/budget edit','NaN numeric-conversion ordering changed for setValueAtTime only'],'diagnostics':'Actual MaxListenersExceededWarning rows in existing regression logs retained; no runtime diagnostics were filtered.'}
(H/'acceptance-all3.json').write_text(json.dumps(acceptance,indent=2)+'\n')
(H/'README.md').write_text('''This packet contains three changed leaves for independent AudioParam past-time normalization. The production change uses the actual context clock for all seven time methods, preserves the offline intrinsic cache, samples cancelAndHold time once, and makes the narrowly observed setValueAtTime numeric conversion order match Native. No pruning, clock modification, DSP math change, or budget change is included.

Actual Native/current baseline R1 completed12groups and proved scheduling/value/cache differences. Both quiet original source runs passed; the historical917census failure expected0.25/got0.5 is preserved and is not erased. The d41/917/current audio source was identical6ed before this proposal, so the packet makes no causal batch attribution. A second Native3 heldout epoch established all-seven suspended behavior, throwing/negative/overflow conversion order, and duration coercion advancing the genuine clock. Eight candidate control groups exactly matched all compared non-clock Native values; actual clocks remain raw with declared quantization checks. Three untouched source fixtures passed under original2sload+fresh2sassert caps. Separate new6 and existing44 tests passed on each of24.22.1,24.19.0,26.13.0:150 total actual tests across separate epochs, including actual offline output/fingerprint, first-getter/brands/VM/heap ownership, Native69 controls and frozen Float32 byte hashes.

These are isolated bounded epochs, not a Root full run. Root integration remains UNRUN. Existing diagnostic warnings remain raw. integration.patch applies only one existing source leaf and adds the authored test and its REQUIRED authored control input; all three leaves are necessary. Never copy the older candidate tree over Root. changed-leaves.json records exact before/after/absence. Source/controller/input manifests remain immutable at ../revision-r2, and baseline/census evidence remains in the parent packet. Native source/license references are reference-only; no engine implementation is imported or copied.
''')
(H/'Root645-native18-before.json').write_bytes((P/'Root645-native18.json').read_bytes())
files={str(p.relative_to(H)):sha(p) for p in sorted(H.rglob('*')) if p.is_file()}
(H/'inventory.json').write_text(json.dumps(files,indent=2)+'\n');assert all(sha(H/n)==h for n,h in files.items())
print(json.dumps({'path':str(H),'patchSHA256':sha(H/'integration.patch'),'leafMapSHA256':sha(H/'changed-leaves.json'),'acceptanceSHA256':sha(H/'acceptance-all3.json'),'inventorySHA256':sha(H/'inventory.json'),'readbackFiles':len(files),'leaves':leafmap},indent=2))
