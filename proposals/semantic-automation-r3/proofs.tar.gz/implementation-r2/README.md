# Semantic registry/LP R2 — STATIC, UNRUN

R1 remains immutable. Its actual gate passed eleven syntax checks and ten of twelve tests; it failed before completing any of the twenty Native whole-object comparisons. The preserved first raw LP response contained eighteen interactive records versus sixteen in Native, including two genuine candidate-only option records. The strict identity guard had no mapping for those unexpected records and rejected them. Listener/focusable names also differed. No equality is inferred from this interrupted comparison.

R2 changes exactly one runtime leaf and one test leaf after R1. The reader classifies ARIA interactivity only from an actual explicit role attribute, preserving implicit option roles for genuine node descriptions without inventing an ARIA-interactive option producer. Listener/focusable record names fall back to actual node content after the existing name algorithm. There are no element-ID/name fixture branches, expected-object returns or mapping changes. All twenty original response/error expectations and every strict comparison assertion remain exact.

The separate utility failure was a setup omission: the low-level createIsolatedWorld test had not installed the real namespace/DOMParser producer. The default dependency path requires a Window _document slot which that utility global intentionally lacks. Production world-sessions and the existing utility namespace test use installNamespaceSerialization with actual Context and controller.createDocument. R2 invokes that same trusted installer in the test. It does not fabricate _document, alter URL/errors, add a Host fallback, retarget a prototype or change utility runtime code. Actual main/utility backend alias assertions and all three V8 objects had passed before that failing parser operation in R1; those proofs and the parser assertion remain.

Exact next command, only after review and a quiet grant:

```
python3 /workspace/shared/semantic-automation-implementation-r2/run-first-gate-r2.py
```

It checks only the two changed JavaScript files (the other nine remain byte-identical to R1's successful syntax epoch), then executes the same twelve tests, twenty Native whole-object comparisons and three genuine V8 objects before/after prototype null. RPC/readiness remains 2500 ms, authored evaluation 200 ms, test caps 6/10 seconds, overall administration 90 seconds. Expected elapsed 6–15 seconds is unmeasured. No retry, Native rerun, Source fixture edit, timeout increase or assertion weakening is included.

The candidate stays on its frozen Root79 lineage. Parent Root deliberately advanced through XML integration while R2 was prepared; six original inputs differ. No refresh or production overwrite occurred. The exact old physical base is reconstructed privately by reversing the immutable R1 patch and checking all 605 original hashes. Cumulative export/roundtrip proof uses that base. The validation controller protects fresh actual Parent Root before/after at launch, without demanding old Root equality or claiming current-HEAD runtime acceptance. A later current-Root composition needs its own context review and gates.

The registry, its actual-context/generation authority, all other runtime bytes, Native oracle and three copied fixture files are unchanged from R1. Its Document.open/import/adopt/cross-target heldouts remain unmeasured; no reset-counter invalidation was added. AX/tree remain unsupported. The 132 protected regressions and other SDKs remain withheld until the first gate passes. All original R1 failed logs, source and negative seal stay exact. Root remains untouched.
