# Semantic continuation R2 — STATIC / UNRUN

This new packet executes only the **38 original response cases never reached** by Semantic R1. It has not run JavaScript syntax/import, Node, Native, HTTP or a build. R1's sealed source, raw observations and failed overall status stay unchanged.

R1 completed three groups, received twenty responses (twelve result envelopes/eight error envelopes), then attempted request 34: `LP.detectForms` with an entire string `params` value. Native closed that connection with WebSocket 1002 and no command reply. It remained alive before owned cleanup, then exited 0 without a signal; stderr contained only server startup. This is a source-backed terminal **CDP envelope** rejection, not a forms-handler error or evidence of a process crash. The outer parser requires an object params token; Link maps its parse failure to disconnect(InvalidJSON), and WS maps that error to 1002. Optional null and a numeric-string backend ID had already returned genuine responses and are not repeated.

The new source preserves the exact original unobserved suffix, indices21–58, including all names, method/parameter bodies and later real fixture mutations. It repeats only necessary fresh-target/real-node-ID setup. It does not replay the twenty responses or resend the already-observed invalid envelope. There is no reconnect/retry after any unexpected close, no relaxed outcome/golden filter and no reclassification of R1 as 59 passing responses.

Nine ordered segments remain: the four unobserved object-envelope parameter cases; partial selectors; actual same-target session authority; child-frame ownership; shadow ownership; live mutation; detached/frameless nodes; authored-getter independence; real navigation invalidation. All outcomes remain unknown. Received protocol errors are captured, not turned into feature successes. Any future additional envelope-invalid case must use its own fresh connection, record the terminal close and stop; it must not poison a connection carrying unrelated planned cases.

Exact queued command:

```
python3 /workspace/shared/semantic-automation-native-continuation-r2/run-continuation-r2.py
```

It uses the same pinned Node/reference binary, fixtures, actual wire journaling and original 2500 ms RPC/handshake/readiness, 200 ms authored VM, 30000 ms owned watchdog, 30-second parent and one shared 3-second cleanup grace. No runtime is authorized by this README. Eighteen Root artifact/receipt inputs remain protected, while actual Root source/test/native maps are captured fresh at launch; no old HEAD behavior binding is claimed. Public branding is retained verbatim.
