# Native semantic continuation — actual observations sealed

The continuation completed nine segments and all 38 replies in 0.663 seconds: 29 result envelopes and nine actual protocol errors. It made 28 setup calls. Node exited 0; the owned Native exited 0 after cleanup. All 592 captured Root inputs were unchanged, no live owned process remained, and authored getters/listeners were not invoked by the measured methods.

This supplements the preserved original partial failure. The original run received 20 replies before its non-object params envelope caused a real WebSocket 1002 close. That process was alive before owned cleanup; there is no crash evidence. No successful earlier case or terminal negative was replayed. Across the two distinct epochs there are 58 method replies and one terminal protocol close, not a single passing 59-response run.

`observed-contracts.json` maps each statement to exact zero-based raw row indices; whole values remain in Native.json. `IMPLEMENTATION-DESIGN.md` describes genuine private registry, node/state/name and separate LP/AX producers. It does not implement them or substitute MCP behavior. `Root-source-design-inputs.json` is a static source inventory, not a behavioral equivalence or current-HEAD runtime claim. Original prepared packets remain unchanged.

No new process, network fixture, build, JavaScript import, Root edit or Native source copy occurred while producing this supplement. All implementation and candidate gates remain unrun.
