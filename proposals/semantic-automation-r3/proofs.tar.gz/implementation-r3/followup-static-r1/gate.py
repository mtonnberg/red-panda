"""Frozen serial followup controller. Parent quiet lease required."""
from pathlib import Path
import hashlib,json,os,re,resource,signal,subprocess,time
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;CANDIDATE=BASE/'candidate';ROOT=Path('/workspace/red-panda')
def digest(file):return hashlib.sha256(Path(file).read_bytes()).hexdigest()
def verify(file,base):
 values=json.loads(file.read_text());bad=[name for name,expected in values.items()if not(base/name).is_file()or digest(base/name)!=expected]
 if bad:raise RuntimeError('Actual frozen input mismatch: '+str(bad))
 return len(values)
def root_map():
 values={str(p.relative_to(ROOT)):digest(p)for folder in ['src','test','native','bin','scripts']for p in sorted((ROOT/folder).rglob('*'))if p.is_file()};values.update({name:digest(ROOT/name)for name in ['package.json','package-lock.json']});return values
def owned(group):
 result=[]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdecimal():continue
  try:
   text=(entry/'stat').read_text();fields=text[text.rfind(')')+2:].split()
   if int(fields[2])==group:result.append({'pid':int(entry.name),'state':fields[0]})
  except(OSError,ValueError,IndexError):pass
 return result
def run(plan_name):
 plan=json.loads((HERE/plan_name).read_text());verify(HERE/'inputs.json',HERE);verify(BASE/'packet-inputs.json',BASE);verify(BASE/'candidate-inputs.json',CANDIDATE);verify(BASE/'tool-inputs.json',Path('/'));verify(HERE/'SDK-and-reference-inputs.json',Path('/'));verify(BASE/'Root2342-source-before.json',ROOT)
 if root_map()!=json.loads((BASE/'Root2342-source-before.json').read_text()):raise RuntimeError('Current Root graph differs from this exact Root2342 gate')
 out=BASE/plan['output'];out.mkdir(exist_ok=False);before=root_map();(out/'Root-before.json').write_text(json.dumps(before,indent=2)+'\n');start=time.monotonic();status={'state':'RUNNING','scope':plan['scope'],'expectedCases':plan['cases'],'administrativeSeconds':plan['administrativeSeconds'],'steps':[]};child=None
 try:
  for specification in plan['steps']:
   elapsed=time.monotonic()-start;remaining=plan['administrativeSeconds']-elapsed
   if remaining<=0:raise RuntimeError('Administrative deadline before '+specification['name'])
   env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1'
   for key in ['NO_PROXY','no_proxy']:env[key]=','.join(filter(None,[env.get(key,''),'127.0.0.1,localhost,0.0.0.0']))
   env.pop('FILE_DISPATCH_RECOVERY_EVIDENCE',None);env.pop('SEMANTIC_REPORT',None)
   if specification.get('semanticReport'):env['SEMANTIC_REPORT']=str(out/(specification['name']+'-comparisons.json'))
   step={key:value for key,value in specification.items()if key!='semanticReport'};status['steps'].append(step);began=time.monotonic()
   with(out/(step['name']+'.stdout')).open('xb')as stdout,(out/(step['name']+'.stderr')).open('xb')as stderr:
    def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    child=subprocess.Popen(step['command'],cwd=CANDIDATE,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);step['pid']=child.pid
    try:step['exit']=child.wait(timeout=min(step['administrativeCapSeconds'],remaining))
    except subprocess.TimeoutExpired:step['deadlineExpired']=True;step['ownedAtDeadline']=owned(child.pid);os.killpg(child.pid,signal.SIGKILL);step['exit']=child.wait()
    live=[row for row in owned(child.pid)if row['state']!='Z'];step['ownedBeforeCleanup']=live
    if live:
     os.killpg(child.pid,signal.SIGKILL);end=time.monotonic()+3
     while time.monotonic()<end and any(row['state']!='Z'for row in owned(child.pid)):time.sleep(.02)
    step['remainingLiveOwnedProcesses']=[row for row in owned(child.pid)if row['state']!='Z']
   step['elapsedSeconds']=time.monotonic()-began;text=(out/(step['name']+'.stdout')).read_text()
   if step['kind']=='tests':
    counts={}
    for key in ['tests','pass','fail','skipped','cancelled']:
     values=re.findall(r'^# '+key+r' (\d+)\s*$',text,re.M);counts[key]=int(values[-1])if values else None
    step['counts']=counts;step['lateUncaughtActivity']='asynchronous activity after'in text or'triggered an unhandledRejection'in text
   print(json.dumps(step),flush=True);(out/'steps.json').write_text(json.dumps(status['steps'],indent=2)+'\n')
   if step['exit']!=0 or step.get('deadlineExpired')or step['remainingLiveOwnedProcesses']:raise RuntimeError('Actual stage failure: '+step['name'])
   if step['kind']=='metadata':
    actual=json.loads(text.strip());step['actualNodeMetadata']=actual
    if actual!=specification['expectedMetadata']:raise RuntimeError('Actual Node/ABI/V8 mismatch: '+step['name'])
   else:
    if step['counts']!={'tests':step['cases'],'pass':step['cases'],'fail':0,'skipped':0,'cancelled':0}:raise RuntimeError('Actual reporter counts differ: '+step['name'])
    if step['lateUncaughtActivity']:raise RuntimeError('Actual late uncaught activity: '+step['name'])
    if specification.get('semanticReport'):
     rows=json.loads((out/(step['name']+'-comparisons.json')).read_text());step['wholeNativeReplies']=len(rows['comparisons']);step['allWholeNativeRepliesEqual']=all(row['actual']==row['expected']for row in rows['comparisons'])
     proofs=[json.loads(line.split('SEMANTIC_CREATION_PROOF ',1)[1])for line in text.splitlines()if'SEMANTIC_CREATION_PROOF 'in line];step['physicalObjects']=len(proofs);step['selectedVMNotHostBeforeAfterNull']=all(row[phase]=={'selected':True,'host':False,'global':True}for row in proofs for phase in ['before','after']);(out/(step['name']+'-physical.json')).write_text(json.dumps(proofs,indent=2)+'\n')
     if step['wholeNativeReplies']!=20 or not step['allWholeNativeRepliesEqual']or len(proofs)!=3 or not step['selectedVMNotHostBeforeAfterNull']:raise RuntimeError('Actual semantic/physical proof mismatch: '+step['name'])
   verify(BASE/'candidate-inputs.json',CANDIDATE);verify(HERE/'SDK-and-reference-inputs.json',Path('/'));verify(BASE/'tool-inputs.json',Path('/'))
  status['state']='PASS_SCOPED_FOLLOWUP_ONLY'
 except Exception as error:status['state']='FAILED_OR_INCOMPLETE';status['failure']={'type':type(error).__name__,'message':str(error)}
 finally:
  if child and child.poll()is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
  after=root_map();(out/'Root-after.json').write_text(json.dumps(after,indent=2)+'\n');status['changedRootInputs']=[name for name in sorted(set(before)|set(after))if before.get(name)!=after.get(name)];status['RootInputs']=len(before);status['elapsedSeconds']=time.monotonic()-start;status['actualPassed']=sum(row.get('counts',{}).get('pass')or 0 for row in status['steps'])
  for name,base in [('candidate-inputs.json',CANDIDATE),('tool-inputs.json',Path('/'))]:
   try:status[name+'StableCount']=verify(BASE/name,base)
   except Exception as error:status[name+'Failure']=str(error);status['state']='GUARD_FAILURE'
  try:status['SDK-and-referenceStableCount']=verify(HERE/'SDK-and-reference-inputs.json',Path('/'));verify(HERE/'inputs.json',HERE)
  except Exception as error:status['followupGuardFailure']=str(error);status['state']='GUARD_FAILURE'
  (out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
 if status['state']!='PASS_SCOPED_FOLLOWUP_ONLY'or status['changedRootInputs']or status['actualPassed']!=plan['cases']:raise SystemExit(1)
