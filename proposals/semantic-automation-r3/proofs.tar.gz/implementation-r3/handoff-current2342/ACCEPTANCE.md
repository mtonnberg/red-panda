# Evidence and limits

Accepted isolated graph: 5 syntax checks; 14 feature cases each Node 24.22/24.19/26.13; 217 existing DOM/Input/File/Runtime/frame/utility/LP/module/parser/namespace/XML/encoding cases on Node 24.22. All pass without skips/cancellations/late uncaught activity. Twenty applicable Native whole replies match on each SDK; three genuine V8 object proofs per SDK remain selected-VM/not-Host before/after null. Root 615/candidate 626/tool 519 and extra 8 pins stayed exact; owned processes closed.

R1 negative: 10/12, unexpected option records and missing content names plus omitted utility factory setup. R2 negative: 11/12, nineteen equal replies but two real internal-observer getter reads before LP; final navigation comparison unrun. Actual causal stacks separately proved both observers. R3 fixes genuine producers; no oracle/assertion/time changes or exception suppression. All prior epochs remain separate.

Handoff patch and source are exact tested bytes. Root integration remains unapplied/unrun. Full independent Lightpanda functionality is not complete.
