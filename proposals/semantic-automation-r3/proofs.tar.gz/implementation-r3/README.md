# Semantic R3 and canonical internal observers — STATIC, UNRUN

This is a new physical projection of Root `2342b41353f04c2ab3c4b40e85b847c0ba2bede4`, including the accepted XML/encoding/initial-parser/lifecycle changes. All 615 physical source/test/native/bin/scripts/package inputs matched before editing. Only the two Browser feature insertion hunks required context adaptation when composing the prior R2 semantic slice; no old Browser or XML source file was substituted. Root, R1, R2 and their actual negative evidence remain unchanged.

R2 produced nineteen whole Native reply comparisons and all nineteen matched. It then failed the genuine zero-getter-read assertion: two Runtime errors occurred during the mutation that reattached the poisoned button, before LP ran. Its final navigation comparison was unrun. The separate actual stack diagnostic proves `modules.js` discovery read localName in both controls, while `dom.js` child-insertion serialization added one read only with DOM notifications enabled. Before/after LP counters were identical. This was a real independent internal-observer gap, not a reason to change the LP oracle or hide errors.

R3 retains both internal observers and their actual work. DOM's owned serialization now reads canonical backend node metadata, actual tree order/whitespace, attributes, frame/template/shadow state and sibling links through the real first frontend cache. Private mutation records supply their actual target/added/removed backend nodes without invoking authored record accessors. Attribute and character-data notifications read real backend values. Existing node budgets, known/expanded state, event shapes and legacy non-owned serialization remain. Closed-shadow serialization keeps the prior omission policy; no new closed-shadow support is claimed.

Owned module discovery walks the real backend tree and uses the existing canonical selector kernel for the same descendant script selector. The explicit root check, real connected/type/parser-inserted state, canonical frontend and seen set remain actual producer decisions. The successful canonical MutationRecord factory supplies observer inputs. Original legacy embedding discovery remains unchanged. Discovery still starts the original real prepare/link/VM evaluation pipeline: no callback suppression, forced promises, dummy scripts, timing changes or synthetic module results. Arbitrary poisoned metadata on a selected script downstream of discovery remains a heldout; this patch does not claim every module producer bypasses every public getter.

A small Host-only `canonicalMutationRecord` reader in mutations.js resolves successful factory records. No observer registration/delivery/reporting/lifetime algorithm changes. It does not accept public symbols, names or prototypes as authority, allocate VM controller tables, filter exceptions or create substitute records. All ordinary reporting remains visible.

The eight-path registry/LP slice from R2 otherwise remains the same: actual context-owned monotonic DOM IDs, immutable successful factory authority, genuine first frontend/utility aliases and actual document-generation retirement; Runtime handles remain session-local. LP details, forms and interactive elements recompute actual backend state and private style visibility. No Source fixture ID/name branches, captured expected outputs or fake roles/trees were added. Red Panda branding and all current XML/lifecycle behavior remain protected. AX/semantic-tree surfaces are still unsupported.

## Prepared first gate

After review and an exclusive quiet grant:

```
python3 /workspace/shared/semantic-automation-implementation-r3/run-first-gate-r3.py
```

It checks five changed/context-adapted JavaScript files, then runs fourteen tests: the same original twelve, the same twenty whole Native replies/errors and three real V8 objects before/after prototype null, plus two true producer controls. Those require actual DOM insertion/attribute notification data and actual nested module evaluation beside a poisoned ordinary node. All observers remain enabled in these tests. They assert zero authored reads and zero Runtime errors. Cleanup restores authored replacements only after the observations, retaining failure propagation and closing owned resources.

The Native oracle, comparison mapping guard, original poison statements and twelve existing assertions are byte-identical to R2. No retry or Native rerun is included. RPC/readiness remains 2500 ms and authored evaluation 200 ms; existing test caps remain 6/10 seconds, new controls 6 seconds; administrative ceiling is 90 seconds. Estimated 7–18 seconds is unmeasured. All R3 JavaScript syntax and runtime remain unrun. Source/Node/dependency/native-artifact guards and fresh Root before/after maps protect this graph. Static export/apply/reverse checks are separate from behavioral acceptance.

The later protected regression plan expands the prior 132 cases with 85 actual module/classic/parser/namespace/XML/encoding cases, for 217 declared cases. All remain withheld until the first gate passes. Other SDKs are likewise unrun. Document.open/import/adopt/cross-target and broader names/roles/listener lifetimes remain Native-first heldouts; no reset-counter invalidation or future reused-global claim is introduced. Full semantic/accessibility parity is not claimed.
