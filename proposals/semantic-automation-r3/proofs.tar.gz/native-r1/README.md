# Semantic automation Native-first packet — STATIC / UNRUN

This packet contains source/interface notes and authored Native-only controls. **No JavaScript syntax/import, Node/browser process, HTTP listener, compiler or functional test has run.** It changes no Root source, test, configuration, dependency or original reference fixture. It imports no candidate engine and copies no Native implementation. Reading the pinned reference source supplies API contracts; it does not establish that the binary behaves identically.

Reference source: `948d773786380bae36f046639fc61e2ddddd212a`, with fifteen read-only source hashes in `native-source-inputs.json`. Reference binary: `/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux`, SHA256 `9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f`. The reference-process helper is an exact copied project helper using only Node builtins. No upstream engine function was copied into an implementation.

## Source inventory

`inventory.json` records the six exact handler schemas, errors, result representations and authority paths. LP's entries in the pinned `protocol.json` omit these detailed schemas, so names alone are insufficient.

| Method | Actual handler parameters | Result / key distinction |
| --- | --- | --- |
| `LP.getSemanticTree` | optional `format: "text"`, `prune`, `interactiveOnly`, `backendNodeId`, unsigned `maxDepth` | `semanticTree`; nested node JSON or text. Only `backendNodeId` scopes the root. |
| `LP.getInteractiveElements` | optional `nodeId` | `elements`; actual native/ARIA/contenteditable/listener/focusable classification, owner-frame names/styles. |
| `LP.getNodeDetails` | required `backendNodeId` | `nodeDetails`; actual selected node, not a selector/name lookup. Omitted params and missing required fields follow different paths. |
| `LP.detectForms` | handler does not parse params | `forms`; real form-associated controls, including external `form=` associations, typed exclusions and redacted values. |
| `Accessibility.getFullAXTree` | optional signed `depth`, `frameId` | flat `nodes`; actual frame Document. Zero/negative depth handling must be calibrated. |
| `Accessibility.getPartialAXTree` | optional `nodeId`, `backendNodeId`, `objectId`, `fetchRelatives` | flat selected/relative `nodes`; after whole-schema parsing, selector precedence is node ID, backend ID, then inspector object ID. |

Ordinary handler/parse errors are sent as `-31998` plus their actual error name; unknown methods/domains use `-32601`; invalid session IDs are rejected before dispatch with `-32001`; explicit frame errors use their own `-32000` text. STARTUP is a separate dispatch profile. Integer declaration alone is not proof of the wire parser's numeric-string/null behavior; the prepared matrix retains those actual responses rather than imposing assumed conversions.

The real registry is BrowserContext-owned and maps actual DOM-node identity to stable unsigned IDs. AX IDs serialize as strings, while DOM-backed `backendDOMNodeId` is numeric. Real synthetic ListMarker IDs have a separate owner map and no DOM backend; they must not be invented from positions or treated as ordinary DOM nodes. Each selected semantic/AX node resolves its actual owning frame. Frameless documents and retired-frame cases cannot borrow the current main Document's style/name context.

LP semantic traversal, interactive discovery and AX flat-tree/ignored traversal are different algorithms. The source does not justify one blanket hidden/ARIA/shadow policy for all three. Semantic trees do not automatically enter child frames; interactive discovery uses a DOM walk; AX has its own flattened relations and ignored-node handling. Whole actual objects and text are captured to measure these differences.

## Root inventory at preparation

The six requested CDP handlers and Accessibility enable/disable are absent from the inspected Root dispatch and domain sets. This is source inspection, not a newly executed unsupported-method result. Existing MCP `tree`, `interactiveElements`, `nodeDetails` and `detectForms` are separate public-DOM approximations with different schemas and IDs; they are not evidence of LP or AX parity.

Root's DOM selector resolver currently requires exactly one identifier, and CDP `backendId` storage is per session. Those cannot silently substitute for Native's parsed selector precedence and BrowserContext registry. `platformFactoryRecord`, canonical backend selector matching, and the actual private style resolver are useful future seams. Existing private Markdown traversal demonstrates backend/slot access but supplies neither a complete accessible-name/ARIA engine nor AX node authority. No implementation is proposed in this packet.

The preparation HEAD and Root source hashes are historical inventory only. If Parent applies EventCounts or other authorized work before a future run, the controller takes **fresh actual Root source/test/native maps at launch and afterward**. It does not require the old HEAD or claim that a Native-only result proves any Root behavior. The eighteen existing native artifact/receipt inputs are separately pinned and protected; none is loaded or rebuilt by the probe.

## Prepared controls

Exact future command, requiring a separate quiet runtime grant:

```
python3 /workspace/shared/semantic-automation-native-r1/run-native-r1.py
```

One ordinary Node driver starts one pinned Native process and one ephemeral loopback HTTP fixture. Twelve ordered groups contain **59 planned response observations**, plus at least 27 required setup CDP calls. These are planned observations, not passing assertions:

1. LP/AX calls before a real target.
2. All six default commands on actual button/form/label/hidden/ARIA content, including AX before enable.
3. Text/unpruned/interactive/depth/scoped semantic variants and an unknown field.
4. Omitted/null/missing/wrong/numeric-string parameters, invalid IDs/frame IDs and signed depth.
5. Partial AX selectors and earlier-selector precedence, enable acknowledgement and depth one.
6. Two genuine sessions on the same target: shared backend ID and foreign-session object ID.
7. Real HTTP child frame, distinct label/action names and actual frame ID.
8. Real open shadow root/slotted control and actual selected shadow node.
9. Actual DOM text/ARIA/form-value/checked-state mutations with existing IDs.
10. Detached retained node and a genuine inactive DOMParser document.
11. Authored getter/method overrides with an actual read counter; no assumed zero or swallowed internal errors.
12. Real main navigation followed by old backend/object ID observations and a new AX tree.

The fixture scripts create genuine DOM state. No role, semantic node, accessible name, tree shape, header, node ID or expected error is fabricated. Required DOM/inspector setup must return real IDs; a setup failure stops the probe and leaves later groups unobserved. Intended command errors remain complete raw responses and do not become success assertions. A connection closure or no-response deadline stops further groups.

An append-only progress journal records every wire message, fixture request and group transition as it occurs, retaining partial evidence even if the parent kills a stalled process. The final driver report records full sent/received messages and incoming bytes, all result/error fields, actual HTTP raw headers, real UA/client hints/version, fixture facts, group progress, PIDs, Native stderr/exit/signal and cleanup. There is no normalization, projection, property-name filtering or original-fixture change. Root keeps Red Panda branding; the reference's actual identity is recorded without spoofing.

## Bounds and resources

RPC and handshake limits remain 2500 ms. Explicit authored Runtime setup has a 200 ms VM limit; readiness observation has its own 2500 ms bound. The original copied reference helper retains its declared 10000 ms readiness and 1500 ms SIGTERM grace. One owned watchdog is 30000 ms; the parent allows 30 seconds followed by **one shared three-second cleanup grace**, then kills only its owned process group. All sockets, reference process and fixture server have real cleanup paths. A final owned SIGKILL is recorded as cleanup, not silently labeled a browser crash. No canonical ports, browser service restart, SDK matrix, build or heap enumeration is involved.

A normal run is expected to be short, but no timing success is claimed. The controller reports `OBSERVED_NOT_A_PARITY_PASS` only when all 12/59 structural observation slots completed, cleanup finished and actual inputs stayed stable. Received protocol errors still remain visible negatives; the label is not conformance acceptance.

Cross-target/context registry isolation, utility worlds, closed shadow roots, deeper ARIA/AccName cycles, all schema/coercion combinations, selected text/non-element roots, synthetic-marker method combinations, CSSOM/dynamic stylesheet visibility, dialog/popover overlays, domain enable/disable lifetimes and context disposal need later controls. This first packet cannot establish full accessibility/semantic parity, Native physical allocation or Root implementation correctness.
