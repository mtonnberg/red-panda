import {test} from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {once} from 'node:events';
import {readFile,writeFile} from 'node:fs/promises';
import {serve} from '../src/cdp.js';
import {connect} from './semantic-client.js';
const oracle=JSON.parse(await readFile(new URL('../docs/reference/semantic-automation/lp-native-subset.json',import.meta.url),'utf8'));
async function fixture(t,{navigate=true}={}){
 const files=await Promise.all(['main','frame','replacement'].map(name=>readFile(new URL('./semantic-'+name+'.html',import.meta.url))));
 const sockets=new Set(),fixture=http.createServer((request,response)=>{const index=['/fixture','/frame','/replacement'].indexOf(request.url);response.writeHead(index<0?404:200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});response.end(files[index]??'Actual owned route absent');});fixture.on('connection',socket=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket));socket.on('error',()=>{});});fixture.listen(0,'127.0.0.1');await once(fixture,'listening');
 const origin='http://127.0.0.1:'+fixture.address().port,service=await serve({port:0,loadResources:['iframe']}),client=await connect('ws://127.0.0.1:'+service.port+'/');let sessionId,targetId;
 t.after(async()=>{await client.close();await service.close();for(const socket of sockets)socket.destroy();fixture.closeAllConnections();await new Promise(resolve=>fixture.close(resolve));});
 const send=(method,params,sid=sessionId)=>client.send(method,params,sid),required=async(method,params,sid=sessionId)=>{const reply=await send(method,params,sid);assert.equal(reply.error,undefined,JSON.stringify(reply));return reply.result;};
 const evaluate=async(expression,sid=sessionId)=>{const value=await required('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,timeout:200},sid);assert.equal(value.exceptionDetails,undefined,JSON.stringify(value));return value.result.value;};
 async function load(){({targetId}=await required('Target.createTarget',{url:'about:blank'},null));({sessionId}=await required('Target.attachToTarget',{targetId,flatten:true},null));await required('Page.enable',{});await required('Runtime.enable',{});await required('Page.navigate',{url:origin+'/fixture'});const began=Date.now();let ready=false;while(Date.now()-began<2500){ready=await evaluate('document.readyState==="complete"&&globalThis.semanticReady===true&&document.getElementById("child").contentWindow?.frameReady===true');if(ready)break;await new Promise(resolve=>setTimeout(resolve,5));}assert.equal(ready,true);assert.deepEqual(await evaluate('semanticSetupErrors'),[]);}
 if(navigate)await load();return{service,client,origin,send,required,evaluate,load,get sessionId(){return sessionId},get targetId(){return targetId}};
}
function content(reply){return reply.error?{error:reply.error}:{result:reply.result};}
function normalize(value,origin,identities){
 if(Array.isArray(value))return value.map(item=>normalize(item,origin,identities));
 if(value&&typeof value==='object'){const result={};for(const[key,item]of Object.entries(value)){if(key==='backendNodeId'||key==='backendDOMNodeId'){assert.ok(identities.has(String(item)),'Unmapped actual backend identity '+item);result[key]=identities.get(String(item));}else result[key]=normalize(item,origin,identities);}return result;}
 return typeof value==='string'?value.replaceAll(origin,'OWNED_ORIGIN'):value;
}
test('twenty whole Native LP objects/errors use actual shared DOM identities across mutation, frames, detachment and retirement',{timeout:10000},async t=>{
 const f=await fixture(t),actualIdentities=new Map(),raw=[],comparisons=[];
 t.after(async()=>{if(process.env.SEMANTIC_REPORT)await writeFile(process.env.SEMANTIC_REPORT,JSON.stringify({raw,comparisons},null,2)+'\n');});
 const document=(await f.required('DOM.getDocument',{depth:0})).root.nodeId;
 for(const id of(await f.required('DOM.querySelectorAll',{nodeId:document,selector:'[id]'})).nodeIds){const node=(await f.required('DOM.describeNode',{nodeId:id,depth:0})).node,attributes=node.attributes;const index=attributes.indexOf('id');assert.ok(index>=0);actualIdentities.set(String(node.backendNodeId),'#'+attributes[index+1]);}
 const forms=(await f.required('DOM.querySelectorAll',{nodeId:document,selector:'form'})).nodeIds;forms.forEach((id,index)=>actualIdentities.set(String(id),'form:'+index));
 const button=(await f.required('DOM.querySelector',{nodeId:document,selector:'#plain'})).nodeId;
 async function node(expression){const remote=(await f.required('Runtime.evaluate',{expression,returnByValue:false,timeout:200})).result;assert.equal(typeof remote.objectId,'string');const value=(await f.required('DOM.describeNode',{objectId:remote.objectId,depth:0})).node,attributes=value.attributes,index=attributes.indexOf('id');if(index>=0)actualIdentities.set(String(value.backendNodeId),'#'+attributes[index+1]);return{...value,objectId:remote.objectId};}
 async function compare(epoch,name,params,sid=f.sessionId){const expected=oracle.epochs[epoch],row=expected.rows.find(row=>row.name===name);assert.ok(row,name);const response=await f.send(row.method,params,sid);raw.push({epoch,name,params,response});const a=normalize(content(response),f.origin,actualIdentities),e=normalize(content(row.response),expected.origin,new Map(Object.entries(expected.nodeIdentityLabels)));comparisons.push({epoch,name,actual:a,expected:e});assert.deepEqual(a,e,name);}
 await compare('r1','interactive default',{});await compare('r1','details real button',{backendNodeId:button});await compare('r1','forms default',{});
 await compare('r1','required details params omitted',undefined);await compare('r1','required details field missing',{});await compare('r1','numeric-string actual backend',{backendNodeId:String(button)});await compare('r1','unknown details backend',{backendNodeId:4294967295});await compare('r1','unknown interactive root',{nodeId:4294967295});
 const second=(await f.required('Target.attachToTarget',{targetId:f.targetId,flatten:true},null)).sessionId;await compare('r2','backend via second real session',{backendNodeId:button},second);
 const child=await node('document.getElementById("child").contentDocument.getElementById("frame-action")');await compare('r2','child details use child label',{backendNodeId:child.backendNodeId});await compare('r2','child interactive root',{nodeId:child.nodeId});
 const shadow=await node('heldShadow'),host=(await f.required('DOM.querySelector',{nodeId:document,selector:'#shadow-host'})).nodeId;await compare('r2','shadow actual node details',{backendNodeId:shadow.backendNodeId});await compare('r2','shadow host interactive walk',{nodeId:host});
 await f.evaluate('(()=>{heldButton.setAttribute("aria-label","Changed action");heldButton.textContent="Changed button contents";document.getElementById("email").value="changed@example.test";document.getElementById("check").checked=true;document.getElementById("role-button").setAttribute("aria-pressed","true");return true})()');await compare('r2','same node live details',{backendNodeId:button});await compare('r2','live interactive values',{});await compare('r2','live forms values',{});
 await f.evaluate('heldButton.remove();true');await compare('r2','detached actual backend details',{backendNodeId:button});const inactive=await node('(globalThis.framelessNode=new DOMParser().parseFromString("<r><button>inactive</button></r>","application/xml").documentElement)');await compare('r2','frameless backend details',{backendNodeId:inactive.backendNodeId});
 await f.evaluate('(()=>{document.body.append(heldButton);globalThis.semanticTrapReads=0;for(const key of ["localName","tagName","ownerDocument","textContent"])Object.defineProperty(heldButton,key,{configurable:true,get(){semanticTrapReads++;throw Error("Authored getter read: "+key)}});Object.defineProperty(heldButton,"getAttribute",{configurable:true,value(){semanticTrapReads++;throw Error("Authored getAttribute read")}});return true})()');await compare('r2','details with authored getters',{backendNodeId:button});assert.deepEqual(await f.evaluate('({reads:semanticTrapReads,listenerActivations})'),{reads:0,listenerActivations:0});
 await f.required('Page.navigate',{url:f.origin+'/replacement'});await compare('r2','old backend after real navigation',{backendNodeId:button});assert.equal(comparisons.length,20);
});
test('schema conversion and no-context errors preserve genuine optional/required parameter distinctions',{timeout:6000},async t=>{
 const f=await fixture(t,{navigate:false});for(const[method,params,message]of[['LP.getInteractiveElements',{},'NoBrowserContext'],['LP.detectForms',{},'NoBrowserContext'],['LP.getNodeDetails',undefined,'InvalidParam'],['LP.getNodeDetails',{},'MissingField'],['LP.getNodeDetails',{backendNodeId:-1},'Overflow'],['LP.getNodeDetails',{backendNodeId:'x'},'InvalidCharacter'],['LP.getNodeDetails',{backendNodeId:true},'UnexpectedToken']]){const reply=await f.send(method,params,null);assert.deepEqual(reply.error,{code:-31998,message});}
});
test('actual Runtime objects stay session-bound while closing one session preserves shared numeric node lookup',{timeout:6000},async t=>{
 const f=await fixture(t),root=(await f.required('DOM.getDocument',{depth:0})).root.nodeId,button=(await f.required('DOM.querySelector',{nodeId:root,selector:'#plain'})).nodeId,object=(await f.required('Runtime.evaluate',{expression:'heldButton',returnByValue:false})).result.objectId;
 const second=(await f.required('Target.attachToTarget',{targetId:f.targetId,flatten:true},null)).sessionId;const wrong=await f.send('Runtime.callFunctionOn',{objectId:object,functionDeclaration:'function(){return this.nodeType}',returnByValue:true},second);assert.equal(wrong.error.code,-32000);assert.match(wrong.error.message,/Could not find object/);
 await f.required('Target.detachFromTarget',{sessionId:f.sessionId},null);assert.equal((await f.required('LP.getNodeDetails',{backendNodeId:button},second)).nodeDetails.name,'Original action');
});
test('listener classification follows real add/remove state and does not activate callbacks',{timeout:6000},async t=>{
 const f=await fixture(t);await f.evaluate('globalThis.dynamic=document.createElement("div");dynamic.id="dynamic";dynamic.textContent="Live listener";globalThis.activation=0;globalThis.callback=()=>{activation++};document.body.append(dynamic);true');
 const has=async()=>((await f.required('LP.getInteractiveElements',{})).elements).find(value=>value.id==='dynamic');assert.equal(await has(),undefined);await f.evaluate('dynamic.addEventListener("click",callback);true');assert.deepEqual((await has()).listeners,['click']);assert.equal((await has()).type,'listener');await f.evaluate('dynamic.removeEventListener("click",callback);true');assert.equal(await has(),undefined);assert.equal(await f.evaluate('activation'),0);
});
test('all three LP readers ignore authored control/form getters while reporting actual live form state',{timeout:6000},async t=>{
 const f=await fixture(t);await f.evaluate('(()=>{globalThis.controlReads=0;for(const id of ["email","actual-form"]){const node=document.getElementById(id);for(const key of ["value","disabled","form","elements","ownerDocument","getAttribute"])Object.defineProperty(node,key,{configurable:true,get(){controlReads++;throw Error("authored control getter")}})}return true})()');
 const forms=(await f.required('LP.detectForms',{})).forms;assert.equal(forms[0].fields[0].value,'first@example.test');const interactive=(await f.required('LP.getInteractiveElements',{})).elements;assert.equal(interactive.find(value=>value.id==='email').name,'Email from actual label');const root=(await f.required('DOM.getDocument',{depth:0})).root.nodeId,button=(await f.required('DOM.querySelector',{nodeId:root,selector:'#plain'})).nodeId;assert.equal((await f.required('LP.getNodeDetails',{backendNodeId:button})).nodeDetails.name,'Original action');assert.equal(await f.evaluate('controlReads'),0);
});
test('semantic-tree and Accessibility data methods retain explicit unsupported status until real traversal producers exist',{timeout:6000},async t=>{
 const f=await fixture(t);for(const method of['LP.getSemanticTree','Accessibility.getFullAXTree','Accessibility.getPartialAXTree'])assert.equal((await f.send(method,{})).error.code,-32601);
});
