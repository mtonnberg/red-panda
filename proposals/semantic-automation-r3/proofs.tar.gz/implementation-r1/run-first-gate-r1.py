#!/usr/bin/env python3
"""Frozen isolated first gate; execute only after Parent's quiet lease."""
import ast,hashlib,json,os,pathlib,re,resource,signal,subprocess,time
BASE=pathlib.Path(__file__).resolve().parent;CANDIDATE=BASE/'candidate';ROOT=pathlib.Path('/workspace/red-panda');NODE=pathlib.Path('/workspace/shared/rea-tools/node_modules/node/bin/node')
def digest(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def verify(manifest,base):
 values=json.loads(manifest.read_text());bad=[name for name,value in values.items()if not(base/name).is_file()or digest(base/name)!=value]
 if bad:raise RuntimeError('Actual frozen input mismatch: '+str(bad))
 return len(values)
def root_map():return{str(file.relative_to(ROOT)):digest(file)for folder in ['src','test','native','bin','scripts']for file in sorted((ROOT/folder).rglob('*'))if file.is_file()}
def owned(group):
 found=[]
 for file in pathlib.Path('/proc').iterdir():
  if not file.name.isdecimal():continue
  try:
   text=(file/'stat').read_text();fields=text[text.rfind(')')+2:].split()
   if int(fields[2])==group:found.append({'pid':int(file.name),'state':fields[0]})
  except(OSError,ValueError,IndexError):pass
 return found
verify(BASE/'candidate-inputs.json',CANDIDATE);verify(BASE/'Root79-source-before.json',ROOT);verify(BASE/'tool-inputs.json',pathlib.Path('/'));verify(BASE/'packet-inputs.json',BASE)
declared=json.loads((BASE/'Root79-source-before.json').read_text());current=root_map();current.update({name:digest(ROOT/name)for name in ['package.json','package-lock.json']});
if current!=declared:raise SystemExit('Actual Root graph differs from the frozen Root79 projection, including added/removed inputs')
out=BASE/'first-gate-r1';out.mkdir(exist_ok=False);before=root_map();(out/'Root-before.json').write_text(json.dumps(before,indent=2)+'\n');started=time.monotonic();env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';env['SEMANTIC_REPORT']=str(out/'actual-native-comparisons.json')
for key in ['NO_PROXY','no_proxy']:env[key]=','.join(filter(None,[env.get(key,''),'127.0.0.1,localhost,0.0.0.0']))
status={'state':'RUNNING','commandCount':0,'expectedTests':12,'expectedWholeNativeComparisons':20,'expectedPhysicalObjects':3,'originalRPCMilliseconds':2500,'originalAuthoredVMTimeout':200,'administrativeSeconds':90,'canonicalProxyEnv':True,'NodeBinarySHA256':digest(NODE),'stages':[]};child=None
try:
 changes=json.loads((BASE/'source-delta.json').read_text());syntax=[name for name in changes if name.endswith('.js')]
 commands=[('syntax-'+str(index),[str(NODE),'--check',name],10)for index,name in enumerate(syntax)]
 commands.append(('focused12',[str(NODE),'--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','test/semantic-registry.test.js','test/semantic-commands.test.js'],90))
 for label,command,cap in commands:
  remaining=90-(time.monotonic()-started)
  if remaining<=0:raise RuntimeError('Administrative deadline exhausted before '+label)
  stage={'name':label,'command':command,'originalStageCapSeconds':cap};status['stages'].append(stage);status['commandCount']+=1
  with(out/(label+'.stdout')).open('wb')as stdout,(out/(label+'.stderr')).open('wb')as stderr:
   def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
   child=subprocess.Popen(command,cwd=CANDIDATE,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);stage['pid']=child.pid
   try:stage['exit']=child.wait(timeout=min(cap,remaining))
   except subprocess.TimeoutExpired:stage['deadlineExpired']=True;stage['ownedAtDeadline']=owned(child.pid);os.killpg(child.pid,signal.SIGKILL);stage['exit']=child.wait()
   survivors=[value for value in owned(child.pid)if value['state']!='Z'];stage['ownedBeforeCleanup']=survivors
   if survivors:
    os.killpg(child.pid,signal.SIGKILL);end=time.monotonic()+3
    while time.monotonic()<end and any(value['state']!='Z'for value in owned(child.pid)):time.sleep(.02)
   stage['remainingLiveOwned']=[value for value in owned(child.pid)if value['state']!='Z']
  print(json.dumps(stage),flush=True)
  if stage['exit']!=0 or stage.get('deadlineExpired')or stage['remainingLiveOwned']:raise RuntimeError('Actual stage failure: '+label)
  if label=='focused12':
   text=(out/(label+'.stdout')).read_text();summary={key:int(re.search(r'^# '+key+r' (\d+)\s*$',text,re.M).group(1))for key in ['tests','pass','fail','skipped']};stage['summary']=summary
   if summary!={'tests':12,'pass':12,'fail':0,'skipped':0}:raise RuntimeError('Actual test summary mismatch: '+str(summary))
   proof=[json.loads(line.split('SEMANTIC_CREATION_PROOF ',1)[1])for line in text.splitlines()if'SEMANTIC_CREATION_PROOF 'in line];stage['physicalObjects']=len(proof);(out/'physical-proofs.json').write_text(json.dumps(proof,indent=2)+'\n')
   if len(proof)!=3:raise RuntimeError('Actual physical proof count mismatch')
   comparisons=json.loads((out/'actual-native-comparisons.json').read_text());stage['wholeNativeComparisons']=len(comparisons['comparisons'])
   if stage['wholeNativeComparisons']!=20 or any(row['actual']!=row['expected']for row in comparisons['comparisons']):raise RuntimeError('Actual whole Native comparison mismatch')
   stage['lateUncaughtActivity']='asynchronous activity after'in text or'triggered an unhandledRejection'in text
   if stage['lateUncaughtActivity']:raise RuntimeError('Actual late uncaught activity')
 status['state']='PASS_ISOLATED_FIRST_GATE_ONLY'
except Exception as error:status['state']='FAILED_OR_INCOMPLETE';status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 if child and child.poll()is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
 after=root_map();(out/'Root-after.json').write_text(json.dumps(after,indent=2)+'\n');status['changedRootInputs']=[name for name in sorted(set(before)|set(after))if before.get(name)!=after.get(name)];status['RootInputs']=len(before);status['elapsedSeconds']=time.monotonic()-started
 for name,base in [('candidate-inputs.json',CANDIDATE),('tool-inputs.json',pathlib.Path('/'))]:
  try:status[name+'StableCount']=verify(BASE/name,base)
  except Exception as error:status[name+'Failure']=str(error);status['state']='GUARD_FAILURE'
 (out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
if status['state']!='PASS_ISOLATED_FIRST_GATE_ONLY'or status['changedRootInputs']:raise SystemExit(1)
