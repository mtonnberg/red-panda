// Separate causal observation only; original R2 sources/assertions remain exact.
import {writeFile} from 'node:fs/promises';
import {serve} from '/workspace/shared/semantic-automation-implementation-r2/candidate/src/cdp.js';
import {connect} from '/workspace/shared/semantic-automation-implementation-r2/candidate/test/semantic-client.js';
const output=process.argv[2],wire=[],rows=[],started=Date.now();let service,client,error,expired=false;
const watchdog=setTimeout(()=>{expired=true;client?.socket.terminate();},5000);watchdog.unref();
try{
 service=await serve({port:0});client=await connect('ws://127.0.0.1:'+service.port+'/',{recordWire:value=>wire.push({...value,atMS:Date.now()-started})});
 async function required(method,params={},sessionId){const response=await client.send(method,params,sessionId);if(response.error)throw Error(JSON.stringify(response));return response.result;}
 async function evaluate(sessionId,expression){const value=await required('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,timeout:200},sessionId);if(value.exceptionDetails)throw Error(JSON.stringify(value));return value.result.value;}
 for(const DOMEnabled of[true,false]){
  const{targetId}=await required('Target.createTarget',{url:'about:blank'}),{sessionId}=await required('Target.attachToTarget',{targetId,flatten:true});
  await required('Runtime.enable',{},sessionId);
  await required('Page.navigate',{url:'data:text/html,'+encodeURIComponent('<!doctype html><title>Actual observer trace</title><body><button id="held">Actual button</button><script>globalThis.heldButton=document.getElementById("held")</script>')},sessionId);
  const ready=await evaluate(sessionId,'({readyState:document.readyState,hasButton:!!heldButton})');if(ready.readyState!=='complete'||!ready.hasButton)throw Error('Actual fixture not ready');
  const document=(await required('DOM.getDocument',{depth:0},sessionId)).root.nodeId,nodeId=(await required('DOM.querySelector',{nodeId:document,selector:'#held'},sessionId)).nodeId;
  await evaluate(sessionId,'heldButton.remove();true');if(!DOMEnabled)await required('DOM.disable',{},sessionId);
  const row={DOMEnabled,targetId,sessionId,nodeId,wireBeforePoison:wire.length};rows.push(row);
  await evaluate(sessionId,'(()=>{document.body.append(heldButton);globalThis.semanticTrapReads=0;globalThis.semanticTrapStacks=[];for(const key of ["localName","tagName","ownerDocument","textContent"])Object.defineProperty(heldButton,key,{configurable:true,get(){semanticTrapReads++;const error=new Error("Actual observer getter: "+key);semanticTrapStacks.push({key,stack:error.stack});throw error}});Object.defineProperty(heldButton,"getAttribute",{configurable:true,value(){semanticTrapReads++;const error=new Error("Actual observer getter: getAttribute");semanticTrapStacks.push({key:"getAttribute",stack:error.stack});throw error}});return true})()');
  row.beforeLP=await evaluate(sessionId,'({reads:semanticTrapReads,stacks:semanticTrapStacks})');
  row.LP=await required('LP.getNodeDetails',{backendNodeId:nodeId},sessionId);
  row.afterLP=await evaluate(sessionId,'({reads:semanticTrapReads,stacks:semanticTrapStacks})');row.wireAfterLP=wire.length;
  // Cleanup only after every diagnostic read/result has been captured. This
  // does not alter the original poison assertion or hide unrelated errors.
  await evaluate(sessionId,'(()=>{for(const key of ["localName","tagName","ownerDocument","textContent","getAttribute"])delete heldButton[key];return true})()');
  await required('Target.closeTarget',{targetId});row.complete=true;
 }
}catch(failure){error={name:failure.name,message:failure.message,stack:failure.stack};}
finally{const cleanup=[];try{await client?.close();}catch(failure){cleanup.push({owner:'client',message:failure.message});}try{await service?.close();}catch(failure){cleanup.push({owner:'service',message:failure.message});}clearTimeout(watchdog);await writeFile(output,JSON.stringify({status:!error&&!expired&&!cleanup.length&&rows.length===2&&rows.every(row=>row.complete)?'CAUSAL_OBSERVATIONS_COMPLETE_NOT_A_PASS':'FAILED_OR_INCOMPLETE',rows,wire,error,expired,cleanup,Node:{pid:process.pid,version:process.version,abi:process.versions.modules},elapsedMS:Date.now()-started,policy:'Stack-marked diagnostic only. Default path plus real supported DOM.disable control; neither is accepted as a fix. Original R2 production and twelve-test oracle/assertions are untouched. Actual 2500ms RPC/200ms VM/5000ms owned budgets. Getter restoration is cleanup only after capturing all observations. No Native run, Root edits, retries or event/error suppression.'},null,2)+'\n',{flag:'wx'});}
if(error||expired)process.exitCode=1;
