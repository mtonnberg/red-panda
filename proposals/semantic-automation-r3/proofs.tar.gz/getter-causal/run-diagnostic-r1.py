#!/usr/bin/env python3
"""Prepared, UNRUN Native-only controls. No candidate engine import or build."""
import hashlib,json,os,pathlib,signal,subprocess,time,resource
BASE=pathlib.Path(__file__).resolve().parent;ROOT=pathlib.Path('/workspace/red-panda');NODE=pathlib.Path('/workspace/shared/rea-tools/node_modules/node/bin/node');NATIVE=pathlib.Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux')
hashfile=lambda file:hashlib.sha256(pathlib.Path(file).read_bytes()).hexdigest()
for manifest,base in [('packet-inputs.json',BASE),('tool-inputs.json',pathlib.Path('/')),('candidate-inputs.json',pathlib.Path('/workspace/shared/semantic-automation-implementation-r2/candidate'))]:
 entries=json.loads((BASE/manifest).read_text())
 for name,expected in entries.items():
  file=pathlib.Path(name)if name.startswith('/')else base/name
  if not file.is_file()or hashfile(file)!=expected:raise SystemExit('Actual frozen input mismatch: '+str(file))
def root_snapshot():return {str(file.relative_to(ROOT)):hashfile(file)for directory in ['src','test','native']for file in sorted((ROOT/directory).rglob('*'))if file.is_file()}
def owned(group):
 values=[]
 for entry in pathlib.Path('/proc').iterdir():
  if not entry.name.isdecimal():continue
  try:
   text=(entry/'stat').read_text();fields=text[text.rfind(')')+2:].split()
   if int(fields[2])==group:values.append({'pid':int(entry.name),'state':fields[0],'parent':int(fields[1]),'group':int(fields[2])})
  except (OSError,ValueError,IndexError):pass
 return values
out=BASE/'actual-diagnostic-r1';out.mkdir(exist_ok=False);before=root_snapshot();(out/'Root-source-before.json').write_text(json.dumps(before,indent=2)+'\n');env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1'
for key in ['NO_PROXY','no_proxy']:env[key]=','.join(filter(None,[env.get(key,''),'127.0.0.1,localhost,0.0.0.0']))
status={'state':'STARTING','plannedIndependentControls':2,'RPCMilliseconds':2500,'NodeOwnedMilliseconds':5000,'parentSeconds':8,'cleanupGraceSeconds':3,'RootGuardMeaning':'Fresh actual current Parent Root sources/tests/native are protected. The diagnostic imports only the frozen R2 candidate engine, its declared Node dependencies and exact native artifacts; current Parent Root behavior is not executed or claimed equivalent.','proxyBypassSHA256':hashlib.sha256((env['NO_PROXY']+'\n'+env['no_proxy']).encode()).hexdigest(),'NodeOptionsSHA256':hashlib.sha256(env.get('NODE_OPTIONS','').encode()).hexdigest()};start=time.monotonic();child=None
try:
 with (out/'Node.stdout').open('wb')as stdout,(out/'Node.stderr').open('wb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  command=[str(NODE),'--experimental-vm-modules',str(BASE/'probe.mjs'),str(out/'observations.json')];child=subprocess.Popen(command,cwd=BASE,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);status.update({'command':command,'pid':child.pid,'state':'RUNNING'})
  try:status['exit']=child.wait(timeout=8)
  except subprocess.TimeoutExpired:
   cleanup_end=time.monotonic()+3;status['deadlineExpired']=True;status['ownedAtDeadline']=owned(child.pid);os.killpg(child.pid,signal.SIGTERM)
   try:status['exit']=child.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);status['exit']=child.wait();status['forcedGroupKill']=True
  cleanup_end=locals().get('cleanup_end',time.monotonic()+3)
  survivors=[entry for entry in owned(child.pid)if entry['state']!='Z'];status['ownedBeforeCleanup']=survivors
  if survivors:
   os.killpg(child.pid,signal.SIGKILL);status['forcedRemainingGroupKill']=True
   while time.monotonic()<cleanup_end and any(entry['state']!='Z'for entry in owned(child.pid)):time.sleep(.02)
  status['ownedAfterCleanup']=owned(child.pid)
 if (out/'observations.json').exists():
  raw=json.loads((out/'observations.json').read_text());status.update({'rawStatus':raw.get('status'),'completedControls':sum(row.get('complete',False)for row in raw.get('rows',[])),'actualError':raw.get('error'),'actualRows':raw.get('rows'),'rawSHA256':hashfile(out/'observations.json')})
 status['state']='OBSERVATIONS_COMPLETE_NOT_A_PASS'if status.get('exit')==0 and status.get('rawStatus')=='CAUSAL_OBSERVATIONS_COMPLETE_NOT_A_PASS'and status.get('completedControls')==2 and not status.get('deadlineExpired')else'INCOMPLETE_OR_FAILED'
except Exception as error:status['state']='CONTROLLER_FAILURE';status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 if child is not None and child.poll()is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
 after=root_snapshot();(out/'Root-source-after.json').write_text(json.dumps(after,indent=2)+'\n');status['changedRootInputs']=[name for name in sorted(set(before)|set(after))if before.get(name)!=after.get(name)];status['RootInputs']=len(before);status['elapsedSeconds']=time.monotonic()-start
 status['remainingLiveOwnedProcesses']=[]if child is None else[entry for entry in owned(child.pid)if entry['state']!='Z'];(out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
if status['state']!='OBSERVATIONS_COMPLETE_NOT_A_PASS'or status['changedRootInputs']or status['remainingLiveOwnedProcesses']:raise SystemExit(1)
