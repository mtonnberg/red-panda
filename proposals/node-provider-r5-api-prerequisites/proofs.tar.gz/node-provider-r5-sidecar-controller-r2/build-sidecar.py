#!/usr/bin/env python3
"""UNRUN: explicitly leased build-only derivative; no API/browser execution."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Assertions must remain enabled; use python3 -I -B')
D = Path(__file__).resolve().parent
R1 = Path('/workspace/shared/node-provider-r5-entry-prerequisite-r1')
R1_SHA = '2da5298cc5a1141bd1ec2c04df494c549a8807ead8dc22653216f295ff0a6a0b'
CAP = 300
COMMAND_CAP = 120
CLEANUP = 2
GUARD_RESERVE = 10
START = time.monotonic()


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def ident(pid):
    try:
        text = Path(f'/proc/{pid}/stat').read_text()
        fields = text[text.rfind(')') + 2:].split()
        try:
            executable = str(Path(f'/proc/{pid}/exe').resolve(strict=True))
        except OSError:
            executable = None
        return {
            'pid': int(pid), 'state': fields[0], 'ppid': int(fields[1]),
            'pgid': int(fields[2]), 'sid': int(fields[3]),
            'startTicks': fields[19],
            'argv': Path(f'/proc/{pid}/cmdline').read_bytes().decode(
                errors='replace').strip('\0').split('\0'),
            'executable': executable,
        }
    except (FileNotFoundError, ProcessLookupError):
        return None


def same(first, second):
    return (first is not None and second is not None and
            first['pid'] == second['pid'] and
            first['startTicks'] == second['startTicks'])


def members(sid):
    result = []
    for item in Path('/proc').iterdir():
        if item.name.isdigit():
            actual = ident(int(item.name))
            if actual and actual['sid'] == sid:
                result.append(actual)
    return sorted(result, key=lambda item: item['pid'])


def tree(path):
    root = Path(path)
    rows = []
    if root.exists():
        for item in sorted(root.rglob('*')):
            kind = ('symlink' if item.is_symlink() else
                    'file' if item.is_file() else
                    'dir' if item.is_dir() else 'other')
            row = {'path': str(item.relative_to(root)), 'kind': kind}
            if kind == 'symlink':
                row['target'] = os.readlink(item)
            rows.append(row)
    return {'path': str(root), 'exists': root.exists(), 'entries': rows}


parser = argparse.ArgumentParser()
parser.add_argument('--manifest-sha', required=True)
parser.add_argument('--epoch', required=True)
args = parser.parse_args()
assert args.epoch and all(c.isalnum() or c in '-_' for c in args.epoch)
# Both reviewed packet identities are required BEFORE any spawn.
assert sha(D / 'manifest.json') == args.manifest_sha, 'Reviewed R2 manifest differs'
manifest = json.loads((D / 'manifest.json').read_text())
assert all(sha(D / name) == digest for name, digest in manifest['files'].items())
assert sha(R1 / 'manifest.json') == R1_SHA, 'Reviewed R1 manifest differs'
r1_manifest = json.loads((R1 / 'manifest.json').read_text())
assert all(sha(R1 / row['path']) == row['sha256'] for row in r1_manifest['files'])
freeze = json.loads((D / 'input-freeze.json').read_text())
plan = json.loads((D / 'compile-link-plan.json').read_text())
assert len(plan['commands']) == 4
assert all(row['capSeconds'] == COMMAND_CAP for row in plan['commands'])
assert plan['originalManifestSHA256'] == R1_SHA
OUT = D / 'evidence' / args.epoch
OUT.mkdir(parents=True, exist_ok=False)
BUILD = D / 'build'
record = {
    'state': 'SETUP', 'scope': 'NEW_SIDECAR_OBJECTS_AND_NEW_NODE_CCTEST_ONLY',
    'reviewedManifestSHA256': args.manifest_sha, 'R1ManifestSHA256': R1_SHA,
    'caps': {'eachOriginalCommandSeconds': COMMAND_CAP, 'cleanupSeconds': CLEANUP,
             'guardAdmissionReserveSeconds': GUARD_RESERVE, 'aggregateSeconds': CAP},
    'stages': [{**row, 'state': 'UNRUN', 'admitted': False}
               for row in plan['commands']],
    'actualNodeOrBrowserCasesRun': 0,
    'originalDetachAsyncAndGCNegatives': 'UNCHANGED',
    'sourceVariants': 'R1 supplemental header/TU unchanged; full-header variant NOT linked',
    'controllerSignals': [],
}
active = None
finalizing = False


def save():
    record['elapsedSeconds'] = time.monotonic() - START
    write(OUT / 'report.json', record)


def guard():
    wanted = dict(freeze['files'])
    wanted.update({str(D / name): digest for name, digest in manifest['files'].items()})
    wanted[str(D / 'manifest.json')] = args.manifest_sha
    bad = {}
    for name, digest in wanted.items():
        try:
            actual = sha(name)
        except OSError as error:
            actual = 'UNREADABLE:' + str(error)
        if actual != digest:
            bad[name] = {'expected': digest, 'actual': actual}
    metadata = []
    for name, expected in freeze['pathResolutions'].items():
        item = Path(name)
        actual = {'resolved': str(item.resolve()),
                  'directLink': os.readlink(item) if item.is_symlink() else None}
        if actual != expected:
            metadata.append({'pathResolution': name, 'actual': actual, 'expected': expected})
    for expected in freeze['rootInventories']:
        if tree(expected['path']) != expected:
            metadata.append({'changedIncludeRootInventory': expected['path']})
    for kind in ['linkSearchDirectoryNames', 'pathSearchDirectoryNames']:
        for name, expected in freeze[kind].items():
            directory = Path(name)
            actual = {'exists': directory.is_dir(),
                      'entries': sorted(x.name for x in directory.iterdir())
                      if directory.is_dir() else []}
            if actual != expected:
                metadata.append({'changedSearchDirectory': name, 'kind': kind})
    for name, expected in freeze['environment'].items():
        raw = os.fsencode(os.environ.get(name, ''))
        actual = {'present': name in os.environ, 'bytes': len(raw),
                  'sha256': hashlib.sha256(raw).hexdigest()}
        if actual != expected:
            metadata.append({'changedEnvironment': name, 'expected': expected, 'actual': actual})
    return {'stable': not bad and not metadata, 'fileCount': len(wanted),
            'fileMismatches': bad, 'metadataMismatches': metadata}


def interrupt(signum, frame):
    record['controllerSignals'].append({'signal': int(signum),
                                        'elapsedSeconds': time.monotonic() - START,
                                        'duringFinalCleanup': finalizing})
    if not finalizing:
        raise InterruptedError('Controller received actual signal ' + str(signum))


def aggregate(signum, frame):
    record['aggregateAdministrativeTimeout'] = True
    interrupt(signum, frame)


signal.signal(signal.SIGTERM, interrupt)
signal.signal(signal.SIGINT, interrupt)
signal.signal(signal.SIGALRM, aggregate)
signal.setitimer(signal.ITIMER_REAL, max(.001, CAP - (time.monotonic() - START)))


def signal_groups(child, saved, row, signum):
    # The direct child is deliberately kept UNREAPED through session cleanup.
    # Its start identity reserves the session leader PID even if it is a zombie.
    assert child.returncode is None, 'Leader already reaped; no session signal authority'
    authority = ident(saved['pid'])
    assert same(saved, authority), 'Saved leader start identity no longer matches'
    assert authority['sid'] == saved['sid'] == saved['pid']
    snapshot = members(saved['sid'])
    for pgid in sorted({item['pgid'] for item in snapshot if item['state'] != 'Z'}):
        assert pgid != os.getpgrp(), 'Refuse controller process group'
        # Reauthenticate immediately BEFORE EACH group signal.
        authority = ident(saved['pid'])
        assert same(saved, authority) and authority['sid'] == saved['sid']
        current = [item for item in members(saved['sid'])
                   if item['pgid'] == pgid and item['state'] != 'Z']
        if not current:
            continue
        assert any(same(item, ident(item['pid'])) for item in current)
        action = {'pgid': pgid, 'signal': int(signum), 'authority': authority,
                  'actualMembers': current, 'elapsedSeconds': time.monotonic() - START}
        row.setdefault('groupSignals', []).append(action)
        save()
        try:
            os.killpg(pgid, signum)
            action['result'] = 'sent'
        except ProcessLookupError:
            action['result'] = 'already-gone'
        except OSError as error:
            action['result'] = 'signal-failed'
            action['error'] = str(error)
            raise


def initial_identity_close(child, row):
    # No group inference or killpg is permitted after initial identity failure.
    # Popen has not been polled or waited; its unreaped direct child alone is safe.
    before = ident(child.pid)
    entry = {'mode': 'INITIAL_IDENTITY_FAILURE_DIRECT_POPEN_CHILD_ONLY',
             'before': before, 'directSignals': [],
             'possibleSessionBeforeObservationOnly': members(child.pid)}
    row.setdefault('cleanupEpochs', []).append(entry)
    try:
        entry['directSignals'].append({'method': 'Popen.terminate', 'signal': int(signal.SIGTERM)})
        child.terminate()
        try:
            child.wait(timeout=1)
        except subprocess.TimeoutExpired:
            entry['directSignals'].append({'method': 'Popen.kill', 'signal': int(signal.SIGKILL)})
            child.kill()
            child.wait(timeout=1)
    finally:
        entry['returnCode'] = child.returncode
        entry['possibleSessionAfterObservationOnly'] = members(child.pid)
        entry['unverifiedDescendantOwnership'] = True
        row['cleanupIdentityFailure'] = True
        row['returnCode'] = child.returncode
        row['signal'] = -child.returncode if child.returncode is not None and child.returncode < 0 else None
        save()


def close(child, saved, row):
    if saved is None:
        initial_identity_close(child, row)
        return
    # Each cleanup call gets at most the original total2s, not2s per signal.
    until = time.monotonic() + CLEANUP
    before = members(saved['sid'])
    epoch = {'membersBeforeCleanup': before, 'start': time.monotonic()}
    row.setdefault('cleanupEpochs', []).append(epoch)
    if any(item['state'] != 'Z' for item in before):
        signal_groups(child, saved, row, signal.SIGTERM)
        term_end = min(until, time.monotonic() + 1)
        while time.monotonic() < term_end and any(
                item['state'] != 'Z' for item in members(saved['sid'])):
            time.sleep(.025)
        if any(item['state'] != 'Z' for item in members(saved['sid'])):
            signal_groups(child, saved, row, signal.SIGKILL)
        while time.monotonic() < until - .05 and any(
                item['state'] != 'Z' for item in members(saved['sid'])):
            time.sleep(.025)
    try:
        child.wait(timeout=max(.001, until - time.monotonic()))
    except subprocess.TimeoutExpired:
        epoch['directChildReapTimeout'] = True
    after = members(saved['sid'])
    epoch.update({'membersAfterCleanup': after,
                  'liveSurvivors': [item for item in after if item['state'] != 'Z'],
                  'terminatedZombies': [item for item in after if item['state'] == 'Z'],
                  'elapsedSeconds': time.monotonic() - epoch['start']})
    row['returnCode'] = child.returncode
    row['signal'] = -child.returncode if child.returncode is not None and child.returncode < 0 else None
    row['liveSurvivors'] = epoch['liveSurvivors']
    row['terminatedZombies'] = epoch['terminatedZombies']
    assert not epoch['liveSurvivors'] and child.returncode is not None, 'Owned live session/reap failure'


def run_stage(row):
    global active
    remaining = CAP - (time.monotonic() - START)
    admission = COMMAND_CAP + CLEANUP + GUARD_RESERVE
    row['admission'] = {'remainingSeconds': remaining, 'requiredSeconds': admission,
                        'originalCommandSeconds': COMMAND_CAP, 'cleanupSeconds': CLEANUP,
                        'postGuardReserveSeconds': GUARD_RESERVE}
    if remaining < admission:
        row['state'] = 'UNRUN_NO_WHOLE_ORIGINAL_COMMAND_ADMISSION'
        save()
        return False
    output = Path(row['output'])
    assert not output.exists(), 'Preserve all existing/partial new outputs'
    assert output.is_relative_to(BUILD), 'Only new own output'
    row['admitted'] = True
    row['state'] = 'STARTED'
    row['administrativeTimeout'] = False
    row['observedProcesses'] = []
    begin = time.monotonic()
    child = None
    saved = None
    log = OUT / (row['label'] + '.log')
    save()
    try:
        with log.open('xb') as stream:
            env = os.environ.copy()
            env['TMPDIR'] = str(BUILD / 'tmp')
            child = subprocess.Popen(row['argv'], cwd=row['cwd'], env=env,
                                     stdin=subprocess.DEVNULL, stdout=stream,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            active = (child, None, row)
            # Capture immediately, before poll/wait or any group signal.
            captured = ident(child.pid)
            row['initialIdentityObservation'] = captured
            assert captured and captured['pid'] == captured['pgid'] == captured['sid']
            assert captured['argv'] == row['argv'], 'Initial argv differs'
            assert captured['executable'] == str(Path(row['argv'][0]).resolve()), 'Initial executable differs'
            saved = captured
            active = (child, saved, row)
            row['identity'] = saved
            write(OUT / (row['label'] + '-identity.json'), saved)
            save()
            seen = set()
            stage_deadline = begin + COMMAND_CAP
            last_progress = begin
            while True:
                assert same(saved, ident(saved['pid'])), 'Unreaped leader identity changed'
                for item in members(saved['sid']):
                    key = (item['pid'], item['startTicks'])
                    if key not in seen:
                        seen.add(key)
                        row['observedProcesses'].append(item)
                        assert item['executable'] is None or item['executable'] in freeze['files'], 'Unfrozen observed tool executable'
                # WNOWAIT preserves the direct PID/start authority through cleanup.
                status = os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                if status is not None:
                    row['observedLeaderExit'] = {'si_pid': status.si_pid,
                                                'si_code': status.si_code,
                                                'si_status': status.si_status}
                    break
                if time.monotonic() >= stage_deadline:
                    row['administrativeTimeout'] = True
                    break
                if time.monotonic() - last_progress >= 20:
                    print(json.dumps({'stage': row['label'], 'state': 'RUNNING',
                                      'elapsedSeconds': time.monotonic() - START}), flush=True)
                    last_progress = time.monotonic()
                time.sleep(.025)
    finally:
        if child is not None:
            close(child, saved, row)
            active = None
        row['elapsedSeconds'] = time.monotonic() - begin
        if log.exists():
            row['logSHA256'] = sha(log)
            row['logBytes'] = log.stat().st_size
        row['guards'] = guard()
        write(OUT / (row['label'] + '-guards.json'), row['guards'])
        save()
    assert row.get('returnCode') == 0 and not row['administrativeTimeout'], 'Actual build failure/timeout'
    assert row['guards']['stable'] and not row.get('liveSurvivors'), 'Actual guard/session failure'
    assert output.is_file() and output.stat().st_size > 0
    with output.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF', 'New output is not ELF'
    row['artifact'] = {'path': str(output), 'sha256': sha(output), 'bytes': output.stat().st_size}
    row['state'] = 'NEW_ELF_BUILD_STAGE_ZERO_RUNTIME_UNRUN'
    save()
    return True


try:
    initial = guard()
    write(OUT / 'inputs-before.json', initial)
    record['initialGuard'] = initial
    assert initial['stable'], 'Exact input/tool/environment preflight mismatch'
    assert not BUILD.exists(), 'Preserve old and partial build directories'
    (BUILD / 'tmp').mkdir(parents=True)
    for row in record['stages']:
        if not run_stage(row):
            record['state'] = 'STOPPED_NO_WHOLE_COMMAND_ADMISSION_LATER_UNRUN'
            break
    else:
        record['outputs'] = {name: row['artifact'] for name, row in
                             zip(['api.o', 'test.o', 'node', 'cctest'], record['stages'])}
        record['state'] = 'NEW_OBJECTS_AND_NODE_CCTEST_LINKED_EXPORT_API_RUNTIME_UNRUN'
except BaseException as error:
    record['state'] = 'STOPPED_FIRST_BUILD_SETUP_SIGNAL_GUARD_OR_CLEANUP_FAILURE'
    record['error'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    finalizing = True
    signal.setitimer(signal.ITIMER_REAL, 0)
    if active is not None:
        try:
            close(*active)
        except BaseException as error:
            record['cleanupError'] = {'type': type(error).__name__, 'message': str(error)}
    sessions = []
    for row in record['stages']:
        if row.get('identity'):
            sessions.append({'identity': row['identity'],
                             'actualMembers': members(row['identity']['sid'])})
    record['finalSessions'] = sessions
    record['finalLiveSurvivors'] = [item for session in sessions for item in session['actualMembers'] if item['state'] != 'Z']
    record['finalTerminatedZombies'] = [item for session in sessions for item in session['actualMembers'] if item['state'] == 'Z']
    try:
        record['finalGuard'] = guard()
        write(OUT / 'inputs-after.json', record['finalGuard'])
    except BaseException as error:
        record['finalGuard'] = {'stable': False, 'error': str(error)}
    if not record['finalGuard']['stable'] or record['finalLiveSurvivors'] or record.get('cleanupError'):
        record['state'] = 'STOPPED_FINAL_INTEGRITY_OR_OWNERSHIP_FAILURE'
    # Includes all final guards; a late successful linker cannot bypass300s.
    record['aggregateAfterFinalGuardsSeconds'] = time.monotonic() - START
    if record['aggregateAfterFinalGuardsSeconds'] > CAP:
        record['aggregateAdministrativeTimeout'] = True
        record['state'] = 'STOPPED_AGGREGATE_THRESHOLD_AFTER_FINAL_GUARDS'
    save()
    print(json.dumps({'state': record['state'], 'report': str(OUT / 'report.json'),
                      'elapsedSeconds': record['elapsedSeconds'],
                      'guardsStable': record['finalGuard']['stable'],
                      'liveSurvivors': record['finalLiveSurvivors'],
                      'terminatedZombies': record['finalTerminatedZombies'],
                      'runtimeCasesRun': 0}), flush=True)
sys.exit(0 if record['state'] == 'NEW_OBJECTS_AND_NODE_CCTEST_LINKED_EXPORT_API_RUNTIME_UNRUN' else 1)
