#!/usr/bin/env python3
"""Separate leased BUILD ONLY. Exact4TUs +1isolatedlink; never executes diagnostic binary."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,signal,subprocess,sys,time
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Use exact python3 -I -B command; assertions cannot be disabled')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def ident(pid):
 try:
  s=Path(f'/proc/{pid}/stat').read_text();v=s[s.rfind(')')+2:].split()
  try:exe=str(Path(f'/proc/{pid}/exe').resolve(strict=True))
  except OSError:exe=None
  return {'pid':int(pid),'state':v[0],'ppid':int(v[1]),'pgid':int(v[2]),'sid':int(v[3]),'startTicks':v[19],
          'argv':Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace').strip('\0').split('\0'),'executable':exe}
 except(FileNotFoundError,ProcessLookupError):return None
def same(a,b):return a is not None and b is not None and a['pid']==b['pid']and a['startTicks']==b['startTicks']
def members(sid):
 result=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   x=ident(int(p.name))
   if x and x['sid']==sid:result.append(x)
 return sorted(result,key=lambda x:x['pid'])
def tree(root):
 root=Path(root);rows=[]
 if not root.exists():return {'path':str(root),'exists':False,'entries':[]}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():rows.append({'path':str(p.relative_to(root)),'kind':'symlink','target':os.readlink(p)})
  elif p.is_file():rows.append({'path':str(p.relative_to(root)),'kind':'file'})
  elif p.is_dir():rows.append({'path':str(p.relative_to(root)),'kind':'dir'})
 return {'path':str(root),'exists':True,'entries':rows}

def guard(frozen,extra):
 files={**frozen['files'],**extra};bad={}
 for p,wanted in files.items():
  try:actual=sha(p)
  except OSError as e:actual='UNREADABLE:'+str(e)
  if actual!=wanted:bad[p]={'expected':wanted,'actual':actual}
 other=[]
 for p,expected in frozen['pathResolutions'].items():
  try:actual={'resolved':str(Path(p).resolve()),'directLink':os.readlink(p)if Path(p).is_symlink()else None}
  except OSError as e:actual={'error':str(e)}
  if actual!=expected:other.append({'pathResolution':p,'expected':expected,'actual':actual})
 for expected in frozen['rootInventories']:
  actual=tree(expected['path'])
  if actual!=expected:other.append({'changedRootInventory':expected['path']})
 for expected in frozen['explicitIncludeDirectoryNames']:
  p=Path(expected['path']);actual={'path':str(p),'exists':p.is_dir(),'entries':sorted(x.name for x in p.iterdir())if p.is_dir()else[]}
  if actual!=expected:other.append({'changedIncludeSearchDirectory':str(p)})
 for name,expected in frozen['linkSearchDirectoryNames'].items():
  p=Path(name);actual={'exists':p.is_dir(),'entries':sorted(x.name for x in p.iterdir())if p.is_dir()else[]}
  if actual!=expected:other.append({'changedLinkSearchDirectory':name})
 for name,expected in frozen['environment'].items():
  raw=os.fsencode(os.environ.get(name,''));actual={'present':name in os.environ,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  if actual!=expected:other.append({'changedEnvironment':name,'expected':expected,'actual':actual})
 return {'stable':not bad and not other,'fileCount':len(files),'frozen8226Files':len(frozen['files']),'fileMismatches':bad,'metadataMismatches':other}

p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--epoch',required=True);a=p.parse_args()
assert a.epoch and all(x.isalnum()or x in '-_'for x in a.epoch)
assert sha(D/'manifest.json')==a.manifest_sha,'Exact separatelyreviewed manifest required'
manifest=json.loads((D/'manifest.json').read_text())
for name,h in manifest['files'].items():assert sha(D/name)==h,name
out=D/'evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
freeze=json.loads((D/'input-freeze.json').read_text());plan=json.loads((D/'compile-link-plan.json').read_text())
extra={str(D/name):h for name,h in manifest['files'].items()};extra[str(D/'manifest.json')]=a.manifest_sha
record={'state':'SETUP','scope':'OWNED_TEST_OBJECTS_AND_DIAGNOSTIC_LINK_ONLY_RUNTIME_UNRUN','sourceCode':'Root6461d88/C3177 unchanged','stages':[],
        'originalCollection3FailuresAndIndependentNamespace2Positive':'UNCHANGED','caps':{'compileEachSeconds':60,'linkSeconds':120,'aggregateSeconds':390,'outerSeconds':420},
        'thinArchiveMembersActuallyByteFrozen':len(freeze['thinArchiveMemberEdges']),'sourceOrOldObjectOrC3BinaryWrites':'NONE','actualCctestCasesRun':0}
start=time.monotonic();deadline=start+390;active=None

def save():record['elapsedSeconds']=time.monotonic()-start;write(out/'report.json',record)
def stop(signum,frame):raise InterruptedError('Controller signal '+str(signum))
def aggregate(signum,frame):record['aggregateAdministrativeTimeout']=True;raise TimeoutError('390s independentbuild administrative threshold')
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGALRM,aggregate);signal.setitimer(signal.ITIMER_REAL,390)

def signal_groups(saved,captured,row,signum):
 now=members(saved['sid'])
 for pgid in sorted({x['pgid']for x in now if x['state']!='Z'}):
  assert pgid!=os.getpgrp()
  current=[x for x in now if x['pgid']==pgid and x['state']!='Z']
  assert same(saved,ident(saved['pid']))or any(same(x,ident(x['pid']))for x in captured if x['pgid']==pgid),'No actual ownedidentity authority'
  row.setdefault('groupSignals',[]).append({'pgid':pgid,'signal':int(signum),'actualMembers':current})
  try:os.killpg(pgid,signum)
  except ProcessLookupError:pass

def close(child,saved,row):
 before=members(saved['sid']);row['membersBeforeCleanup']=before
 if any(x['state']!='Z'for x in before):
  signal_groups(saved,before,row,signal.SIGTERM);until=time.monotonic()+3
  while time.monotonic()<until and any(x['state']!='Z'for x in members(saved['sid'])):time.sleep(.025)
  if any(x['state']!='Z'for x in members(saved['sid'])):signal_groups(saved,before,row,signal.SIGKILL)
 try:child.wait(timeout=1)
 except subprocess.TimeoutExpired:row['reapTimeout']=True
 after=members(saved['sid']);row['membersAfterCleanup']=after;row['liveSurvivors']=[x for x in after if x['state']!='Z'];row['terminatedZombies']=[x for x in after if x['state']=='Z'];row['returnCode']=child.returncode;row['signal']=-child.returncode if child.returncode is not None and child.returncode<0 else None
 assert not row['liveSurvivors'],'Owned compiler/linker survivors remain'

def run_stage(name,argv,cwd,cap,output):
 global active
 assert deadline-time.monotonic()>=cap+13,'No whole-stage budget admission; no cap inflation'
 assert not Path(output).exists(),'Never overwrite prior/partial diagnostic artifact'
 row={'name':name,'argv':argv,'cwd':cwd,'capSeconds':cap,'state':'STARTED','administrativeTimeout':False,'observedProcesses':[]};record['stages'].append(row);save();begin=time.monotonic();child=None;saved=None
 log=out/(name+'.log')
 try:
  with log.open('xb')as stream:
   child=subprocess.Popen(argv,cwd=cwd,env=os.environ.copy(),stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   try:saved=ident(child.pid);assert saved and saved['pid']==saved['sid']==saved['pgid']
   except BaseException:
    child.terminate()
    try:child.wait(timeout=3)
    except subprocess.TimeoutExpired:child.kill();child.wait(timeout=1)
    raise
   row['identity']=saved;active=(child,saved,row);write(out/(name+'-identity.json'),saved);save();seen=set();stageDeadline=begin+cap
   try:
    while child.poll()is None:
     for x in members(saved['sid']):
      key=(x['pid'],x['startTicks'])
      if key not in seen:
       seen.add(key);row['observedProcesses'].append(x)
       assert x['executable']is None or x['executable']in freeze['files'],'Unfrozen actual compiler subprogram'
     if time.monotonic()>=stageDeadline:row['administrativeTimeout']=True;break
     time.sleep(.025)
   finally:close(child,saved,row);active=None
  row['state']='PROCESS_CLOSED'
 finally:
  row['elapsedSeconds']=time.monotonic()-begin
  if log.exists():row['logSHA256']=sha(log);row['logBytes']=log.stat().st_size
  row['guards']=guard(freeze,extra);write(out/(name+'-guards.json'),row['guards']);save()
 assert row.get('returnCode')==0 and not row['administrativeTimeout'],'Actual compiler/linker failure/timeout'
 assert row['guards']['stable']and not row.get('liveSurvivors'),'Actual input or ownership changed'
 result=Path(output);assert result.is_file()and result.stat().st_size>0
 with result.open('rb')as f:assert f.read(4)==b'\x7fELF','Actual object/link output not ELF'
 row['artifact']={'path':str(result),'sha256':sha(result),'bytes':result.stat().st_size};row['state']='BUILD_STAGE_ZERO_WITH_ACTUAL_ELF';save()

try:
 before=guard(freeze,extra);write(out/'inputs-before.json',before);assert before['stable'],'Exact source/cache/header/tool/environment guard preflight mismatch'
 assert len(plan['compiles'])==4 and plan['budgets']['serialCompilers']==1
 proof=json.loads((D/'link-replacement-proof.json').read_text());assert proof['onlyExact3OldObjectsRemoved']and proof['exact4OwnedObjectsAdded']and proof['noOldTestObjectInsideAnyThinArchive']
 build=D/'build';assert not build.exists(),'Fresh own build only; preserve old partials'
 (build/'objects').mkdir(parents=True)
 record['inputFreezeSHA256']=sha(D/'input-freeze.json');record['resourceObservation']={'availableDiskBytes':__import__('shutil').disk_usage(D).free}
 for i,item in enumerate(plan['compiles'],1):run_stage('compile-'+str(i),item['argv'],item['cwd'],60,item['output'])
 run_stage('link',plan['link']['argv'],plan['link']['cwd'],120,plan['link']['output'])
 record['diagnosticBinary']=record['stages'][-1]['artifact'];record['state']='DIAGNOSTIC_TEST_BINARY_BUILT_RUNTIME_UNRUN'
except BaseException as error:record['state']='STOPPED_FIRST_BUILD_SETUP_PROCESS_GUARD_OR_CLEANUP_FAILURE';record['error']={'type':type(error).__name__,'message':str(error)}
finally:
 signal.setitimer(signal.ITIMER_REAL,0)
 if active is not None:
  try:close(*active)
  except BaseException as e:record['cleanupError']={'type':type(e).__name__,'message':str(e)}
 final=[]
 for row in record['stages']:
  if row.get('identity'):final.extend(members(row['identity']['sid']))
 record['finalMembers']=final;record['finalLiveSurvivors']=[x for x in final if x['state']!='Z'];record['finalTerminatedZombies']=[x for x in final if x['state']=='Z']
 record['finalGuard']=guard(freeze,extra);write(out/'inputs-after.json',record['finalGuard'])
 if not record['finalGuard']['stable']or record['finalLiveSurvivors']or record.get('cleanupError'):record['state']='STOPPED_FINAL_INTEGRITY_OR_OWNERSHIP_FAILURE'
 if time.monotonic()-start>390:record['aggregateAdministrativeTimeout']=True;record['state']='STOPPED_AGGREGATE_THRESHOLD'
 save();print(json.dumps({'state':record['state'],'stages':len(record['stages']),'guardsStable':record['finalGuard']['stable'],'liveSurvivors':record['finalLiveSurvivors'],'report':str(out/'report.json'),'runtimeCasesRun':0}),flush=True)
raise SystemExit(0 if record['state']=='DIAGNOSTIC_TEST_BINARY_BUILT_RUNTIME_UNRUN'else 1)
