"""Provenance generator; STATIC only, already used before freeze. Do not rerun frozen packet."""
from pathlib import Path
import json,hashlib,os,shutil
D=Path(__file__).resolve().parents[1];R1=Path('/workspace/shared/node-provider-r5-entry-prerequisite-r1');COV=Path('/workspace/shared/node-provider-gc-observer-storage-build-r2');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(R1/'manifest.json')=='2da5298cc5a1141bd1ec2c04df494c549a8807ead8dc22653216f295ff0a6a0b'
old=json.loads((D/'reference/toolchain-freeze-parent.json').read_text());model=json.loads((R1/'evidence/sidecar-link-model.json').read_text());manifest=json.loads((R1/'manifest.json').read_text());files={};roles={}
def add(p,h=None,role='exact-input'):
 p=Path(p);actual=sha(p);assert h is None or h==actual,str(p)+' changed';files[str(p)]=actual;roles.setdefault(str(p),set()).add(role)
for p,rs in old['roles'].items():
 if any(x in rs for x in ['systemOrCompilerIncludeSuperset-MMDomissionCovered','actualCompilerAssemblerLinkerStartupOrELFDependency']):add(p,old['files'][p],'frozen-system-header-and-toolchain-superset')
for row in manifest['files']:add(R1/row['path'],row['sha256'],'immutable-R1-proposal')
add(R1/'manifest.json','2da5298cc5a1141bd1ec2c04df494c549a8807ead8dc22653216f295ff0a6a0b','reviewed-R1-manifest')
for p,h in json.loads((R1/'reference/C3-original177-inputs.json').read_text()).items():add(p,h,'exact-C3-original177')
for row in model['cacheInputs']:add(row['path'],row['sha256'],'actual-link-and-thin-archive-closure')
for row in model['actualC3BaselineOutputs'].values():add(row['path'],row['sha256'],'original-C3-executable-unchanged')
for row in model['models']:add(row['ninja'],row['ninjaSHA256'],'actual-Ninja-link-metadata')
def inventory(p):
 p=Path(p);rows=[]
 if p.exists():
  for x in sorted(p.rglob('*')):
   kind='symlink'if x.is_symlink()else'file'if x.is_file()else'dir'if x.is_dir()else'other';row={'path':str(x.relative_to(p)),'kind':kind}
   if kind=='symlink':row['target']=os.readlink(x)
   rows.append(row)
 return{'path':str(p),'exists':p.exists(),'entries':rows}
roots={r['path']:r for r in old['rootInventories']if r['path'].startswith('/usr/')};dirs=[]
for c in model['compileTemplates'].values():
 for i,arg in enumerate(c['argv']):
  target=c['argv'][i+1]if arg=='-I'else arg[2:]if arg.startswith('-I')else None
  if target is not None:
   p=(Path(c['directory'])/target).resolve();roots[str(p)]=inventory(p);dirs.append(str(p))
   if p.is_dir():
    for x in p.rglob('*'):
     if x.is_file():add(x,role='actual-explicit-include-tree')
p=R1/'sidecar/src';roots[str(p)]=inventory(p)
for x in p.rglob('*'):
 if x.is_file():add(x,role='supplemental-public-and-Node-internal-source')
for path,row in roots.items():assert inventory(path)==row,'Borrowed inventory changed: '+path
resolutions={p:v for p,v in old['pathResolutions'].items()if v['resolved']in files}
for path in files:
 p=Path(path);resolutions.setdefault(path,{'resolved':str(p.resolve()),'directLink':os.readlink(p)if p.is_symlink()else None})
for p,v in resolutions.items():assert {'resolved':str(Path(p).resolve()),'directLink':os.readlink(p)if Path(p).is_symlink()else None}==v
# This source-only preparation uses the ACTUAL current environment, not an older hash.
environment={};environmentDeltas={}
for n,v in old['environment'].items():
 raw=os.fsencode(os.environ.get(n,''));actual={'present':n in os.environ,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};environment[n]=actual
 if actual!=v:environmentDeltas[n]={'olderReviewedHelper':v,'currentStaticPreparation':actual}
searchDirs={}
for s in os.environ.get('PATH','').split(os.pathsep):
 p=Path(s or '.');searchDirs[str(p)]={'exists':p.is_dir(),'entries':sorted(x.name for x in p.iterdir())if p.is_dir()else[]}
toolSearch={}
for name,expected in [('as','/usr/bin/x86_64-linux-gnu-as'),('ld','/usr/bin/x86_64-linux-gnu-ld.bfd')]:
 actual=shutil.which(name);assert actual and str(Path(actual).resolve())==expected,'Actual tool search changed';toolSearch[name]={'lookup':actual,'resolved':expected,'sha256':sha(Path(expected))};resolutions[actual]={'resolved':expected,'directLink':os.readlink(actual)if Path(actual).is_symlink()else None}
plan={'kind':'Controller-only derivative: original120s per command,300s total; immutable R1 SDK variants','commands':[],'sourceRoot':str(R1),'ownBuild':str(D/'build'),'originalManifestSHA256':sha(R1/'manifest.json'),'engineSourceContractSHA256':sha(R1/'sidecar-source-contract.json'),'budgets':{'perCommandSeconds':120,'cleanupSeconds':2,'finalGuardReserveSeconds':10,'aggregateSeconds':300},'actualBuild':'UNRUN'}
for c in model['futureCommands']:
 row=dict(c);row['argv']=[x.replace(str(R1/'build-sidecar'),str(D/'build'))for x in c['argv']];row['output']=c['output'].replace(str(R1/'build-sidecar'),str(D/'build'));row['capSeconds']=120;plan['commands'].append(row)
freeze={'kind':'STATIC actual toolchain/system-header/include/object closure; no compiler invocations','files':files,'roles':{p:sorted(v)for p,v in roles.items()},'pathResolutions':resolutions,'rootInventories':list(roots.values()),'linkSearchDirectoryNames':old['linkSearchDirectoryNames'],'pathSearchDirectoryNames':searchDirs,'toolSearch':toolSearch,'environment':environment,'olderHelperEnvironmentDeltas':environmentDeltas,'toolDependencyPolicy':old['toolPolicy'],'elfToolDependencyClosure':old['elfToolDependencyClosure'],'originalCoverageFreezeSHA256':sha(COV/'input-freeze.json'),'explicitIncludeRoots':sorted(set(dirs)),'originalCacheInputs':len(model['cacheInputs']),'originalC3Inputs':177,'limits':['No hermetic build or exact output reproducibility claim','Host kernel/procfs/Python and scheduler remain prerequisites','Sampling may miss short-lived subprograms; frozen executable and ELF dependency bytes plus search inventories are source-based coverage, not a sandbox','No configure/Ninja/cache-output writes admitted','System include root bytes and path inventories frozen; absence of a file-open trace is explicit']}
(D/'input-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');(D/'compile-link-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'frozenFiles':len(files),'toolchainFileCount':81,'systemHeaderFileCount':3331,'includeInventories':len(roots),'environmentDeltas':list(environmentDeltas),'commands':len(plan['commands']),'R1Unchanged':sha(R1/'manifest.json')}))
