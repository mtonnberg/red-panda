/workspace/shared/node-provider-r5-sidecar-controller-r2/build/api.o: \
 /workspace/shared/node-provider-r5-entry-prerequisite-r1/sidecar/src/node_owned_carrier_api.cc \
 /workspace/shared/node-provider-r5-entry-prerequisite-r1/sidecar/src/node_owned_carrier_api.h \
 ../../src/node.h ../../deps/v8/include/v8.h \
 ../../deps/v8/include/cppgc/common.h ../../deps/v8/include/v8config.h \
 ../../deps/v8/include/v8-array-buffer.h \
 ../../deps/v8/include/v8-local-handle.h \
 ../../deps/v8/include/v8-handle-base.h \
 ../../deps/v8/include/v8-internal.h ../../deps/v8/include/v8config.h \
 ../../deps/v8/include/v8-memory-span.h ../../deps/v8/include/v8-object.h \
 ../../deps/v8/include/v8-maybe.h \
 ../../deps/v8/include/cppgc/internal/conditional-stack-allocated.h \
 ../../deps/v8/include/cppgc/macros.h \
 ../../deps/v8/include/cppgc/internal/compiler-specific.h \
 ../../deps/v8/include/cppgc/type-traits.h \
 ../../deps/v8/include/v8-persistent-handle.h \
 ../../deps/v8/include/v8-weak-callback-info.h \
 ../../deps/v8/include/v8-primitive.h ../../deps/v8/include/v8-data.h \
 ../../deps/v8/include/v8-value.h ../../deps/v8/include/v8-sandbox.h \
 ../../deps/v8/include/v8-traced-handle.h \
 ../../deps/v8/include/v8-platform.h \
 ../../deps/v8/include/v8-source-location.h \
 ../../deps/v8/include/v8-container.h ../../deps/v8/include/v8-context.h \
 ../../deps/v8/include/v8-snapshot.h ../../deps/v8/include/v8-isolate.h \
 ../../deps/v8/include/v8-callbacks.h ../../deps/v8/include/v8-promise.h \
 ../../deps/v8/include/v8-debug.h ../../deps/v8/include/v8-script.h \
 ../../deps/v8/include/v8-message.h \
 ../../deps/v8/include/v8-embedder-heap.h \
 ../../deps/v8/include/v8-exception.h \
 ../../deps/v8/include/v8-function-callback.h \
 ../../deps/v8/include/v8-microtask.h \
 ../../deps/v8/include/v8-statistics.h \
 ../../deps/v8/include/v8-unwinder.h \
 ../../deps/v8/include/v8-embedder-state-scope.h \
 ../../deps/v8/include/v8-date.h ../../deps/v8/include/v8-extension.h \
 ../../deps/v8/include/v8-external.h ../../deps/v8/include/v8-function.h \
 ../../deps/v8/include/v8-template.h \
 ../../deps/v8/include/v8-initialization.h \
 ../../deps/v8/include/v8-json.h ../../deps/v8/include/v8-locker.h \
 ../../deps/v8/include/v8-microtask-queue.h \
 ../../deps/v8/include/v8-primitive-object.h \
 ../../deps/v8/include/v8-proxy.h ../../deps/v8/include/v8-regexp.h \
 ../../deps/v8/include/v8-typed-array.h \
 ../../deps/v8/include/v8-value-serializer.h \
 ../../deps/v8/include/v8-version.h ../../deps/v8/include/v8-wasm.h \
 ../../deps/v8/include/v8-platform.h ../../src/node_version.h \
 ../../src/node_api.h ../../src/js_native_api.h \
 ../../src/js_native_api_types.h ../../src/node_api_types.h \
 ../../src/env-inl.h ../../src/aliased_buffer-inl.h \
 ../../src/aliased_buffer.h ../../src/memory_tracker.h \
 ../../deps/v8/include/v8-profiler.h ../../deps/uv/include/uv.h \
 ../../deps/uv/include/uv/errno.h ../../deps/uv/include/uv/version.h \
 ../../deps/uv/include/uv/unix.h ../../deps/uv/include/uv/threadpool.h \
 ../../deps/uv/include/uv/linux.h ../../src/memory_tracker-inl.h \
 ../../src/cppgc_helpers.h \
 ../../deps/v8/include/cppgc/garbage-collected.h \
 ../../deps/v8/include/cppgc/internal/api-constants.h \
 ../../deps/v8/include/cppgc/platform.h \
 ../../deps/v8/include/cppgc/source-location.h \
 ../../deps/v8/include/v8-source-location.h \
 ../../deps/v8/include/cppgc/trace-trait.h \
 ../../deps/v8/include/cppgc/name-provider.h \
 ../../deps/v8/include/cppgc/persistent.h \
 ../../deps/v8/include/cppgc/internal/persistent-node.h \
 ../../deps/v8/include/cppgc/internal/logging.h \
 ../../deps/v8/include/cppgc/internal/pointer-policies.h \
 ../../deps/v8/include/cppgc/internal/member-storage.h \
 ../../deps/v8/include/cppgc/internal/caged-heap.h \
 ../../deps/v8/include/cppgc/internal/base-page-handle.h \
 ../../deps/v8/include/cppgc/heap-handle.h \
 ../../deps/v8/include/cppgc/sentinel-pointer.h \
 ../../deps/v8/include/cppgc/internal/write-barrier.h \
 ../../deps/v8/include/cppgc/heap-state.h \
 ../../deps/v8/include/cppgc/internal/atomic-entry-flag.h \
 ../../deps/v8/include/cppgc/visitor.h \
 ../../deps/v8/include/cppgc/custom-space.h \
 ../../deps/v8/include/cppgc/liveness-broker.h \
 ../../deps/v8/include/cppgc/heap.h ../../deps/v8/include/cppgc/common.h \
 ../../deps/v8/include/cppgc/member.h ../../src/util.h \
 ../../deps/v8/include/v8-inspector.h ../../src/node.h \
 ../../src/node_exit_code.h ../../deps/v8/include/v8-cppgc.h \
 ../../deps/v8/include/cppgc/custom-space.h \
 ../../deps/v8/include/cppgc/heap-statistics.h \
 ../../deps/v8/include/cppgc/visitor.h ../../deps/v8/include/v8-sandbox.h \
 ../../src/util-inl.h ../../deps/v8/include/v8-isolate.h \
 ../../src/node_revert.h ../../src/callback_queue-inl.h \
 ../../src/callback_queue.h ../../src/env.h ../../src/inspector_agent.h \
 ../../src/inspector/network_resource_manager.h ../../src/node_mutex.h \
 ../../src/node_options.h ../../src/node_constants.h \
 ../../src/node_mutex.h \
 ../../deps/openssl/openssl/include/openssl/opensslv.h \
 ../../deps/openssl/openssl/include/openssl/../../../config/opensslv.h \
 ../../deps/openssl/openssl/include/openssl/../../../config/./opensslv_asm.h \
 ../../deps/openssl/openssl/include/openssl/../../../config/././archs/linux-x86_64/asm/include/openssl/opensslv.h \
 ../../deps/openssl/openssl/include/openssl/macros.h \
 ../../deps/openssl/openssl/include/openssl/opensslconf.h \
 ../../deps/openssl/openssl/include/openssl/configuration.h \
 ../../deps/openssl/openssl/include/openssl/../../../config/configuration.h \
 ../../deps/openssl/openssl/include/openssl/../../../config/./configuration_asm.h \
 ../../deps/openssl/openssl/include/openssl/../../../config/././archs/linux-x86_64/asm/include/openssl/configuration.h \
 ../../src/quic/guard.h ../../src/inspector_profiler.h \
 ../../deps/simdjson/simdjson.h ../../src/cleanup_queue-inl.h \
 ../../src/cleanup_queue.h ../../src/compile_cache.h \
 ../../src/debug_utils.h ../../src/async_wrap.h ../../src/base_object.h \
 ../../src/base_object_types.h ../../src/env_properties.h \
 ../../src/handle_wrap.h ../../src/node_binding.h \
 ../../src/node_builtins.h ../../src/builtin_info.h \
 ../../src/node_external_reference.h \
 ../../deps/v8/include/v8-fast-api-calls.h \
 ../../src/node_threadsafe_cow.h ../../src/node_union_bytes.h \
 ../../src/node_main_instance.h ../../src/node_perf_common.h \
 ../../src/node_profiling.h ../../src/node_realm.h \
 ../../src/node_snapshotable.h ../../src/permission/permission.h \
 ../../src/debug_utils.h ../../src/node_diagnostics_channel.h \
 ../../src/node_options.h ../../src/permission/addon_permission.h \
 ../../src/permission/permission_base.h \
 ../../src/permission/child_process_permission.h \
 ../../src/permission/fs_permission.h ../../src/util.h \
 ../../src/permission/inspector_permission.h \
 ../../src/permission/openssl_store_permission.h \
 ../../src/permission/wasi_permission.h \
 ../../src/permission/worker_permission.h ../../src/req_wrap.h \
 ../../deps/v8/include/v8-external-memory-accounter.h \
 ../../src/node_context_data.h ../../src/node_internals.h \
 ../../src/tracing/trace_event.h ../../src/tracing/agent_legacy.h \
 ../../deps/v8/include/libplatform/v8-tracing.h \
 ../../deps/v8/include/libplatform/libplatform-export.h \
 ../../src/tracing/agent.h ../../src/tracing/trace_event_common.h \
 ../../src/node_realm-inl.h ../../src/base_object-inl.h \
 ../../src/env-inl.h ../../src/node_contextify.h \
 ../../src/cppgc_helpers-inl.h ../../src/node_errors.h \
 ../../src/debug_utils-inl.h ../../src/node_buffer.h \
 ../../src/node_context_data.h ../../src/node_errors.h
