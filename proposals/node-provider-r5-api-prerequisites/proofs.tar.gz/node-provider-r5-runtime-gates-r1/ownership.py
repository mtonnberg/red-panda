"""Verbatim reviewed R2 ownership functions; globals wired by individual runner."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time

def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def ident(pid):
    try:
        text = Path(f'/proc/{pid}/stat').read_text()
        fields = text[text.rfind(')') + 2:].split()
        try:
            executable = str(Path(f'/proc/{pid}/exe').resolve(strict=True))
        except OSError:
            executable = None
        return {
            'pid': int(pid), 'state': fields[0], 'ppid': int(fields[1]),
            'pgid': int(fields[2]), 'sid': int(fields[3]),
            'startTicks': fields[19],
            'argv': Path(f'/proc/{pid}/cmdline').read_bytes().decode(
                errors='replace').strip('\0').split('\0'),
            'executable': executable,
        }
    except (FileNotFoundError, ProcessLookupError):
        return None


def same(first, second):
    return (first is not None and second is not None and
            first['pid'] == second['pid'] and
            first['startTicks'] == second['startTicks'])


def members(sid):
    result = []
    for item in Path('/proc').iterdir():
        if item.name.isdigit():
            actual = ident(int(item.name))
            if actual and actual['sid'] == sid:
                result.append(actual)
    return sorted(result, key=lambda item: item['pid'])


def tree(path):
    root = Path(path)
    rows = []
    if root.exists():
        for item in sorted(root.rglob('*')):
            kind = ('symlink' if item.is_symlink() else
                    'file' if item.is_file() else
                    'dir' if item.is_dir() else 'other')
            row = {'path': str(item.relative_to(root)), 'kind': kind}
            if kind == 'symlink':
                row['target'] = os.readlink(item)
            rows.append(row)
    return {'path': str(root), 'exists': root.exists(), 'entries': rows}


def signal_groups(child, saved, row, signum):
    # The direct child is deliberately kept UNREAPED through session cleanup.
    # Its start identity reserves the session leader PID even if it is a zombie.
    assert child.returncode is None, 'Leader already reaped; no session signal authority'
    authority = ident(saved['pid'])
    assert same(saved, authority), 'Saved leader start identity no longer matches'
    assert authority['sid'] == saved['sid'] == saved['pid']
    snapshot = members(saved['sid'])
    for pgid in sorted({item['pgid'] for item in snapshot if item['state'] != 'Z'}):
        assert pgid != os.getpgrp(), 'Refuse controller process group'
        # Reauthenticate immediately BEFORE EACH group signal.
        authority = ident(saved['pid'])
        assert same(saved, authority) and authority['sid'] == saved['sid']
        current = [item for item in members(saved['sid'])
                   if item['pgid'] == pgid and item['state'] != 'Z']
        if not current:
            continue
        assert any(same(item, ident(item['pid'])) for item in current)
        action = {'pgid': pgid, 'signal': int(signum), 'authority': authority,
                  'actualMembers': current, 'elapsedSeconds': time.monotonic() - START}
        row.setdefault('groupSignals', []).append(action)
        save()
        try:
            os.killpg(pgid, signum)
            action['result'] = 'sent'
        except ProcessLookupError:
            action['result'] = 'already-gone'
        except OSError as error:
            action['result'] = 'signal-failed'
            action['error'] = str(error)
            raise


def initial_identity_close(child, row):
    # No group inference or killpg is permitted after initial identity failure.
    # Popen has not been polled or waited; its unreaped direct child alone is safe.
    before = ident(child.pid)
    entry = {'mode': 'INITIAL_IDENTITY_FAILURE_DIRECT_POPEN_CHILD_ONLY',
             'before': before, 'directSignals': [],
             'possibleSessionBeforeObservationOnly': members(child.pid)}
    row.setdefault('cleanupEpochs', []).append(entry)
    try:
        entry['directSignals'].append({'method': 'Popen.terminate', 'signal': int(signal.SIGTERM)})
        child.terminate()
        try:
            child.wait(timeout=1)
        except subprocess.TimeoutExpired:
            entry['directSignals'].append({'method': 'Popen.kill', 'signal': int(signal.SIGKILL)})
            child.kill()
            child.wait(timeout=1)
    finally:
        entry['returnCode'] = child.returncode
        entry['possibleSessionAfterObservationOnly'] = members(child.pid)
        entry['unverifiedDescendantOwnership'] = True
        row['cleanupIdentityFailure'] = True
        row['returnCode'] = child.returncode
        row['signal'] = -child.returncode if child.returncode is not None and child.returncode < 0 else None
        save()


def close(child, saved, row):
    if saved is None:
        initial_identity_close(child, row)
        return
    # Each cleanup call gets at most the original total2s, not2s per signal.
    until = time.monotonic() + CLEANUP
    before = members(saved['sid'])
    epoch = {'membersBeforeCleanup': before, 'start': time.monotonic()}
    row.setdefault('cleanupEpochs', []).append(epoch)
    if any(item['state'] != 'Z' for item in before):
        signal_groups(child, saved, row, signal.SIGTERM)
        term_end = min(until, time.monotonic() + 1)
        while time.monotonic() < term_end and any(
                item['state'] != 'Z' for item in members(saved['sid'])):
            time.sleep(.025)
        if any(item['state'] != 'Z' for item in members(saved['sid'])):
            signal_groups(child, saved, row, signal.SIGKILL)
        while time.monotonic() < until - .05 and any(
                item['state'] != 'Z' for item in members(saved['sid'])):
            time.sleep(.025)
    try:
        child.wait(timeout=max(.001, until - time.monotonic()))
    except subprocess.TimeoutExpired:
        epoch['directChildReapTimeout'] = True
    after = members(saved['sid'])
    epoch.update({'membersAfterCleanup': after,
                  'liveSurvivors': [item for item in after if item['state'] != 'Z'],
                  'terminatedZombies': [item for item in after if item['state'] == 'Z'],
                  'elapsedSeconds': time.monotonic() - epoch['start']})
    row['returnCode'] = child.returncode
    row['signal'] = -child.returncode if child.returncode is not None and child.returncode < 0 else None
    row['liveSurvivors'] = epoch['liveSurvivors']
    row['terminatedZombies'] = epoch['terminatedZombies']
    assert not epoch['liveSurvivors'] and child.returncode is not None, 'Owned live session/reap failure'

