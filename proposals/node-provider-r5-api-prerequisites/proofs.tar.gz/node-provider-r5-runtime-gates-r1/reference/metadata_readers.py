"""Read-only parsers for actual Ninja v4 deps and GNU regular/thin archive metadata."""
from pathlib import Path
import struct

def ninja_deps(path):
    paths=[];deps={};records=0
    with Path(path).open('rb')as f:
        assert f.read(12)==b'# ninjadeps\n'
        assert struct.unpack('<I',f.read(4))[0]==4
        while True:
            size=f.read(4)
            if not size:break
            assert len(size)==4
            word=struct.unpack('<I',size)[0];is_deps=bool(word&0x80000000);n=word&0x7fffffff
            assert n%4==0 and 0<n<(1<<24)
            body=f.read(n);assert len(body)==n
            if is_deps:
                assert n>=12
                target=struct.unpack_from('<I',body)[0];mtime=struct.unpack_from('<Q',body,4)[0];ids=struct.unpack_from('<'+'I'*((n-12)//4),body,12)
                assert target<len(paths)and all(i<len(paths)for i in ids)
                deps[paths[target]]={'targetID':target,'mtime':mtime,'dependencyPaths':[paths[i]for i in ids]}
            else:
                assert n>=4
                checksum=struct.unpack_from('<I',body,n-4)[0];assert checksum==((~len(paths))&0xffffffff)
                name=body[:-4].rstrip(b'\0');assert b'\0'not in name
                paths.append(name.decode())
            records+=1
    return {'format':'NinjaDeps4','pathRecords':len(paths),'records':records,'latestDeps':deps}

def archive_members(path):
    path=Path(path);rows=[];names=b''
    with path.open('rb')as f:
        magic=f.read(8);assert magic in [b'!<thin>\n',b'!<arch>\n'],str(path)
        thin=magic==b'!<thin>\n'
        while True:
            pos=f.tell();hdr=f.read(60)
            if not hdr:break
            assert len(hdr)==60 and hdr[-2:]==b'`\n',(str(path),pos)
            field=hdr[:16].decode().rstrip();size=int(hdr[48:58].decode().strip())
            special=field in ['/','//','/SYM64/']
            if field=='//':names=f.read(size);assert len(names)==size
            elif special:f.seek(size,1)
            elif field.startswith('/'):
                # GNU thin references to external regular-archive members use /offset:memberOffset.
                reference=field.rstrip('/').strip();bits=reference[1:].split(':');offset=int(bits[0].strip());assert offset<len(names)
                end=names.find(b'/\n',offset);assert end>=offset
                name=names[offset:end].decode();resolved=(path.parent/name).resolve()
                rows.append({'name':name,'path':str(resolved),'sizeFromHeader':size,'nestedMemberOffset':int(bits[1])if len(bits)==2 else None})
                if not thin:f.seek(size,1)
            elif field.startswith('#1/'):
                raise AssertionError('BSD extended archive names need explicit review; no guessed parsing')
            else:
                name=field.rstrip('/');resolved=(path.parent/name).resolve();rows.append({'name':name,'path':str(resolved),'sizeFromHeader':size,'nestedMemberOffset':None})
                if not thin:f.seek(size,1)
            if (special or not thin)and size%2:f.seek(1,1)
    return {'path':str(path.resolve()),'thin':thin,'members':rows,'format':'GNUthin'if thin else'GNUar'}

def elf_dependencies(path):
    """ELF64 little-endian program-table/dynamic metadata; no executable invocation."""
    with Path(path).open('rb')as f:
        header=f.read(64)
        if header[:4]!=b'\x7fELF':return None
        assert header[4:6]==bytes([2,1]),str(path)
        phoff=struct.unpack_from('<Q',header,32)[0];phentsize,phnum=struct.unpack_from('<HH',header,54)
        if phnum==0:return {'interpreter':None,'needed':[],'searchPaths':[]}
        assert phentsize>=56
        segments=[];dynamic=None;interpreter=None
        for i in range(phnum):
            f.seek(phoff+i*phentsize);p=f.read(phentsize);kind,flags,offset,vaddr,paddr,filesz,memsz,align=struct.unpack_from('<IIQQQQQQ',p)
            if kind==1:segments.append((vaddr,vaddr+filesz,offset))
            elif kind==2:dynamic=(offset,filesz)
            elif kind==3:f.seek(offset);interpreter=f.read(filesz).rstrip(b'\0').decode()
        if dynamic is None:return {'interpreter':interpreter,'needed':[],'searchPaths':[]}
        offset,size=dynamic;f.seek(offset);data=f.read(size);tags=[]
        for i in range(0,len(data),16):
            tag,value=struct.unpack_from('<qQ',data,i)
            if tag==0:break
            tags.append((tag,value))
        strings=next((value for tag,value in tags if tag==5),None)
        if strings is None:return {'interpreter':interpreter,'needed':[],'searchPaths':[]}
        translated=next(offset+(strings-a)for a,b,offset in segments if a<=strings<b)
        strsize=next(value for tag,value in tags if tag==10);f.seek(translated);table=f.read(strsize)
        def word(index):return table[index:table.index(0,index)].decode()
        return {'interpreter':interpreter,'needed':[word(v)for t,v in tags if t==1],'searchPaths':[word(v)for t,v in tags if t in [15,29]]}
