#!/usr/bin/env python3
"""UNRUN. Exactly ONE separately granted API inspection/test stage per invocation."""
from pathlib import Path
import argparse,hashlib,json,os,re,signal,subprocess,sys,time
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Use python3 -I -B; assertions must remain enabled')
D=Path(__file__).resolve().parent
R1=Path('/workspace/shared/node-provider-r5-entry-prerequisite-r1')
R2=Path('/workspace/shared/node-provider-r5-sidecar-controller-r2')
R1_SHA='2da5298cc5a1141bd1ec2c04df494c549a8807ead8dc22653216f295ff0a6a0b'
R2_SHA='f4e6dcd989b1d72df5841fac95b9e28720b420686b7c176a8d32fa0337ad6cde'
START=time.monotonic();CLEANUP=2;GUARD_RESERVE=10
parser=argparse.ArgumentParser()
for name in ['manifest-sha','epoch','stage','build-receipt','build-receipt-sha','node-sha','cctest-sha']:parser.add_argument('--'+name,required=True)
a=parser.parse_args();assert a.stage in ['export','cpp-passive','addons-fresh','cpp-gc'];assert a.epoch and all(x.isalnum()or x in '-_'for x in a.epoch)
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert digest(D/'manifest.json')==a.manifest_sha,'Reviewed runtime packet required'
manifest=json.loads((D/'manifest.json').read_text());assert all(digest(D/p)==h for p,h in manifest['files'].items())
# Only now import the exact reviewed helper; -I excludes ordinary cwd imports.
sys.path.insert(0,str(D))
import ownership as own
for folder,digest in [(R1,R1_SHA),(R2,R2_SHA)]:
 assert own.sha(folder/'manifest.json')==digest
 old=json.loads((folder/'manifest.json').read_text());items=old['files'].items()if isinstance(old['files'],dict)else[(x['path'],x['sha256'])for x in old['files']]
 assert all(own.sha(folder/p)==h for p,h in items)
receipt=Path(a.build_receipt).resolve();assert receipt.is_relative_to(R2/'evidence')and receipt.name=='report.json';assert own.sha(receipt)==a.build_receipt_sha,'Actual reviewed build receipt required'
built=json.loads(receipt.read_text());assert built['state']=='NEW_OBJECTS_AND_NODE_CCTEST_LINKED_EXPORT_API_RUNTIME_UNRUN';assert built['reviewedManifestSHA256']==R2_SHA and built['R1ManifestSHA256']==R1_SHA
assert built['finalGuard']['stable']and not built['finalLiveSurvivors']and not built.get('cleanupError')and built['aggregateAfterFinalGuardsSeconds']<=300
assert len(built['stages'])==4 and all(x['state']=='NEW_ELF_BUILD_STAGE_ZERO_RUNTIME_UNRUN'and x['returnCode']==0 and x['guards']['stable']and not x.get('liveSurvivors')for x in built['stages'])
node=R2/'build/node';cctest=R2/'build/cctest'
assert str(node)==built['outputs']['node']['path']and str(cctest)==built['outputs']['cctest']['path']
assert a.node_sha==built['outputs']['node']['sha256']==own.sha(node)
assert a.cctest_sha==built['outputs']['cctest']['sha256']==own.sha(cctest)
freeze=json.loads((D/'input-freeze.json').read_text())
CAP={'export':45,'cpp-passive':45,'addons-fresh':120,'cpp-gc':45}[a.stage]
OUT=D/'evidence'/a.epoch;OUT.mkdir(parents=True,exist_ok=False)
selected=json.loads((D/'stage-plan.json').read_text())['cases']
record={'state':'SETUP','stage':a.stage,'scope':'ONE_SELECTED_R5_STAGE_NOT_BROWSER_ACCEPTANCE','reviewedManifestSHA256':a.manifest_sha,'reviewedBuildReceipt':{'path':str(receipt),'sha256':a.build_receipt_sha},'actualBuiltBinaries':{'nodeSHA256':a.node_sha,'cctestSHA256':a.cctest_sha},'originalPriorNegativeEpochs':'UNCHANGED; newer observer-storage diagnostic also separate','stages':[],'caps':{'aggregateSeconds':CAP,'cleanupSeconds':CLEANUP,'guardReserveSeconds':GUARD_RESERVE},'controllerSignals':[]}
active=None;finalizing=False

def save():record['elapsedSeconds']=time.monotonic()-START;own.write(OUT/'report.json',record)
own.START=START;own.CLEANUP=CLEANUP;own.record=record;own.save=save

def guard():
 wanted=dict(freeze['files']);wanted.update({str(D/p):h for p,h in manifest['files'].items()});wanted.update({str(D/'manifest.json'):a.manifest_sha,str(receipt):a.build_receipt_sha,str(node):a.node_sha,str(cctest):a.cctest_sha})
 bad={};metadata=[]
 for p,h in wanted.items():
  try:actual=own.sha(p)
  except OSError as error:actual='UNREADABLE:'+str(error)
  if actual!=h:bad[p]={'expected':h,'actual':actual}
 for p,expected in freeze['pathResolutions'].items():
  f=Path(p);actual={'resolved':str(f.resolve()),'directLink':os.readlink(f)if f.is_symlink()else None}
  if actual!=expected:metadata.append({'changedPathResolution':p,'actual':actual,'expected':expected})
 for expected in freeze['rootInventories']:
  actual=own.tree(expected['path'])
  if'excludeParts'in expected:
   exclusions=expected['excludeParts'];actual['entries']=[r for r in actual['entries']if not any(x in exclusions for x in Path(r['path']).parts)];actual['excludeParts']=exclusions
  if actual!=expected:metadata.append({'changedIncludeOrDependencyInventory':expected['path']})
 for kind in ['linkSearchDirectoryNames','pathSearchDirectoryNames']:
  for p,expected in freeze[kind].items():
   f=Path(p);actual={'exists':f.is_dir(),'entries':sorted(x.name for x in f.iterdir())if f.is_dir()else[]}
   if actual!=expected:metadata.append({'changedSearchDirectory':p,'kind':kind})
 for n,expected in freeze['environment'].items():
  raw=os.fsencode(os.environ.get(n,''));actual={'present':n in os.environ,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  if actual!=expected:metadata.append({'changedEnvironment':n,'actual':actual,'expected':expected})
 return{'stable':not bad and not metadata,'fileCount':len(wanted),'fileMismatches':bad,'metadataMismatches':metadata}

def interrupt(signum,frame):
 record['controllerSignals'].append({'signal':int(signum),'elapsedSeconds':time.monotonic()-START,'duringFinalCleanup':finalizing})
 if not finalizing:raise InterruptedError('Controller actual signal '+str(signum))
def aggregate(signum,frame):record['aggregateAdministrativeTimeout']=True;interrupt(signum,frame)
signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGALRM,aggregate);signal.setitimer(signal.ITIMER_REAL,max(.001,CAP-(time.monotonic()-START)))

def run(label,argv,cap,env=None):
 global active
 row={'label':label,'argv':[str(x)for x in argv],'capSeconds':cap,'state':'UNRUN','admitted':False};record['stages'].append(row)
 remaining=CAP-(time.monotonic()-START);row['admission']={'remainingSeconds':remaining,'wholeCommandSeconds':cap,'cleanupSeconds':CLEANUP,'guardReserveSeconds':GUARD_RESERVE}
 if remaining<cap+CLEANUP+GUARD_RESERVE:row['state']='UNRUN_NO_WHOLE_ORIGINAL_COMMAND_ADMISSION';save();raise TimeoutError('Insufficient full-command admission; suffix UNRUN')
 row['admitted']=True;row['state']='STARTED';row['administrativeTimeout']=False;row['observedProcesses']=[];begin=time.monotonic();child=None;saved=None;log=OUT/(label+'.log');save()
 try:
  with log.open('xb')as stream:
   child=subprocess.Popen(row['argv'],cwd=D,env=env or os.environ.copy(),stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);active=(child,None,row)
   captured=own.ident(child.pid);row['initialIdentityObservation']=captured
   assert captured and captured['pid']==captured['pgid']==captured['sid'];assert captured['argv']==row['argv'];assert captured['executable']==str(Path(row['argv'][0]).resolve())
   saved=captured;active=(child,saved,row);row['identity']=saved;own.write(OUT/(label+'-identity.json'),saved);save();seen=set();deadline=begin+cap;progress=begin
   allowed={**freeze['files'],str(node):a.node_sha,str(cctest):a.cctest_sha}
   while True:
    assert own.same(saved,own.ident(saved['pid'])),'Unreaped leader identity changed'
    for item in own.members(saved['sid']):
     key=(item['pid'],item['startTicks'])
     if key not in seen:
      seen.add(key);row['observedProcesses'].append(item);assert item['executable']is None or item['executable']in allowed,'Unfrozen observed child executable'
    status=os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
    if status is not None:row['observedLeaderExit']={'si_pid':status.si_pid,'si_code':status.si_code,'si_status':status.si_status};break
    if time.monotonic()>=deadline:row['administrativeTimeout']=True;break
    if time.monotonic()-progress>=20:print(json.dumps({'stage':label,'elapsedSeconds':time.monotonic()-START}),flush=True);progress=time.monotonic()
    time.sleep(.025)
 finally:
  if child is not None:own.close(child,saved,row);active=None
  row['elapsedSeconds']=time.monotonic()-begin
  if log.exists():
   row['logSHA256']=own.sha(log);row['logBytes']=log.stat().st_size
   raw=log.read_text(errors='replace')
   if label in ['cpp-passive','cpp-gc']:record['actualGtest']=observe_gtest(raw,selected['passive4']if label=='cpp-passive'else selected['gc1'])
   if label=='fresh-entry-five':
    observed=[]
    for line in raw.splitlines():
     if line.startswith('{'):
      try:observed.append(json.loads(line))
      except json.JSONDecodeError as error:row.setdefault('observationParseErrors',[]).append(str(error))
    record['actualEntryRows']=observed
  row['guards']=guard();own.write(OUT/(label+'-guards.json'),row['guards']);save()
 assert row.get('returnCode')==0 and not row['administrativeTimeout'],'Actual selected command failure/timeout'
 assert row['guards']['stable']and not row.get('liveSurvivors'),'Actual integrity/session failure'
 row['state']='SELECTED_COMMAND_ZERO';save();return log.read_text(errors='replace')

def observe_gtest(text,wanted):
 clean=re.sub(r'\x1b\[[0-9;]*m','',text)
 actual_run=re.findall(r'^\[\s*RUN\s*\]\s+(\S+)\s*$',clean,re.M);actual_ok=re.findall(r'^\[\s*OK\s*\]\s+(\S+)',clean,re.M)
 failures=re.findall(r'^\[\s*FAILED\s*\]\s+(.+)',clean,re.M);skips=re.findall(r'^\[\s*SKIPPED\s*\]\s+(.+)',clean,re.M)
 return {'expected':wanted,'actualRUN':actual_run,'actualOK':actual_ok,'actualFAILED':failures,'actualSKIPPED':skips,'rawExitNeverNormalized':True}

def gtest(text,wanted):
 data=observe_gtest(text,wanted);record['actualGtest']=data;save()
 assert sorted(data['actualRUN'])==sorted(wanted)and sorted(data['actualOK'])==sorted(wanted)and not data['actualFAILED']and not data['actualSKIPPED'],'Exact selected gtest names/counts differ'

try:
 record['initialGuard']=guard();own.write(OUT/'inputs-before.json',record['initialGuard']);assert record['initialGuard']['stable'],'Exact input preflight mismatch'
 if a.stage=='export':
  record['expectedSymbols']=['node::GetOwnedContextCarrier(']
  for binary in [node,cctest]:
   text=run('nm-'+binary.name,[freeze['additionalToolSearch']['nm']['lookup'],'-D','-C',binary],5);assert 'node::GetOwnedContextCarrier('in text,'New API absent from real dynamic symbol output'
  record['state']='TWO_NEW_OUTPUT_EXPORTS_OBSERVED_ONLY_API_UNRUN'
 elif a.stage in ['cpp-passive','cpp-gc']:
  wanted=selected['passive4']if a.stage=='cpp-passive'else selected['gc1'];text=run(a.stage,[cctest,'--gtest_filter='+':'.join(wanted)],20);gtest(text,wanted);record['state']='SELECTED_CPP_'+str(len(wanted))+'_PASS_ONLY'
 else:
  addon=D/'candidate/addon';assert not(addon/'build').exists(),'Preserve all existing/partial addon outputs';gyp=Path('/workspace/shared/node-provider-build-r4/source/deps/npm/node_modules/node-gyp/bin/node-gyp.js');env=os.environ.copy();env.update({'TMPDIR':str(OUT/'tmp'),'NODE_GYP_FORCE_PYTHON':freeze['selectedPython'],'PYTHON':freeze['selectedPython'],'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','CXX':freeze['selectedCompiler'],'MAKE':freeze['selectedMake']});(OUT/'tmp').mkdir()
  record['addonChildEnvironmentOverrides']={k:env[k]for k in ['TMPDIR','NODE_GYP_FORCE_PYTHON','PYTHON','PYTHONDONTWRITEBYTECODE','PYTHONNOUSERSITE','CXX','MAKE']}
  run('build-own-addons',[node,gyp,'configure','build','--nodedir=/workspace/shared/node-provider-build-r4/source','--directory='+str(addon),'--devdir='+str(D/'gyp-cache'),'--jobs=1'],60,env)
  info={'nodeSHA256':a.node_sha}
  for name,source,binary in [('runtime',addon/'native/runtime.cc',addon/'build/Release/runtime.node'),('fixture',D/'candidate/controls/provider-fixture.cc',addon/'build/Release/provider_fixture.node')]:
   assert binary.is_file()
   with binary.open('rb')as f:assert f.read(4)==b'\x7fELF'
   info[name]={'binary':str(binary),'source':str(source),'binarySHA256':own.sha(binary),'sourceSHA256':own.sha(source)}
  own.write(OUT/'actual-addon-manifest.json',info);text=run('fresh-entry-five',[node,D/'candidate/controls/owned-entry.mjs',OUT/'actual-addon-manifest.json'],8,env);rows=[json.loads(line)for line in text.splitlines()if line.startswith('{')]
  actual=[x['phase']for x in rows if x.get('asserted')is True];record['actualEntryPhases']=actual;save();assert actual==selected['freshEntry5'];assert rows[-1].get('completed')==5 and rows[-1].get('allContextsFresh')is True and rows[-1].get('noDetachOrAsyncClaim')is True
  record['state']='FIVE_FRESH_ENTRY_GROUPS_PASS_ONLY_GC_DETACH_BROWSER_UNPROVED'
except BaseException as error:record['state']='STOPPED_FIRST_SELECTED_SETUP_SIGNAL_PROCESS_VALUE_OR_GUARD_FAILURE';record['error']={'type':type(error).__name__,'message':str(error)}
finally:
 finalizing=True;signal.setitimer(signal.ITIMER_REAL,0)
 if active is not None:
  try:own.close(*active)
  except BaseException as error:record['cleanupError']={'type':type(error).__name__,'message':str(error)}
 record['finalSessions']=[{'identity':row['identity'],'actualMembers':own.members(row['identity']['sid'])}for row in record['stages']if row.get('identity')]
 record['finalLiveSurvivors']=[x for s in record['finalSessions']for x in s['actualMembers']if x['state']!='Z'];record['finalTerminatedZombies']=[x for s in record['finalSessions']for x in s['actualMembers']if x['state']=='Z']
 try:record['finalGuard']=guard();own.write(OUT/'inputs-after.json',record['finalGuard'])
 except BaseException as error:record['finalGuard']={'stable':False,'error':str(error)}
 if not record['finalGuard']['stable']or record['finalLiveSurvivors']or record.get('cleanupError'):record['state']='STOPPED_FINAL_INTEGRITY_OR_OWNERSHIP_FAILURE'
 record['aggregateAfterFinalGuardsSeconds']=time.monotonic()-START
 if record['aggregateAfterFinalGuardsSeconds']>CAP:record['aggregateAdministrativeTimeout']=True;record['state']='STOPPED_AGGREGATE_THRESHOLD_AFTER_FINAL_GUARDS'
 save();print(json.dumps({'state':record['state'],'stage':a.stage,'elapsedSeconds':record['elapsedSeconds'],'guardsStable':record['finalGuard']['stable'],'liveSurvivors':record['finalLiveSurvivors'],'terminatedZombies':record['finalTerminatedZombies'],'report':str(OUT/'report.json')}),flush=True)
sys.exit(0 if record['state']in ['TWO_NEW_OUTPUT_EXPORTS_OBSERVED_ONLY_API_UNRUN','SELECTED_CPP_4_PASS_ONLY','SELECTED_CPP_1_PASS_ONLY','FIVE_FRESH_ENTRY_GROUPS_PASS_ONLY_GC_DETACH_BROWSER_UNPROVED']else 1)
