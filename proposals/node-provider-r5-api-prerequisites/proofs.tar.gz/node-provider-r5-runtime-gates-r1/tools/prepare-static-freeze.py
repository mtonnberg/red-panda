"""STATIC preparation provenance only; no Node/compiler/external tool invocation."""
from pathlib import Path
import sys,sysconfig,json,hashlib,os,shutil,importlib.util
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parents[1];R2=Path('/workspace/shared/node-provider-r5-sidecar-controller-r2');R1=Path('/workspace/shared/node-provider-r5-entry-prerequisite-r1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((R2/'input-freeze.json').read_text());files=dict(base['files']);roots={r['path']:r for r in base['rootInventories']};resolutions=dict(base['pathResolutions']);roles={p:['R2-reviewed-closure']for p in files}
def add(p,role):
 p=Path(p);resolved=p.resolve();assert resolved.is_file(),p;name=str(resolved);h=sha(resolved)
 if name in files:assert files[name]==h,name+' changed'
 files[name]=h;roles.setdefault(name,[]).append(role);resolutions[str(p)]={'resolved':name,'directLink':os.readlink(p)if p.is_symlink()else None};return name
def inventory(root,exclude=()):
 root=Path(root);rows=[]
 if root.exists():
  for p in sorted(root.rglob('*')):
   rel=p.relative_to(root)
   if any(x in exclude for x in rel.parts):continue
   kind='symlink'if p.is_symlink()else'file'if p.is_file()else'dir'if p.is_dir()else'other';row={'path':str(rel),'kind':kind}
   if kind=='symlink':row['target']=os.readlink(p)
   rows.append(row)
 return{'path':str(root),'exists':root.exists(),'entries':rows,'excludeParts':list(exclude)}
m=json.loads((R2/'manifest.json').read_text())
for name,h in m['files'].items():assert sha(R2/name)==h;add(R2/name,'reviewed-R2-controller-and-model')
add(R2/'manifest.json','reviewed-R2-manifest')
# npm's actual bundled dependency tree supplies node-gyp + gyp Python, all offline.
for root in [Path('/workspace/shared/node-provider-build-r4/source/deps/npm'),Path(sysconfig.get_path('stdlib'))]:
 exclude=('__pycache__','site-packages');roots[str(root)]=inventory(root,exclude)
 for p in root.rglob('*'):
  if p.is_file()and not any(x in exclude for x in p.relative_to(root).parts):add(p,'bundled-node-gyp-or-explicit-Python-stdlib')
for p in(D/'candidate').rglob('*'):
 if p.is_file():add(p,'exact-R1-source-own-addon-copy')
for name in ['common.gypi','config.gypi']:add(Path('/workspace/shared/node-provider-build-r4/source')/name,'actual-addon-gyp-configuration')
# Static ELF dependency parser: no ldd/readelf or executable launch.
spec=importlib.util.spec_from_file_location('metadata_readers',D/'reference/metadata_readers.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
lookup=['nm','make','sh','mkdir','rm','mv','touch','ln','cp','sed','printf','flock','env','uname','dirname','cat','ar','g++'];toolLookup={};queue=[sys.executable]
for name in lookup:
 path=shutil.which(name);assert path,name;toolLookup[name]={'lookup':path,'resolved':str(Path(path).resolve())};queue.append(path)
search=[Path('/lib/x86_64-linux-gnu'),Path('/usr/lib/x86_64-linux-gnu'),Path('/lib64'),Path('/usr/lib64')];seen=set();elf=[]
while queue:
 path=queue.pop();resolved=add(path,'runtime-inspection-or-gyp-tool-ELF-closure')
 if resolved in seen:continue
 seen.add(resolved);meta=reader.elf_dependencies(resolved)
 if meta is None:continue
 if meta['interpreter']:queue.append(meta['interpreter'])
 local=[]
 for group in meta['searchPaths']:
  for entry in group.split(':'):
   entry=entry.replace('${ORIGIN}',str(Path(resolved).parent)).replace('$ORIGIN',str(Path(resolved).parent));assert '$'not in entry;local.append(Path(entry))
 deps=[]
 for needed in meta['needed']:
  found=next((p/needed for p in local+search if(p/needed).is_file()),None);assert found,needed;deps.append({'soname':needed,'path':str(found.resolve())});queue.append(str(found))
 elf.append({'path':resolved,**meta,'resolvedDependencies':deps})
for p,h in files.items():assert sha(Path(p))==h,p
# Keep original R2 environment invariant and add Node/gyp/Python knobs.
env=dict(base['environment'])
for name in ['NODE_OPTIONS','NODE_PATH','NODE_GYP_FORCE_PYTHON','PYTHON','PYTHONPATH','PYTHONHOME','PYTHONNOUSERSITE','PYTHONDONTWRITEBYTECODE','MAKE','CXX','CC','AR','GYP_DEFINES','GYP_GENERATORS','npm_config_nodedir','npm_config_devdir','npm_config_arch','npm_config_target','npm_config_disturl','npm_config_runtime']:
 raw=os.fsencode(os.environ.get(name,''));env[name]={'present':name in os.environ,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
assert all({'present':n in os.environ,'bytes':len(os.fsencode(os.environ.get(n,''))),'sha256':hashlib.sha256(os.fsencode(os.environ.get(n,''))).hexdigest()}==v for n,v in env.items())
freeze={'files':files,'roles':roles,'rootInventories':list(roots.values()),'pathResolutions':resolutions,'linkSearchDirectoryNames':base['linkSearchDirectoryNames'],'pathSearchDirectoryNames':base['pathSearchDirectoryNames'],'environment':env,'additionalToolSearch':toolLookup,'extraELFDependencyClosure':elf,'baseR2InputFreezeSHA256':sha(R2/'input-freeze.json'),'selectedPython':str(Path(sys.executable).resolve()),'selectedCompiler':str(Path('/usr/bin/x86_64-linux-gnu-g++-14').resolve()),'selectedMake':str(Path(shutil.which('make')).resolve()),'limits':['No hermetic/sandbox/full-file-open trace claim','Kernel/procfs/Python execution/site import machinery remain host prerequisites','Observed subprocess sampling may miss short-lived processes','Python stdlib excludes site-packages and __pycache__; explicit gyp child PYTHONNOUSERSITE=1 but system site import behavior is not a new compatibility claim','Original R1/R2 source and all prior negative epochs remain immutable']}
(D/'input-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps({'staticFiles':len(files),'extraELFObjects':len(elf),'actualBuildOrRuntimeChildren':0}))
