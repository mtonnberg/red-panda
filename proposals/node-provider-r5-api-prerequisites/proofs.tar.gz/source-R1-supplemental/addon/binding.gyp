{
  "targets": [
    {
      "target_name": "runtime",
      "sources": [
        "native/runtime.cc"
      ],
      "cflags_cc": [
        "-std=c++20"
      ],
      "include_dirs": [
        "../sidecar/src"
      ]
    },
    {
      "target_name": "provider_fixture",
      "sources": [
        "../controls/provider-fixture.cc"
      ],
      "cflags_cc": [
        "-std=c++20"
      ],
      "include_dirs": [
        "../sidecar/src"
      ]
    }
  ]
}
