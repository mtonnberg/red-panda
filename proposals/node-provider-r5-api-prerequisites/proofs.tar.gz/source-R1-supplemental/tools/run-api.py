"""UNRUN. Explicit individual runtime grant required for each named phase."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,signal,time,re
ROOT=Path(__file__).resolve().parents[1];START=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(sys.argv)==3,'phase epoch required'
phase,epoch=sys.argv[1:];assert phase in ['export','cpp-passive','cpp-gc','addons-fresh'];assert epoch and all(c.isalnum()or c in '-_'for c in epoch)
OUT=ROOT/'api-evidence'/epoch;OUT.mkdir(parents=True,exist_ok=False)
manifest=json.loads((ROOT/'manifest.json').read_text());paths=[ROOT/r['path']for r in manifest['files']]+[ROOT/'manifest.json'];assert all(sha(ROOT/r['path'])==r['sha256']for r in manifest['files'])
model=json.loads((ROOT/'evidence/sidecar-link-model.json').read_text());paths.extend(Path(r['path'])for r in model['cacheInputs']);paths.extend(Path(r['path'])for r in model['actualC3BaselineOutputs'].values())
BUILD=ROOT/'build-sidecar';node=BUILD/'node';cctest=BUILD/'cctest';assert node.is_file()and cctest.is_file(),'Build/link new outputs first'
buildReceipt=json.loads((ROOT/'build-evidence/first-build/report.json').read_text());assert buildReceipt.get('stable')is True and buildReceipt.get('status')=='OWN_NEW_LINK_OUTPUTS_ONLY; export/API/runtime/GC_UNRUN'
for name in ['node','cctest']:assert sha(BUILD/name)==buildReceipt['outputs'][name]['sha256'],'Build output identity differs'
original177=json.loads((ROOT/'reference/C3-original177-inputs.json').read_text());assert all(sha(Path(p))==h for p,h in original177.items());paths.extend(Path(p)for p in original177)
paths.extend([node,cctest,ROOT/'build-evidence/first-build/report.json']);guard=lambda:{str(p):sha(p)for p in dict.fromkeys(paths)}
record={'phase':phase,'commands':[],'before':guard(),'status':'started','C3DetachAsyncAndGCNegatives':'UNCHANGED; this is not blanket provider acceptance'}
CAP={'export':15,'cpp-passive':30,'cpp-gc':30,'addons-fresh':90}[phase];record['administrativeCapSeconds']=CAP
(OUT/'report.json').write_text(json.dumps(record,indent=2)+'\n')
def save():(OUT/'report.json').write_text(json.dumps(record,indent=2)+'\n')
def members(group):
 result=[]
 for stat in Path('/proc').glob('[0-9]*/stat'):
  try:
   fields=stat.read_text().rsplit(')',1)[1].split()
   if int(fields[2])==group and fields[0]!='Z':result.append(int(stat.parent.name))
  except (FileNotFoundError,ProcessLookupError,PermissionError,ValueError):pass
 return result
def kill(pid,sig):
 try:os.killpg(pid,sig)
 except ProcessLookupError:pass
def command(label,args,cap,cwd=ROOT):
 row={'label':label,'argv':[str(x)for x in args],'capSeconds':cap,'start':time.monotonic()};record['commands'].append(row);save();child=None
 try:
  remaining=CAP-(time.monotonic()-START);assert remaining>2,'Overall administrative cap expired'
  with(OUT/(label+'.stdout')).open('wb')as out,(OUT/(label+'.stderr')).open('wb')as err:
   child=subprocess.Popen(row['argv'],cwd=cwd,stdout=out,stderr=err,start_new_session=True);row['pid']=child.pid;save();deadline=time.monotonic()+min(cap,remaining-2)
   while True:
    left=deadline-time.monotonic()
    if left<=0:raise subprocess.TimeoutExpired(row['argv'],cap)
    try:row['exitCode']=child.wait(timeout=min(15,left));break
    except subprocess.TimeoutExpired:
     if time.monotonic()>=deadline:raise
     print(json.dumps({'phase':phase,'command':label,'elapsedSec':time.monotonic()-START}),flush=True)
  assert row['exitCode']==0,label+' actual exit failure'
  return(OUT/(label+'.stdout')).read_text(errors='replace')
 finally:
  if child is not None and child.poll()is None:
   kill(child.pid,signal.SIGTERM)
   try:child.wait(timeout=2)
   except subprocess.TimeoutExpired:kill(child.pid,signal.SIGKILL);child.wait()
  survivors=members(child.pid)if child is not None else[]
  if survivors:
   kill(child.pid,signal.SIGTERM);deadline=time.monotonic()+2
   while members(child.pid)and time.monotonic()<deadline:time.sleep(.025)
   if members(child.pid):kill(child.pid,signal.SIGKILL)
  row['survivorsBeforeCleanup']=survivors;row['remainingOwnedPIDs']=members(child.pid)if child is not None else[];row['closed']=not row['remainingOwnedPIDs'];row['elapsedSec']=time.monotonic()-row['start'];save()
try:
 if phase=='export':
  for binary in [node,cctest]:
   text=command('nm-'+binary.name,['/usr/bin/nm','-D','-C',binary],5);assert 'node::GetOwnedContextCarrier('in text,'New public API not exported'
  record['status']='NEW_SYMBOL_EXPORT_ONLY; API_RUNTIME_UNRUN'
 elif phase in ['cpp-passive','cpp-gc']:
  gc='OwnedCarrierR5Test.HeapStoredWeakCustodyWithOrdinaryAndOwnedBaseline';selected=gc if phase=='cpp-gc'else'OwnedCarrierR5Test.*-'+gc;expected=1 if phase=='cpp-gc'else 4
  text=command(phase,[cctest,'--gtest_filter='+selected],20);assert re.search(r'\[\s*PASSED\s*\]\s*'+str(expected)+r' tests?\.',text),'Actual gtest count differs';assert '[  SKIPPED ]'not in text
  record['actualPassed']=expected;record['status']='SELECTED_CPP_CONTROLS_PASS_ONLY'
 else:
  addon=ROOT/'addon';assert not(addon/'build').exists(),'Preserve prior addon outputs; no implicit retry'
  gyp=Path('/workspace/shared/node-provider-build-r4/source/deps/npm/node_modules/node-gyp/bin/node-gyp.js');assert gyp.is_file()
  command('build-addons',[node,gyp,'configure','build','--nodedir=/workspace/shared/node-provider-build-r4/source','--directory='+str(addon),'--devdir='+str(ROOT/'gyp-cache'),'--jobs=1'],60)
  metadata={'nodeSHA256':sha(node)}
  for name,source in [('runtime',addon/'native/runtime.cc'),('fixture',ROOT/'controls/provider-fixture.cc')]:
   binary=addon/'build/Release'/('runtime.node'if name=='runtime'else'provider_fixture.node');metadata[name]={'binary':str(binary),'source':str(source),'binarySHA256':sha(binary),'sourceSHA256':sha(source)}
  file=OUT/'addons.json';file.write_text(json.dumps(metadata,indent=2)+'\n');text=command('fresh-owned-entry',[node,ROOT/'controls/owned-entry.mjs',file],8)
  rows=[json.loads(line)for line in text.splitlines()if line.startswith('{')];assert sum(r.get('asserted')is True for r in rows)==5;assert rows[-1].get('completed')==5;assert rows[-1].get('allContextsFresh')is True
  record['actualOrderedGroups']=5;record['status']='FRESH_ENTRY_CONTROLS_PASS_ONLY; DETACH_GC_BROWSER_UNPROVED'
except BaseException as error:record['status']='stopped-first-contrary';record['error']={'name':type(error).__name__,'message':str(error)}
finally:
 if not all(row.get('closed')for row in record['commands']):record['status']='stopped-first-contrary';record['cleanupFailure']=True
 record['after']=guard();record['stable']=record['before']==record['after'];record['elapsedSec']=time.monotonic()-START;save();print(json.dumps({'status':record['status'],'stable':record['stable'],'elapsedSec':record['elapsedSec']}),flush=True)
if not record['stable']or record['status']=='stopped-first-contrary':sys.exit(1)
