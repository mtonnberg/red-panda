"""Static metadata/hash verification only. Never invokes compiler/Node/linker/Ninja."""
from pathlib import Path
import json,hashlib,shlex,re
R=Path(__file__).resolve().parents[1];j=json.loads((R/'evidence/sidecar-link-model.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert j['cryptographicCacheGuardsMaterialized']is True
assert all(sha(Path(r['path']))==r['sha256']for r in j['cacheInputs'])
assert sha(Path(j['compiler']['resolvedPath']))==j['compiler']['sha256']
for m in j['models']:assert sha(Path(m['ninja']))==m['ninjaSHA256']
for row in j['futureCommands']:
 args=row['argv'];assert args[0]==j['compiler']['resolvedPath'];assert Path(args[args.index('-o')+1]).is_relative_to(R/'build-sidecar')
 if row['label'].startswith('compile-'):
  assert Path(args[args.index('-MF')+1]).is_relative_to(R/'build-sidecar')
  assert Path(args[args.index('-c')+1]).is_relative_to(R/'sidecar')
 else:
  assert '-rdynamic'in args and '-Wl,--start-group'in args and '-Wl,--end-group'in args
  assert not any(x.startswith(('-Wl,-Map','-Wl,--dependency-file','-save-temps','-flto','-Wl,--thinlto'))for x in args)
for item in j['actualC3BaselineOutputs'].values():assert sha(Path(item['path']))==item['sha256']
print(json.dumps({'staticModelValid':True,'originalGuardedInputs':len(j['cacheInputs']),'originalGuardedBytes':j['cacheInputBytes'],'newCommands':len(j['futureCommands']),'build':'UNRUN'}))
