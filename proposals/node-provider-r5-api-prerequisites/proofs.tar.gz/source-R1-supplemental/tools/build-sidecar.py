"""UNRUN, explicit build grant required. Only own compile/link outputs, no tests."""
from pathlib import Path
import json,hashlib,os,time,subprocess,signal,sys
ROOT=Path(__file__).resolve().parents[1];START=time.monotonic();CAP=300;PER_COMMAND=120;CLEANUP=2
epoch=sys.argv[1]if len(sys.argv)==2 else '';assert epoch and all(c.isalnum()or c in '-_'for c in epoch),'Supply a new evidence epoch'
OUT=ROOT/'build-evidence'/epoch;OUT.mkdir(parents=True,exist_ok=False);BUILD=ROOT/'build-sidecar';assert not BUILD.exists(),'Preserve prior outputs; no implicit retry/rebuild';BUILD.mkdir();(BUILD/'tmp').mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((ROOT/'manifest.json').read_text());assert all(sha(ROOT/r['path'])==r['sha256']for r in manifest['files']),'Proposal differs'
model=json.loads((ROOT/'evidence/sidecar-link-model.json').read_text());assert all(sha(Path(r['path']))==r['sha256']for r in model['cacheInputs']),'C3 exact object/archive closure differs'
paths=[ROOT/r['path']for r in manifest['files']]+[ROOT/'manifest.json',Path(model['compiler']['resolvedPath'])]+[Path(r['path'])for r in model['cacheInputs']]
for m in model['models']:paths.append(Path(m['ninja']))
for c in model['compileTemplates'].values():
 tokens=c['argv'];i=0
 while i<len(tokens):
  item=tokens[i];directory=None
  if item=='-I':i+=1;directory=tokens[i]
  elif item.startswith('-I'):directory=item[2:]
  if directory:
   base=(Path(c['directory'])/directory).resolve()
   if base.is_dir():paths.extend(p for p in base.rglob('*')if p.is_file())
  i+=1
for r in model['actualC3BaselineOutputs'].values():paths.append(Path(r['path']))
original177=json.loads((ROOT/'reference/C3-original177-inputs.json').read_text());assert all(sha(Path(p))==h for p,h in original177.items());paths.extend(Path(p)for p in original177)
paths=list(dict.fromkeys(p.resolve()for p in paths));guard=lambda:{str(p):sha(p)for p in paths}
record={'scope':'New internal API/test objects + NEW Node/cctest links from immutable C3 graph; no C3 source/object writes','before':guard(),'commands':[],'capSeconds':CAP,'perCommandSeconds':PER_COMMAND,'tests':'UNRUN','status':'started'}
env=os.environ.copy();env['TMPDIR']=str(BUILD/'tmp')
def save():(OUT/'report.json').write_text(json.dumps(record,indent=2)+'\n')
def members(group):
 result=[]
 for stat in Path('/proc').glob('[0-9]*/stat'):
  try:
   fields=stat.read_text().rsplit(')',1)[1].split()
   if int(fields[2])==group and fields[0]!='Z':result.append(int(stat.parent.name))
  except (FileNotFoundError,ProcessLookupError,PermissionError,ValueError):pass
 return result
def kill(pid,sig):
 try:os.killpg(pid,sig)
 except ProcessLookupError:pass
try:
 for spec in model['futureCommands']:
  remaining=CAP-(time.monotonic()-START)
  if remaining<=CLEANUP:raise TimeoutError('Owned total build allowance expired')
  row={**spec,'startedMonotonic':time.monotonic()};record['commands'].append(row);child=None;save()
  try:
   with(OUT/(spec['label']+'.stdout')).open('wb')as stdout,(OUT/(spec['label']+'.stderr')).open('wb')as stderr:
    child=subprocess.Popen(spec['argv'],cwd=spec['cwd'],env=env,stdout=stdout,stderr=stderr,start_new_session=True);row['pid']=child.pid;save()
    try:
     deadline=time.monotonic()+min(PER_COMMAND,remaining)
     while True:
      left=deadline-time.monotonic()
      if left<=0:raise subprocess.TimeoutExpired(spec['argv'],min(PER_COMMAND,remaining))
      try:row['exitCode']=child.wait(timeout=min(20,left));break
      except subprocess.TimeoutExpired:
       if time.monotonic()>=deadline:raise
       print(json.dumps({'stage':spec['label'],'elapsedSec':time.monotonic()-START,'stillRunning':True}),flush=True)
    except subprocess.TimeoutExpired:
     row['administrativeTimeout']=True;kill(child.pid,signal.SIGTERM)
     try:child.wait(timeout=CLEANUP)
     except subprocess.TimeoutExpired:kill(child.pid,signal.SIGKILL);child.wait()
     raise
   if row['exitCode']!=0:raise RuntimeError(spec['label']+' actual failure; later stages UNRUN')
  finally:
   if child is not None and child.poll()is None:kill(child.pid,signal.SIGKILL);child.wait()
   survivors=members(child.pid)if child is not None else[]
   if survivors:
    kill(child.pid,signal.SIGTERM);deadline=time.monotonic()+CLEANUP
    while members(child.pid)and time.monotonic()<deadline:time.sleep(.025)
    if members(child.pid):kill(child.pid,signal.SIGKILL)
   row['survivorsBeforeCleanup']=survivors;row['remainingOwnedPIDs']=members(child.pid)if child is not None else[];row['closed']=not row['remainingOwnedPIDs'];row['elapsedSec']=time.monotonic()-row['startedMonotonic'];save();print(json.dumps({k:v for k,v in row.items()if k!='argv'}),flush=True)
 record['outputs']={name:{'path':str(BUILD/name),'sha256':sha(BUILD/name),'bytes':(BUILD/name).stat().st_size}for name in ['node','cctest']};record['status']='OWN_NEW_LINK_OUTPUTS_ONLY; export/API/runtime/GC_UNRUN'
 if not all(row.get('closed')for row in record['commands']):raise RuntimeError('Owned build process survived cleanup')
except BaseException as error:record['status']='stopped-first-build-contrary';record['error']={'name':type(error).__name__,'message':str(error)}
finally:record['after']=guard();record['stable']=record['before']==record['after'];record['elapsedSec']=time.monotonic()-START;save();print(json.dumps({'status':record['status'],'stable':record['stable']}),flush=True)
if not record['stable']or record['status']=='stopped-first-build-contrary':sys.exit(1)
