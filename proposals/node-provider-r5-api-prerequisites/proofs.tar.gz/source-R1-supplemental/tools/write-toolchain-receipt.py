"""Static receipt writer AFTER genuine individual controls; never manufactures observations."""
from pathlib import Path
import json,hashlib,sys
R=Path(__file__).resolve().parents[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(sys.argv)==2,'New output receipt path required';out=Path(sys.argv[1]);assert not out.exists()
build=json.loads((R/'build-evidence/first-build/report.json').read_text());assert build.get('stable')is True and build['status']=='OWN_NEW_LINK_OUTPUTS_ONLY; export/API/runtime/GC_UNRUN'
expected={'first-export':'NEW_SYMBOL_EXPORT_ONLY; API_RUNTIME_UNRUN','first-cpp-passive':'SELECTED_CPP_CONTROLS_PASS_ONLY','first-entry':'FRESH_ENTRY_CONTROLS_PASS_ONLY; DETACH_GC_BROWSER_UNPROVED','first-cpp-gc':'SELECTED_CPP_CONTROLS_PASS_ONLY'}
receipts=[]
for epoch,status in expected.items():
 p=R/'api-evidence'/epoch/'report.json';j=json.loads(p.read_text());assert j.get('stable')is True and j['status']==status;receipts.append({'path':str(p),'sha256':sha(p)})
node=R/'build-sidecar/node';assert sha(node)==build['outputs']['node']['sha256']
result={'status':'SELECTED_R5_API_CONTROLS_PASSED_NOT_BROWSER_OR_DETACHED_ASYNC_VALIDATED','providerSourceManifest':sha(R/'sidecar-source-contract.json'),'binary':str(node),'binarySHA256':sha(node),'buildReceiptSHA256':sha(R/'build-evidence/first-build/report.json'),'selectedAPIReceipts':receipts,'knownC3NegativesUnchanged':True}
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2)+'\n');print(str(out))
