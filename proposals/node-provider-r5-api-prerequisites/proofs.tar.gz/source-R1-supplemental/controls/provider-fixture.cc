// Privileged test fixture only; no carrier/provider object is a browser API.
#include <node.h>
#if __has_include(<node_owned_carrier_api.h>)
#include <node_owned_carrier_api.h>
#endif
#include <node_version.h>
#include <v8.h>
#include <utility>
#include <initializer_list>
#ifndef NODE_HAVE_OWNED_CONTEXT_CARRIER_LOOKUP
#error "Actual extended Node headers/runtime are required"
#endif
namespace {
using namespace v8;
struct State{node::Environment* env;Global<Context> host;};
State* StateOf(const FunctionCallbackInfo<Value>& info){return static_cast<State*>(info.Data().As<External>()->Value());}
node::Environment* Env(const FunctionCallbackInfo<Value>& info){return StateOf(info)->env;}
bool Access(Local<Context> caller,Local<Object>,Local<Value> data){auto* state=static_cast<State*>(data.As<External>()->Value());return caller==state->host.Get(caller->GetIsolate());}
void Create(const FunctionCallbackInfo<Value>& info){
 auto* isolate=info.GetIsolate();if(info.Length()!=2||!info[0]->IsObject()||!info[1]->IsSymbol()){isolate->ThrowException(Exception::TypeError(String::NewFromUtf8Literal(isolate,"Actual ticket/token required")));return;}
 node::OwnedContextOptions options;Local<Context> context;auto blueprint=ObjectTemplate::New(isolate);blueprint->SetAccessCheckCallback(Access,info.Data());
 if(node::CreateOwnedContext(Env(info),info[0].As<Object>(),blueprint,info[1],options).ToLocal(&context))info.GetReturnValue().Set(context->Global());
}
void SameRealm(const FunctionCallbackInfo<Value>& info){Local<Context> actual,owner;if(info.Length()!=2||!info[1]->IsObject())return;if(!node::GetOwnedContext(Env(info),info[1].As<Object>()).ToLocal(&owner))return;info.GetReturnValue().Set(info[0]->IsObject()&&info[0].As<Object>()->GetCreationContext().ToLocal(&actual)&&actual==owner);}
void CarrierFor(const FunctionCallbackInfo<Value>& info){Local<Context> actual;Local<Object> carrier;if(info.Length()!=1||!info[0]->IsObject())return;if(info[0].As<Object>()->GetCreationContext().ToLocal(&actual)&&node::GetOwnedContextCarrier(Env(info),actual).ToLocal(&carrier))info.GetReturnValue().Set(carrier);}
NODE_MODULE_INIT(){auto* env=node::GetCurrentEnvironment(context);if(!env)return;auto* state=new State{env,{}};state->host.Reset(context->GetIsolate(),context);node::AddEnvironmentCleanupHook(context->GetIsolate(),[](void* p){auto* state=static_cast<State*>(p);state->host.Reset();delete state;},state);const auto data=External::New(context->GetIsolate(),state);for(const auto& item:{std::pair<const char*,FunctionCallback>{"create",Create},{"sameRealm",SameRealm},{"carrierFor",CarrierFor}})exports->CreateDataProperty(context,String::NewFromUtf8(context->GetIsolate(),item.first).ToLocalChecked(),Function::New(context,item.second,data).ToLocalChecked()).Check();}
}  // namespace
