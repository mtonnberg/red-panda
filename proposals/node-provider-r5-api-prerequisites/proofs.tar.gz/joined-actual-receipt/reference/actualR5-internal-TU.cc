// NEW Node-internal TU, linked into NEW Node/cctest, never into an addon.
#include "node_owned_carrier_api.h"
#include "env-inl.h"
#include "node_contextify.h"
#include "node_context_data.h"
#include "node_errors.h"
namespace node {
v8::MaybeLocal<v8::Object> GetOwnedContextCarrier(
    Environment* env, v8::Local<v8::Context> context) {
  if (env == nullptr || context.IsEmpty() ||
      context->GetIsolate() != env->isolate() ||
      !ContextEmbedderTag::IsNodeContext(context) ||
      Environment::GetCurrent(context) != env) {
    return {};
  }
  // The real Node tag guarantees the complete configured embedder-data layout.
  // This is the existing traced Value, not an address map or additional root.
  v8::Local<v8::Value> value = context->GetEmbedderData(
      ContextEmbedderIndex::kOwnedContextCarrier);
  if (!value->IsObject()) return {};
  v8::Local<v8::Object> carrier = value.As<v8::Object>();
  contextify::ContextifyContext* owned =
      contextify::ContextifyContext::FromOwnedCarrier(env, carrier);
  if (owned == nullptr) return {};
  if (owned->context() != context) {
    THROW_ERR_INVALID_STATE(env->isolate(), "Owned context authority mismatch");
    return {};
  }
  return carrier;
}

}  // namespace node
