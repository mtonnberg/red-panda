// New source-only R5 controls. All syntax/build/runtime outcomes UNRUN.
#include <node.h>
#include "node_owned_carrier_api.h"
#include <v8.h>
#include <memory>
#include "node_contextify.h"
#include "node_context_data.h"
#include "node_test_fixture.h"

using namespace v8;
class OwnedCarrierR5Test : public EnvironmentTestFixture {};
namespace {
Local<String> Key(Isolate* isolate,const char* text){return String::NewFromUtf8(isolate,text).ToLocalChecked();}
Local<Array> Tickets(node::Environment* env){return node::LoadEnvironment(env,"const vm=require('node:vm');return [vm.prepareOwnedContext(),vm.prepareOwnedContext(),vm.createContext({})];").ToLocalChecked().As<Array>();}
Local<Context> Make(Isolate* isolate,node::Environment* env,Local<Object> carrier,Local<ObjectTemplate> blueprint){node::OwnedContextOptions options;return node::CreateOwnedContext(env,carrier,blueprint,env->context()->GetSecurityToken(),options).ToLocalChecked();}
void Incumbent(const FunctionCallbackInfo<Value>& info){auto* env=static_cast<node::Environment*>(info.Data().As<External>()->Value());Local<Object> value;if(node::GetOwnedContextCarrier(env,info.GetIsolate()->GetIncumbentContext()).ToLocal(&value))info.GetReturnValue().Set(value);}
struct WeakRoots{Global<Context> context;Global<Object> carrier;};
V8_NOINLINE void PrepareWeak(Isolate* isolate,node::Environment* env,Local<Context> host,Local<Object> carrier,bool lookup,WeakRoots* roots){
 HandleScope inner(isolate);Local<Context> context;
 if(carrier.IsEmpty())return;
 if(node::contextify::ContextifyContext* ordinary=node::contextify::ContextifyContext::ContextFromContextifiedSandbox(env,carrier)){context=ordinary->context();}
 else context=Make(isolate,env,carrier,ObjectTemplate::New(isolate));
 if(lookup)EXPECT_EQ(node::GetOwnedContextCarrier(env,context).ToLocalChecked(),carrier);
 roots->context.Reset(isolate,context);roots->context.SetWeak();roots->carrier.Reset(isolate,carrier);roots->carrier.SetWeak();
}
V8_NOINLINE void PopulateWeak(Isolate* isolate,node::Environment* env,Local<Context> host,WeakRoots* ordinary,WeakRoots* baseline,WeakRoots* queried){
 HandleScope inner(isolate);auto values=Tickets(env);
 PrepareWeak(isolate,env,host,values->Get(host,2).ToLocalChecked().As<Object>(),false,ordinary);
 PrepareWeak(isolate,env,host,values->Get(host,0).ToLocalChecked().As<Object>(),false,baseline);
 PrepareWeak(isolate,env,host,values->Get(host,1).ToLocalChecked().As<Object>(),true,queried);
}
}  // namespace

TEST_F(OwnedCarrierR5Test, ActiveCanonicalContextAndIncumbent){
 const HandleScope handles(isolate_);const Argv argv;Env env{handles,argv};auto host=env.context();auto tickets=Tickets(*env);auto carrier=tickets->Get(host,0).ToLocalChecked().As<Object>();
 auto owner=Make(isolate_,*env,carrier,ObjectTemplate::New(isolate_));ASSERT_EQ(node::GetOwnedContextCarrier(*env,owner).ToLocalChecked(),carrier);
 Context::Scope scope(owner);auto function=Function::New(owner,Incumbent,External::New(isolate_,*env)).ToLocalChecked();ASSERT_TRUE(owner->Global()->Set(owner,Key(isolate_,"readCarrier"),function).FromMaybe(false));
 ASSERT_EQ(Script::Compile(owner,Key(isolate_,"readCarrier()")).ToLocalChecked()->Run(owner).ToLocalChecked(),carrier);
 ASSERT_EQ(function->GetCreationContext().ToLocalChecked(),owner);ASSERT_EQ(node::GetOwnedContext(*env,carrier).ToLocalChecked(),owner);
}

TEST_F(OwnedCarrierR5Test, PassiveOldAndNewContextsHaveDistinctCarriersAfterReuse){
 const HandleScope handles(isolate_);const Argv argv;Env env{handles,argv};auto host=env.context();auto tickets=Tickets(*env);auto a=tickets->Get(host,0).ToLocalChecked().As<Object>(),b=tickets->Get(host,1).ToLocalChecked().As<Object>();auto blueprint=ObjectTemplate::New(isolate_);
 auto first=Make(isolate_,*env,a,blueprint);auto original=first->Global();ASSERT_EQ(node::DetachOwnedContext(*env,a).ToLocalChecked(),original);node::OwnedContextOptions options;
 auto second=node::CreateOwnedContext(*env,b,blueprint,host->GetSecurityToken(),options,a).ToLocalChecked();ASSERT_EQ(second->Global(),original);ASSERT_NE(first,second);
 ASSERT_EQ(node::GetOwnedContextCarrier(*env,first).ToLocalChecked(),a);ASSERT_EQ(node::GetOwnedContextCarrier(*env,second).ToLocalChecked(),b);
 ASSERT_EQ(node::GetOwnedContext(*env,a).ToLocalChecked(),first);ASSERT_EQ(node::GetOwnedContext(*env,b).ToLocalChecked(),second);
 // Passive metadata only: NEVER execute old JS or enqueue old Promise work.
 // Native creationDocument.URL failure and C3 detached-async failure remain.
}

TEST_F(OwnedCarrierR5Test, OrdinaryForeignRawAndEmptyAreNotOwned){
 const HandleScope handles(isolate_);const Argv argv;Env env{handles,argv};auto host=env.context();auto tickets=Tickets(*env);auto a=tickets->Get(host,0).ToLocalChecked().As<Object>(),sandbox=tickets->Get(host,2).ToLocalChecked().As<Object>();auto owned=Make(isolate_,*env,a,ObjectTemplate::New(isolate_));
 auto* ordinary=node::contextify::ContextifyContext::ContextFromContextifiedSandbox(*env,sandbox);ASSERT_NE(ordinary,nullptr);auto raw=Context::New(isolate_);TryCatch caught(isolate_);
 ASSERT_TRUE(node::GetOwnedContextCarrier(*env,host).IsEmpty());ASSERT_TRUE(node::GetOwnedContextCarrier(*env,ordinary->context()).IsEmpty());ASSERT_TRUE(node::GetOwnedContextCarrier(*env,raw).IsEmpty());ASSERT_TRUE(node::GetOwnedContextCarrier(*env,Local<Context>()).IsEmpty());ASSERT_TRUE(node::GetOwnedContextCarrier(nullptr,owned).IsEmpty());
 {Env foreign{handles,argv};ASSERT_TRUE(node::GetOwnedContextCarrier(*foreign,owned).IsEmpty());ASSERT_TRUE(node::GetOwnedContextCarrier(*env,foreign.context()).IsEmpty());}
 ASSERT_FALSE(caught.HasCaught());ASSERT_EQ(node::GetOwnedContextCarrier(*env,owned).ToLocalChecked(),a);
}

TEST_F(OwnedCarrierR5Test, ScalarAbsentAndMalformedOrWrongGenerationNeverAuthenticate){
 const HandleScope handles(isolate_);const Argv argv;Env env{handles,argv};auto host=env.context();auto tickets=Tickets(*env);auto a=tickets->Get(host,0).ToLocalChecked().As<Object>(),b=tickets->Get(host,1).ToLocalChecked().As<Object>();auto first=Make(isolate_,*env,a,ObjectTemplate::New(isolate_));auto second=Make(isolate_,*env,b,ObjectTemplate::New(isolate_));
 // Internal fault injection uses the NODE symbolic slot, never addon numeric
 // discovery or browser-visible mutation; restore it before leaving each arm.
 const int slot=node::ContextEmbedderIndex::kOwnedContextCarrier;
 first->SetEmbedderData(slot,Null(isolate_));{TryCatch caught(isolate_);ASSERT_TRUE(node::GetOwnedContextCarrier(*env,first).IsEmpty());ASSERT_FALSE(caught.HasCaught());}first->SetEmbedderData(slot,a);
 for(auto wrong:{Object::New(isolate_),b}){TryCatch caught(isolate_);first->SetEmbedderData(slot,wrong);EXPECT_TRUE(node::GetOwnedContextCarrier(*env,first).IsEmpty());first->SetEmbedderData(slot,a);EXPECT_TRUE(caught.HasCaught());if(caught.HasCaught()){auto error=caught.Exception().As<Object>();EXPECT_TRUE(error->Get(host,Key(isolate_,"code")).ToLocalChecked()->StrictEquals(Key(isolate_,"ERR_INVALID_STATE")));}caught.Reset();}
 ASSERT_EQ(node::GetOwnedContextCarrier(*env,first).ToLocalChecked(),a);ASSERT_EQ(node::GetOwnedContextCarrier(*env,second).ToLocalChecked(),b);
}

TEST_F(OwnedCarrierR5Test, HeapStoredWeakCustodyWithOrdinaryAndOwnedBaseline){
 const HandleScope handles(isolate_);const Argv argv;Env env{handles,argv};
 auto ordinary=std::make_unique<WeakRoots>(),baseline=std::make_unique<WeakRoots>(),queried=std::make_unique<WeakRoots>();PopulateWeak(isolate_,*env,env.context(),ordinary.get(),baseline.get(),queried.get());
 // Same original8 bound. Actual C3 had3 bounded noncollection failures; this
 // separate heap-storage/baseline discriminator does not erase or explain them.
 for(int i=0;i<8;i++){isolate_->LowMemoryNotification();platform->DrainTasks(isolate_);}
 EXPECT_TRUE(ordinary->context.IsEmpty());EXPECT_TRUE(ordinary->carrier.IsEmpty());EXPECT_TRUE(baseline->context.IsEmpty());EXPECT_TRUE(baseline->carrier.IsEmpty());EXPECT_TRUE(queried->context.IsEmpty());EXPECT_TRUE(queried->carrier.IsEmpty());
}
