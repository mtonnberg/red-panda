// All five ordered groups UNRUN. No old Context is detached/executed here.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
const file=process.argv[2];if(!file)throw Error('Exact built addon/Node manifest required');
const manifest=JSON.parse(readFileSync(file,'utf8')),digest=p=>createHash('sha256').update(readFileSync(p)).digest('hex'),require=createRequire(import.meta.url);
assert.equal(digest(process.execPath),manifest.nodeSHA256);for(const item of[manifest.runtime,manifest.fixture]){assert.equal(digest(item.binary),item.binarySHA256);assert.equal(digest(item.source),item.sourceSHA256)}
const evaluate=(source,carrier)=>vm.runInContext(source,carrier,{timeout:200});
const runtime=require(resolve(manifest.runtime.binary)),fixture=require(resolve(manifest.fixture.binary));assert.equal(runtime.ownedEntryVersion,1);assert.equal(typeof runtime.createOwnedEntry,'function');assert.equal(typeof vm.prepareOwnedContext,'function');
const watchdog=setTimeout(()=>{process.stderr.write('OWNED_ENTRY_FRESH_DEADLINE\n');process.exit(92)},5000);watchdog.unref();let completed=0;
const phase=name=>{completed++;process.stdout.write(JSON.stringify({phase:name,asserted:true})+'\n')};
try{
 const token=Symbol('real same principal'),a=vm.prepareOwnedContext(),b=vm.prepareOwnedContext();const ga=fixture.create(a,token),gb=fixture.create(b,token),anchorA=evaluate('({})',a),anchorB=evaluate('({})',b);
 assert.equal(fixture.carrierFor(anchorA),a);assert.equal(fixture.carrierFor(anchorB),b);assert.notEqual(a,b);assert.notEqual(ga,gb);
 phase('actual-fresh-context-carrier-identity');
 const records=[],callback=function(authority,receiver,args){records.push({authority,receiver,args});return args[0]},entry=runtime.createOwnedEntry(callback,a,'actualEntry');ga.entry=entry;gb.entry=entry;
 const valueA=evaluate('globalThis.own={real:1};entry(own)',a);assert.equal(valueA,ga.own);const first=records.at(-1);assert.equal(first.authority.current.kind,'owned');assert.equal(first.authority.current.carrier,a);assert.equal(first.authority.incumbent.carrier,a);assert.equal(first.authority.entered.carrier,a);assert.equal(fixture.sameRealm(first.args,a),true);assert.equal(Object.getPrototypeOf(first.authority),null);for(const value of Object.values(first.authority))assert.equal(Object.getPrototypeOf(value),null);
 phase('genuine-current-incumbent-entered-and-arguments');
 const valueB=evaluate('globalThis.own={real:2};entry(own)',b);assert.equal(valueB,gb.own);const borrowed=records.at(-1);assert.equal(borrowed.authority.current.carrier,a);assert.equal(borrowed.authority.incumbent.carrier,b);assert.equal(borrowed.authority.entered.carrier,b);assert.equal(fixture.sameRealm(borrowed.args,a),true);
 phase('fresh-foreign-caller-keeps-definition-and-caller-separate');
 assert.equal(entry(7),7);const host=records.at(-1);assert.equal(host.authority.current.carrier,a);assert.equal(host.authority.incumbent.kind,'unowned');assert.equal(host.authority.incumbent.carrier,null);assert.equal(host.authority.entered.kind,'unowned');
 for(const object of[entry,first.args,borrowed.args]){assert.equal(fixture.sameRealm(object,a),true);assert.equal(fixture.sameRealm(object,b),false);const prototype=Object.getPrototypeOf(object);Object.setPrototypeOf(object,null);assert.equal(fixture.sameRealm(object,a),true);assert.equal(fixture.sameRealm(object,b),false);Object.setPrototypeOf(object,prototype)}
 phase('actual-entry-and-argument-creation-context-before-after-null');
 const foreign=evaluate('()=>0',b);assert.throws(()=>runtime.createOwnedEntry(foreign,a,'bad'));const fake=Object.create(a);assert.throws(()=>runtime.createOwnedEntry(callback,fake,'bad'));assert.throws(()=>runtime.createOwnedEntry(callback,new Proxy(a,{}),'bad'));assert.equal(vm.isContext(a),true);assert.equal(vm.isContext(b),true);const descriptor=Object.getOwnPropertyDescriptor(entry,'name');assert.equal(descriptor.value,'actualEntry');assert.throws(()=>new entry(),error=>error?.name==='TypeError');assert.equal(evaluate('(function(){try{new entry()}catch(e){return e instanceof TypeError}})()',a),true);
 const originalError=new Error('actual Host callback failure'),throwing=runtime.createOwnedEntry(()=>{throw originalError},a,'throwingEntry');assert.throws(()=>throwing(),error=>error===originalError);
 assert.equal(typeof runtime.promiseSnapshot,'function');assert.equal(typeof runtime.consumeObservedPromise,'function');assert.equal(typeof runtime.errorOrigin,'function');assert.equal(typeof runtime.createEntry,'function');
 phase('strong-carrier-callback-boundary-and-current-legacy-exports');
}catch(error){process.stdout.write(JSON.stringify({phase:'failure',completed,message:error.message,stack:error.stack})+'\n');throw error}
finally{clearTimeout(watchdog);process.stdout.write(JSON.stringify({phase:'finished',completed,allContextsFresh:true,noDetachOrAsyncClaim:true})+'\n')}
