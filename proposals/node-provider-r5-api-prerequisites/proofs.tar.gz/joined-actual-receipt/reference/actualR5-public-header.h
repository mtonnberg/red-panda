// Supplemental public SDK header for an actually relinked owned Node only.
#ifndef NODE_OWNED_CARRIER_API_H_
#define NODE_OWNED_CARRIER_API_H_
#include <node.h>
#define NODE_HAVE_OWNED_CONTEXT_CARRIER_LOOKUP 1
namespace node {
// Passive identity only. Requires the same live Environment / owning thread.
// Ordinary, foreign, empty, untagged or scalar-anchor Contexts return empty.
// Malformed object/canonical mismatch retains ERR_INVALID_STATE. No extra root.
NODE_EXTERN v8::MaybeLocal<v8::Object> GetOwnedContextCarrier(
    Environment* env, v8::Local<v8::Context> context);
}
#endif
