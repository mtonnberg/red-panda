import {Worker,isMainThread,parentPort}from'node:worker_threads';
import {createRequire}from'node:module';
import vm from'node:vm';
import {writeFile}from'node:fs/promises';
import{once}from'node:events';
if(isMainThread){const worker=new Worker(new URL(import.meta.url),{execArgv:['--experimental-vm-modules']});let message;try{[message]=await once(worker,'message');await once(worker,'exit');}finally{await worker.terminate()}await writeFile(process.argv[2],JSON.stringify(message,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({wall:message.wall,cpu:message.cpu,cpuSource:message.cpuSource,compile:message.compile,modules:message.modules.slice(0,12)}));}
else{
 const require=createRequire(import.meta.url),Module=require('node:module'),originalCompile=Module.prototype._compile,originalFunction=vm.compileFunction,clock=()=>Number(process.hrtime.bigint())/1e6,cpuReader=process.threadCpuUsage?()=>process.threadCpuUsage():()=>process.cpuUsage(),cpuValue=()=>{const r=cpuReader();return(r.user+r.system)/1000},modules=new Map(),stack=[],compile={count:0,wall:0,cpu:0,sourceBytes:0},start=clock(),cpuStart=cpuValue();
 Module.prototype._compile=function(source,filename,...rest){const at=clock(),cpuAt=cpuValue(),entry={childWall:0,childCPU:0};stack.push(entry);try{return Reflect.apply(originalCompile,this,[source,filename,...rest])}finally{stack.pop();const wall=clock()-at,cpu=cpuValue()-cpuAt,parent=stack.at(-1);if(parent){parent.childWall+=wall;parent.childCPU+=cpu}const row=modules.get(filename)??{filename,count:0,wall:0,cpu:0,selfWall:0,selfCPU:0};row.count++;row.wall+=wall;row.cpu+=cpu;row.selfWall+=wall-entry.childWall;row.selfCPU+=cpu-entry.childCPU;modules.set(filename,row)}};
 vm.compileFunction=function(source,...args){const at=clock(),cpuAt=cpuValue();try{return Reflect.apply(originalFunction,this,[source,...args])}finally{compile.count++;compile.wall+=clock()-at;compile.cpu+=cpuValue()-cpuAt;compile.sourceBytes+=typeof source==='string'?Buffer.byteLength(source):0}};
 let error;try{await import('../src/workers.js')}catch(e){error={message:e.message,stack:e.stack}}finally{Module.prototype._compile=originalCompile;vm.compileFunction=originalFunction}
 parentPort.postMessage({node:process.version,wall:clock()-start,cpu:cpuValue()-cpuStart,cpuSource:process.threadCpuUsage?'actual-thread':'whole-process-fallback',compile,modules:[...modules.values()].sort((a,b)=>b.selfCPU-a.selfCPU),error});
}
