from pathlib import Path
import json,hashlib,subprocess,time,os,signal,sys,re
scope=sys.argv[1]
groups={'A':['messaging','platform-codec','geometry-platform','dom-wrapper-realms','dom-factory-parity','webcodecs-processors'],'B':['workers','worker-abort','web-crypto','shared-workers','service-workers','worker-fetch','eventsource','websocket-quota']}
groups['C']=groups['A']+groups['B']
groups['Shared']=['shared-workers']
groups['Remaining']=['web-crypto','webcodecs-processors','websocket-quota','worker-abort','worker-fetch','workers']
paths={str(p) for folder in ['src','test','scripts','bin','native','oracle','docs/reference'] for p in Path(folder).rglob('*') if p.is_file()}|{'package.json','package-lock.json'}
manifest={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(paths)};Path(f'evidence/focused-{scope}-before.json').write_text(json.dumps(manifest,indent=2)+'\n')
command=['/workspace/shared/rea-tools/node_modules/node/bin/node','--experimental-vm-modules','--test','--test-concurrency=1','--test-name-pattern=^(?!.*heap)']+[f'test/{name}.test.js' for name in groups[scope]]
start=time.monotonic();terminated=False
with open(f'evidence/focused-{scope}.log','xb') as output:
 child=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=child.wait(timeout=118 if scope=='C' else 88 if scope=='Remaining' else 39 if scope=='Shared' else 44)
 except subprocess.TimeoutExpired:
  terminated=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=1)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
changed=[p for p,h in manifest.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h]
log=Path(f'evidence/focused-{scope}.log').read_text();summary={name:int(value) for name,value in re.findall(r'ℹ (tests|pass|fail|cancelled|skipped) (\d+)',log)}
status={'scope':scope,'command':command,'seconds':time.monotonic()-start,'exit':code,'outerResourceTermination':terminated,'inputCount':len(manifest),'changed':changed,'summary':summary,'heavyHeapEnumeration':'explicitly unrun by name pattern; final validation still required'}
Path(f'evidence/focused-{scope}-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
