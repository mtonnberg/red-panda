from pathlib import Path
import json,hashlib,difflib,tarfile,io,gzip
root=Path('/workspace/red-panda');work=Path.cwd();primary=Path('/workspace/shared/red-panda-phase22-preparation');out=root/'proposals/worker-bootstrap-cost';out.mkdir(exist_ok=True);base=json.loads((work/'evidence/base-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
files={str(p.relative_to(work)) for p in (work/'src').glob('*') if p.is_file()};files.add('test/shared-workers.test.js');names=sorted(n for n in files if n not in base or sha((work/n).read_bytes())!=base[n]);assert len(names)==21
manifest={'base':'exact Source4 primary graph after load-readiness2fd6+JSURLd36+location-boundaries; copied485inputs','files':{}};patch='';runtime='';test=''
for n in names:
 before=(primary/n).read_bytes() if n in base else b'';after=(work/n).read_bytes();assert not before or sha(before)==base[n],n
 manifest['files'][n]={'before':sha(before) if before else None,'after':sha(after)};p=out/'candidate'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(after)
 part=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+n if before else '/dev/null',tofile='b/'+n));patch+=part
 if n.startswith('src/'):runtime+=part
 else:test+=part
(out/'integration.patch').write_text(patch);(out/'runtime.patch').write_text(runtime);(out/'fixture-cleanup.patch').write_text(test);(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
snapshots=[('trim',work/'evidence'),('progress',Path('/workspace/shared/worker-progress-diagnostic-recovery/evidence')),('shared-diagnostic',Path('/workspace/shared/worker-shared-progress-recovery/evidence'))];entries=[]
for label,directory in snapshots:
 for p in sorted(directory.iterdir()):
  if p.is_file():entries.append((label+'/'+p.name,p.read_bytes()))
for name in ['source-four-before.json','source-four-after.json']:
 p=primary/'integration-evidence'/name;entries.append(('primary-source4/'+name,p.read_bytes()))
with open(out/'evidence.tar.gz','wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;info.mtime=0;tar.addfile(info,io.BytesIO(data))
(out/'evidence-manifest.json').write_text(json.dumps({n:sha(b) for n,b in sorted(entries)},indent=2)+'\n')
metadata={'node':'v24.22.1','runtimeLeafCount':20,'fixtureCleanupLeafCount':1,'nativeSHA256':'9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f','registrationMapSHA256':'066ad73e170657f43d79ca4f35b0741c18cec15dbed44bb1dba0518bf400c9b8','finalEvidence':{'sourceWorkerNative':'pass load84ms/assert86ms','sourceWorkerCandidate':'pass load844ms/assert3920ms original2s/8s;five Runtime exception text entries unclassified','completedPositiveCoverage':'170distinct matched checks across final-runtime C completed positive files +later Shared15 +Remaining75; NOT a single clean full14file epoch','laterShared':{'pass':15,'seconds':9.382956186993397},'laterRemaining':{'pass':75,'seconds':45.1887094440026}},'preservedRejectedEpochs':['Original Source4 assertion timeout8004ms after real load816ms','Instrumented startup trace timeout with26threads/25online/11moduleentry atdeadline','Initial afterprofile193ms fails CJS circular load','Initial trim106pass8fail5cancel;one genuine messaging failure/seven missing-oracle setup failures;manual SIGTERM59.079s before extension delivered','B77pass1real WS first-import failure1resource-cancel at44.147s','C93pass2Sharedfail7resource-cancel at118.161s;transfer rows[]/SyncHTTP ctor readiness2000ms timeout','Zombie process-state misclassification corrected;3knownPIDs areZ, no signals sent'],'unrun':['Heavy heap enumeration in own scopes','Other SDKs for this trim packet','Root-composed affected/all SDK/full regression pending Parent'],'artifacts':{n:sha((out/n).read_bytes()) for n in ['integration.patch','runtime.patch','fixture-cleanup.patch','source-manifest.json','evidence.tar.gz','evidence-manifest.json']}}
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata['artifacts'],indent=2))
