from pathlib import Path
import subprocess,json,time,hashlib
node='/workspace/shared/rea-tools/node_modules/node/bin/node'
base=[node,'--experimental-vm-modules','scripts/conformance.mjs','--root','/workspace/red-panda/.cache/lightpanda-reference/browser-948d773786/src/browser/tests','--isolate','--fixture-profile','upstream','--source-load-contract','--websocket-port','9584','--registration-map','/workspace/red-panda/proposals/native455-canonical/registration-map.json','--port','9582','--tests-file','evidence/source-worker-selection.json']
rows=[]
for name,binary in [('native','/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux'),('candidate',str(Path('evidence/candidate-cli').resolve()))]:
 command=base+['--binary',binary,'--report',f'evidence/source-worker-{name}.json'];start=time.monotonic()
 with open(f'evidence/source-worker-{name}.log','xb') as output:p=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'exit':p.returncode,'seconds':time.monotonic()-start};rows.append(row);print(json.dumps(row),flush=True)
Path('evidence/source-worker-status.json').write_text(json.dumps(rows,indent=2)+'\n')
a=json.loads(Path('evidence/focused-Remaining-before.json').read_text());bad=[n for n,h in a.items() if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h];Path('evidence/post-source-worker-sourceguard.json').write_text(json.dumps({'count':len(a),'changed':bad},indent=2)+'\n')
