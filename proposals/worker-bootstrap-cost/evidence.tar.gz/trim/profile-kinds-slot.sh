#!/bin/sh
set -eu
/workspace/shared/rea-tools/node_modules/node/bin/node --experimental-vm-modules /workspace/shared/worker-progress-diagnostic-recovery/evidence/import-profile-kinds.mjs /workspace/shared/worker-bootstrap-trim-recovery/evidence/import-profile-before-kinds.json > /workspace/shared/worker-bootstrap-trim-recovery/evidence/import-profile-before-kinds.log 2>&1
/workspace/shared/rea-tools/node_modules/node/bin/node --experimental-vm-modules /workspace/shared/worker-bootstrap-trim-recovery/evidence/import-profile.mjs /workspace/shared/worker-bootstrap-trim-recovery/evidence/import-profile-after2.json > /workspace/shared/worker-bootstrap-trim-recovery/evidence/import-profile-after2.log 2>&1
python3 - <<'PY'
import json
from pathlib import Path
p=Path('/workspace/shared/worker-bootstrap-trim-recovery/evidence');a=json.loads((p/'import-profile-before-kinds.json').read_text());b=json.loads((p/'import-profile-after2.json').read_text());d={'beforeError':a.get('error'),'afterError':b.get('error'),'beforeWall':a['wall'],'afterWall':b['wall'],'beforeCPU':a['cpu'],'afterCPU':b['cpu'],'beforeModuleCount':len(a['modules']),'afterModuleCount':len(b['modules']),'knownKindsEqual':a['knownKinds']==b['knownKinds'],'beforeKnownKinds':a['knownKinds'],'afterKnownKinds':b['knownKinds']};(p/'profile-comparison.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
PY
