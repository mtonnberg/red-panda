#!/bin/sh
set -eu
cd /workspace/shared/worker-shared-progress-recovery
python3 evidence/shared-trace-controller.py
