from pathlib import Path
import subprocess,time,os,signal,json,hashlib
command=['/workspace/shared/rea-tools/node_modules/node/bin/node','--experimental-vm-modules','evidence/shared-causal-trace.mjs','evidence/shared-causal-trace.json'];environment=os.environ.copy();environment['RED_PANDA_TRACE_WORKERS']='1';start=time.monotonic();terminated=False
with open('evidence/shared-causal-trace.log','xb') as output:
 child=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT,start_new_session=True,env=environment)
 try:code=child.wait(timeout=7)
 except subprocess.TimeoutExpired:
  terminated=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=0.5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
manifest=json.loads(Path('evidence/base-manifest.json').read_text());changed=[n for n,h in manifest.items() if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h];status={'command':command,'exit':code,'seconds':time.monotonic()-start,'resourceTerminated':terminated,'note':'7s outer diagnostic resource guard; original fixture1800ms and SyncHTTP2000ms remain untouched, no acceptance inferred','changedSourceLeaves':changed};Path('evidence/shared-trace-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status))
