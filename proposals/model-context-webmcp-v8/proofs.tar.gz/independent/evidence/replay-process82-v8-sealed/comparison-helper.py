"""Full-row Native comparison. Differences remain differences, including timing placement."""
from pathlib import Path
import argparse, hashlib, json, urllib.parse

p=argparse.ArgumentParser()
for name in ['surface','invocation','semantics','realms','getter']:p.add_argument('--'+name,required=True)
p.add_argument('--output',required=True);a=p.parse_args();base=Path('/workspace/shared/webmcp-independent-20261101');plan=Path('/workspace/shared/webmcp-native-plan-20261031')
specs={'surface':(plan/'evidence/surface/raw.json',21,'95c564ee5d62d7db4cfb048b01cfcae9e9251c70a4409b027536e1e674f5b864'),'invocation':(plan/'evidence/invocation/raw.json',21,'af2737c22c69aab5dfe7a3fd4900b9e154ad765d64d8425c95bbc0a814aedb75'),'semantics':(base/'evidence/native-semantics-1/raw.json',19,'ec298a6f1c5337036c1e20c36dad32f44b3584b3cca9bcab797a4d45117e99e8'),'realms':(base/'evidence/native-realms-3/raw.json',15,'e7a021106f9e4bbf4e8dc9ad94bf77d732d0f7fb7cee01ede31e7cf8183386d3'),'getter':(base/'evidence/native-getter-backend-1/raw.json',6,'9aa6500179f1bbe6ff1afebe1092caf8031adcea039a3f2233380f82ba77bc3c')}
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();paths=[Path(__file__)];data={}
for name,(oracle,count,pin)in specs.items():
 candidate=Path(getattr(a,name)).resolve();inventory=oracle.parent/'inventory.sha256';assert sha(inventory)==pin
 entries=dict((name,digest)for digest,name in [line.split('  ',1)for line in inventory.read_text().splitlines()]);assert sha(oracle)==entries['raw.json'];paths.extend([oracle,inventory,candidate,candidate.parent/'status.json']);data[name]=(json.loads(oracle.read_text()),json.loads(candidate.read_text()),json.loads((candidate.parent/'status.json').read_text()),count)
before={str(path):sha(path)for path in paths}
def normalize(raw):
 ids={raw['frameId']:'$ROOT_FRAME'}
 if raw.get('childFrameId'):ids[raw['childFrameId']]='$CHILD_FRAME'
 sid={event.get('sessionId')for row in raw['rows']for event in row['events']if event['method'].startswith('WebMCP.')}
 if len(sid)!=1 or None in sid:raise ValueError('Exact single genuine attached session required')
 ids[next(iter(sid))]='$SESSION';number=0
 for row in raw['rows']:
  identifier=row.get('result',{}).get('invocationId')
  if identifier is not None:
   if identifier in ids:raise ValueError('Invocation identity reuse')
   number+=1;ids[identifier]='$INVOCATION_'+str(number)
 fixture=raw.get('ownedFixture',{}).get('url');origin=None
 if fixture:
  parts=urllib.parse.urlsplit(fixture);origin=parts.scheme+'://'+parts.netloc
 def value(item,key=None):
  if isinstance(item,str):
   if item in ids:return ids[item]
   if origin and key in ['url','documentURL','origin']and(item==origin or item.startswith(origin+'/')):return '$OWNED_HTTP_ORIGIN'+item[len(origin):]
   return item
  if isinstance(item,list):return [value(element)for element in item]
  if isinstance(item,dict):return {name:value(element,name)for name,element in item.items()}
  return item
 return [value({key:item for key,item in row.items()if key!='elapsedMs'})for row in raw['rows']]
profiles=[];failure=None
try:
 for name,(oracle,candidate,status,count)in data.items():
  if oracle.get('failure')or candidate.get('failure')or not status['unchanged']or status.get('controllerFailure')or status.get('profileFailure')or len(oracle['rows'])!=count or len(candidate['rows'])!=count:raise ValueError('Incomplete/failed source profile '+name)
  expected=normalize(oracle);actual=normalize(candidate);rows=[{'index':index,'label':left['label'],'fullRowEqual':left==right,'sameResultOrError':{k:v for k,v in left.items()if k!='events'}=={k:v for k,v in right.items()if k!='events'}}for index,(left,right)in enumerate(zip(expected,actual))]
  # Additional transcript diagnostic is separately labelled. It does not turn
  # per-row event-placement differences into strict matching rows.
  flatten=lambda entries:[event for row in entries for event in row['events']if event['method'].startswith('WebMCP.')]
  profiles.append({'profile':name,'rows':count,'strictEqualRows':sum(row['fullRowEqual']for row in rows),'rowsComparison':rows,'fullExpectedRows':expected,'fullActualRows':actual,'additionalWholeWebMCPTranscriptEqual':flatten(expected)==flatten(actual),'brandAndFixtureSetup':'Actual raw5setup/HTTPwire retained; currentRedPandaUA unchanged. No setup/type/authority differences silently promoted.'})
except Exception as error:failure={'name':type(error).__name__,'message':str(error)}
after={str(path):sha(path)for path in paths};total=sum(item['rows']for item in profiles);equal=sum(item['strictEqualRows']for item in profiles);report={'status':'ALL82_FULL_ROWS_EQUAL'if failure is None and total==82 and equal==82 else'ACTUAL_DIFFERENCES_OR_INCOMPLETE','failure':failure,'completedRows':total,'strictEqualRows':equal,'profiles':profiles,'inputs':before,'unchanged':before==after,'normalization':'Exact opaque frame/session/invocation identifiers and actual owned HTTP fixture origin only, measured elapsedMs excluded. Every observed request/result/error/event/order/placement and RuntimeJSON bytes retained; no protocol timestamp or semantic fields removed.','noAllSemanticsClaim':True,'noNativeRerun':True};output=Path(a.output);output.parent.mkdir(parents=True,exist_ok=True)
with output.open('x')as stream:stream.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'completedRows':total,'strictEqualRows':equal,'failure':failure,'unchanged':report['unchanged'],'output':str(output)}))
