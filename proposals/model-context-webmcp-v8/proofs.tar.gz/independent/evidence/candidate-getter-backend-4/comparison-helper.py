"""Read-only full observed-row comparison; only opaque identities normalize."""
from pathlib import Path
import argparse, hashlib, json

p=argparse.ArgumentParser();p.add_argument('--native',required=True);p.add_argument('--candidate',required=True);p.add_argument('--output',required=True);a=p.parse_args()
native=Path(a.native).resolve();candidate=Path(a.candidate).resolve();output=Path(a.output).resolve()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
inventory=native.parent/'inventory.sha256'
assert sha(inventory)=='9aa6500179f1bbe6ff1afebe1092caf8031adcea039a3f2233380f82ba77bc3c'
entries={name:digest for digest,name in [line.split('  ',1)for line in inventory.read_text().splitlines()]}
assert sha(native)==entries[str(native.relative_to(native.parent))]
paths=[Path(__file__),native,candidate,inventory,candidate.parent/'status.json']
before={str(path):sha(path)for path in paths}
native_raw=json.loads(native.read_text());candidate_raw=json.loads(candidate.read_text());candidate_status=json.loads((candidate.parent/'status.json').read_text())
def normalized(raw):
 if raw.get('failure') or len(raw['rows'])!=6 or len(raw.get('setupRows',[]))!=5:raise ValueError('Incomplete/failed profile is not six comparable observations')
 if not isinstance(raw.get('frameId'),str) or not isinstance(raw.get('childFrameId'),str) or raw['frameId']==raw['childFrameId']:raise ValueError('Missing genuine distinct frame identities')
 ids={raw['frameId']:'$ROOT_FRAME',raw['childFrameId']:'$CHILD_FRAME'}
 sessions={event.get('sessionId')for row in raw['rows']for event in row['events']if event['method'].startswith('WebMCP.')}
 if len(sessions)!=1 or None in sessions:raise ValueError('Expected exact one attached actual WebMCP session')
 ids[next(iter(sessions))]='$SESSION'
 number=0
 for row in raw['rows']:
  identifier=row.get('result',{}).get('invocationId')
  if identifier is not None:
   if identifier in ids:raise ValueError('Invocation identity reused')
   number+=1;ids[identifier]='$INVOCATION_'+str(number)
 def value(item):
  if isinstance(item,str):return ids.get(item,item)
  if isinstance(item,list):return [value(element)for element in item]
  if isinstance(item,dict):return {key:value(element)for key,element in item.items()}
  return item
 # Preserve every observed request/result/error and every per-row event in
 # order. Runtime JSON strings stay byte-exact; no assertion fields removed.
 return [value({key:item for key,item in row.items()if key!='elapsedMs'})for row in raw['rows']]
failure=None;expected=actual=None;comparisons=[]
try:
 if not candidate_status['unchanged'] or candidate_status['profileFailure'] or candidate_status['controllerFailure'] or candidate_status['actualRows']!=6 or candidate_status['actualSetupRows']!=5:raise ValueError('Candidate setup/integrity gate failed')
 expected=normalized(native_raw);actual=normalized(candidate_raw)
 comparisons=[{'index':index,'label':left['label'],'equal':left==right}for index,(left,right)in enumerate(zip(expected,actual))]
except Exception as error:failure={'name':type(error).__name__,'message':str(error)}
after={str(path):sha(path)for path in paths}
def headers(raw):
 return [wire['headers']for wire in raw.get('ownedFixture',{}).get('httpWire',[])if wire['phase']=='request']
report={'status':'SIX_FULL_OBSERVED_ROWS_EQUAL'if failure is None and expected==actual else'ACTUAL_DIFFERENCE_OR_FAILED_SETUP','failure':failure,'comparisons':comparisons,'expectedFullObservedRows':expected,'actualFullObservedRows':actual,'inputs':before,'unchanged':before==after,'normalization':'Exact opaque root/child frame, attached session and invocation identities only. Per-row event order/placement, error codes/messages, every result/request field and Runtime JSON bytes preserved. Only measured elapsedMs removed.','setup':'Five setup rows/real HTTP fixture retained in original raw; setup authority and genuine product brand differ by declared actor, not included in six API-observation equality.','actualHTTPHeaders':{'native':headers(native_raw),'candidate':headers(candidate_raw)},'branding':'Actual RedPanda UA/client hints unchanged; reference Lightpanda HTTP branding remains disclosed. No UA override/harness eligibility adapter used.','wholeAPIFidelityClaim':False}
output.parent.mkdir(parents=True,exist_ok=True)
with output.open('x')as stream:stream.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'comparisons':comparisons,'unchanged':report['unchanged'],'output':str(output)}))
