from pathlib import Path
import argparse,hashlib,json,urllib.parse
p=argparse.ArgumentParser();p.add_argument('profile',choices=['semantics','realms']);p.add_argument('--fresh',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=Path('/workspace/shared/webmcp-independent-20261101');oracle=r/'evidence'/('native-semantics-1'if a.profile=='semantics'else'native-realms-3')/'raw.json';fresh=Path(a.fresh);status=json.loads((fresh.parent/'status.json').read_text());assert status['status']=='OBSERVED_REPLAY_COMPLETE'and status['unchanged']and status['Root18Unchanged'];expected=json.loads(oracle.read_text());actual=json.loads(fresh.read_text());sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();paths=[Path(__file__),r/'helpers/compare-observed82.py',oracle,oracle.parent/'inventory.sha256',fresh,fresh.parent/'status.json'];before={str(path):sha(path)for path in paths}
def normalize(raw):
 ids={raw['frameId']:'$ROOT_FRAME'}
 if raw.get('childFrameId'):ids[raw['childFrameId']]='$CHILD_FRAME'
 sid={event.get('sessionId')for row in raw['rows']for event in row['events']if event['method'].startswith('WebMCP.')}
 if len(sid)!=1 or None in sid:raise ValueError('Exact single genuine attached session required')
 ids[next(iter(sid))]='$SESSION';number=0
 for row in raw['rows']:
  identifier=row.get('result',{}).get('invocationId')
  if identifier is not None:
   if identifier in ids:raise ValueError('Invocation identity reuse')
   number+=1;ids[identifier]='$INVOCATION_'+str(number)
 fixture=raw.get('ownedFixture',{}).get('url');origin=None
 if fixture:
  parts=urllib.parse.urlsplit(fixture);origin=parts.scheme+'://'+parts.netloc
 def value(item,key=None):
  if isinstance(item,str):
   if item in ids:return ids[item]
   if origin and key in ['url','documentURL','origin']and(item==origin or item.startswith(origin+'/')):return '$OWNED_HTTP_ORIGIN'+item[len(origin):]
   return item
  if isinstance(item,list):return [value(element)for element in item]
  if isinstance(item,dict):return {name:value(element,name)for name,element in item.items()}
  return item
 return [value({key:item for key,item in row.items()if key!='elapsedMs'})for row in raw['rows']]
left,right=normalize(expected),normalize(actual);assert len(left)==len(right)==(19 if a.profile=='semantics' else 15)
rows=[{'index':index,'label':x['label'],'fullRowEqual':x==y,'sameRequestResultError':{k:v for k,v in x.items()if k!='events'}=={k:v for k,v in y.items()if k!='events'},'expected':x,'actual':y}for index,(x,y)in enumerate(zip(left,right))]
logical=lambda rows:[event for row in rows for event in row['events']if event['method'].startswith('WebMCP.')or event['method']=='Page.frameDetached']
relations=[]
for command in actual['wireCommands']:
 if command['label']not in ['invoke-own_then','invoke-constructor','invoke-species','invoke-held-child','resolve-after-tool-abort','remove-real-child']:continue
 reply=next((item for item in actual['wire']if item['direction']=='in'and item['message'].get('id')==command['commandId']),None)
 row=next(x for x in actual['rows']if x['label']==command['label']);invocation=row.get('result',{}).get('invocationId')
 if not invocation and command['label']=='resolve-after-tool-abort':invocation=next(x for x in actual['rows']if x['label']=='invoke-held-child').get('result',{}).get('invocationId')
 response=next((item for item in actual['wire']if item['direction']=='in'and item['message'].get('method')=='WebMCP.toolResponded'and item['message']['params'].get('invocationId')==invocation),None)
 detach=next((item for item in actual['wire']if item['direction']=='in'and item['message'].get('method')=='Page.frameDetached'),None)
 relations.append({'label':command['label'],'actualCommandId':command['commandId'],'replySequence':reply['sequence']if reply else None,'responseSequence':response['sequence']if response else None,'responseBeforeReply':response['sequence']<reply['sequence']if response and reply else None,'replyReadBatch':reply.get('readBatch')if reply else None,'responseReadBatch':response.get('readBatch')if response else None,'responseBeforeDetach':response['sequence']<detach['sequence']if response and detach else None})
after={str(path):sha(path)for path in paths};report={'status':'ACTUAL_NATIVE_COUNTERCONTROL','profile':a.profile,'actor':actual['actor'],'completedRows':len(rows),'strictEqualRows':sum(x['fullRowEqual']for x in rows),'sameRequestResultErrorRows':sum(x['sameRequestResultError']for x in rows),'logicalRelevantTranscriptEqual':logical(left)==logical(right),'rows':rows,'wireRelations':relations,'inputs':before,'unchanged':before==after,'interpretation':'Exact original82 normalizer. Native-vs-Native strict row differences, if observed, remain true differences and establish rowcut variability only; never promote prior76/82. All original requests/results/errors/events/RuntimeJSON retained. Wire observations expose actual reply/response/read-batch/FrameDetached order without delays, acknowledgement gates or modified author controls.'};Path(a.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({key:report[key]for key in ['status','completedRows','strictEqualRows','sameRequestResultErrorRows','logicalRelevantTranscriptEqual','unchanged']}))
