from pathlib import Path
import argparse, hashlib, json, os, signal, subprocess, time

def administrative_signal(number,_frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,administrative_signal)
r=Path(__file__).resolve().parent.parent;p=argparse.ArgumentParser();p.add_argument('--build-report',required=True);p.add_argument('--epoch',required=True);p.add_argument('--mode',choices=['observed','old-mark'],default='observed');p.add_argument('--sdk',choices=['all','24.22.1','24.19.0','26.13.0'],default='all');a=p.parse_args();out=r/'consumer-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
build=Path(a.build_report).resolve();report=json.loads(build.read_text());assert report['status']=='BUILT_RUNTIME_ONLY_TESTS_UNRUN'and report['unchanged']and report['Root18Unchanged'];protected=json.loads((r/'protected-root-native.json').read_text());versions=[('24.22.1',Path('/workspace/shared/rea-tools/node_modules/node/bin/node')),('24.19.0',Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')),('26.13.0',Path('/workspace/shared/node26/node_modules/node/bin/node'))];versions=[item for item in versions if a.sdk=='all'or item[0]==a.sdk]
paths=[Path(__file__),r/'helpers/consumer-controls.mjs',build,r/'candidate/src/native-runtime.js',r/'candidate/native/runtime.cc',r/'protected-root-native.json']+list(map(Path,protected['files']))+[node for _,node in versions]
for row in report['rows']:paths.extend([Path(row['output']),Path(row['output']+'.json')])
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();paths=sorted(set(paths));snapshot=lambda:{str(path):sha(path)for path in paths};before=snapshot();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');assert all(sha(Path(path))==value for path,value in protected['files'].items())
for row in report['rows']:assert sha(Path(row['output']))==row['manifest']['binarySHA256']and row['manifest']['sourceSHA256']==sha(r/'candidate/native/runtime.cc')
rows=[];failure=None;started=time.monotonic()
try:
 for version,node in versions:
  artifact=next(row['output']for row in report['rows']if row['manifest']['node']=='v'+version);raw=out/(version+'.raw.json');command=[str(node),str(r/'helpers/consumer-controls.mjs'),a.mode,str(raw)];row={'node':version,'command':command,'mode':a.mode,'administrativeWatchdogSeconds':8};child=None;begin=time.monotonic()
  with(out/(version+'.stdout.log')).open('xb')as stdout,(out/(version+'.stderr.log')).open('xb')as stderr:
   child=subprocess.Popen(command,cwd=r,env=dict(os.environ,RED_PANDA_RUNTIME_ADDON=artifact),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
   try:child.wait(timeout=8)
   except BaseException:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=.2)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    row['exit']=child.returncode;rows.append(row);raise
  row['exit']=child.returncode;row['elapsedSeconds']=time.monotonic()-begin;row['rawAvailable']=raw.exists();actual=json.loads(raw.read_text())if raw.exists()else None;row['actualChecks']=len(actual['checks'])if actual else 0;row['allChecksPass']=actual['allChecksPass']if actual else None;rows.append(row)
  # A declared old-API counterfactual must fail actual contract checks. Setup
  # errors, missing output or an unrelated crash never count as that evidence.
  if actual is None or actual.get('failure'):raise RuntimeError('Actual consumer setup/transport failure; futureSDKs UNRUN')
  if a.mode=='observed'and(row['exit']!=0 or not row['allChecksPass']):raise RuntimeError('Actual observed consumer contract failure; futureSDKs UNRUN')
  if a.mode=='old-mark'and(row['exit']!=1 or row['allChecksPass']):raise RuntimeError('Discriminating old-consumer negative did not produce required actual contract failure')
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)}
finally:
 after=snapshot();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');result={'status':'OBSERVED_POSITIVE_COMPLETE'if failure is None and a.mode=='observed'else'ACTUAL_EXPECTED_NEGATIVE_RETAINED'if failure is None else'STOPPED_FUTURE_SDKS_UNRUN','mode':a.mode,'rows':rows,'failure':failure,'inputs':len(before),'unchanged':before==after,'changed':[path for path in before if before[path]!=after[path]],'Root18Unchanged':all(sha(Path(path))==value for path,value in protected['files'].items()),'elapsedSeconds':time.monotonic()-started,'scope':'Actual producer handling, pending rejection, doubleconsume, Host/Proxy/copy negatives, unconsumed positive and true latehandled. Process listeners exist only in owned diagnostic child; production installs none.'};(out/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
