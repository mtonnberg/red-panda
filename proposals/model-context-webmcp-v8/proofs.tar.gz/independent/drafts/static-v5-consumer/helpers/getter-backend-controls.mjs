import {startReference} from '../../webmcp-native-plan-20261031/harness/scripts/reference-server.mjs';
import {connect} from '../../webmcp-native-plan-20261031/harness/test/cdp-client.js';
import {writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {createHash} from 'node:crypto';

const [profile,actor,output]=process.argv.slice(2);
let service,client,context,session,frameId,childFrameId,failure,fixture,fixtureURL;
let recordingSetup=profile==='realms';const setupRows=[],httpWire=[];
const rows=[],errors=e=>({name:e.name,message:e.message,code:e.code});
try{
 if(actor==='native')service=await startReference('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux',{args:['--load-resources','iframe']});
 else if(actor==='candidate'){
  const {serve}=await import('../candidate/src/cdp.js');
  service=await serve({host:'127.0.0.1',port:0,loadResources:['iframe']});
  service.endpoint='ws://127.0.0.1:'+service.port+'/';
 }else throw Error('Unknown actor');
 const ownerHTML='<!doctype html><html><head><meta charset=utf-8><title>Actual WebMCP realm owner</title></head><body><p>Actual owned HTTP document</p></body></html>';
 fixture=createServer((request,response)=>{httpWire.push({phase:'request',at:performance.now(),method:request.method,url:request.url,headers:request.headers});response.writeHead(200,{'content-type':'text/html; charset=utf-8'});response.end(ownerHTML);httpWire.push({phase:'response-end',at:performance.now(),status:200,bodySHA256:createHash('sha256').update(ownerHTML).digest('hex')})});fixture.listen(0,'127.0.0.1');await once(fixture,'listening');fixtureURL='http://127.0.0.1:'+fixture.address().port+'/actual-owner';
 client=await connect(service.endpoint);
 const send=(method,params={},sid=session)=>client.send(method,params,sid,{timeout:2500});
 ({browserContextId:context}=await send('Target.createBrowserContext',{},undefined));
 const {targetId}=await send('Target.createTarget',{url:'about:blank',browserContextId:context},undefined);
 ({sessionId:session}=await send('Target.attachToTarget',{targetId,flatten:true},undefined));
 await send('Runtime.enable');await send('Page.enable');
 frameId=(await send('Page.getFrameTree')).frameTree.frame.id;
 async function command(label,method,params={}){
  const start=performance.now(),offset=client.events.length,row={label,method,params};
  try{row.result=await send(method,params)}catch(error){row.error=errors(error)}
  row.elapsedMs=performance.now()-start;row.events=client.events.slice(offset);(recordingSetup?setupRows:rows).push(row);
  console.log(JSON.stringify({label,error:row.error??null}));
  if(row.error&&(row.error.message.startsWith('CDP timeout:')||row.error.message==='CDP connection closed'))throw Error('Stopped on actual no-response: '+label);
  return row;
 }
 const errorSource=`const errorData=e=>({name:e.name,message:e.message,code:e.code,constructorName:e.constructor?.name,isError:e instanceof Error,isDOMException:typeof DOMException==='function'&&e instanceof DOMException});`;
 const evaluate=(label,body,asynchronous=false)=>command(label,'Runtime.evaluate',{expression:`(${asynchronous?'async ':''}()=>{${errorSource}try{const value=${asynchronous?'await ':''}(${asynchronous?'async ':''}()=>{${body}})();return JSON.stringify({ok:true,value,valueType:typeof value})}catch(e){return JSON.stringify({ok:false,error:errorData(e)})}})()`,awaitPromise:asynchronous,returnByValue:true});
 await command('enable','WebMCP.enable');
 if(profile==='semantics'){
  await evaluate('public-descriptors',`const shape=object=>object===null?null:Reflect.ownKeys(object).map(key=>{const d=Object.getOwnPropertyDescriptor(object,key);return{key:String(key),enumerable:d.enumerable,configurable:d.configurable,writable:d.writable,type:typeof d.value,value:typeof d.value==='string'?d.value:undefined,functionName:typeof d.value==='function'?d.value.name:undefined,functionLength:typeof d.value==='function'?d.value.length:undefined,getName:d.get?.name,getLength:d.get?.length,setName:d.set?.name}});const attempts=[];for(const f of[()=>ModelContext(),()=>new ModelContextClient(),()=>ModelContextClient()])try{const value=f();attempts.push({ok:true,tag:Object.prototype.toString.call(value)})}catch(e){attempts.push({ok:false,error:errorData(e)})}return{contextPrototype:shape(ModelContext.prototype),clientPrototype:shape(ModelContextClient.prototype),contextConstructor:shape(ModelContext),clientConstructor:shape(ModelContextClient),navigatorDescriptor:shape(Object.getPrototypeOf(navigator)).find(x=>x.key==='modelContext'),attempts}`);
  await evaluate('register-metadata-and-client',`globalThis.actualClients=[];globalThis.actualTape=[];globalThis.actualSchemaReads=[];globalThis.actualSchema={type:'object',actualBefore:1};const schemaWithGetter={get actualGetter(){actualSchemaReads.push('actualGetter');return 9}};for(const[name,inputSchema,execute]of [['capture',{},function(input,client){actualClients.push(client);actualTape.push({name:'capture',thisWindow:this===globalThis,inputRealm:input instanceof Object});return{actual:input}}],['mutable',actualSchema,function(input){return input}],['getter_schema',schemaWithGetter,function(input){return input}]])navigator.modelContext.registerTool({name,description:'actual '+name,inputSchema,execute});return{reads:actualSchemaReads}`);
  await evaluate('mutate-real-schema',`actualSchema.actualBefore=2;actualSchema.actualAfter={actual:true};return{reads:actualSchemaReads}`);
  await command('disable-before-metadata-replay','WebMCP.disable');
  await command('actual-metadata-replay','WebMCP.enable');
  await evaluate('metadata-getter-count','return actualSchemaReads');
  await command('invoke-capture','WebMCP.invokeTool',{frameId,toolName:'capture',input:{actualInput:true}});
  await evaluate('actual-client-descriptors',`const c=actualClients[0],p=Object.getPrototypeOf(c);return{own:Reflect.ownKeys(c).map(String),prototypeNull:p===null,prototypeIsConstructor:p===ModelContextClient.prototype,constructorPrototypeNull:ModelContextClient.prototype===null,constructorInstance:c instanceof ModelContextClient,tag:Object.prototype.toString.call(c),prototypeOwn:p?Reflect.ownKeys(p).map(String):null,methodName:c.requestUserInteraction.name,methodLength:c.requestUserInteraction.length,methodRealm:c.requestUserInteraction instanceof Function,tape:actualTape}`);
  await evaluate('client-brand-and-argument-errors',`const c=actualClients[0],results=[];for(const invoke of[()=>c.requestUserInteraction.call({},()=>1),()=>c.requestUserInteraction(),()=>c.requestUserInteraction(7),()=>c.requestUserInteraction(()=>{throw new TypeError('actual interaction throw')})]){try{const result=invoke();const before={type:typeof result,promise:result instanceof Promise};try{results.push({...before,ok:true,value:await result})}catch(error){results.push({...before,ok:false,error:errorData(error)})}}catch(error){results.push({synchronous:true,ok:false,error:errorData(error)})}}return results`,true);
  await evaluate('interaction-real-receiver-and-result',`const result=actualClients[0].requestUserInteraction(function(){actualTape.push({name:'interaction-control',thisWindow:this===globalThis,args:arguments.length});return{then(resolve){actualTape.push({name:'interaction-thenable-called'});resolve({actualInteraction:true})}}});const promise=result instanceof Promise,value=await result;return{promise,value,tape:actualTape}`,true);
  await evaluate('register-real-poisoned-promises',`globalThis.actualPoisonReads=[];for(const name of['own_then','constructor','species'])navigator.modelContext.registerTool({name,description:'actual '+name,execute(input){const p=Promise.resolve({actualPromise:name,input});if(name==='own_then')Object.defineProperty(p,'then',{get(){actualPoisonReads.push(name);throw new Error('actual own then getter')}});else if(name==='constructor')Object.defineProperty(p,'constructor',{get(){actualPoisonReads.push(name);throw new Error('actual constructor getter')}});else Object.defineProperty(p,'constructor',{value:{get [Symbol.species](){actualPoisonReads.push(name);throw new Error('actual species getter')}}});return p}});return true`);
  for(const name of ['own_then','constructor','species']){
   await command('invoke-'+name,'WebMCP.invokeTool',{frameId,toolName:name,input:{value:name}});
   await evaluate('checkpoint-'+name,'return actualPoisonReads');
  }
  await evaluate('copied-signal-prototype-is-not-authority',`const genuine=new AbortController().signal,fake=Object.create(Object.getPrototypeOf(genuine));return navigator.modelContext.registerTool({name:'fake_signal',description:'actual',execute(){}},{signal:fake})`);
 }else if(profile==='realms'){
  await command('setup-real-http-owner','Page.navigate',{url:fixtureURL});
  const rootTree=await command('setup-real-http-root-tree','Page.getFrameTree');frameId=rootTree.result?.frameTree?.frame.id;if(typeof frameId!=='string')throw Error('Actual HTTP owner frame absent');
  const setup=await evaluate('create-real-child-in-genuine-body',`const root=document.documentElement??document.appendChild(document.createElement('html'));const body=document.body??root.appendChild(document.createElement('body'));globalThis.actualFrame=document.createElement('iframe');body.appendChild(actualFrame);globalThis.actualChild=actualFrame.contentWindow;globalThis.actualParentTape=[];return{document:!!actualChild.document,context:typeof actualChild.navigator.modelContext,childConstructor:typeof actualChild.ModelContext,distinct:actualChild.navigator.modelContext!==navigator.modelContext}`);
  if(JSON.parse(setup.result?.result?.value??'null')?.ok!==true)throw Error('Actual authored iframe setup failed; later realm controls unobserved');
  const tree=await command('actual-unique-child-owner-tree','Page.getFrameTree');
  const children=tree.result?.frameTree?.childFrames??[];
  if(children.length!==1)throw Error('Expected one genuine fresh child tree relationship; observed '+children.length+'; later controls unobserved');
  childFrameId=children[0]?.frame?.id;
  if(typeof childFrameId!=='string'||childFrameId===frameId)throw Error('Actual unique child frame identity absent; later realm controls unobserved');
  recordingSetup=false;
  await evaluate('borrowed-getter-exact-identity',`const parentFront=navigator.modelContext,childFront=actualChild.navigator.modelContext,parentGet=Object.getOwnPropertyDescriptor(Navigator.prototype,'modelContext').get,childGet=Object.getOwnPropertyDescriptor(actualChild.Navigator.prototype,'modelContext').get;globalThis.parentOnChild=parentGet.call(actualChild.navigator);globalThis.childOnParent=childGet.call(navigator);const shape=value=>({sameParent:value===parentFront,sameChild:value===childFront,parentPrototype:Object.getPrototypeOf(value)===ModelContext.prototype,childPrototype:Object.getPrototypeOf(value)===actualChild.ModelContext.prototype,parentRealm:value instanceof Object,childRealm:value instanceof actualChild.Object,own:Reflect.ownKeys(value).map(String),tag:Object.prototype.toString.call(value)});return{parentOnChild:shape(parentOnChild),childOnParent:shape(childOnParent),parentRepeat:parentGet.call(actualChild.navigator)===parentOnChild,childRepeat:childGet.call(navigator)===childOnParent}`);
  await evaluate('register-through-actual-borrowed-front',`parentOnChild.registerTool({name:'actual_getter_backend',description:'actual borrowed getter backend',execute(input){return{actualCalled:true,thisParent:this===globalThis,thisChild:this===actualChild,inputParent:input instanceof Object,inputChild:input instanceof actualChild.Object,input}}});return true`);
  await command('invoke-actual-getter-backend-parent','WebMCP.invokeTool',{frameId,toolName:'actual_getter_backend',input:{actualFrame:'parent'}});
  await command('invoke-actual-getter-backend-child','WebMCP.invokeTool',{frameId:childFrameId,toolName:'actual_getter_backend',input:{actualFrame:'child'}});
  await command('disable-before-borrowed-metadata-replay','WebMCP.disable');
  await command('replay-actual-borrowed-backend','WebMCP.enable');
 }else throw Error('Unknown heldout profile');
}catch(error){failure=errors(error)}
finally{
 if(client&&context)try{await client.send('Target.disposeBrowserContext',{browserContextId:context},undefined,{timeout:1000})}catch{}
 await client?.close();await service?.close();if(fixture){fixture.closeAllConnections();await new Promise(resolve=>fixture.close(resolve))}
 await writeFile(output,JSON.stringify({profile,actor,rows,setupRows,nativeArgs:actor==='native'?['--load-resources','iframe']:null,ownedFixture:{url:fixtureURL,httpWire},events:client?.events??[],frameId,childFrameId,failure,ownedBrowser:service?.process?{pid:service.process.pid,exitCode:service.process.exitCode,signal:service.process.signalCode,stderr:service.stderr,stderrTruncated:service.stderrTruncated}:null},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({profile,actor,rows:rows.length,setupRows:setupRows.length,failure}));
}
