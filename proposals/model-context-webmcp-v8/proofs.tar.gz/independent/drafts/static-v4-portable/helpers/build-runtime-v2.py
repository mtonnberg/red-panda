from pathlib import Path
import argparse, hashlib, json, os, shutil, signal, subprocess, time

def administrative_signal(number, _frame):
    raise KeyboardInterrupt('Administrative signal '+str(number))

signal.signal(signal.SIGTERM, administrative_signal)

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--epoch', required=True)
args = parser.parse_args()
out = root / 'build-evidence' / args.epoch
out.mkdir(parents=True, exist_ok=False)
candidate = root / 'candidate'
protected = json.loads((root / 'protected-root-native.json').read_text())
versions = [
    ('24.22.1', Path('/workspace/shared/rea-tools/node_modules/node/bin/node')),
    ('24.19.0', Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')),
    ('26.13.0', Path('/workspace/shared/node26/node_modules/node/bin/node')),
]
compiler = Path(shutil.which('g++')).resolve()
paths = [Path(__file__), root / 'base.json', root / 'protected-root-native.json', root / 'unchanged-sdk-prerequisites.json', compiler]
paths += [candidate / name for name in ['native/runtime.cc','native/build-runtime.mjs','native/build-collections.mjs']]
paths += list(map(Path, protected['files']))
headers = {}
for version, node in versions:
    paths.append(node)
    original = Path(protected['protected']) / ('linux-x64/node-' + version + '/runtime.node.json')
    # protected points at native/build itself, so avoid another linux-x64 if
    # a future provenance record already points at the platform directory.
    if not original.exists():
        original = Path(protected['protected']) / ('node-' + version + '/runtime.node.json')
    headers[version] = Path(json.loads(original.read_text())['headers'])
    paths.extend(path for path in headers[version].rglob('*') if path.is_file())
paths = sorted(set(paths))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
snapshot = lambda: {str(path):sha(path) for path in paths}
before = snapshot()
(out / 'before.json').write_text(json.dumps(before, indent=2)+'\n')
assert all(sha(Path(path))==value for path,value in protected['files'].items())
assert not (candidate/'native/build').is_symlink()
rows = []
started = time.monotonic()
failure = None
try:
    for version, node in versions:
        output = candidate / ('native/build/runtime-2/linux-x64/node-' + version + '/runtime.node')
        if output.exists() or Path(str(output)+'.json').exists():
            raise RuntimeError('Fresh actual runtime output required; existing artifact epoch must be preserved: '+str(output))
        command = [str(node), str(candidate/'native/build-runtime.mjs'), '--headers', str(headers[version]), '--output', str(output)]
        row = {'node':version, 'command':command, 'output':str(output), 'administrativeWatchdogSeconds':60}
        child = None
        begin = time.monotonic()
        with (out/(version+'.stdout.log')).open('xb') as stdout, (out/(version+'.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen(command, cwd=candidate, env=dict(os.environ, CXX=str(compiler)), stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                child.wait(timeout=60)
            except BaseException:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=.2)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                row['exit']=child.returncode
                rows.append(row)
                raise
        row['exit']=child.returncode;row['elapsedSeconds']=time.monotonic()-begin
        if row['exit']:
            rows.append(row)
            raise RuntimeError('Actual isolated runtime build failed: '+version)
        manifest=json.loads(Path(str(output)+'.json').read_text())
        assert manifest['node']=='v'+version
        assert manifest['sourceSHA256']==sha(candidate/'native/runtime.cc')
        assert manifest['binarySHA256']==sha(output)
        row['manifest']=manifest;row['manifestSHA256']=sha(Path(str(output)+'.json'));rows.append(row)
except BaseException as error:
    failure={'type':type(error).__name__,'message':str(error)}
finally:
    after=snapshot();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
    report={'status':'BUILT_RUNTIME_ONLY_TESTS_UNRUN' if failure is None and len(rows)==3 else 'STOPPED_FUTURE_SDKS_UNRUN','failure':failure,'rows':rows,'inputs':len(before),'unchanged':before==after,'changed':[p for p in before if before[p]!=after[p]],'Root18Unchanged':all(sha(Path(p))==value for p,value in protected['files'].items()),'elapsedSeconds':time.monotonic()-started,'networkDownloads':False,'runtimeTestsRun':False,'aggregateAdministrativeMaximumSeconds':180}
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
