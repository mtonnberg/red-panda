from pathlib import Path
import argparse, hashlib, json, os, signal, subprocess, time

root = Path(__file__).resolve().parent.parent
plan = Path('/workspace/shared/webmcp-native-plan-20261031')
parser = argparse.ArgumentParser()
parser.add_argument('profile', choices=['semantics', 'realms'])
parser.add_argument('actor', choices=['native', 'candidate'])
parser.add_argument('--epoch', required=True)
args = parser.parse_args()
output = root / 'evidence' / args.epoch
output.mkdir(parents=True, exist_ok=False)
node = Path('/workspace/shared/rea-tools/node_modules/node/bin/node')
native = Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux')
source = Path('/workspace/red-panda/.cache/lightpanda-reference/browser-948d773786')
contracts = json.loads((plan / 'source-contract-hashes.json').read_text())
paths = [node, native, root / 'base.json', root / 'helpers/heldout-controls.mjs', Path(__file__), plan / 'source-contract-hashes.json']
if (root/'protected-root-native.json').exists():
    paths.append(root/'protected-root-native.json')
    paths.extend(map(Path,json.loads((root/'protected-root-native.json').read_text())['files']))
for tree in [plan / 'harness', plan / 'node_modules', root / 'candidate/src', root / 'candidate/native']:
    paths.extend(path for path in tree.rglob('*') if path.is_file())
# Path.rglob does not recurse a symlink nested inside native. Record all actual
# matching SDK binaries/manifests as protected inputs explicitly, never build.
paths.extend(path for path in (root / 'candidate/native/build').rglob('*') if path.is_file())
paths.extend(source / name for name in contracts['files'])
paths = sorted(set(paths))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
snapshot = lambda: {str(path): sha(path) for path in paths}
before = snapshot()
(output / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
assert sha(native) == '9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f'
assert all(sha(source / name) == value for name, value in contracts['files'].items())
env = dict(os.environ, NODE_USE_ENV_PROXY='1')
previous = ','.join(filter(None, [env.get('NO_PROXY', ''), env.get('no_proxy', '')]))
aliases = '0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]'
env.update({key: ','.join(filter(None, [previous, aliases])) for key in ['NO_PROXY', 'no_proxy']})
command = [str(node), '--experimental-vm-modules', str(root / 'helpers/heldout-controls.mjs'), args.profile, args.actor, str(output / 'raw.json')]
started = time.monotonic()
child = None
failure = None
try:
    with (output / 'stdout.log').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr:
        child = subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            child.wait(timeout=25)
        except BaseException:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=.2)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            raise
except BaseException as error:
    failure = {'type': type(error).__name__, 'message': str(error)}
finally:
    after = snapshot()
    (output / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
    raw = json.loads((output / 'raw.json').read_text()) if (output / 'raw.json').exists() else None
    result = {'command': command, 'profile': args.profile, 'actor': args.actor, 'plannedRows': {'semantics':19, 'realms':18}[args.profile], 'actualRows':len(raw['rows']) if raw else None, 'exit':child.returncode if child else None, 'controllerFailure':failure, 'profileFailure':raw.get('failure') if raw else None, 'elapsedSeconds':time.monotonic()-started, 'inputs':len(before), 'unchanged':before==after, 'changed':[str(path) for path in before if before[path]!=after[path]], 'clientPerCommandMs':2500, 'ownedAdministrativeWatchdogSeconds':25, 'originalSourceFixtureUnchanged':True, 'noPuppeteer':True}
    (output / 'status.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
