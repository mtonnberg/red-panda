// Independent Window author-tool registry. The automation MCP server is a
// separate service; author callbacks and their actual documents own these tools.
import vm from 'node:vm';
import {types} from 'node:util';
import {createRequire} from 'node:module';
import {createInvocationTrampoline} from './invocation.js';
import {platformFactoryRecord} from './platform-factories.js';
import {registerProtocolPrototype} from './protocol-classes.js';
import {captureDOMExceptionFactory} from './worker-dom-exception.js';

const {implForWrapper}=createRequire(import.meta.url)('jsdom/lib/jsdom/living/generated/utils.js');
const owners=new WeakMap(),contexts=new WeakMap(),navigators=new WeakMap(),registries=new WeakMap(),sessions=new WeakMap();
const apply=Reflect.apply,create=Object.create,assign=Object.assign;
const state=fields=>assign(create(null),fields);

function definition(g,b){
 'use strict';
 const {defineProperty:define,getOwnPropertyDescriptor:own}=Object;
 const apply=Reflect.apply,StringConstructor=String,TypeErrorConstructor=TypeError,ErrorConstructor=Error,PromiseConstructor=Promise;
 const description=own(Symbol.prototype,'description').get,test=RegExp.prototype.test;
 const namePattern=/^[a-zA-Z0-9_.-]{1,128}$/;
 const object=value=>value!==null&&(typeof value==='object'||typeof value==='function'||(typeof value==='undefined'&&value!==undefined));
 const invalid=()=>{throw new TypeErrorConstructor('invalid argument')};
 const illegal=()=>{throw new TypeErrorConstructor('Illegal invocation')};
 const text=value=>StringConstructor(typeof value==='symbol'?apply(description,value,[]):value);
 function ModelContext(){throw new TypeErrorConstructor('Illegal Constructor')}
 function ModelContextClient(){throw new TypeErrorConstructor('Illegal Constructor')}
 // These objects are the public prototypes themselves, including the methods'
 // original HomeObjects. There is no retained VM interfaces/controller table.
 const contextPrototype={
  registerTool(tool){
   if(!b.hasContext(this))illegal();if(!object(tool))invalid();
   let readOnly=false,untrustedContent=false,autosubmit=false;
   const annotations=tool.annotations;
   if(annotations!==undefined&&annotations!==null){
    if(!object(annotations))invalid();
    const automatic=annotations.autoSubmitHint;if(automatic!==undefined)autosubmit=!!automatic;
    const read=annotations.readOnlyHint;if(read!==undefined)readOnly=!!read;
    const untrusted=annotations.untrustedContentHint;if(untrusted!==undefined)untrustedContent=!!untrusted;
   }
   const descriptionValue=tool.description;if(descriptionValue===undefined)invalid();const convertedDescription=text(descriptionValue);
   const execute=tool.execute;if(typeof execute!=='function')invalid();
   const schema=tool.inputSchema;if(schema!==undefined&&schema!==null&&!object(schema))invalid();
   const nameValue=tool.name;if(nameValue===undefined)invalid();const name=text(nameValue);
   const title=tool.title;if(title!==undefined&&title!==null)text(title);
   const options=arguments[1];let signal;
   if(options!==undefined&&options!==null){if(!object(options))invalid();signal=options.signal;if(signal!==undefined&&signal!==null&&!b.hasSignal(signal))invalid()}
   if(!apply(test,namePattern,[name])||!convertedDescription.length)throw b.invalidState();
   b.register(this,name,convertedDescription,execute,schema,readOnly,untrustedContent,autosubmit,signal);
  },
 };
 const clientPrototype={
  requestUserInteraction(callback){
   // Native's actual Client operation is stateless: borrowing onto {} works.
   // Argument conversion and callback failures reject its real realm Promise.
   return new PromiseConstructor((resolve,reject)=>{
    if(typeof callback!=='function'){reject(new TypeErrorConstructor('invalid argument'));return}
    try{resolve(b.interact(callback))}catch(error){reject(new ErrorConstructor(text(error==null?error:(error.message===undefined?error:error.message))))}
   });
  },
 };
 for(const [Constructor,prototype]of [[ModelContext,contextPrototype],[ModelContextClient,clientPrototype]]){
  for(const key of Reflect.ownKeys(prototype)){const descriptor=own(prototype,key);define(prototype,key,{...descriptor,writable:true,enumerable:true,configurable:true})}
  define(prototype,'constructor',{value:Constructor,writable:true,configurable:true});
  define(prototype,Symbol.toStringTag,{value:Constructor.name,configurable:true});
  define(Constructor,'prototype',{value:prototype,writable:false});
  define(g,Constructor.name,{value:Constructor,writable:true,configurable:true});
 }
 const navigatorAccess={get modelContext(){if(!b.hasNavigator(this))illegal();return b.context(this)}};
 define(g.Navigator.prototype,'modelContext',{get:own(navigatorAccess,'modelContext').get,enumerable:true,configurable:true});
 b.exportPublic(ModelContext,ModelContextClient);
}

function registryFor(page){
 const root=page.registry?.page??page;
 let registry=registries.get(root);
 if(!registry){registry=state({root,owners:new Set(),subscriptions:new Set(),invocations:new Map(),nextInvocation:0});registries.set(root,registry)}
 return registry;
}
const live=owner=>!owner.disposed&&!owner.page.closed&&!owner.signal?.aborted&&owner.window.document===owner.document;
function notify(registry,method,params){for(const subscriber of registry.subscriptions)if(subscriber.enabled&&!subscriber.session.closed)subscriber.session.event(method,params)}
function serialize(owner,value){
 // Author JSON getters/toJSON run in their actual VM under its actual watchdog.
 const json=owner.invocation.invoke(owner.stringify,owner.JSON,[value],owner.options);
 return json===undefined?undefined:JSON.parse(json);
}
function toolMetadata(tool){return {name:tool.name,description:tool.description,inputSchema:tool.schema==null?{}:serialize(tool.owner,tool.schema),annotations:{readOnly:tool.readOnly,untrustedContent:tool.untrustedContent,autosubmit:tool.autosubmit},frameId:tool.owner.page.frameId}}
function signalSource(value){const record=platformFactoryRecord(value);return record?.kind==='AbortSignal'?record.implementation:null}
function removeTool(tool){
 const owner=tool.owner;if(owner.tools.get(tool.name)!==tool)return;
 owner.tools.delete(tool.name);if(tool.source&&tool.abort)tool.source._removeAlgorithm(tool.abort);tool.abort=null;
 notify(owner.registry,'WebMCP.toolsRemoved',{tools:[{name:tool.name,frameId:owner.page.frameId}]});
}
function cleanupInvocation(job){
 job.active=false;job.owner.registry.invocations.delete(job.id);job.owner.invocations.delete(job);job.result=null;job.tool=null;
}
function errorText(owner,error,synchronous){
 // A fresh non-retained VM function bounds actual authored error conversion.
 return owner.invocation.invokeDeclaration(synchronous?'function(value,String){return String(value==null?value:(value.message===undefined?value:value.message))}':'function(value,String){return String(value)}',undefined,[error,owner.String],owner.options);
}
function respond(job,kind,value){
 if(!job.active)return;
 const owner=job.owner;
 try{
  if(!live(owner))return;
  const params={invocationId:job.id,status:kind==='value'?'Completed':'Error'};
  if(kind==='value')params.output=serialize(owner,value);else params.errorText=errorText(owner,value,kind==='throw');
  // Reentrant serialization may cancel this real invocation. Cancellation owns
  // delivery and is checked again after all authored conversions have finished.
  if(job.active&&live(owner))notify(owner.registry,'WebMCP.toolResponded',params);
 }finally{cleanupInvocation(job)}
}
function cancelInvocation(job){
 if(!job.active)return;
 try{notify(job.owner.registry,'WebMCP.toolResponded',{invocationId:job.id,status:'Canceled'})}finally{cleanupInvocation(job)}
}

export function installModelContext(page,window){
 if(owners.has(window))return;
 const context=implForWrapper(window)._globalObject;
 if(!vm.isContext(context))throw new TypeError('ModelContext requires its actual Window VM');
 const registry=registryFor(page),owner=state({page,window,document:window.document,signal:page.documentAbort?.signal,registry,disposed:false,tools:new Map(),invocations:new Set(),front:null});
 owner.invocation=createInvocationTrampoline(context);owner.options=state({timeout:Math.min(page.timeout??2000,2000),displayErrors:false});
 // Captured public intrinsics are actual VM functions; no private VM factories
 // are returned to Host or retained in an ordinary VM record.
 owner.create=window.Object.create;owner.JSON=window.JSON;owner.stringify=window.JSON.stringify;owner.parse=window.JSON.parse;
 owner.String=window.String;owner.then=window.Promise.prototype.then;owner.invalidState=captureDOMExceptionFactory(window);
 const bridge=state({
  hasContext:value=>contexts.has(value),hasNavigator:value=>navigators.has(value),hasSignal:value=>!!signalSource(value),
  invalidState:()=>owner.invalidState('The object is in an invalid state','InvalidStateError'),
  context(receiver){const actual=navigators.get(receiver);if(actual.front===null){actual.front=apply(actual.create,undefined,[actual.contextPrototype]);contexts.set(actual.front,actual)}return actual.front},
  register(receiver,name,description,execute,schema,readOnly,untrustedContent,autosubmit,signal){
   const actual=contexts.get(receiver);
   if(!live(actual)||actual.tools.has(name))throw owner.invalidState('The object is in an invalid state','InvalidStateError');
   const source=signal==null?null:signalSource(signal);if(source?.aborted)return;
   const tool=state({owner:actual,name,description,execute,schema,readOnly,untrustedContent,autosubmit,source,abort:null});
   actual.tools.set(name,tool);if(source){tool.abort=()=>removeTool(tool);source._addAlgorithm(tool.abort)}
   notify(actual.registry,'WebMCP.toolsAdded',{tools:[toolMetadata(tool)]});
  },
  interact(callback){return owner.invocation.invoke(callback,owner.window,[],owner.options)},
  exportPublic(ModelContext,ModelContextClient){owner.contextPrototype=ModelContext.prototype;owner.clientPrototype=ModelContextClient.prototype;registerProtocolPrototype(owner.contextPrototype,'ModelContext');registerProtocolPrototype(owner.clientPrototype,'ModelContextClient')},
 });
 vm.compileFunction(`(${definition.toString()})(globalThis,bridge)`,['bridge'],{parsingContext:context})(bridge);
 owners.set(window,owner);navigators.set(window.navigator,owner);registry.owners.add(owner);
 const dispose=()=>{
  if(owner.disposed)return;owner.disposed=true;registry.owners.delete(owner);
  for(const tool of owner.tools.values())if(tool.source&&tool.abort)tool.source._removeAlgorithm(tool.abort);
  owner.tools.clear();for(const job of owner.invocations)cleanupInvocation(job);
  owner.signal?.removeEventListener('abort',dispose);page.off?.('close',dispose);
 };
 owner.signal?.addEventListener('abort',dispose,{once:true});page.once?.('close',dispose);
 if(owner.signal?.aborted||page.closed)dispose();
}

export function initializeModelContextSession(session){
 const registry=registryFor(session.page),record=state({session,registry,enabled:false});sessions.set(session,record);registry.subscriptions.add(record);
}
export function closeModelContextSession(session){const record=sessions.get(session);if(record){record.enabled=false;record.registry.subscriptions.delete(record);sessions.delete(session)}}
export function runModelContextCDP(session,method,params,ProtocolError,completedResponse){
 const record=sessions.get(session),registry=record.registry;
 if(method==='WebMCP.enable'){
  record.enabled=true;session.domains.add('WebMCP');const tools=[];
  for(const owner of registry.owners)if(live(owner))for(const tool of owner.tools.values())tools.push(toolMetadata(tool));
  if(tools.length)session.event('WebMCP.toolsAdded',{tools});return {};
 }
 if(method==='WebMCP.disable'){record.enabled=false;session.domains.delete('WebMCP');return {}}
 if(method==='WebMCP.cancelInvocation'){
  const job=registry.invocations.get(params.invocationId);if(job)cancelInvocation(job);return {};
 }
 if(method!=='WebMCP.invokeTool')throw new ProtocolError(`'${method}' wasn't found`,-32601);
 const owner=[...registry.owners].find(value=>live(value)&&value.page.frameId===params.frameId),tool=owner?.tools.get(params.toolName);
 if(!tool)throw new ProtocolError('NotFound',-31998);
 const id='INV-'+String(++registry.nextInvocation).padStart(10,'0'),job=state({owner,tool,id,active:true,result:null});
 registry.invocations.set(id,job);owner.invocations.add(job);
 let asynchronous=false;
 try{
  const inputJSON=JSON.stringify(params.input??{}),input=owner.invocation.invoke(owner.parse,owner.JSON,[inputJSON],owner.options);
  const client=apply(owner.create,undefined,[owner.clientPrototype]);
  notify(registry,'WebMCP.toolInvoked',{toolName:tool.name,frameId:owner.page.frameId,invocationId:id,input:inputJSON});
  let returned;
  try{returned=owner.invocation.invoke(tool.execute,owner.window,[input,client],owner.options)}catch(error){respond(job,'throw',error);return {invocationId:id}}
  if(!types.isPromise(returned)){
   // Serialize BEFORE crossing any async command boundary. In particular an
   // ordinary author thenable must never be adopted by a Host async function.
   respond(job,'value',returned);return {invocationId:id};
  }
  job.result=returned;asynchronous=true;
  // The existing CDP completion owner arms real Promise reactions only after
  // its response is sent. Immediate/plain responses above stay synchronous.
  return completedResponse({invocationId:id},()=>{
   // STATIC-v2 OPEN BLOCKER: Native19 proves constructor/species must remain
   // unread. Captured then below still reads them, so this draft Promise path
   // is not integration-ready until an owned hook-free observer is supplied.
   try{owner.invocation.invoke(owner.then,returned,[value=>respond(job,'value',value),error=>respond(job,'reject',error)],owner.options)}catch(error){respond(job,'throw',error)}
  });
 }finally{if(!asynchronous&&job.active)cleanupInvocation(job)}
}
