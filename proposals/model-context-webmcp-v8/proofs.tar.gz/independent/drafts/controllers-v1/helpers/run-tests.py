from pathlib import Path
import argparse, hashlib, json, os, signal, subprocess, time

def administrative_signal(number, _frame):
 raise KeyboardInterrupt('Administrative signal '+str(number))

signal.signal(signal.SIGTERM,administrative_signal)

root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--build-report',required=True);p.add_argument('--epoch',required=True);a=p.parse_args()
out=root/'test-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
build=Path(a.build_report).resolve();report=json.loads(build.read_text())
assert report['status']=='BUILT_RUNTIME_ONLY_TESTS_UNRUN' and report['unchanged'] and report['Root18Unchanged']
assert len(report['rows'])==3 and all(row['exit']==0 for row in report['rows'])
candidate=root/'candidate';protected=json.loads((root/'protected-root-native.json').read_text())
versions=[('24.22.1',Path('/workspace/shared/rea-tools/node_modules/node/bin/node')),('24.19.0',Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')),('26.13.0',Path('/workspace/shared/node26/node_modules/node/bin/node'))]
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
paths=[Path(__file__),build,root/'base.json',root/'protected-root-native.json',root/'unchanged-sdk-prerequisites.json']+list(map(Path,protected['files']))
for tree in [candidate/'src',candidate/'node_modules',candidate/'native']:
 paths.extend(path for path in tree.rglob('*')if path.is_file())
paths += [candidate/'test/model-context.test.js',candidate/'test/cdp-client.js']
paths += [node for _,node in versions];paths=sorted(set(paths));snapshot=lambda:{str(path):sha(path)for path in paths};before=snapshot();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
assert all(sha(Path(path))==value for path,value in protected['files'].items())
for row in report['rows']:
 path=Path(row['output']);assert path.is_relative_to(candidate/'native/build');assert not path.is_symlink()
 assert sha(path)==row['manifest']['binarySHA256'] and sha(Path(str(path)+'.json'))==row['manifestSHA256']
 assert row['manifest']['sourceSHA256']==sha(candidate/'native/runtime.cc')
env=dict(os.environ,NODE_USE_ENV_PROXY='1');previous=','.join(filter(None,[env.get('NO_PROXY',''),env.get('no_proxy','')]));aliases='0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]';env.update({key:','.join(filter(None,[previous,aliases]))for key in ['NO_PROXY','no_proxy']})
rows=[];failure=None;started=time.monotonic()
try:
 for version,node in versions:
  command=[str(node),'--experimental-vm-modules','--test','--test-concurrency=1','test/model-context.test.js'];row={'node':version,'command':command,'plannedCases':8,'administrativeWatchdogSeconds':45};begin=time.monotonic();child=None
  with(out/(version+'.stdout.log')).open('xb')as stdout,(out/(version+'.stderr.log')).open('xb')as stderr:
   child=subprocess.Popen(command,cwd=candidate,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
   try:child.wait(timeout=45)
   except BaseException:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=.2)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    row['exit']=child.returncode;rows.append(row);raise
  row['exit']=child.returncode;row['elapsedSeconds']=time.monotonic()-begin;row['actualStdoutSHA256']=sha(out/(version+'.stdout.log'));rows.append(row)
  if row['exit']:raise RuntimeError('First actual failing SDK; later SDKs UNRUN: '+version)
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)}
finally:
 after=snapshot();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');result={'status':'COMPLETED_ALL3'if failure is None and len(rows)==3 else'STOPPED_FUTURE_SDKS_UNRUN','rows':rows,'failure':failure,'inputs':len(before),'unchanged':before==after,'changed':[path for path in before if before[path]!=after[path]],'Root18Unchanged':all(sha(Path(path))==value for path,value in protected['files'].items()),'elapsedSeconds':time.monotonic()-started,'counts':'Actual TAP output is authoritative; planned8 is not a pass claim','NativeBounds':'Poisoned then/constructor/species, client conversion/schema proved. Exact timeout/lifetime/late rejection/response ordering remain independent Native heldouts.'};(out/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
