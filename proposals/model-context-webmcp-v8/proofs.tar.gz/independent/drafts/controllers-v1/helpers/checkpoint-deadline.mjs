// Separate local embedding guard diagnostic, not a Native parity assertion.
import {serve} from '../candidate/src/cdp.js';
import {connect} from '../candidate/test/cdp-client.js';
import {writeFileSync,appendFileSync} from 'node:fs';
const [output,trace]=process.argv.slice(2);let service,client,context,session,failure;
const rows=[];writeFileSync(trace,'',{flag:'wx'});
const phase=(name,extra={})=>appendFileSync(trace,JSON.stringify({name,pid:process.pid,at:performance.now(),...extra})+'\n');
try{
 phase('start');service=await serve({host:'127.0.0.1',port:0,timeout:20});
 client=await connect('ws://127.0.0.1:'+service.port+'/');
 const send=async(method,params={},sid=session)=>{phase('command-start',{method});const begin=performance.now(),offset=client.events.length,row={method,params};try{row.result=await client.send(method,params,sid,{timeout:2500})}catch(error){row.error={name:error.name,message:error.message,code:error.code}}row.elapsedMs=performance.now()-begin;row.events=client.events.slice(offset);rows.push(row);phase('command-end',{method,error:row.error??null});if(row.error)throw Error('Stop on actual command failure: '+row.error.message);return row.result};
 ({browserContextId:context}=await send('Target.createBrowserContext',{},undefined));
 const {targetId}=await send('Target.createTarget',{url:'about:blank',browserContextId:context},undefined);
 ({sessionId:session}=await send('Target.attachToTarget',{targetId,flatten:true},undefined));
 const frameId=(await send('Page.getFrameTree')).frameTree.frame.id;
 await send('Runtime.enable');await send('WebMCP.enable');
 await send('Runtime.evaluate',{expression:`navigator.modelContext.registerTool({name:'reaction_deadline',description:'actual genuine Promise reaction',execute(){return Promise.resolve().then(function(){for(;;){}})}});navigator.modelContext.registerTool({name:'after_reaction',description:'actual later callback',execute(){return{actualAfterReaction:true}}});'registered'`,returnByValue:true});
 phase('before-genuine-promise-reaction');
 await send('WebMCP.invokeTool',{frameId,toolName:'reaction_deadline',input:{actual:true}});
 phase('after-genuine-promise-reaction');
 await send('WebMCP.invokeTool',{frameId,toolName:'after_reaction',input:{actual:true}});
 await send('Runtime.evaluate',{expression:'JSON.stringify({actualAlive:true})',returnByValue:true});
}catch(error){failure={name:error.name,message:error.message}}
finally{
 phase('cleanup-start');if(client&&context)try{await client.send('Target.disposeBrowserContext',{browserContextId:context},undefined,{timeout:1000})}catch{}
 await client?.close();await service?.close();phase('cleanup-complete');
 writeFileSync(output,JSON.stringify({rows,events:client?.events??[],failure,scope:'Actual local VM20ms Promise reaction/checkpoint guard, not Native timeout fidelity'},null,2)+'\n',{flag:'wx'});
}
