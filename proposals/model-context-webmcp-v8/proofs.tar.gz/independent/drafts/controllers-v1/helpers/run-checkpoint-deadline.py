from pathlib import Path
import argparse, hashlib, json, os, signal, subprocess, time

def administrative_signal(number,_frame):
 raise KeyboardInterrupt('Administrative signal '+str(number))

signal.signal(signal.SIGTERM,administrative_signal)
r=Path(__file__).resolve().parent.parent;p=argparse.ArgumentParser();p.add_argument('--build-report',required=True);p.add_argument('--epoch',required=True);a=p.parse_args();out=r/'checkpoint-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
build=Path(a.build_report).resolve();report=json.loads(build.read_text());assert report['status']=='BUILT_RUNTIME_ONLY_TESTS_UNRUN' and report['unchanged'] and report['Root18Unchanged']
node=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');protected=json.loads((r/'protected-root-native.json').read_text());paths=[Path(__file__),r/'helpers/checkpoint-deadline.mjs',build,node,r/'candidate/test/cdp-client.js',r/'protected-root-native.json']+list(map(Path,protected['files']))
for tree in [r/'candidate/src',r/'candidate/native',r/'candidate/node_modules']:paths.extend(path for path in tree.rglob('*')if path.is_file())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();paths=sorted(set(paths));snapshot=lambda:{str(path):sha(path)for path in paths};before=snapshot();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
assert all(sha(Path(path))==value for path,value in protected['files'].items())
for row in report['rows']:
 artifact=Path(row['output']);assert sha(artifact)==row['manifest']['binarySHA256'] and row['manifest']['sourceSHA256']==sha(r/'candidate/native/runtime.cc')
env=dict(os.environ,NODE_USE_ENV_PROXY='1');prior=','.join(filter(None,[env.get('NO_PROXY',''),env.get('no_proxy','')]));aliases='0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]';env.update({key:','.join(filter(None,[prior,aliases]))for key in ['NO_PROXY','no_proxy']});command=[str(node),'--experimental-vm-modules',str(r/'helpers/checkpoint-deadline.mjs'),str(out/'raw.json'),str(out/'phases.jsonl')];child=None;failure=None;started=time.monotonic()
try:
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  child=subprocess.Popen(command,cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
  try:child.wait(timeout=10)
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=.2)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)}
finally:
 after=snapshot();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');result={'command':command,'exit':child.returncode if child else None,'failure':failure,'rawAvailable':(out/'raw.json').exists(),'elapsedSeconds':time.monotonic()-started,'inputs':len(before),'unchanged':before==after,'changed':[path for path in before if before[path]!=after[path]],'Root18Unchanged':all(sha(Path(path))==value for path,value in protected['files'].items()),'administrativeWatchdogSeconds':10,'actualVMWatchdogMs':20,'clientAPICommandMs':2500,'scope':'Separate genuine Promise-reaction checkpoint interruption diagnostic, NOT Native timeout-fidelity PASS'};(out/'status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
