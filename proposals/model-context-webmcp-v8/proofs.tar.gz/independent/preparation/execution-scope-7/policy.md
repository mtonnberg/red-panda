STATIC execution policy boundary, no runtime or execution-limit edits

Native observed finite2100ms WebMCP Promise reaction Completes under unchanged default CLI and2500ms API. The independent implementation's captured min(page.timeout,2000) rejects this actual work. This proves a concrete lower-bound incompatibility; it does not identify a universal upper bound, CLI load-timeout authority or first-timeout settlement semantics.

One newly prepared finite5-row profile observes default public Runtime2100 and synchronous WebMCP2100 separately, plus genuine markers/results/alive. No infinite authors, no test limit changes, no repeated old timeout20 controls. Runtime await/deadline values and all real effects are recorded as actuals. This profile is UNRUN.

Current public-V8 runtime checkpoint uses the isolate default queue. A callback owner or a timer record cannot make that shared queue exclusive to the invocation. Changing only a WebMCP option value to10000 would still give other queued reactions that wider checkpoint watchdog. It is not accepted as an ownership proof.

Genuine paths after facts: (a) a true per-context owned MicrotaskQueue/context provider with scoped execution policy, preserving every other Page/Runtime guard; or (b) separately measured target-wide execution policy and a deliberately separate implementation change. Neither is implicitly implemented by the v7 order/trust fix. No arbitrary2101/3000 ceiling, no response timeout fabrication, no Promise.prototype.then, no hooks, no broad rejection suppression.

First timedout reaction currently remains pending despite proven later callback/server recovery. That job lifecycle/settlement is still a separate unresolved behavior, never claimed Native parity.
