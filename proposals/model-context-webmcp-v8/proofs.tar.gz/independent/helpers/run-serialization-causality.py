from pathlib import Path
import argparse, hashlib, json, os, signal, subprocess, time

def terminated(number,_frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,terminated)
r=Path(__file__).resolve().parent.parent;plan=Path('/workspace/shared/webmcp-native-plan-20261031');p=argparse.ArgumentParser();p.add_argument('profile',choices=['serialization']);p.add_argument('actor',choices=['native','candidate-process']);p.add_argument('--epoch',required=True);p.add_argument('--build-report');a=p.parse_args();out=r/'calibration-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False);driver=r/'helpers/serialization-causality-controls.mjs';node=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');native=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');protected=json.loads((r/'protected-root-native.json').read_text());contracts=json.loads((plan/'source-contract-hashes.json').read_text());reference=Path('/workspace/red-panda/.cache/lightpanda-reference/browser-948d773786')
paths=[Path(__file__),driver,node,native,r/'protected-root-native.json',plan/'source-contract-hashes.json']+list(map(Path,protected['files']));runtime=None
if a.actor=='candidate-process':
 if not a.build_report:raise ValueError('Candidate requires actual matching all3SDK build receipt')
 build=Path(a.build_report).resolve();report=json.loads(build.read_text());assert report['status']=='BUILT_RUNTIME_ONLY_TESTS_UNRUN'and report['unchanged']and report['Root18Unchanged'];runtime=next(row for row in report['rows']if row['manifest']['node']=='v24.22.1');paths.extend([build,Path(runtime['output']),Path(runtime['output']+'.json')])
for tree in [r/'candidate/src',r/'candidate/native',plan/'harness',plan/'node_modules']:paths.extend(path for path in tree.rglob('*')if path.is_file())
paths.extend(path for path in(r/'candidate/bin').rglob('*')if path.is_file());paths.append(r/'candidate/package.json');paths.extend(reference/name for name in contracts['files']);paths=sorted(set(paths));sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();snapshot=lambda:{str(path):sha(path)for path in paths};before=snapshot();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');assert sha(native)=='9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f';assert all(sha(reference/name)==value for name,value in contracts['files'].items());assert all(sha(Path(path))==value for path,value in protected['files'].items())
env=dict(os.environ,NODE_USE_ENV_PROXY='1');old=','.join(filter(None,[env.get('NO_PROXY',''),env.get('no_proxy','')]));aliases='0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]';env.update({key:','.join(filter(None,[old,aliases]))for key in ['NO_PROXY','no_proxy']})
if runtime:
 assert sha(Path(runtime['output']))==runtime['manifest']['binarySHA256']and sha(r/'candidate/native/runtime.cc')==runtime['manifest']['sourceSHA256'];env['RED_PANDA_RUNTIME_ADDON']=runtime['output']
command=[str(node),'--experimental-vm-modules',str(driver),a.actor,str(out/'raw.json')];child=None;failure=None;started=time.monotonic()
try:
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  child=subprocess.Popen(command,cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
  try:child.wait(timeout=25)
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=.2)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)}
finally:
 after=snapshot();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');raw=json.loads((out/'raw.json').read_text())if(out/'raw.json').exists()else None;expected=14;complete=failure is None and child is not None and child.returncode==0 and raw is not None and not raw.get('failure')and len(raw['rows'])==expected;result={'status':'CAUSAL_OBSERVATIONS_COMPLETE'if complete and before==after else'STOPPED_UNOBSERVED_REMAINDER','profile':a.profile,'actor':a.actor,'command':command,'exit':child.returncode if child else None,'controllerFailure':failure,'profileFailure':raw.get('failure')if raw else None,'plannedRows':expected,'actualRows':len(raw['rows'])if raw else None,'setupRows':len(raw.get('setupRows',[]))if raw else None,'idleObservations':len(raw.get('idleObservations',[]))if raw else None,'inputs':len(before),'unchanged':before==after,'changed':[path for path in before if before[path]!=after[path]],'Root18Unchanged':all(sha(Path(path))==value for path,value in protected['files'].items()),'elapsedSeconds':time.monotonic()-started,'APICommandMs':2500,'ownedWatchdogSeconds':25,'noImplementationChanges':True,'noTargetDefaultTimeoutChange':True};(out/'status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if not complete or before!=after:raise SystemExit(1)
