import {startCandidateCLI} from './candidate-cli-process.mjs';
import {startReference} from '../../webmcp-native-plan-20261031/harness/scripts/reference-server.mjs';
import {connect} from '../../webmcp-native-plan-20261031/harness/test/cdp-client.js';
import {writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {createHash} from 'node:crypto';

const [profile,actor,output]=process.argv.slice(2);
let service,client,context,session,frameId,childFrameId,failure,fixture,fixtureURL;
let recordingSetup=profile==='realms';const setupRows=[],httpWire=[];
const rows=[],errors=e=>({name:e.name,message:e.message,code:e.code});
try{
 if(actor==='native')service=await startReference('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux',{args:['--load-resources','iframe']});
 else if(actor==='candidate-process')service=await startCandidateCLI({args:["--load-resources", "iframe"]});else throw Error('Unknown actor');
 const ownerHTML='<!doctype html><html><head><meta charset=utf-8><title>Actual WebMCP realm owner</title></head><body><p>Actual owned HTTP document</p></body></html>';
 fixture=createServer((request,response)=>{httpWire.push({phase:'request',at:performance.now(),method:request.method,url:request.url,headers:request.headers});response.writeHead(200,{'content-type':'text/html; charset=utf-8'});response.end(ownerHTML);httpWire.push({phase:'response-end',at:performance.now(),status:200,bodySHA256:createHash('sha256').update(ownerHTML).digest('hex')})});fixture.listen(0,'127.0.0.1');await once(fixture,'listening');fixtureURL='http://127.0.0.1:'+fixture.address().port+'/actual-owner';
 client=await connect(service.endpoint);
 const send=(method,params={},sid=session)=>client.send(method,params,sid,{timeout:2500});
 ({browserContextId:context}=await send('Target.createBrowserContext',{},undefined));
 const {targetId}=await send('Target.createTarget',{url:'about:blank',browserContextId:context},undefined);
 ({sessionId:session}=await send('Target.attachToTarget',{targetId,flatten:true},undefined));
 await send('Runtime.enable');await send('Page.enable');
 frameId=(await send('Page.getFrameTree')).frameTree.frame.id;
 async function command(label,method,params={}){
  const start=performance.now(),offset=client.events.length,row={label,method,params};
  try{row.result=await send(method,params)}catch(error){row.error=errors(error)}
  row.elapsedMs=performance.now()-start;row.events=client.events.slice(offset);(recordingSetup?setupRows:rows).push(row);
  console.log(JSON.stringify({label,error:row.error??null}));
  if(row.error&&(row.error.message.startsWith('CDP timeout:')||row.error.message==='CDP connection closed'))throw Error('Stopped on actual no-response: '+label);
  return row;
 }
 const errorSource=`const errorData=e=>({name:e.name,message:e.message,code:e.code,constructorName:e.constructor?.name,isError:e instanceof Error,isDOMException:typeof DOMException==='function'&&e instanceof DOMException});`;
 const evaluate=(label,body,asynchronous=false)=>command(label,'Runtime.evaluate',{expression:`(${asynchronous?'async ':''}()=>{${errorSource}try{const value=${asynchronous?'await ':''}(${asynchronous?'async ':''}()=>{${body}})();return JSON.stringify({ok:true,value,valueType:typeof value})}catch(e){return JSON.stringify({ok:false,error:errorData(e)})}})()`,awaitPromise:asynchronous,returnByValue:true});
 await command('enable','WebMCP.enable');
 if(profile==='semantics'){
  await evaluate('public-descriptors',`const shape=object=>object===null?null:Reflect.ownKeys(object).map(key=>{const d=Object.getOwnPropertyDescriptor(object,key);return{key:String(key),enumerable:d.enumerable,configurable:d.configurable,writable:d.writable,type:typeof d.value,value:typeof d.value==='string'?d.value:undefined,functionName:typeof d.value==='function'?d.value.name:undefined,functionLength:typeof d.value==='function'?d.value.length:undefined,getName:d.get?.name,getLength:d.get?.length,setName:d.set?.name}});const attempts=[];for(const f of[()=>ModelContext(),()=>new ModelContextClient(),()=>ModelContextClient()])try{const value=f();attempts.push({ok:true,tag:Object.prototype.toString.call(value)})}catch(e){attempts.push({ok:false,error:errorData(e)})}return{contextPrototype:shape(ModelContext.prototype),clientPrototype:shape(ModelContextClient.prototype),contextConstructor:shape(ModelContext),clientConstructor:shape(ModelContextClient),navigatorDescriptor:shape(Object.getPrototypeOf(navigator)).find(x=>x.key==='modelContext'),attempts}`);
  await evaluate('register-metadata-and-client',`globalThis.actualClients=[];globalThis.actualTape=[];globalThis.actualSchemaReads=[];globalThis.actualSchema={type:'object',actualBefore:1};const schemaWithGetter={get actualGetter(){actualSchemaReads.push('actualGetter');return 9}};for(const[name,inputSchema,execute]of [['capture',{},function(input,client){actualClients.push(client);actualTape.push({name:'capture',thisWindow:this===globalThis,inputRealm:input instanceof Object});return{actual:input}}],['mutable',actualSchema,function(input){return input}],['getter_schema',schemaWithGetter,function(input){return input}]])navigator.modelContext.registerTool({name,description:'actual '+name,inputSchema,execute});return{reads:actualSchemaReads}`);
  await evaluate('mutate-real-schema',`actualSchema.actualBefore=2;actualSchema.actualAfter={actual:true};return{reads:actualSchemaReads}`);
  await command('disable-before-metadata-replay','WebMCP.disable');
  await command('actual-metadata-replay','WebMCP.enable');
  await evaluate('metadata-getter-count','return actualSchemaReads');
  await command('invoke-capture','WebMCP.invokeTool',{frameId,toolName:'capture',input:{actualInput:true}});
  await evaluate('actual-client-descriptors',`const c=actualClients[0],p=Object.getPrototypeOf(c);return{own:Reflect.ownKeys(c).map(String),prototypeNull:p===null,prototypeIsConstructor:p===ModelContextClient.prototype,constructorPrototypeNull:ModelContextClient.prototype===null,constructorInstance:c instanceof ModelContextClient,tag:Object.prototype.toString.call(c),prototypeOwn:p?Reflect.ownKeys(p).map(String):null,methodName:c.requestUserInteraction.name,methodLength:c.requestUserInteraction.length,methodRealm:c.requestUserInteraction instanceof Function,tape:actualTape}`);
  await evaluate('client-brand-and-argument-errors',`const c=actualClients[0],results=[];for(const invoke of[()=>c.requestUserInteraction.call({},()=>1),()=>c.requestUserInteraction(),()=>c.requestUserInteraction(7),()=>c.requestUserInteraction(()=>{throw new TypeError('actual interaction throw')})]){try{const result=invoke();const before={type:typeof result,promise:result instanceof Promise};try{results.push({...before,ok:true,value:await result})}catch(error){results.push({...before,ok:false,error:errorData(error)})}}catch(error){results.push({synchronous:true,ok:false,error:errorData(error)})}}return results`,true);
  await evaluate('interaction-real-receiver-and-result',`const result=actualClients[0].requestUserInteraction(function(){actualTape.push({name:'interaction-control',thisWindow:this===globalThis,args:arguments.length});return{then(resolve){actualTape.push({name:'interaction-thenable-called'});resolve({actualInteraction:true})}}});const promise=result instanceof Promise,value=await result;return{promise,value,tape:actualTape}`,true);
  await evaluate('register-real-poisoned-promises',`globalThis.actualPoisonReads=[];for(const name of['own_then','constructor','species'])navigator.modelContext.registerTool({name,description:'actual '+name,execute(input){const p=Promise.resolve({actualPromise:name,input});if(name==='own_then')Object.defineProperty(p,'then',{get(){actualPoisonReads.push(name);throw new Error('actual own then getter')}});else if(name==='constructor')Object.defineProperty(p,'constructor',{get(){actualPoisonReads.push(name);throw new Error('actual constructor getter')}});else Object.defineProperty(p,'constructor',{value:{get [Symbol.species](){actualPoisonReads.push(name);throw new Error('actual species getter')}}});return p}});return true`);
  for(const name of ['own_then','constructor','species']){
   await command('invoke-'+name,'WebMCP.invokeTool',{frameId,toolName:name,input:{value:name}});
   await evaluate('checkpoint-'+name,'return actualPoisonReads');
  }
  await evaluate('copied-signal-prototype-is-not-authority',`const genuine=new AbortController().signal,fake=Object.create(Object.getPrototypeOf(genuine));return navigator.modelContext.registerTool({name:'fake_signal',description:'actual',execute(){}},{signal:fake})`);
 }else if(profile==='realms'){
  await command('setup-real-http-owner','Page.navigate',{url:fixtureURL});
  const rootTree=await command('setup-real-http-root-tree','Page.getFrameTree');frameId=rootTree.result?.frameTree?.frame.id;if(typeof frameId!=='string')throw Error('Actual HTTP owner frame absent');
  const setup=await evaluate('create-real-child-in-genuine-body',`const root=document.documentElement??document.appendChild(document.createElement('html'));const body=document.body??root.appendChild(document.createElement('body'));globalThis.actualFrame=document.createElement('iframe');body.appendChild(actualFrame);globalThis.actualChild=actualFrame.contentWindow;globalThis.actualParentTape=[];return{document:!!actualChild.document,context:typeof actualChild.navigator.modelContext,childConstructor:typeof actualChild.ModelContext,distinct:actualChild.navigator.modelContext!==navigator.modelContext}`);
  if(JSON.parse(setup.result?.result?.value??'null')?.ok!==true)throw Error('Actual authored iframe setup failed; later realm controls unobserved');
  const tree=await command('actual-unique-child-owner-tree','Page.getFrameTree');
  const children=tree.result?.frameTree?.childFrames??[];
  if(children.length!==1)throw Error('Expected one genuine fresh child tree relationship; observed '+children.length+'; later controls unobserved');
  childFrameId=children[0]?.frame?.id;
  if(typeof childFrameId!=='string'||childFrameId===frameId)throw Error('Actual unique child frame identity absent; later realm controls unobserved');
  recordingSetup=false;
  await evaluate('register-borrowed-methods',`actualChild.eval('globalThis.actualChildTape=[];globalThis.actualClients=[];navigator.modelContext.registerTool({name:"child_created",description:"actual child",execute:function(input,client){actualClients.push(client);actualChildTape.push({name:"child_created",receiver:this===globalThis,inputRealm:input instanceof Object});return {actualChild:input}}})');navigator.modelContext.registerTool.call(actualChild.navigator.modelContext,{name:'parent_created',description:'actual parent callback',execute:function(input,client){actualChild.actualClients.push(client);actualParentTape.push({name:'parent_created',receiverParent:this===globalThis,receiverChild:this===actualChild,inputParent:input instanceof Object,inputChild:input instanceof actualChild.Object});return{actualParent:input}}});return true`);
  await command('invoke-child-created','WebMCP.invokeTool',{frameId:childFrameId,toolName:'child_created',input:{actual:'child'}});
  await command('invoke-parent-created-child-owned','WebMCP.invokeTool',{frameId:childFrameId,toolName:'parent_created',input:{actual:'parent'}});
  await evaluate('borrowed-realms-and-client-values',`return{childTape:actualChild.actualChildTape,parentTape:actualParentTape,clients:actualChild.actualClients.map(c=>({parentObject:c instanceof Object,childObject:c instanceof actualChild.Object,parentClient:c instanceof ModelContextClient,childClient:c instanceof actualChild.ModelContextClient,methodParent:c.requestUserInteraction instanceof Function,methodChild:c.requestUserInteraction instanceof actualChild.Function}))}`);
  await evaluate('borrowed-getter-and-error-realms',`const getter=Object.getOwnPropertyDescriptor(Navigator.prototype,'modelContext').get,childGetter=Object.getOwnPropertyDescriptor(actualChild.Navigator.prototype,'modelContext').get,results=[];for(const invoke of[()=>navigator.modelContext.registerTool.call(actualChild.navigator.modelContext,{name:'',description:'d',execute(){}}),()=>actualChild.navigator.modelContext.registerTool.call(navigator.modelContext,{name:'',description:'d',execute(){}}),()=>getter.call({}),()=>childGetter.call({})])try{invoke();results.push({ok:true})}catch(error){results.push({name:error.name,message:error.message,parentError:error instanceof Error,childError:error instanceof actualChild.Error,parentDOM:error instanceof DOMException,childDOM:error instanceof actualChild.DOMException})}return{parentGetterChild:getter.call(actualChild.navigator)===actualChild.navigator.modelContext,childGetterParent:childGetter.call(navigator)===navigator.modelContext,results}`);
  await evaluate('borrowed-interaction-realm',`const c=actualChild.actualClients[0],parentMethod=ModelContextClient.prototype.requestUserInteraction,childMethod=actualChild.ModelContextClient.prototype.requestUserInteraction,results=[];for(const method of[parentMethod,childMethod]){try{const promise=method.call(c,function(){return{thisParent:this===globalThis,thisChild:this===actualChild}});results.push({parentPromise:promise instanceof Promise,childPromise:promise instanceof actualChild.Promise,value:await promise})}catch(error){results.push({error:errorData(error)})}}return results`,true);
  await evaluate('register-child-held-promise',`actualChild.eval('globalThis.actualRelease=null;navigator.modelContext.registerTool({name:"held",description:"actual held",execute:function(){return new Promise(resolve=>{actualRelease=()=>{actualChildTape.push({name:"released"});resolve({actualReleased:true})}})}},{signal:(globalThis.actualController=new AbortController()).signal})');return true`);
  await command('invoke-held-child','WebMCP.invokeTool',{frameId:childFrameId,toolName:'held',input:{actual:'pending'}});
  await evaluate('abort-registered-pending-tool','actualChild.actualController.abort();return true');
  await evaluate('resolve-after-tool-abort','actualChild.actualRelease();return actualChild.actualChildTape');
  await evaluate('remove-real-child','actualFrame.remove();return{oldContextType:typeof actualChild.navigator.modelContext}');
  await evaluate('retained-child-after-removal',`let retained;try{actualChild.navigator.modelContext.registerTool({name:'retained',description:'actual retained',execute(){return{actualRetained:true}}});retained={ok:true}}catch(error){retained={ok:false,error:errorData(error)}}navigator.modelContext.registerTool({name:'parent_kept',description:'actual parent',execute(){return{actualParentKept:true}}});return retained`);
  await command('invoke-retired-child-owner','WebMCP.invokeTool',{frameId:childFrameId,toolName:'retained',input:{actual:true}});
  await evaluate('same-document-parent-tools','history.pushState({actual:true},"","#actual-tools");return true');
  await command('invoke-live-parent-after-child-removal','WebMCP.invokeTool',{frameId,toolName:'parent_kept',input:{actual:true}});
 }else throw Error('Unknown heldout profile');
}catch(error){failure=errors(error)}
finally{
 if(client&&context)try{await client.send('Target.disposeBrowserContext',{browserContextId:context},undefined,{timeout:1000})}catch{}
 await client?.close();await service?.close();if(fixture){fixture.closeAllConnections();await new Promise(resolve=>fixture.close(resolve))}
 await writeFile(output,JSON.stringify({profile,actor,rows,setupRows,nativeArgs:actor==='native'?['--load-resources','iframe']:null,ownedFixture:{url:fixtureURL,httpWire},events:client?.events??[],frameId,childFrameId,failure,ownedBrowser:service?.process?{pid:service.process.pid,exitCode:service.process.exitCode,signal:service.process.signalCode,stderr:service.stderr,stderrTruncated:service.stderrTruncated}:null},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({profile,actor,rows:rows.length,setupRows:setupRows.length,failure}));
}
