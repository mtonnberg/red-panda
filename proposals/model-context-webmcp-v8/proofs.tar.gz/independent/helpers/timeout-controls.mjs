import {startReference} from '../../webmcp-native-plan-20261031/harness/scripts/reference-server.mjs';
import {connect} from '../../webmcp-native-plan-20261031/harness/test/cdp-client.js';
import {writeFile} from 'node:fs/promises';
const [profile,output]=process.argv.slice(2);let service,client,context,session,frameId,failure;
const rows=[],omitted=[],fields=error=>({name:error.name,message:error.message,code:error.code});
try{
 service=await startReference('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');client=await connect(service.endpoint);
 const send=(method,params={},sid=session)=>client.send(method,params,sid,{timeout:2500});
 ({browserContextId:context}=await send('Target.createBrowserContext',{},undefined));const{targetId}=await send('Target.createTarget',{url:'about:blank',browserContextId:context},undefined);({sessionId:session}=await send('Target.attachToTarget',{targetId,flatten:true},undefined));await send('Runtime.enable');await send('Page.enable');frameId=(await send('Page.getFrameTree')).frameTree.frame.id;
 const command=async(label,method,params={})=>{const start=performance.now(),offset=client.events.length,row={label,method,params};try{row.result=await send(method,params)}catch(error){row.error=fields(error)}row.elapsedMs=performance.now()-start;row.events=client.events.slice(offset);rows.push(row);console.log(JSON.stringify({label,error:row.error??null}));if(row.error&&(row.error.message.startsWith('CDP timeout:')||row.error.message==='CDP connection closed'))throw Error('Stopped actual protocol no-response: '+label);return row};
 await command('enable','WebMCP.enable');
 if(profile==='runtime-option'){
  await command('finite100ms-with-explicit-Runtime-timeout20','Runtime.evaluate',{expression:`(()=>{globalThis.actualFinite100Completed=false;const end=performance.now()+100;while(performance.now()<end){}actualFinite100Completed=true;return JSON.stringify({actualFinite100Completed})})()`,timeout:20,returnByValue:true});
  await command('actual-alive-after-option','Runtime.evaluate',{expression:`JSON.stringify({actualAlive:true,completed:globalThis.actualFinite100Completed})`,returnByValue:true});
  await command('finite100ms-default-options-control','Runtime.evaluate',{expression:`(()=>{const end=performance.now()+100;while(performance.now()<end){}return JSON.stringify({actualDefault100Completed:true})})()`,returnByValue:true});
 }else if(profile==='bounded-reaction'){
  await command('register-real-bounded-reaction','Runtime.evaluate',{expression:`globalThis.actualTape=[];globalThis.actualHealthyCount=0;navigator.modelContext.registerTool({name:'bounded_actual_reaction',description:'real finite2100ms authored reaction',execute(input){actualTape.push('execute-returning-promise');return Promise.resolve().then(()=>{actualTape.push('reaction-entered');const end=performance.now()+2100;while(performance.now()<end){}actualTape.push('reaction-completed');return{actualReactionCompleted:true,input}})}});navigator.modelContext.registerTool({name:'healthy_after_actual_reaction',description:'real later healthy callback',execute(){actualHealthyCount++;return{actualHealthyCount}}});JSON.stringify({registered:true,tape:actualTape})`,returnByValue:true});
  const invocation=await command('invoke-real-finite2100ms-reaction','WebMCP.invokeTool',{frameId,toolName:'bounded_actual_reaction',input:{actualWork:'finite2100ms'}});
  await command('actual-post-reaction-checkpoint','Runtime.evaluate',{expression:`JSON.stringify({actualAlive:true,tape:actualTape,actualHealthyCount})`,returnByValue:true});
  await command('invoke-real-healthy-after-reaction','WebMCP.invokeTool',{frameId,toolName:'healthy_after_actual_reaction',input:{actualHealthy:true}});
  await command('actual-later-tape-and-count','Runtime.evaluate',{expression:`JSON.stringify({actualAlive:true,tape:actualTape,actualHealthyCount})`,returnByValue:true});
  const id=invocation.result?.invocationId,terminal=id&&client.events.some(event=>event.method==='WebMCP.toolResponded'&&event.params.invocationId===id);
  if(id&&!terminal)await command('cancel-actual-still-pending-reaction','WebMCP.cancelInvocation',{invocationId:id});
  else omitted.push({label:'cancel-actual-still-pending-reaction',reason:id?'Actual invocation already responded; no invented repeated cancellation':'Actual invocationId not returned'});
 }else throw Error('Unknown declared timeout profile');
}catch(error){failure=fields(error)}
finally{
 if(client&&context)try{await client.send('Target.disposeBrowserContext',{browserContextId:context},undefined,{timeout:1000})}catch{}
 await client?.close();await service?.close();
 await writeFile(output,JSON.stringify({profile,rows,omitted,events:client?.events??[],frameId,failure,ownedBrowser:service?{pid:service.process.pid,exitCode:service.process.exitCode,signal:service.process.signalCode,stderr:service.stderr,stderrTruncated:service.stderrTruncated}:null,scope:'Native causal control only. Default CLI unchanged,2500ms client APIs unchanged. Runtime timeout20 is an explicitly authored public-parameter discriminator, not a raised test budget. Finite2100ms work may complete or hit actual target limit; no assumed timeout/automatic settlement result.'},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({profile,rows:rows.length,omitted,failure}));
}
