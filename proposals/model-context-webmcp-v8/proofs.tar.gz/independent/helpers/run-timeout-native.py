from pathlib import Path
import argparse, hashlib, json, os, signal, subprocess, time

def terminated(number,_frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,terminated)
r=Path(__file__).resolve().parent.parent;plan=Path('/workspace/shared/webmcp-native-plan-20261031');p=argparse.ArgumentParser();p.add_argument('profile',choices=['runtime-option','bounded-reaction']);p.add_argument('--epoch',required=True);a=p.parse_args();out=r/'timeout-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False);node=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');native=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');protected=json.loads((r/'protected-root-native.json').read_text());contracts=json.loads((plan/'source-contract-hashes.json').read_text());reference=Path('/workspace/red-panda/.cache/lightpanda-reference/browser-948d773786')
paths=[Path(__file__),r/'helpers/timeout-controls.mjs',node,native,r/'protected-root-native.json',plan/'source-contract-hashes.json']+list(map(Path,protected['files']))
for tree in [plan/'harness',plan/'node_modules',r/'candidate/src',r/'candidate/native']:paths.extend(path for path in tree.rglob('*')if path.is_file())
paths.extend(reference/name for name in contracts['files']);paths=sorted(set(paths));sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();snapshot=lambda:{str(path):sha(path)for path in paths};before=snapshot();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');assert sha(native)=='9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f';assert all(sha(reference/name)==value for name,value in contracts['files'].items());assert all(sha(Path(path))==value for path,value in protected['files'].items())
env=dict(os.environ,NODE_USE_ENV_PROXY='1');old=','.join(filter(None,[env.get('NO_PROXY',''),env.get('no_proxy','')]));aliases='0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]';env.update({key:','.join(filter(None,[old,aliases]))for key in ['NO_PROXY','no_proxy']});command=[str(node),'--experimental-vm-modules',str(r/'helpers/timeout-controls.mjs'),a.profile,str(out/'raw.json')];child=None;failure=None;started=time.monotonic()
try:
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  child=subprocess.Popen(command,cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
  try:child.wait(timeout=25)
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=.2)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)}
finally:
 after=snapshot();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');raw=json.loads((out/'raw.json').read_text())if(out/'raw.json').exists()else None;complete=failure is None and child is not None and child.returncode==0 and raw is not None and not raw.get('failure');result={'status':'NATIVE_CAUSAL_OBSERVATIONS_COMPLETE'if complete and before==after else'STOPPED_UNOBSERVED_REMAINDER','profile':a.profile,'command':command,'exit':child.returncode if child else None,'controllerFailure':failure,'profileFailure':raw.get('failure')if raw else None,'plannedRows':4 if a.profile=='runtime-option' else '6 plus conditional real pending cancellation','actualRows':len(raw['rows'])if raw else None,'omitted':raw.get('omitted')if raw else None,'inputs':len(before),'unchanged':before==after,'changed':[path for path in before if before[path]!=after[path]],'Root18Unchanged':all(sha(Path(path))==value for path,value in protected['files'].items()),'elapsedSeconds':time.monotonic()-started,'APICommandMs':2500,'ownedWatchdogSeconds':25,'originalDefaultCLIUnchanged':True,'noAssumedTimeout':True,'noInfiniteAuthorLoop':True};(out/'status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if not complete or before!=after:raise SystemExit(1)
