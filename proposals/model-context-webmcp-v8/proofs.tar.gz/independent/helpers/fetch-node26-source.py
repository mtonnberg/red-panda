"""Declared source-only acquisition; never executes Node, builds or installs."""
from pathlib import Path
import argparse, hashlib, json, os, re, signal, ssl, time, urllib.error, urllib.parse, urllib.request

root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--epoch',required=True);a=p.parse_args()
out=root/'node-source-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
node=Path('/workspace/shared/node26/node_modules/node/bin/node')
headers=Path('/workspace/shared/node26/node_modules/node/node_modules/node-linux-x64/include/node')
runtime=root/'build-evidence/runtime-2/artifacts/26.13.0/runtime.node.json'
protected=json.loads((root/'protected-root-native.json').read_text())
guard_paths=[Path(__file__),node,headers/'node_version.h',headers/'v8-version.h',headers/'node.h',runtime,root/'protected-root-native.json']+list(map(Path,protected['files']))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
snapshot=lambda:{str(path):sha(path)for path in guard_paths}
before=snapshot();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
started=time.monotonic();deadline=started+20;responses=[];failure=None;identity=None;commit=None
proxy_values=[value for key,value in os.environ.items()if key.lower()in ('https_proxy','http_proxy','all_proxy')]
def sanitized(error):
 text=str(error)
 for value in proxy_values:text=text.replace(value,'[managed-proxy]')
 return text
def alarm(_number,_frame):raise TimeoutError('Declared20s source-acquisition resource deadline')
def terminate(number,_frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGALRM,alarm);signal.signal(signal.SIGTERM,terminate)
def request(url,label):
 remaining=deadline-time.monotonic()
 if remaining<=0:raise TimeoutError('Source acquisition deadline before '+label)
 parsed=urllib.parse.urlsplit(url)
 if parsed.scheme!='https' or parsed.hostname not in ['api.github.com','raw.githubusercontent.com']:raise RuntimeError('Unexpected source authority')
 record={'label':label,'url':url,'startedSeconds':time.monotonic()-started};responses.append(record)
 path=out/'responses'/(str(len(responses)).zfill(2)+'-'+label.replace('/','_'))
 path.parent.mkdir(exist_ok=True)
 try:
  with opener.open(urllib.request.Request(url,headers={'User-Agent':'RedPanda-source-calibration','Accept':'application/vnd.github+json' if parsed.hostname=='api.github.com' else 'text/plain'}),timeout=min(4,remaining))as response:
   actual=urllib.parse.urlsplit(response.geturl())
   if actual.scheme!='https' or actual.hostname not in ['api.github.com','raw.githubusercontent.com']:raise RuntimeError('Unexpected redirected source authority')
   record.update(status=response.status,actualURL=response.geturl(),headers=dict(response.headers))
   chunks=[];count=0
   while True:
    if time.monotonic()>deadline:raise TimeoutError('Source acquisition body deadline')
    chunk=response.read(65536)
    if not chunk:break
    chunks.append(chunk);count+=len(chunk)
    if count>2*1024*1024:raise RuntimeError('Source response exceeds declared2MiB cap')
   data=b''.join(chunks);path.write_bytes(data);record.update(bytes=len(data),SHA256=hashlib.sha256(data).hexdigest(),path=str(path))
   return data
 except BaseException as error:
  record['failure']={'type':type(error).__name__,'message':sanitized(error)}
  if isinstance(error,urllib.error.HTTPError):record['status']=error.code
  raise
def version(text,prefix):
 result=[]
 for part in ['MAJOR','MINOR','PATCH']:
  match=re.search(r'^#define '+prefix+'_'+part+r'_VERSION\s+(\d+)',text,re.M)
  if not match:raise RuntimeError('Unknown source version macro '+prefix+'_'+part)
  result.append(match[1])
 return '.'.join(result)
try:
 signal.setitimer(signal.ITIMER_REAL,20)
 tls=ssl.create_default_context()
 opener=urllib.request.build_opener(urllib.request.ProxyHandler(),urllib.request.HTTPSHandler(context=tls))
 assert all(sha(Path(path))==value for path,value in protected['files'].items())
 tag='v26.13.0';ref=json.loads(request('https://api.github.com/repos/nodejs/node/git/ref/tags/'+tag,'tag-ref.json'))
 if ref.get('ref')!='refs/tags/'+tag:raise RuntimeError('Unexpected exact official tag ref')
 obj=ref['object'];sha_pattern=re.compile(r'^[0-9a-f]{40}$')
 if not sha_pattern.fullmatch(obj.get('sha','')):raise RuntimeError('Unknown tag object SHA')
 if obj.get('type')=='tag':
  annotated=json.loads(request('https://api.github.com/repos/nodejs/node/git/tags/'+obj['sha'],'annotated-tag.json'))
  if annotated.get('tag')!=tag:raise RuntimeError('Unexpected annotated tag label')
  obj=annotated['object']
 if obj.get('type')!='commit' or not sha_pattern.fullmatch(obj.get('sha','')):raise RuntimeError('Official tag did not resolve to one immutable commit')
 commit=obj['sha']
 source_root='https://raw.githubusercontent.com/nodejs/node/'+commit+'/'
 actual_header=request(source_root+'src/node_version.h','src_node_version.h').decode('utf8')
 actual_version=version(actual_header,'NODE');installed_version=version((headers/'node_version.h').read_text(),'NODE')
 build=json.loads(runtime.read_text())
 if actual_version!='26.13.0' or installed_version!=actual_version or build['node']!='v'+actual_version:raise RuntimeError('Official/installed/actual-runtime Node version mismatch')
 files=['src/node_task_queue.cc','lib/internal/process/promises.js','src/api/environment.cc','src/env-inl.h','src/env.cc','src/node_contextify.cc','src/node.h','deps/v8/include/v8-version.h']
 for name in files:request(source_root+name,name)
 # Select by the actual recorded label rather than assuming annotated/light
 # tag request count; all response bytes remain separately retained.
 v8_record=next(record for record in responses if record['label']=='deps/v8/include/v8-version.h')
 source_v8=Path(v8_record['path']).read_text();installed_v8=(headers/'v8-version.h').read_text()
 def v8_version(text):
  parts=[]
  for macro in ['MAJOR_VERSION','MINOR_VERSION','BUILD_NUMBER','PATCH_LEVEL']:
   match=re.search(r'^#define V8_'+macro+r'\s+(\d+)',text,re.M)
   if not match:raise RuntimeError('Unknown V8 source version macro '+macro)
   parts.append(match[1])
  return '.'.join(parts)
 if v8_version(source_v8)!=v8_version(installed_v8) or build['v8'].split('-')[0]!=v8_version(source_v8):raise RuntimeError('Official/installed/actual-runtime V8 version mismatch')
 identity={'officialTag':tag,'immutableCommit':commit,'sourceNodeVersion':actual_version,'installedNodeVersion':installed_version,'actualRuntimeVersion':build['node'],'actualRuntimeABI':build['abi'],'actualRuntimeV8':build['v8'],'officialV8Base':v8_version(source_v8),'installedNodeBinarySHA256':sha(node),'runtimeMetadataProvenance':str(runtime),'sourceHeaderSHA256':hashlib.sha256(actual_header.encode()).hexdigest(),'installedHeaderSHA256':sha(headers/'node_version.h')}
except BaseException as error:failure={'type':type(error).__name__,'message':sanitized(error)}
finally:
 signal.setitimer(signal.ITIMER_REAL,0)
 after=snapshot();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');trust=ssl.get_default_verify_paths()
 report={'status':'SOURCE_ACQUIRED_CONTRACT_READ_PENDING'if failure is None else'STOPPED_REMAINING_SOURCE_UNOBSERVED','failure':failure,'identity':identity,'resolvedCommit':commit,'responses':responses,'inputs':len(before),'unchanged':before==after,'changed':[path for path in before if before[path]!=after[path]],'Root18Unchanged':all(sha(Path(path))==value for path,value in protected['files'].items()),'elapsedSeconds':time.monotonic()-started,'resourceMaximumSeconds':20,'TLS':{'verification':'ssl.create_default_context; CERT_REQUIRED; hostname verified; no insecure fallback','defaultCAFile':trust.cafile,'defaultCAPath':trust.capath,'SSL_CERT_FILEPresent':bool(os.environ.get('SSL_CERT_FILE')),'SSL_CERT_DIRPresent':bool(os.environ.get('SSL_CERT_DIR'))},'proxy':{'mode':'urllib environment ProxyHandler; no credentials recorded','configuredEnvironmentKeys':[key for key in os.environ if key.lower()in ['http_proxy','https_proxy','all_proxy','no_proxy']]},'scope':'Official immutable-tag Node26 source bytes only; no Node execution/build/install/full archive','noRetries':True,'RootSourceWrites':False};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
