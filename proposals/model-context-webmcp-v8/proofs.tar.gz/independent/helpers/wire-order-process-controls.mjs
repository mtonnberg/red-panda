import {startReference} from '../../webmcp-native-plan-20261031/harness/scripts/reference-server.mjs';
import {connect} from '../../webmcp-native-plan-20261031/harness/test/cdp-client.js';
import {writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const [actor,output]=process.argv.slice(2);let service,client,context,session,frameId,failure,sequence=0;const rows=[],wire=[],idleObservations=[];
const now=()=>Number(process.hrtime.bigint())/1e6;
let candidateStartup=null,readBatch=0;const transportBatches=[];
async function startActualCandidateCLI(){
 const reservation=createServer();await new Promise((resolve,reject)=>{reservation.once('error',reject);reservation.listen(0,'127.0.0.1',resolve)});const port=reservation.address().port;await new Promise(resolve=>reservation.close(resolve));
 const cli=fileURLToPath(new URL('../candidate/bin/red-panda.js',import.meta.url));
 const command=[process.execPath,'--experimental-vm-modules',cli,'serve','--host','127.0.0.1','--port',String(port)];
 const child=spawn(command[0],command.slice(1),{stdio:['ignore','pipe','pipe']});
 const record=candidateStartup={command,pid:child.pid,actualPort:port,stdout:'',stderr:'',stdoutTruncated:false,stderrTruncated:false,exitCode:null,signal:null,matchingRuntimeAddon:process.env.RED_PANDA_RUNTIME_ADDON??null};
 let spawnError;child.once('error',error=>{spawnError=error});
 for(const name of ['stdout','stderr'])child[name].on('data',bytes=>{const text=bytes.toString();if(record[name].length+text.length>65536)record[name+'Truncated']=true;record[name]=(record[name]+text).slice(0,65536)});
 child.once('exit',(code,signal)=>{record.exitCode=code;record.signal=signal});
 const close=async()=>{if(child.exitCode!==null||child.signalCode!==null||!child.pid)return;const exited=new Promise(resolve=>child.once('exit',resolve));child.kill('SIGTERM');const force=setTimeout(()=>{if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL')},1500);force.unref();try{await exited}finally{clearTimeout(force)}};
 try{
  const deadline=Date.now()+10000;while(true){if(spawnError)throw spawnError;if(child.exitCode!==null||child.signalCode!==null)throw Error('Actual candidate CLI exited before readiness: '+record.stderr);let ready=false;try{ready=(await fetch('http://127.0.0.1:'+port+'/json/version')).ok}catch{}if(ready)break;if(Date.now()>=deadline)throw Error('Actual candidate CLI readiness timeout: '+record.stderr);await new Promise(resolve=>setTimeout(resolve,20))}
  return{endpoint:'ws://127.0.0.1:'+port+'/',close,process:child,get stderr(){return record.stderr},get stderrTruncated(){return record.stderrTruncated}};
 }catch(error){await close();throw error}
}
try{
 if(actor==='native')service=await startReference('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');
 else if(actor==='candidate-process')service=await startActualCandidateCLI();else throw Error('Unknown actor');
 client=await connect(service.endpoint);client.socket._socket.prependListener('data',bytes=>{transportBatches.push({readBatch:++readBatch,at:now(),bytes:bytes.length,hex:bytes.toString('hex')})});const originalSend=client.socket.send.bind(client.socket);
 client.socket.send=function(payload,...args){wire.push({sequence:++sequence,direction:'out',at:now(),message:JSON.parse(String(payload))});return originalSend(payload,...args)};
 client.socket.on('message',payload=>wire.push({sequence:++sequence,direction:'in',at:now(),readBatch,message:JSON.parse(String(payload))}));
 async function command(label,method,params={},sid=session){const row={label,method,params,started:now()},offset=client.events.length;const pending=client.send(method,params,sid,{timeout:2500});row.commandId=wire.findLast(item=>item.direction==='out').message.id;try{row.result=await pending}catch(error){row.error={name:error.name,message:error.message,code:error.code}}row.finished=now();row.events=client.events.slice(offset);rows.push(row);console.log(JSON.stringify({label,error:row.error??null}));if(row.error&&(row.error.message.startsWith('CDP timeout:')||row.error.message==='CDP connection closed'))throw Error('Stopped actual no-response: '+label);return row.result}
 const idle=async(label,milliseconds)=>{const start=now(),before=sequence;await new Promise(resolve=>setTimeout(resolve,milliseconds));idleObservations.push({label,requestedMs:milliseconds,actualMs:now()-start,beforeSequence:before,afterSequence:sequence})};
 ({browserContextId:context}=await command('setup-context','Target.createBrowserContext',{},undefined));const{targetId}=await command('setup-target','Target.createTarget',{url:'about:blank',browserContextId:context},undefined);({sessionId:session}=await command('setup-attach','Target.attachToTarget',{targetId,flatten:true},undefined));await command('setup-runtime','Runtime.enable');await command('setup-page','Page.enable');frameId=(await command('setup-frame','Page.getFrameTree')).frameTree.frame.id;
 await command('enable','WebMCP.enable');
 await command('register-real-producers','Runtime.evaluate',{expression:`globalThis.actualWireTape=[];for(const[name,execute]of Object.entries({plain(input){actualWireTape.push(['plain',input.trial]);return{actual:'plain',input}},immediate(input){actualWireTape.push(['immediate',input.trial]);return Promise.resolve({actual:'immediate',input})},deferred(input){actualWireTape.push(['deferred',input.trial]);return new Promise(resolve=>{globalThis.actualWireRelease=()=>{actualWireTape.push(['resolved',input.trial]);resolve({actual:'deferred',input})}})},timer(input){actualWireTape.push(['timer-created',input.trial]);return new Promise(resolve=>setTimeout(()=>{actualWireTape.push(['timer-fired',input.trial]);resolve({actual:'timer',input})},0))}}))navigator.modelContext.registerTool({name:'wire_'+name,description:'actual '+name,execute});JSON.stringify({registered:true,tape:actualWireTape})`,returnByValue:true});
 await command('invoke-plain-control','WebMCP.invokeTool',{frameId,toolName:'wire_plain',input:{trial:0}});
 await command('invoke-immediate-first','WebMCP.invokeTool',{frameId,toolName:'wire_immediate',input:{trial:1}});await idle('idle10-without-VM-entry-first',10);
 await command('non-VM-frame-tree-after-first','Page.getFrameTree');await command('actual-VM-checkpoint-first','Runtime.evaluate',{expression:'JSON.stringify(actualWireTape)',returnByValue:true});
 await command('invoke-identical-immediate-second','WebMCP.invokeTool',{frameId,toolName:'wire_immediate',input:{trial:2}});await idle('idle10-without-VM-entry-second',10);await command('actual-VM-checkpoint-second','Runtime.evaluate',{expression:'JSON.stringify(actualWireTape)',returnByValue:true});
 await command('invoke-real-deferred','WebMCP.invokeTool',{frameId,toolName:'wire_deferred',input:{trial:3}});await command('actual-resolver-VM-task','Runtime.evaluate',{expression:'actualWireRelease();JSON.stringify(actualWireTape)',returnByValue:true});
 await command('invoke-real-timer','WebMCP.invokeTool',{frameId,toolName:'wire_timer',input:{trial:4}});await idle('idle20-real-window-timer',20);await command('actual-VM-checkpoint-after-timer','Runtime.evaluate',{expression:'JSON.stringify(actualWireTape)',returnByValue:true});
}catch(error){failure={name:error.name,message:error.message,code:error.code}}
finally{
 if(client&&context)try{await client.send('Target.disposeBrowserContext',{browserContextId:context},undefined,{timeout:1000})}catch{}await client?.close();await service?.close();
 const relations=[];
 for(const row of rows){const id=row.result?.invocationId;if(!id)continue;const reply=wire.find(item=>item.direction==='in'&&item.message.id===row.commandId),response=wire.find(item=>item.direction==='in'&&item.message.method==='WebMCP.toolResponded'&&item.message.params.invocationId===id);relations.push({label:row.label,invocationId:id,actualCommandId:row.commandId,actualReplySequence:reply?.sequence,actualResponseSequence:response?.sequence,responseBeforeReply:reply&&response?response.sequence<reply.sequence:null,responseDuringIdle:idleObservations.filter(idle=>response&&response.sequence>idle.beforeSequence&&response.sequence<=idle.afterSequence).map(idle=>idle.label)})}
 await writeFile(output,JSON.stringify({actor,rows,wire,transportBatches,candidateStartup,idleObservations,relations,frameId,failure,ownedBrowser:service?.process?{pid:service.process.pid,exitCode:service.process.exitCode,signal:service.process.signalCode,stderr:service.stderr,stderrTruncated:service.stderrTruncated}:null,scope:'Actual outbound/inbound CDP message order including replies; no event-slice inference/acknowledgement gate.15observations after6setup, three real bounded idle observations. All2500ms API bounds unchanged.'},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({actor,rows:rows.length,idles:idleObservations.length,failure}));
}
