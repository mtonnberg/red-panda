import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
export async function startCandidateCLI({args=[]}={}){
 const reservation=createServer();await new Promise((resolve,reject)=>{reservation.once('error',reject);reservation.listen(0,'127.0.0.1',resolve)});const port=reservation.address().port;await new Promise(resolve=>reservation.close(resolve));
 const cli=fileURLToPath(new URL('../candidate/bin/red-panda.js',import.meta.url));
 const command=[process.execPath,'--experimental-vm-modules',cli,'serve','--host','127.0.0.1','--port',String(port),...args];
 const child=spawn(command[0],command.slice(1),{stdio:['ignore','pipe','pipe']});
 const record={command,pid:child.pid,actualPort:port,stdout:'',stderr:'',stdoutTruncated:false,stderrTruncated:false,exitCode:null,signal:null,matchingRuntimeAddon:process.env.RED_PANDA_RUNTIME_ADDON??null};
 let spawnError;child.once('error',error=>{spawnError=error});
 for(const name of ['stdout','stderr'])child[name].on('data',bytes=>{const text=bytes.toString();if(record[name].length+text.length>65536)record[name+'Truncated']=true;record[name]=(record[name]+text).slice(0,65536)});
 child.once('exit',(code,signal)=>{record.exitCode=code;record.signal=signal});
 const close=async()=>{if(child.exitCode!==null||child.signalCode!==null||!child.pid)return;const exited=new Promise(resolve=>child.once('exit',resolve));child.kill('SIGTERM');const force=setTimeout(()=>{if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL')},1500);force.unref();try{await exited}finally{clearTimeout(force)}};
 try{
  const deadline=Date.now()+10000;while(true){if(spawnError)throw spawnError;if(child.exitCode!==null||child.signalCode!==null)throw Error('Actual candidate CLI exited before readiness: '+record.stderr);let ready=false;try{ready=(await fetch('http://127.0.0.1:'+port+'/json/version')).ok}catch{}if(ready)break;if(Date.now()>=deadline)throw Error('Actual candidate CLI readiness timeout: '+record.stderr);await new Promise(resolve=>setTimeout(resolve,20))}
  return{endpoint:'ws://127.0.0.1:'+port+'/',close,process:child,startup:record,get stderr(){return record.stderr},get stderrTruncated(){return record.stderrTruncated}};
 }catch(error){await close();throw error}
}
