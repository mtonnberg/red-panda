from pathlib import Path
import argparse,json
r=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--secure',required=True);p.add_argument('--wire',required=True);p.add_argument('--output',required=True);a=p.parse_args()
def raw(epoch):
 directory=r/'calibration-evidence'/epoch;status=json.loads((directory/'status.json').read_text());assert status['status']=='CAUSAL_OBSERVATIONS_COMPLETE'and status['unchanged']and status['Root18Unchanged'];return json.loads((directory/'raw.json').read_text())
native_secure,candidate_secure=raw('native-secure-1'),raw(a.secure)
def payloads(data):return {row['label']:json.loads(row['result']['result']['value'])for row in data['rows']}
def normalize(value,origin):
 if isinstance(value,str):
  for host in ['127.0.0.1','0.0.0.0']:value=value.replace('http://'+host+':'+origin,'http://'+host+':OWNED_PORT')
  return value
 if isinstance(value,list):return [normalize(item,origin)for item in value]
 if isinstance(value,dict):return {key:normalize(item,origin)for key,item in value.items()}
 return value
native,candidate=payloads(native_secure),payloads(candidate_secure);assert native.keys()==candidate.keys()
np=native['actual-loopback-owner']['locationOrigin'].split(':')[-1];cp=candidate['actual-loopback-owner']['locationOrigin'].split(':')[-1]
secure=[{'label':label,'equal':normalize(native[label],np)==normalize(candidate[label],cp),'native':normalize(native[label],np),'candidate':normalize(candidate[label],cp)}for label in native]
def producers(data):
 result=[]
 for row in data['rows']:
  invocation=row.get('result',{}).get('invocationId')
  if not invocation:continue
  reply=next(item for item in data['wire']if item['direction']=='in'and item['message'].get('id')==row['commandId'])
  response=next(item for item in data['wire']if item['direction']=='in'and item['message'].get('method')=='WebMCP.toolResponded'and item['message']['params']['invocationId']==invocation)
  later_commands=[item for item in data['wire']if item['direction']=='out'and item['sequence']>reply['sequence']]
  actual=dict(response['message']['params']);actual.pop('invocationId')
  result.append({'label':row['label'],'actualPayload':actual,'responseBeforeReply':response['sequence']<reply['sequence'],'responseBeforeNextCommand':not later_commands or response['sequence']<later_commands[0]['sequence'],'idleLabels':[idle['label']for idle in data['idleObservations']if idle['beforeSequence']<response['sequence']<=idle['afterSequence']]})
 return result
native_wire,candidate_wire=producers(raw('native-wire-1')),producers(raw(a.wire));assert len(native_wire)==len(candidate_wire)==5
wire=[{'label':left['label'],'equal':left==right,'native':left,'candidate':right}for left,right in zip(native_wire,candidate_wire)]
result={'status':'MEASURED_PRODUCERS_EQUAL'if all(row['equal']for row in secure+wire)else'ACTUAL_PRODUCER_DIFFERENCES','secureFullPayloads':secure,'wireFiveActualResultsAndOrder':wire,'scope':'Secure: all13 complete actual public result payloads, exact owned tuple port substitution only. Wire: actual5 output/status payloads, real reply/nextcommand relationships and actual bounded-idle delivery. Native/candidate Target/Page framework metadata remains different; this is not full transcript/82-row parity. No event fields dropped from raw evidence.'}
Path(a.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'secureEqual':sum(row['equal']for row in secure),'secureObserved':13,'wireEqual':sum(row['equal']for row in wire),'wireObserved':5}))
if result['status']!='MEASURED_PRODUCERS_EQUAL':raise SystemExit(1)
