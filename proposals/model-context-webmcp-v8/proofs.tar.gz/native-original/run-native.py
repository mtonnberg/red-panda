from pathlib import Path
import argparse,json,hashlib,subprocess,os,time,signal
r=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('profile',choices=['surface','invocation']);a=p.parse_args();out=r/'evidence'/a.profile;out.mkdir(exist_ok=False);node=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');native=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');contract=json.loads((r/'source-contract-hashes.json').read_text());source=Path('/workspace/red-panda/.cache/lightpanda-reference/browser-948d773786');paths=[p for tree in [r/'harness',r/'node_modules']for p in tree.rglob('*')if p.is_file()];paths.extend([r/'native-controls.mjs',r/'run-native.py',r/'package.json',r/'source-contract-hashes.json',node,native]);paths.extend(source/name for name in contract['files']);paths=sorted(set(paths));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();snap=lambda:{str(p):sha(p)for p in paths};before=snap();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');assert sha(native)=='9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f';assert all(sha(source/name)==value for name,value in contract['files'].items());env=dict(os.environ,NODE_USE_ENV_PROXY='1');previous=','.join(filter(None,[env.get('NO_PROXY',''),env.get('no_proxy','')]));aliases='0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]';env.update({key:','.join(filter(None,[previous,aliases]))for key in ['NO_PROXY','no_proxy']});command=[str(node),'--experimental-vm-modules',str(r/'native-controls.mjs'),a.profile,str(out/'raw.json')];start=time.monotonic();failure=None;child=None
try:
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  child=subprocess.Popen(command,cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=child.wait(timeout=25)
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=.2)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)}
finally:
 after=snap();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n');status={'profile':a.profile,'command':command,'exit':child.returncode if child else None,'failure':failure,'inputs':len(before),'unchanged':before==after,'changed':[p for p in before if before[p]!=after[p]],'elapsedSeconds':time.monotonic()-start,'clientPerCommandMs':2500,'administrativeProcessWatchdogSeconds':25};(out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
