from pathlib import Path
import argparse,json,re,time
from common import BASE,CANDIDATE,sha,guard,run,environment
p=argparse.ArgumentParser();p.add_argument('--epoch',required=True);p.add_argument('--build-report',required=True);a=p.parse_args();out=BASE/'proof-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False);buildpath=Path(a.build_report).resolve();build=json.loads(buildpath.read_text());assert build['status']=='BUILT_COMBINED_ALL3_PROOFS_UNRUN'and build['unchanged']and build['Root18Unchanged']and len(build['rows'])==3;before=guard();before[str(buildpath)]=sha(buildpath)
for row in build['rows']:
 output=Path(row['output']);assert output.is_relative_to(CANDIDATE/'native/build')and not output.is_symlink();assert row['manifest']['sourceSHA256']==sha(CANDIDATE/'native/runtime.cc')and row['manifest']['binarySHA256']==sha(output)and row['manifestSHA256']==sha(Path(str(output)+'.json'));before[str(output)]=sha(output);before[str(output)+'.json']=sha(Path(str(output)+'.json'))
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');sdks=json.loads((BASE/'sdks.json').read_text())['SDKs'];rows=[];failure=None;began=time.monotonic()
try:
 for sdk in sdks:
  version=sdk['version'];artifact=next(row for row in build['rows']if row['node']==version);env=environment();env['RED_PANDA_RUNTIME_ADDON']=artifact['output'];raw=out/(version+'.mcp.json');row={'node':version,'phases':[]};rows.append(row)
  phase=run(out,version+'-mcp13',[sdk['node'],str(BASE/'helpers/consumer-controls.mjs'),'observed',str(raw)],8,env);row['phases'].append(phase)
  if phase.get('failure')or phase['exit']!=0:raise RuntimeError('Actual MCP consumer producer failed; later stages UNRUN')
  data=json.loads(raw.read_text());assert data['allChecksPass']and not data.get('failure')and len(data['checks'])==13 and all(value['pass']for value in data['checks']);row['actualMCPChecks']=13
  phase=run(out,version+'-origin5',[sdk['node'],'--test','--test-reporter=tap','--test-concurrency=1','test/worker-error-origin.test.js'],45,env);row['phases'].append(phase)
  if phase.get('failure')or phase['exit']!=0:raise RuntimeError('Actual Origin consumer producer failed; later stages UNRUN')
  text=(out/(version+'-origin5.stdout.log')).read_text();counts={key:int(value)for key,value in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$',text,re.M)};assert counts=={'tests':5,'pass':5,'fail':0,'cancelled':0,'skipped':0,'todo':0};row['actualOriginTAP']=counts;row['actualCombinedConsumerChecks']=18
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)}
finally:
 try:after=guard();after.update({path:sha(path)for path in before if path not in after});changed=[path for path in before if before[path]!=after.get(path)]
 except BaseException as error:after={};changed=['FROZEN_GUARD_FAILURE'];failure=failure or{'type':type(error).__name__,'message':str(error)}
 (out/'after.json').write_text(json.dumps(after,indent=2)+'\n');report={'status':'ACTUAL_COMBINED_CONSUMERS_ALL3_PASS'if failure is None and len(rows)==3 and not changed else'STOPPED_FUTURE_STAGES_UNRUN','failure':failure,'rows':rows,'sourceSHA256':sha(CANDIDATE/'native/runtime.cc'),'buildReport':str(buildpath),'inputs':len(before),'unchanged':before==after,'changed':changed,'Root18Unchanged':all(sha(path)==digest for path,digest in json.loads((BASE/'protected-root-native.json').read_text())['files'].items()),'elapsedSeconds':time.monotonic()-began,'counts':'13 actualMCP checks +5actualOrigin TAPcases EACHSDK=18consumer checks,54total when ALL actual pass; NOT54TAP tests','componentCaps':{'MCPSeconds':8,'OriginWholeSeconds':45,'OriginEachOriginalCaseMs':15000},'noAllWorkerOrMCPIntegrationClaim':True};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if report['status']!='ACTUAL_COMBINED_CONSUMERS_ALL3_PASS':raise SystemExit(1)
