// Standalone genuine-producer controls. Process event listeners are diagnostic
// observers in this child only; production installs no hook or listener here.
import vm from 'node:vm';
import {writeFileSync} from 'node:fs';
import {getRuntimeBinding} from '../candidate/src/native-runtime.js';
const [mode,output]=process.argv.slice(2),binding=getRuntimeBinding(),context=vm.createContext({}),anchor=vm.runInContext('Object.prototype',context);
const checks=[],events=[],labels=new Map();let failure;
const check=(label,actual,expected)=>checks.push({label,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
const unhandled=(reason,promise)=>events.push({type:'unhandledRejection',label:labels.get(promise)??'other-actual-producer',reasonName:reason?.name,reasonMessage:reason?.message,actualPromise:labels.has(promise)});
const handled=promise=>events.push({type:'rejectionHandled',label:labels.get(promise)??'other-actual-producer',actualPromise:labels.has(promise)});
const tick=()=>new Promise(resolve=>setTimeout(resolve,10));
process.on('unhandledRejection',unhandled);process.on('rejectionHandled',handled);
function consume(promise,owner=anchor){if(mode==='observed')return binding.consumeObservedPromise(promise,owner);if(mode==='old-mark')return binding.markPromiseHandled(promise);throw Error('Unknown declared mode')}
try{
 const values=vm.runInContext(`(()=>{
  globalThis.actualHookReads=[];
  const observed=Promise.reject(new RangeError('actual observed rejection'));
  const pending=new Promise((_resolve,reject)=>globalThis.actualRejectPending=()=>reject(new TypeError('actual pending rejection')));
  const double=Promise.reject(new Error('actual double consumed'));
  const unconsumed=Promise.reject(new Error('actual unconsumed positive'));
  const late=Promise.reject(new Error('actual late handled'));
  for(const p of [observed,pending,double]){
   Object.defineProperty(p,'then',{get(){actualHookReads.push('then');throw new Error('authored then getter')}});
   Object.defineProperty(p,'constructor',{get(){actualHookReads.push('constructor');throw new Error('authored constructor getter')}});
  }
  const species=Promise.resolve({actualSpecies:true});
  Object.defineProperty(species,'constructor',{value:{get [Symbol.species](){actualHookReads.push('species');throw new Error('authored species getter')}}});
  return{observed,pending,double,unconsumed,late,species};
 })()`,context);
 for(const[label,promise]of Object.entries(values))labels.set(promise,label);
 for(const label of ['observed','pending','double','species'])consume(values[label]);
 consume(values.double);
 vm.runInContext('actualRejectPending()',context);
 check('observed-rejected-state',binding.promiseSnapshot(values.observed).state,2);
 check('pending-then-actually-rejected-state',binding.promiseSnapshot(values.pending).state,2);
 check('snapshot-unconsumed-state-remains-readable',binding.promiseSnapshot(values.unconsumed).state,2);
 let hostRejected=false;try{consume(Promise.resolve('actual Host foreign'),anchor)}catch(error){hostRejected=error instanceof TypeError}
 check('Host-foreign-realm-rejected',hostRejected,true);
 let traps=0;
 const fake=Object.create(Object.getPrototypeOf(values.observed));
 for(const symbol of Object.getOwnPropertySymbols(values.observed)){const d=Object.getOwnPropertyDescriptor(values.observed,symbol);Object.defineProperty(fake,symbol,d)}
 for(const[label,value]of [['plain',{}],['copied-symbols-prototype',fake],['proxy',new Proxy(values.observed,{get(){traps++;throw new Error('fake getter')}})]]){
  let rejected=false;try{consume(value,anchor)}catch(error){rejected=error instanceof TypeError}
  check('genuine-brand-'+label,rejected,true);
 }
 check('proxy-getters-not-consulted',traps,0);
 await tick();
 check('unconsumed-rejection-positive',events.filter(e=>e.type==='unhandledRejection').map(e=>e.label).sort(),['late','unconsumed']);
 check('consumed-rejections-not-emitted',events.some(e=>e.type==='unhandledRejection'&&['observed','pending','double'].includes(e.label)),false);
 consume(values.late);consume(values.late);
 await tick();
 check('actual-late-handled-exactly-once',events.filter(e=>e.type==='rejectionHandled').map(e=>e.label),['late']);
 const before=events.findIndex(e=>e.type==='unhandledRejection'&&e.label==='late'),after=events.findIndex(e=>e.type==='rejectionHandled'&&e.label==='late');
 check('late-event-order',before>=0&&after>before,true);
 check('then-constructor-species-hooks-unread',vm.runInContext('JSON.stringify(actualHookReads)',context),'[]');
}catch(error){failure={name:error.name,message:error.message,stack:error.stack}}
finally{
 // Remove our own observers only. No global event/map reset or retagging.
 process.off('unhandledRejection',unhandled);process.off('rejectionHandled',handled);
 writeFileSync(output,JSON.stringify({mode,checks,events,failure,allChecksPass:!failure&&checks.every(c=>c.pass),scope:'Standalone actual Node/V8 consumer and genuine unconsumed/late event countercontrols; no Native browser lifetime claim'},null,2)+'\n',{flag:'wx'});
 process.exitCode=failure||checks.some(c=>!c.pass)?1:0;
}
