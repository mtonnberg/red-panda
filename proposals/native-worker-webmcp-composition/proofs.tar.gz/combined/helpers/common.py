from pathlib import Path
import hashlib,json,os,signal,subprocess,time
BASE=Path(__file__).resolve().parent.parent
CANDIDATE=BASE/'candidate'
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
def interrupted(number,_frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,interrupted)
def guard():
 packet=json.loads((BASE/'packet-inputs.json').read_text());prerequisites=json.loads((BASE/'prerequisite-inputs.json').read_text());values={str(BASE/name):digest for name,digest in packet.items()};values.update(prerequisites)
 assert all(sha(path)==digest for path,digest in values.items()),'Frozen source/SDK/header/Root input changed'
 return {path:sha(path)for path in sorted(values)}
def group(pid):
 records=[]
 for path in Path('/proc').iterdir():
  if not path.name.isdigit():continue
  try:
   data=(path/'stat').read_text();fields=data[data.rfind(')')+2:].split()
   if int(fields[2])==pid:records.append({'pid':int(path.name),'startTicks':fields[19],'state':fields[0]})
  except(OSError,ValueError,IndexError):pass
 return records
def cleanup(pid):
 if not any(row['state']!='Z'for row in group(pid)):return
 try:os.killpg(pid,signal.SIGTERM)
 except ProcessLookupError:return
 end=time.monotonic()+3
 while time.monotonic()<end and any(row['state']!='Z'for row in group(pid)):time.sleep(.02)
 if any(row['state']!='Z'for row in group(pid)):
  try:os.killpg(pid,signal.SIGKILL)
  except ProcessLookupError:pass

def run(out,label,command,cap,env,cwd=CANDIDATE):
 row={'label':label,'command':command,'capSeconds':cap};child=None;began=time.monotonic()
 try:
  with(out/(label+'.stdout.log')).open('xb')as stdout,(out/(label+'.stderr.log')).open('xb')as stderr:
   child=subprocess.Popen(command,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True);row['pid']=child.pid;row['ownedInitial']=group(child.pid)
   try:child.wait(timeout=cap)
   except BaseException:cleanup(child.pid);child.wait();raise
  row['exit']=child.returncode;row['ownedBeforeCleanup']=group(child.pid)
  if any(value['state']!='Z'for value in row['ownedBeforeCleanup']):cleanup(child.pid);raise RuntimeError('Unexpected live owned remainder')
 except BaseException as error:row['failure']={'type':type(error).__name__,'message':str(error)}
 finally:
  if child is not None and child.poll()is None:cleanup(child.pid);child.wait()
  row.update(elapsedSeconds=time.monotonic()-began,exit=child.returncode if child else None,ownedAfter=[]if child is None else group(child.pid));(out/(label+'.status.json')).write_text(json.dumps(row,indent=2)+'\n')
 return row

def environment():
 env=dict(os.environ,NODE_USE_ENV_PROXY='1');old=','.join(filter(None,[env.get('NO_PROXY',''),env.get('no_proxy','')]));aliases='0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]';env.update({key:','.join(filter(None,[old,aliases]))for key in ['NO_PROXY','no_proxy']});return env
