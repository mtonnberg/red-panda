from pathlib import Path
import argparse,json,time
from common import BASE,CANDIDATE,sha,guard,run,environment
p=argparse.ArgumentParser();p.add_argument('--epoch',required=True);a=p.parse_args();out=BASE/'build-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False);before=guard();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');spec=json.loads((BASE/'sdks.json').read_text());rows=[];failure=None;began=time.monotonic()
try:
 for sdk in spec['SDKs']:
  version=sdk['version'];output=CANDIDATE/('native/build/combined-'+a.epoch+'/linux-x64/node-'+version+'/runtime.node');assert not output.exists()and not Path(str(output)+'.json').exists(),'Fresh combined output required'
  env=environment();env['CXX']=spec['compiler'];command=[sdk['node'],str(CANDIDATE/'native/build-runtime.mjs'),'--headers',sdk['headers'],'--output',str(output)];row=run(out,'compile-'+version,command,60,env);row['node']=version;row['output']=str(output);rows.append(row)
  if row.get('failure')or row['exit']!=0:raise RuntimeError('First actual combined build failed; later SDKs UNRUN: '+version)
  manifest=json.loads(Path(str(output)+'.json').read_text());assert manifest['sourceSHA256']==sha(CANDIDATE/'native/runtime.cc')and manifest['binarySHA256']==sha(output)and manifest['node']=='v'+version and manifest['headers']==sdk['headers'];row['manifest']=manifest;row['manifestSHA256']=sha(Path(str(output)+'.json'))
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)}
finally:
 try:after=guard();changed=[path for path in before if before[path]!=after.get(path)]
 except BaseException as error:after={};changed=['FROZEN_GUARD_FAILURE'];failure=failure or{'type':type(error).__name__,'message':str(error)}
 (out/'after.json').write_text(json.dumps(after,indent=2)+'\n');report={'status':'BUILT_COMBINED_ALL3_PROOFS_UNRUN'if failure is None and len(rows)==3 and not changed else'STOPPED_FUTURE_SDKS_UNRUN','failure':failure,'rows':rows,'sourceSHA256':sha(CANDIDATE/'native/runtime.cc'),'inputs':len(before),'unchanged':before==after,'changed':changed,'Root18Unchanged':all(sha(path)==digest for path,digest in json.loads((BASE/'protected-root-native.json').read_text())['files'].items()),'elapsedSeconds':time.monotonic()-began,'componentCapSeconds':60,'networkOrInstall':False,'proofsRun':False,'oldRuntimeReuse':False};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if report['status']!='BUILT_COMBINED_ALL3_PROOFS_UNRUN':raise SystemExit(1)
