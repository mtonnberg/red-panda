import http from 'node:http';import {once} from 'node:events';import {readFile,writeFile} from 'node:fs/promises';import assert from 'node:assert/strict';import {programs} from './causal-minimal-programs.mjs';
import {startReference} from '../registration455-adapted-plan-20261031/harness/scripts/reference-server.mjs';import {connect} from '../registration455-adapted-plan-20261031/harness/test/cdp-client.js';
const output=process.argv[2];if(!output)throw Error('New owned output directory required');
const frozen=JSON.parse(await readFile(new URL('./checkpoint5-minimal-r1-contraries/minimal-r1-gate/Native.json',import.meta.url),'utf8'));
const expected=new Map(frozen.rows.map(row=>[row.name,row.value]));const reports=[],requests=[];let server,browser,client;
try{
 server=http.createServer((request,response)=>{requests.push({url:request.url,at:Date.now()});response.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});response.end('<!doctype html><title>Owned causal document</title><body>independent control</body>')});server.listen(0,'127.0.0.1');await once(server,'listening');const origin='http://127.0.0.1:'+server.address().port;
 for(const engine of ['NativeSameOrigin','candidateMinimalR2']){
  const report={engine,origin,sharedRealFixtureOrigin:true,rootBaseline:'97bb0acacb53e621842fc5d35b296de5f0ffd271',rows:[],wire:[],APIReplyMilliseconds:5000,scriptParameterMilliseconds:1000,actualLoadBarrierMilliseconds:2000,publicUAOverrides:false,NativeOtherProfiles:'Immutable checkpoint5 R1 Native4; no repeated profiles'};reports.push(report);
  const binary=engine==='NativeSameOrigin'?'/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux':'/workspace/shared/census-dom-lifecycle-recovery/candidate-minimal-r2/red-panda-launcher';
  try{
   for(const[name,program]of Object.entries(programs)){
    if(engine==='NativeSameOrigin'&&name!=='baseGetterEdges')continue;
    let browserContextId,session;const row={name};report.rows.push(row);
    try{
     browser=await startReference(binary,{args:['--ws-max-concurrent','50','--load-resources','iframe','--load-resources','worker']});row.pid=browser.process.pid;client=await connect(browser.endpoint,{timeout:5000});
     const send=async(method,params={},sid=session)=>{const request={method,params,sessionId:sid};report.wire.push(request);try{const value=await client.send(method,params,sid,{timeout:5000});request.result=value;return value}catch(error){request.error={message:error.message,code:error.code};throw error}};
     browserContextId=(await send('Target.createBrowserContext')).browserContextId;const target=await send('Target.createTarget',{url:'about:blank',browserContextId});session=(await send('Target.attachToTarget',{targetId:target.targetId,flatten:true})).sessionId;await send('Page.enable');await send('Runtime.enable');await send('Page.setLifecycleEventsEnabled',{enabled:true});
     const offset=client.events.length,started=Date.now(),navigation=await send('Page.navigate',{url:origin+'/'+name});
     while(Date.now()-started<2000){const load=client.events.slice(offset).find(event=>event.sessionId===session&&event.method==='Page.lifecycleEvent'&&event.params.name==='load'&&event.params.frameId===navigation.frameId);if(load){const state=await send('Runtime.evaluate',{expression:'JSON.stringify({ready:document.readyState,url:document.URL,UA:navigator.userAgent})',returnByValue:true,timeout:1000});if(state.exceptionDetails)throw Error('Document barrier evaluation exception');const value=JSON.parse(state.result.value);if(value.ready==='complete'&&value.url===origin+'/'+name&&Date.now()-started<2000){row.barrier={event:load.params,document:value,elapsedMilliseconds:Date.now()-started};break}}await new Promise(resolve=>setTimeout(resolve,5))}if(!row.barrier)throw Error('Original 2000ms actual load+complete barrier');
     const result=await send('Runtime.evaluate',{expression:'('+program.toString()+')('+JSON.stringify(origin)+').then(value=>JSON.stringify(value))',awaitPromise:true,returnByValue:true,timeout:1000});if(result.exceptionDetails){row.exceptionDetails=result.exceptionDetails;throw Error('Actual causal program exception: '+name)}row.value=JSON.parse(result.result.value);row.events=client.events.slice(offset);
     if(engine==='NativeSameOrigin')expected.set(name,row.value);else{assert.deepStrictEqual(row.value,expected.get(name));row.exactNativeProjection=true}
     console.log(JSON.stringify({engine,name,pid:row.pid,observed:true,exactNativeProjection:row.exactNativeProjection}));
    }finally{
     if(browserContextId&&client)try{await client.send('Target.disposeBrowserContext',{browserContextId},undefined,{timeout:5000})}catch(error){row.cleanupError={message:error.message,code:error.code}}await client?.close();client=null;await browser?.close();if(browser){row.exit=browser.process.exitCode;row.signal=browser.process.signalCode;row.stderr=browser.stderr}browser=null;
    }
   }
  }catch(error){report.failure={name:error.name,message:error.message,stack:error.stack};throw error}finally{await writeFile(output+'/'+engine+'.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'})}
 }
}catch(error){process.exitCode=1;console.error(error.stack??error)}finally{await client?.close();await browser?.close();if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}await writeFile(output+'/server.json',JSON.stringify({requests,origin:reports[0]?.origin,closed:!server?.listening},null,2)+'\n',{flag:'wx'})}
