"""Unrun owned Native/current causal profile. Explicit exclusive lease required."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent;O=R/'minimal-r2-gate';assert not O.exists();O.mkdir();P=Path('/workspace/red-panda');A=Path('/workspace/shared/registration455-adapted-plan-20261031');started=time.monotonic();N='/workspace/shared/rea-tools/node_modules/.bin/node'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(root):
 values={str(p.relative_to(root)):sha(p)for d in['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()};values.update({n:sha(root/n)for n in['package.json','package-lock.json']});return values
def new(name,v):
 with(O/name).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
before=identity(P);candidateBefore=identity(R/'candidate-minimal-r2');assert candidateBefore==json.loads((R/'candidate-minimal-r2-manifest.json').read_text())['files'];contracts={str(p):sha(p)for p in[R/'causal-minimal-programs.mjs',R/'run-minimal-r2-pair.mjs',R/'run-minimal-r2-gate.py',R/'checkpoint5-minimal-r1-contraries/minimal-r1-gate/Native.json']};new('before.json',{'externalRoot':before,'frozenCandidate':candidateBefore,'controlSources':contracts})
env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';env['PATH']=str(Path(N).parent)+':'+env.get('PATH','');proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy;commands=[];failure=None
def run(label,args):
 begin=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  p=subprocess.Popen([N,*args],cwd=R,env=env,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'started':label,'pid':p.pid}),flush=True);expired=False
  try:code=p.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;os.killpg(p.pid,signal.SIGKILL);p.wait();code=p.returncode
 row={'label':label,'pid':p.pid,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin};commands.append(row);print(json.dumps(row),flush=True)
 if expired or code:raise RuntimeError('Owned causal command failed: '+label)
try:
 for file in['causal-minimal-programs.mjs','run-minimal-r2-pair.mjs',*[str(Path('candidate-minimal-r2')/name)for name in ['src/browser.js','src/html-reflections.js','src/dom-wrapper-realms.js','src/errors.js','src/html-base-urls.js','src/html-handler-slots.js','test/details-name.test.js','test/lifecycle-minimal.test.js']]]:run('syntax-'+file.replace('/','_'),['--check',str(R/file)])
 run('Native1-candidate5-same-origin',[str(R/'run-minimal-r2-pair.mjs'),str(O)])
 for engine,count in [('NativeSameOrigin',1),('candidateMinimalR2',5)]:
  report=json.loads((O/(engine+'.json')).read_text());assert report.get('failure')is None and len(report['rows'])==count
  for row in report['rows']:assert row.get('value')is not None and row.get('barrier')and row.get('cleanupError')is None and row.get('exit')==0 and row.get('signal')is None,row
 run('focused13',['--experimental-vm-modules','--test',str(R/'candidate-minimal-r2/test/details-name.test.js'),str(R/'candidate-minimal-r2/test/lifecycle-minimal.test.js')]);text=(O/'focused13.stdout').read_text();assert '# pass 13' in text and '# fail 0' in text,text
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 guards={'externalRootUnchanged':before==identity(P),'frozenCandidateUnchanged':candidateBefore==identity(R/'candidate-minimal-r2'),'controlSourcesUnchanged':all(sha(Path(p))==s for p,s in contracts.items())};new('after-guards.json',guards)
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 new('status.json',{'complete':failure is None,'commands':commands,'failure':failure,'seconds':time.monotonic()-started,'API5s':True,'scriptParameter1s':True,'actualLoadComplete2s':True,'administrative90s':True,'separateFromOriginalFixtures':True,'focusExpected':13,'newNativeProfiles':1,'candidateProfiles':5,'immutableNativeProfilesReused':4,'rawURLResultsNormalized':False,'realSharedOrigin':True,'priorOriginalSourceFixturesNotReplayed':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
