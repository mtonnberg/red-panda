"""Prepared remaining SDK26cases + Source6; explicit runtime lease required."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent;O=R/'minimal-r2-sdk-source';assert not O.exists();O.mkdir();P=Path('/workspace/red-panda');A=Path('/workspace/shared/registration455-adapted-plan-20261031');C=R/'candidate-minimal-r2';started=time.monotonic();N='/workspace/shared/rea-tools/node_modules/.bin/node';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(root):
 values={str(p.relative_to(root)):sha(p)for d in['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()};values.update({n:sha(root/n)for n in['package.json','package-lock.json']});return values
before=identity(P);candidateBefore=identity(C);assert candidateBefore==json.loads((R/'candidate-minimal-r2-manifest.json').read_text())['files'];fixtures=[v for v in json.loads((R/'observed-facts.json').read_text())['observations']if v['row']in[134,137,140]];assert len(fixtures)==3
contracts={str(p):sha(p)for p in(A/'harness').rglob('*')if p.is_file()and not p.is_symlink()and'node_modules'not in p.parts};contracts.update({str(p):sha(p)for p in[R/'run-r2-sdk-source.py',A/'fixtures/adapted/testing.js',A/'maps/registration-map.json',C/'red-panda-launcher',R/'candidate-minimal-r2-manifest.json']})
for row in fixtures:
 p=A/'fixtures/adapted'/row['path'];assert sha(p)==row['fixtureSHA256'];contracts[str(p)]=sha(p)
binary=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');assert sha(binary)=='9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f';contracts[str(binary)]=sha(binary)
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
write('before.json',{'externalRoot':before,'frozenCandidate':candidateBefore,'controlSources':contracts,'RootBaseReadOnlyHEAD':'ba3a2394bb7403d1f568a398e1f256a39e7e96d1','candidateActually97bbPlusR2':True})
env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy;commands=[];failure=None

def run(label,node,args,cwd=C):
 begin=time.monotonic();local=env.copy();local['PATH']=str(Path(node).parent)+':'+env.get('PATH','')
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  p=subprocess.Popen([node,*args],cwd=cwd,env=local,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'started':label,'pid':p.pid}),flush=True);expired=False
  try:code=p.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;os.killpg(p.pid,signal.SIGKILL);p.wait();code=p.returncode
 row={'label':label,'pid':p.pid,'command':[node,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin};commands.append(row);print(json.dumps(row),flush=True)
 if expired or code:raise RuntimeError('Actual command failure: '+label)
 return row
try:
 for label,node in [('24.19','/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'),('26.13','/workspace/shared/node26/node_modules/node/bin/node')]:
  run('SDK13-'+label,node,['--experimental-vm-modules','--test-reporter=tap','--test',str(C/'test/details-name.test.js'),str(C/'test/lifecycle-minimal.test.js')]);text=(O/('SDK13-'+label+'.stdout')).read_text();counts={k:int(v)for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};assert counts=={'tests':13,'suites':0,'pass':13,'fail':0,'cancelled':0,'skipped':0,'todo':0},counts
 for engine,executable in [('Native',binary),('candidateR2',C/'red-panda-launcher')]:
  for row in fixtures:
   label=engine+'-'+str(row['row']);report=O/(label+'.json');args=[str(A/'harness/scripts/conformance.mjs'),'--root',str(A/'fixtures/adapted'),'--binary',str(executable),'--isolate','--fixture-profile','upstream','--source-load-contract','--websocket-port','0','--registration-map',str(A/'maps/registration-map.json'),'--runner-global-arg=--ws-max-concurrent','--runner-global-arg=50','--port','0','--test',row['path'],'--report',str(report)];run(label,N,args)
   actual=json.loads(report.read_text());assert len(actual['results'])==1;result=actual['results'][0];assert result['status']=='passed' and result['sha256']==row['fixtureSHA256'] and result['harnessObserved']and result['nativeHarnessBranch']and result['nonzeroObservationsEnforced'],result;assert result['sourceLoadContract']['loadBarrier']['observed']and result['sourceLoadContract']['assertionStartedAfterLoad'];assert result['ownedBrowser']['exitCode']==0 and result['ownedBrowser']['signal']is None;assert result['observedUserAgent'].startswith('Lightpanda/'if engine=='Native'else'RedPanda/');assert not actual['publicUserAgentOverrideApplied']and not actual['publicClientHintsOverrideApplied']and actual['fixtureAssertionSourcesUnchanged']
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 guards={'externalRootUnchanged':before==identity(P),'frozenCandidateUnchanged':candidateBefore==identity(C),'controlSourcesUnchanged':all(sha(Path(p))==s for p,s in contracts.items())};write('after-guards.json',guards)
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 write('status.json',{'complete':failure is None,'commands':commands,'failure':failure,'seconds':time.monotonic()-started,'administrative90s':True,'SDK13Each':[24.19,26.13],'SourceFixtures3Each':['Native','candidateR2'],'SourceLoad2sFreshAssert2or8sOriginalRegistration':True,'assertionsUnchanged':True,'actualUAAndDisclosed455EligibilityAdapter':True,'RootIntegrationUnrun':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
