from pathlib import Path
import subprocess,json,os,time,hashlib,signal,re
r=Path('/workspace/red-panda');o=Path(__file__).resolve().parent;files=json.loads((o/'tests.json').read_text());files+=['test/input.test.js']if'test/input.test.js'not in files else[];before=json.loads((o/'code-before.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();assert all(sha(r/n)==h for n,h in before.items());env=dict(os.environ,NODE_USE_ENV_PROXY='1');bypass=','.join(filter(None,[env.get('NO_PROXY'),env.get('no_proxy'),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']));env.update(NO_PROXY=bypass,no_proxy=bypass);cmd=['/workspace/shared/rea-tools/node_modules/node/bin/node','--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*files];start=time.monotonic();child=None;failure=None;counts=None
assert not(o/'status.json').exists(),'Immutable Root epoch already exists'
def interrupted(number,frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,interrupted)
try:
 with(o/'selected.stdout').open('xb')as stdout,(o/'selected.stderr').open('xb')as stderr:
  child=subprocess.Popen(cmd,cwd=r,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try:child.wait(timeout=120)
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 counts={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled) (\d+)$',(o/'selected.stdout').read_text(),re.M)}
 if child.returncode or not counts.get('tests')or counts.get('pass')!=counts['tests']or any(counts.get(k)!=0 for k in['fail','skipped','cancelled']):raise RuntimeError('Actual test exit/count failure')
except BaseException as e:failure={'type':type(e).__name__,'message':str(e)}
after={n:sha(r/n)for n in before};(o/'code-after.json').write_text(json.dumps(after,indent=2)+'\n');report={'command':cmd,'pid':child.pid if child else None,'exit':child.returncode if child else None,'counts':counts,'failure':failure,'sourceInputs':len(before),'unchanged':before==after,'seconds':time.monotonic()-start,'administrativeCap':120,'originalTestAndVMRecoveryBudgetsUnchanged':True,'actualComposition':'0532Pointer+8lifeR2leaves','lastFullSuite':'2043JS129PS13Native at97bb; not rerun'};(o/'status.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(0 if failure is None and before==after else 1)
