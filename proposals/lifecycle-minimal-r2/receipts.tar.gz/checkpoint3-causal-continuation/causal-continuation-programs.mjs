// New epoch: completed Native details is not repeated. Original profiles stay immutable.
import {programs as original} from './causal-programs.mjs';
export const programs={...original,
 base: async function () {
  const rows=[],fallback=document.URL;
  for(const text of ['data:/,more-test','javascript:/,more-test','DATA:/,more-test','JavaScript:/,more-test',' data:/,more-test','java\tscript:/,more-test','http://[broken','https://www.example.com/allowed/']){
   const b=document.createElement('base');b.href=text;document.head.prepend(b);
   try{const a=document.createElement('a');a.href='blah';const observation={text,base:document.baseURI};try{observation.reflected=b.href}catch(error){observation.reflectedError={name:error.name,text:String(error),selectedTypeError:error instanceof TypeError}}observation.link=a.href;rows.push(observation)}finally{b.remove()}
  }
  const host=document.createElement('div');document.body.append(host);const root=host.attachShadow({mode:'open'}),b=document.createElement('base');b.href='https://www.example.com/shadow/';root.append(b);const independentShadow=document.baseURI;host.remove();
  const first=document.createElement('base'),second=document.createElement('base');first.href='data:/,bad';second.href='https://www.example.com/second/';document.head.prepend(first,second);const prohibitedBeforeAllowed=document.baseURI;first.remove();const allowedAfterRemoval=document.baseURI;second.remove();
  return {fallback,rows,independentShadow,prohibitedBeforeAllowed,allowedAfterRemoval,restored:document.baseURI};
 },
};
