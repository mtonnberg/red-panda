// Tiny creation-only control; no heap enumeration, GC or production edits.
import vm from 'node:vm';import {JSDOM} from '/workspace/red-panda/node_modules/jsdom/lib/api.js';import {writeFile} from 'node:fs/promises';
import {getHeapBinding} from './baseline-97bb/src/native-heap.js';
const output=process.argv[2];if(!output)throw Error('New output path required');const dom=new JSDOM('',{runScripts:'outside-only'}),context=dom.getInternalVMContext(),binding=getHeapBinding(),anchor=vm.runInContext('[]',context),Function=vm.runInContext('Function',context),evaluate=vm.runInContext('eval',context),rows=[];
const body='this is not valid js(',cases={
 capturedFunction:()=>Reflect.construct(Function,[body]),
 capturedEval:()=>Reflect.apply(evaluate,undefined,['(function onclick(event){'+body+'})\n//# sourceURL=anonymous']),
 compileFunction:()=>vm.compileFunction(body,[],{parsingContext:context,filename:'anonymous'}),
 runInContext:()=>vm.runInContext('(function onclick(event){'+body+'})',context,{filename:'anonymous'}),
};
try{
 for(const phase of ['original','authoredPrepareStackTrace']){
  if(phase!=='original')vm.runInContext('Error.prepareStackTrace=()=>"authored-stack"',context);
  for(const[name,operation]of Object.entries(cases)){let error;try{operation()}catch(value){error=value}if(!error)throw Error('Actual invalid code did not throw');const row={phase,name,errorName:error.name,message:error.message,ownKeys:Reflect.ownKeys(error).map(String),stack:error.stack,before:{VM:binding.sameRealm(error,anchor),Host:binding.sameRealm(error,[])}};const prototype=Object.getPrototypeOf(error);try{Object.setPrototypeOf(error,null);row.after={VM:binding.sameRealm(error,anchor),Host:binding.sameRealm(error,[])}}finally{Object.setPrototypeOf(error,prototype)}rows.push(row)}
 }
 await writeFile(output,JSON.stringify({node:process.version,rows},null,2)+'\n',{flag:'wx'});
}finally{dom.window.close()}
