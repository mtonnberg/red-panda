// Independent owned-origin observations; no original fixture/assertion is edited.
export const programs = {
 details: async function () {
  const d=document.createElement('details'),descriptor=Object.getOwnPropertyDescriptor(HTMLDetailsElement.prototype,'name'),trace=[];
  document.body.append(d);const scalar=value=>typeof value==='bigint'||typeof value==='symbol'?{kind:typeof value,text:String(value)}:{kind:typeof value,value};const snap=label=>({label,value:scalar(d.name),attribute:d.getAttribute('name'),own:Object.hasOwn(d,'name')});
  trace.push(snap('missing'));d.name='group1';trace.push(snap('property'));d.setAttribute('name','attribute');trace.push(snap('attribute'));d.removeAttribute('name');trace.push(snap('removed'));
  const conversions=[];for(const value of [null,undefined,42,true,7n,Symbol('symbol-name'),'lone\ud800end']){try{d.name=value;conversions.push({kind:typeof value,value:scalar(d.name),attribute:d.getAttribute('name')})}catch(error){conversions.push({kind:typeof value,error:error.name,message:error.message,realm:error instanceof TypeError})}}
  const order=[];if(descriptor){descriptor.set.call(d,{[Symbol.toPrimitive](hint){order.push(hint);return 'converted'}});try{descriptor.set.call({}, {[Symbol.toPrimitive](){order.push('invalid-receiver-coercion');return 'bad'}})}catch(error){order.push(error.name,error instanceof TypeError)}}
  d.remove();return {trace,conversions,descriptor:descriptor?{enumerable:descriptor.enumerable,configurable:descriptor.configurable,getName:descriptor.get.name,setName:descriptor.set.name,getLength:descriptor.get.length,setLength:descriptor.set.length,getRealm:Object.getPrototypeOf(descriptor.get)===Function.prototype,setRealm:Object.getPrototypeOf(descriptor.set)===Function.prototype}:null,order};
 },
 base: async function () {
  const rows=[],fallback=document.URL;
  for(const text of ['data:/,more-test','javascript:/,more-test','DATA:/,more-test','JavaScript:/,more-test',' data:/,more-test','java\tscript:/,more-test','http://[broken','https://www.example.com/allowed/']){
   const b=document.createElement('base');b.href=text;document.head.prepend(b);
   try{const a=document.createElement('a');a.href='blah';rows.push({text,base:document.baseURI,reflected:b.href,link:a.href})}finally{b.remove()}
  }
  const host=document.createElement('div');document.body.append(host);const root=host.attachShadow({mode:'open'}),b=document.createElement('base');b.href='https://www.example.com/shadow/';root.append(b);const independentShadow=document.baseURI;host.remove();
  const first=document.createElement('base'),second=document.createElement('base');first.href='data:/,bad';second.href='https://www.example.com/second/';document.head.prepend(first,second);const prohibitedBeforeAllowed=document.baseURI;first.remove();const allowedAfterRemoval=document.baseURI;second.remove();
  return {fallback,rows,independentShadow,prohibitedBeforeAllowed,allowedAfterRemoval,restored:document.baseURI};
 },
 handlers: async function () {
  const types=['pointerdown','pointerup','pointermove','pointerover','pointerout','pointerenter','pointerleave','pointercancel','animationstart','animationend','animationiteration','animationcancel','transitionrun','transitionstart','transitionend','transitioncancel'];
  const div=document.createElement('div');document.body.append(div);const defaults=types.map(type=>({type,present:('on'+type)in div,value:div['on'+type]===null?'null':typeof div['on'+type]}));
  const r=[];div.addEventListener('click',()=>r.push(1));const a=()=>r.push(2);div.onclick=a;div.addEventListener('click',()=>r.push(3));div.click();const first=r.splice(0);div.onclick=()=>r.push('replace');div.click();const replace=r.splice(0);div.onclick=null;div.click();const cleared=r.splice(0);div.onclick=()=>r.push('append');div.click();const readded=r.splice(0);
  div.onclick=5;const primitiveClears=div.onclick===null;let objectState;try{div.onclick={};objectState={value:div.onclick===null?'null':typeof div.onclick}}catch(error){objectState={error:error.name,message:error.message,realm:error instanceof TypeError}}
  const attr=document.createElement('div');document.body.append(attr);globalThis.ownedHandlerOrder=[];attr.setAttribute('onclick',"ownedHandlerOrder.push('attribute')");attr.addEventListener('click',()=>ownedHandlerOrder.push('listener'));attr.click();const attrFirst=ownedHandlerOrder.splice(0);attr.removeAttribute('onclick');attr.setAttribute('onclick',"ownedHandlerOrder.push('again')");attr.click();const attrAgain=ownedHandlerOrder.splice(0);
  const errors=[];const observe=event=>{errors.push({type:event.type,trusted:event.isTrusted,name:event.error?.name,message:event.message,selected:event.error instanceof SyntaxError,filename:event.filename,lineno:event.lineno});event.preventDefault()};window.addEventListener('error',observe);const bad=document.createElement('div');bad.setAttribute('onclick','this is not valid js(');const badHandler=bad.onclick;const repeated=bad.onclick;window.removeEventListener('error',observe);
  div.remove();attr.remove();return {defaults,first,replace,cleared,readded,primitiveClears,objectState,attrFirst,attrAgain,badHandler:badHandler===null?'null':typeof badHandler,repeated:repeated===null?'null':typeof repeated,errors};
 },
 close: async function () {
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const frame=async()=>{const f=document.createElement('iframe'),loaded=new Promise(resolve=>f.addEventListener('load',resolve,{once:true}));document.body.append(f);await loaded;return f};
  const f=await frame(),w=f.contentWindow,d=w.document,events=[];d.open();d.addEventListener('readystatechange',()=>events.push('rsc:'+d.readyState));d.addEventListener('DOMContentLoaded',()=>events.push('DCL'));d.addEventListener('load',()=>events.push('document-load'));w.addEventListener('load',()=>events.push('window-load'));d.write('<p>owned</p>');events.push('before:'+d.readyState);d.close();events.push('after:'+d.readyState);const immediate=events.slice();await wait(20);const eventual=events.slice();f.remove();
  const g=await frame(),gw=g.contentWindow,nested=[];let count=0;const rewrite=()=>{const doc=gw.document;doc.open();doc.addEventListener('readystatechange',()=>nested.push('rsc:'+doc.readyState));doc.addEventListener('DOMContentLoaded',()=>nested.push('DCL'));doc.addEventListener('load',()=>nested.push('document-load'));gw.addEventListener('load',onload);doc.write('<p>'+count+'</p>');doc.close()};const onload=()=>{nested.push('window-load');count++;if(count<3)rewrite()};rewrite();const nestedImmediate={count,events:nested.slice(),state:gw.document.readyState};await wait(30);const nestedEventual={count,events:nested.slice(),state:gw.document.readyState};g.remove();
  const h=document.createElement('iframe'),iframeEvents=[];let elementLoads=0,windowLoads=0,dcls=0;const done=new Promise(resolve=>h.addEventListener('load',()=>{elementLoads++;if(elementLoads>1)return;const doc=h.contentDocument;doc.open();doc.addEventListener('DOMContentLoaded',()=>dcls++);h.contentWindow.addEventListener('load',()=>windowLoads++);doc.write('<p>muted</p>');doc.close();iframeEvents.push({afterClose:doc.readyState,windowEvent:h.contentWindow.event?.type??null,parentEvent:window.event?.type??null});setTimeout(resolve,30)}));document.body.append(h);await done;const iframe={elementLoads,windowLoads,dcls,events:iframeEvents,text:h.contentDocument.body.textContent};h.remove();
  return {immediate,eventual,nestedImmediate,nestedEventual,iframe};
 },
};
