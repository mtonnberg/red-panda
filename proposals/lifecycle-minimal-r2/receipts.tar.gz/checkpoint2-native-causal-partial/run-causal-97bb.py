"""Unrun owned Native/current causal profile. Explicit exclusive lease required."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent;O=R/'causal-baseline-97bb';assert not O.exists();O.mkdir();P=Path('/workspace/red-panda');A=Path('/workspace/shared/registration455-adapted-plan-20261031');started=time.monotonic();N='/workspace/shared/rea-tools/node_modules/.bin/node'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(root):
 values={str(p.relative_to(root)):sha(p)for d in['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()};values.update({n:sha(root/n)for n in['package.json','package-lock.json']});return values
def new(name,v):
 with(O/name).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
before=identity(P);candidateBefore=identity(R/'baseline-97bb');assert candidateBefore==json.loads((R/'baseline-97bb-manifest.json').read_text())['files'];contracts={str(p):sha(p)for p in[R/'causal-programs.mjs',R/'run-causal-97bb-driver.mjs',R/'run-causal-97bb.py']};new('before.json',{'externalRoot':before,'frozenCandidate':candidateBefore,'controlSources':contracts})
env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';env['PATH']=str(Path(N).parent)+':'+env.get('PATH','');proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy;commands=[];failure=None
def run(label,args):
 begin=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  p=subprocess.Popen([N,*args],cwd=R,env=env,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'started':label,'pid':p.pid}),flush=True);expired=False
  try:code=p.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;os.killpg(p.pid,signal.SIGKILL);p.wait();code=p.returncode
 row={'label':label,'pid':p.pid,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin};commands.append(row);print(json.dumps(row),flush=True)
 if expired or code:raise RuntimeError('Owned causal command failed: '+label)
try:
 for file in['causal-programs.mjs','run-causal-97bb-driver.mjs']:run('syntax-'+file,['--check',str(R/file)])
 for engine in['Native','baseline97bb']:
  output=O/(engine+'.json');run(engine,[str(R/'run-causal-97bb-driver.mjs'),engine,str(output)]);report=json.loads(output.read_text());assert report.get('failure')is None and len(report['rows'])==4
  for row in report['rows']:assert row.get('value')is not None and row.get('barrier')and row.get('cleanupError')is None and row.get('exit')==0 and row.get('signal')is None,row
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 guards={'externalRootUnchanged':before==identity(P),'frozenCandidateUnchanged':candidateBefore==identity(R/'baseline-97bb'),'controlSourcesUnchanged':all(sha(Path(p))==s for p,s in contracts.items())};new('after-guards.json',guards)
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 new('status.json',{'complete':failure is None,'commands':commands,'failure':failure,'seconds':time.monotonic()-started,'API5s':True,'scriptParameter1s':True,'actualLoadComplete2s':True,'administrative90s':True,'separateFromOriginalFixtures':True,'implementationAndDetailsTestsUnrun':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
