import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { JSDOM } from 'jsdom';
import { installWorkers } from '../src/workers.js';

const tick = () => new Promise(resolve => setImmediate(resolve));
const deadline = (promise, milliseconds = 8000) => new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error('Worker fixture timed out')), milliseconds);
  Promise.resolve(promise).then(value => { clearTimeout(timer); resolve(value); }, error => { clearTimeout(timer); reject(error); });
});
function fixture(t, sources = {}) {
  const page = new EventEmitter(); page.documentAbort = new AbortController();
  const errors = [], requests = [];
  page.on('pageError', error => errors.push(error));
  page.referrerFor = (url, source) => source;
  page.fetch = async (url, init, type) => {
    requests.push({ url, init, type });
    let entry = sources[url]; if (typeof entry === 'function') entry = await entry(init);
    if (init.signal.aborted) throw new DOMException('Aborted', 'AbortError');
    if (typeof entry === 'string') entry = { source: entry };
    const response = new Response(entry?.source ?? '', { status: entry?.status ?? (entry ? 200 : 404),
      headers: { 'content-type': entry?.mime ?? 'text/javascript', ...(entry?.headers ?? {}) } });
    Object.defineProperty(response, 'url', { value: entry?.url ?? url }); return response;
  };
  const dom = new JSDOM('<body></body>', { url: 'https://example.test/app/page.html', runScripts: 'outside-only' });
  const workers = installWorkers(page, dom.window);
  t.after(() => { page.closed = true; page.documentAbort.abort(); workers.dispose(); dom.window.close(); });
  return { page, window: dom.window, workers, errors, requests };
}
function message(worker) { return deadline(new Promise((resolve, reject) => {
  worker.addEventListener('message', event => resolve(event.data), { once: true });
  worker.addEventListener('error', event => reject(event.error ?? new Error(event.message)), { once: true });
})); }
function portMessage(port) { return deadline(new Promise(resolve => {
  port.addEventListener('message', resolve, { once: true }); port.start();
})); }

test('worker callback errors remain local and recover after a canceled error event', async t => {
  const f = fixture(t, { 'https://example.test/app/error.js': `addEventListener('error', event => {
    const before = event.defaultPrevented; event.preventDefault();
    postMessage({ kind: 'local-error', message: event.message, filename: event.filename,
      lineno: event.lineno, colno: event.colno, errorName: event.error.name,
      errorMessage: event.error.message, errorRealm: event.error instanceof Error,
      trusted: event.isTrusted, cancelable: event.cancelable, before, after: event.defaultPrevented });
  }); onmessage = event => { if (event.data === 'throw') throw new Error('worker boom'); postMessage('recovered'); };` });
  const worker = new f.window.Worker('./error.js'), outerErrors = [];
  worker.addEventListener('error', event => outerErrors.push(event));
  const localError = message(worker); worker.postMessage('throw'); const event = await localError;
  assert.equal(event.kind, 'local-error'); assert.equal(event.message, 'Error: worker boom');
  assert.equal(event.filename, 'https://example.test/app/error.js');
  assert.equal(typeof event.lineno, 'number'); assert.equal(event.lineno > 0, true);
  assert.equal(typeof event.colno, 'number'); assert.equal(event.colno > 0, true);
  assert.equal(event.errorName, 'Error'); assert.equal(event.errorMessage, 'worker boom');
  assert.equal(event.errorRealm, true); assert.equal(event.trusted, true); assert.equal(event.cancelable, true);
  assert.equal(event.before, false); assert.equal(event.after, true);
  const result = message(worker); worker.postMessage('ok'); assert.equal(await result, 'recovered');
  assert.deepEqual(outerErrors, []); assert.deepEqual(f.errors, []); worker.terminate();
});
