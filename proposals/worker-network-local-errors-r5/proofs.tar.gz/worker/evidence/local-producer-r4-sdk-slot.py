from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
p=Path.cwd();sdk,=sys.argv[1:];assert sdk in ['24.19.0','26.13.0']
started=time.monotonic();cap=300;modes=['callbacks16','global15','origin4','fronts2','affected18','regressions91'];counts={'callbacks16':16,'global15':15,'origin4':4,'fronts2':2,'affected18':18,'regressions91':91}
output=p/('evidence/local-producer-r4-sdk-'+sdk+'-status.json');assert not output.exists(),'Immutable queue status already exists'
def digest(q):
 h=hashlib.sha256()
 with q.open('rb')as f:
  for z in iter(lambda:f.read(1048576),b''):h.update(z)
 return h.hexdigest()
manifest=p/'evidence/local-producer-r4-sdk-queue-inputs.json';expected=json.loads(manifest.read_text())
def changed():return[n for n,h in expected.items()if not Path(n).is_file()or digest(Path(n))!=h]
assert not changed(),'Frozen queue inputs changed before execution'
for mode in modes:assert not(p/('evidence/local-producer-r4-'+mode+'-'+sdk+'-status.json')).exists(),'A constituent immutable epoch already exists'
def rootState():
 root=Path('/workspace/red-panda');return{str(q):digest(q)for q in sorted((root/'src').rglob('*'))if q.is_file()}
before=rootState();env=os.environ.copy();union=list(dict.fromkeys([v.strip()for n in ['NO_PROXY','no_proxy']for v in env.get(n,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union)
status={'kind':'Six existing controllers, serial stop-first, no original budgets changed','sdk':sdk,'planned':modes,'actual':[],'expectedNativeModes':35,'expectedTests':111,'expectedTotal':146,'administrativeCap':cap,'individualOriginalCap':120,'cleanupGrace':3,'RPCMilliseconds':2500,'inputs':len(expected),'manifestSHA256':digest(manifest),'newSourceOrRuntimeEdits':False,'rootSourceBefore':before,'canonicalProxyBeforeChildren':True,'proxyTLSPreserved':all(env.get(n)==os.environ.get(n)for n in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR'])}
def checkpoint():status['seconds']=time.monotonic()-started;output.write_text(json.dumps(status,indent=2)+'\n')
def proc(pid):
 try:
  raw=Path('/proc/'+str(pid)+'/stat').read_text();v=raw[raw.rindex(')')+2:].split();return{'pid':pid,'state':v[0],'ppid':int(v[1]),'pgrp':int(v[2]),'startTicks':v[19]}
 except(FileNotFoundError,ProcessLookupError,PermissionError):return None
def observe(child,known):
 for directory in Path('/proc').iterdir():
  if directory.name.isdigit():
   v=proc(int(directory.name))
   if v and(v['pid']==child.pid or v['pgrp']==child.pid or v['ppid']in known):known.setdefault(v['pid'],v)
def live(known):
 values=[]
 for pid,identity in known.items():
  now=proc(pid)
  if now and now['startTicks']==identity['startTicks']and now['state']not in ['Z','X']:values.append(now)
 return values
try:
 for mode in modes:
  phase={'mode':mode,'expectedCases':counts[mode],'command':[sys.executable,'evidence/local-producer-r4-slot.py',mode,sdk],'complete':False,'startedSeconds':time.monotonic()-started};status['actual'].append(phase);checkpoint();known={}
  log=p/('evidence/local-producer-r4-sdk-'+sdk+'-'+mode+'.log');phase['queueLog']=str(log)
  with log.open('xb')as stream:
   child=subprocess.Popen(phase['command'],cwd=p,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);phase['controllerPID']=child.pid
   while child.poll()is None:
    observe(child,known)
    if time.monotonic()-started>=cap:
     phase['administrativeExpiry']=True
     for v in live(known):
      try:os.kill(v['pid'],signal.SIGTERM)
      except ProcessLookupError:pass
     try:child.wait(timeout=3)
     except subprocess.TimeoutExpired:child.kill();child.wait()
     break
    time.sleep(.1)
   phase['exit']=child.returncode
  phase['seconds']=time.monotonic()-started-phase['startedSeconds'];phase['observedOwnedProcesses']=list(known.values());phase['liveBeforeCleanup']=live(known)
  if phase['liveBeforeCleanup']:
   for v in live(known):
    try:os.kill(v['pid'],signal.SIGTERM)
    except ProcessLookupError:pass
   limit=time.monotonic()+3
   while time.monotonic()<limit and live(known):time.sleep(.05)
   for v in live(known):
    try:os.kill(v['pid'],signal.SIGKILL)
    except ProcessLookupError:pass
  phase['liveAfterCleanup']=live(known);receipt=p/('evidence/local-producer-r4-'+mode+'-'+sdk+'-status.json');phase['receipt']=str(receipt)
  if receipt.exists():phase['receiptSHA256']=digest(receipt);actualReceipt=json.loads(receipt.read_text());phase['actualReceiptPassed']=actualReceipt.get('passedObservedPhases');phase['actualReceiptPhases']=actualReceipt.get('phases',[])
  else:actualReceipt={}
  checkpoint()
  if phase['exit']or phase.get('administrativeExpiry')or phase['liveBeforeCleanup']or phase['liveAfterCleanup']or not actualReceipt.get('passedObservedPhases')or actualReceipt.get('changedInputs')or actualReceipt.get('rootChangedSourceFiles')or not all(v['complete']for v in actualReceipt.get('phases',[])):raise RuntimeError('Actual constituent failure/incomplete/resource boundary in '+mode)
  phase['complete']=True;checkpoint();print(json.dumps({'sdk':sdk,'completed':mode,'seconds':phase['seconds'],'observedCases':counts[mode]}),flush=True)
 status['passedObservedQueue']=True
except BaseException as error:status['passedObservedQueue']=False;status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 status['changedInputs']=changed();after=rootState();status['rootChangedSourceFiles']=[n for n in set(before)|set(after)if before.get(n)!=after.get(n)];status['observedNativeModes']=sum(counts[x['mode']]for x in status['actual']if x['complete']and x['mode']in modes[:3]);status['observedTests']=sum(counts[x['mode']]for x in status['actual']if x['complete']and x['mode']in modes[3:]);checkpoint();print(json.dumps({'sdk':sdk,'passedObservedQueue':status['passedObservedQueue'],'failure':status.get('failure'),'nativeModes':status['observedNativeModes'],'tests':status['observedTests'],'changedInputs':status['changedInputs'],'rootChangedSourceFiles':status['rootChangedSourceFiles'],'seconds':status['seconds']}),flush=True)
sys.exit(0 if status['passedObservedQueue']and not status['changedInputs']and not status['rootChangedSourceFiles']else 1)
