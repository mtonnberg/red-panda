from pathlib import Path
import os,sys,json,hashlib,subprocess,time,signal,re
p=Path.cwd();candidate=p/'candidate';sdk=sys.argv[1];nodes={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/bin/node','24.19.0':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','26.13.0':'/workspace/shared/node26/node_modules/node/bin/node'};headers={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/node_modules/node-linux-x64/include/node','24.19.0':'/workspace/shared/node-headers/v24.19.0/node-v24.19.0/include/node','26.13.0':'/workspace/shared/node26/node_modules/node/node_modules/node-linux-x64/include/node'};assert sdk in nodes
manifest=p/'evidence/helper-build-inputs.json';expected=json.loads(manifest.read_text());stem='helper-build-'+sdk;statusPath=p/('evidence/'+stem+'-status.json');assert not statusPath.exists(),'Immutable epoch already exists'
def digest(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert all(digest(n)==h for n,h in expected.items()),'Build/source/header/binary inputs changed'
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for key in['NO_PROXY','no_proxy']for v in env.get(key,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NO_PROXY']=env['no_proxy']=','.join(union);env['NODE_USE_ENV_PROXY']='1';env['RED_PANDA_RUNTIME_ADDON']=str(candidate/('native/build/linux-x64/node-'+sdk+'/runtime.node'));env['RED_PANDA_COLLECTIONS_ADDON']=str(candidate/('native/build/linux-x64/node-'+sdk+'/collections.node'));started=time.monotonic();status={'sdk':sdk,'inputs':len(expected),'administrativeCap':45,'cleanupGrace':3,'manifestSHA256':digest(manifest),'phases':[],'originalCaseCap':15000,'network':False}
def run(name,command):
 log=p/('evidence/'+stem+'-'+name+'.log');row={'name':name,'command':command};status['phases'].append(row)
 with log.open('xb')as out:
  child=subprocess.Popen(command,cwd=candidate,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:row['exit']=child.wait(timeout=max(.1,45-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:
   row['administrativeExpiry']=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   row['exit']=child.returncode
 row['pid']=child.pid;row['presentAfterWait']=Path('/proc/'+str(child.pid)).exists()
 if row['exit']or row.get('administrativeExpiry')or row['presentAfterWait']:raise RuntimeError('Actual build/helper-test/resource boundary: '+name)
 return log
try:
 output=Path(env['RED_PANDA_RUNTIME_ADDON']);assert not output.exists(),'A fresh genuine runtime build is required'
 run('compile',[nodes[sdk],'native/build-runtime.mjs','--headers',headers[sdk]])
 actual=json.loads(Path(str(output)+'.json').read_text());assert actual['sourceSHA256']==digest(candidate/'native/runtime.cc')and actual['binarySHA256']==digest(output)
 status['actualProducedManifest']=actual
 log=run('proof',[nodes[sdk],'--test','--test-reporter=tap','test/worker-error-origin.test.js']);summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$',log.read_text(),re.M)};status['tapSummary']=summary;assert summary=={'tests':5,'pass':5,'fail':0,'cancelled':0,'skipped':0,'todo':0},'Actual helper proof failure/count'
 status['passed']=True
except BaseException as error:status['passed']=False;status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 status['seconds']=time.monotonic()-started;status['changedInputs']=[n for n,h in expected.items()if digest(n)!=h];statusPath.write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
sys.exit(0 if status['passed']and not status['changedInputs']else 1)
