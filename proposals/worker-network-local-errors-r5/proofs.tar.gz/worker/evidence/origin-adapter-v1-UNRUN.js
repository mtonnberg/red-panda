import{getRuntimeBinding}from'./native-runtime.js';
export function workerErrorOrigins(){
 const actualOrigins=new Set();
 return Object.freeze({
  compiled(url){actualOrigins.add(url)},
  read(value){const reader=getRuntimeBinding().errorOrigin;if(typeof reader!=='function')throw new Error('A matching Worker error-origin runtime build is required');const result=reader(value);return result&&actualOrigins.has(result.filename)?result:null},
 });
}
