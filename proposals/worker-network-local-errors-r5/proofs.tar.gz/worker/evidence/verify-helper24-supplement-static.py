from pathlib import Path
import hashlib,json,re,time
p=Path('/workspace/shared/worker-local-errors-r5');e=p/'evidence';H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();old=e/'helper-build-24.22.1-status.json';d=json.loads(old.read_text());assert d['passed']is False and d['failure']=={'type':'TypeError','message':"'dict' object is not callable"};assert not d['changedInputs']and not d['rootChangedSourceFiles'];assert [r['exit']for r in d['phases']]==[0,0]
log=e/'helper-build-24.22.1-proof.log';text=log.read_text();summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$',text,re.M)};assert summary=={'tests':5,'pass':5,'fail':0,'cancelled':0,'skipped':0,'todo':0};assert len(re.findall(r'^ok \d+ - ',text,re.M))==5;assert re.findall(r'^not ok ',text,re.M)==[]
output=p/'candidate/native/build/linux-x64/node-24.22.1/runtime.node';actualManifest=json.loads(Path(str(output)+'.json').read_text());compileLog=json.loads((e/'helper-build-24.22.1-compile.log').read_text());assert compileLog['output']==str(output);assert compileLog['manifest']==actualManifest==d['actualProducedManifest'];assert actualManifest['sourceSHA256']==H(p/'candidate/native/runtime.cc')and actualManifest['binarySHA256']==H(output)
header=Path(actualManifest['headers'])/'node_version.h';version=header.read_text();parts=[re.search(r'^#define NODE_'+name+r'_VERSION (\d+)$',version,re.M).group(1)for name in ['MAJOR','MINOR','PATCH']];assert 'v'+'.'.join(parts)==actualManifest['node']=='v24.22.1';assert re.search(r'^#define NODE_MODULE_VERSION (\d+)$',version,re.M).group(1)==actualManifest['abi']=='137'
inputs=json.loads((e/'helper-build-inputs.json').read_text());changed=[n for n,h in inputs.items()if H(Path(n))!=h];assert not changed
# Source receipt already proves no Root delta during the run. This independent
# read checks the exact observed process birth identities now; no process killed.
def proc(pid):
 try:
  raw=Path('/proc/'+str(pid)+'/stat').read_text();tail=raw[raw.rindex(')')+2:].split();return{'pid':pid,'state':tail[0],'ppid':int(tail[1]),'pgrp':int(tail[2]),'startTicks':tail[19]}
 except(FileNotFoundError,ProcessLookupError,PermissionError):return None
observed=[r for phase in d['phases']for r in phase['observedOwnedProcesses']];states=[]
for identity in observed:
 now=proc(identity['pid']);same=now is not None and now['startTicks']==identity['startTicks'];states.append({'observedIdentity':identity,'currentState':now,'sameBirthIdentity':same});assert not same or now['state']in['Z','X']
groups={r['pgrp']for r in observed};currentGroups=[]
for f in Path('/proc').iterdir():
 if f.name.isdigit():
  now=proc(int(f.name))
  if now and now['pgrp']in groups and now['state']not in['Z','X']:currentGroups.append(now)
assert not currentGroups
result={'scope':'Authoritative STATIC supplement of ACTUAL compile+5 child proofs; original controller administrative failure is preserved, NOT controller success and NOT rerun','originalStatusSHA256':H(old),'originalControllerPassed':False,'originalFailure':d['failure'],'actualCompileExit':d['phases'][0]['exit'],'actualProofExit':d['phases'][1]['exit'],'tapSummary':summary,'actualProofDurationMs':float(re.search(r'^# duration_ms ([0-9.]+)$',text,re.M).group(1)),'originalControllerSeconds':d['seconds'],'actualProducedManifest':actualManifest,'actualProducedManifestFileSHA256':H(Path(str(output)+'.json')),'compileLogSHA256':H(e/'helper-build-24.22.1-compile.log'),'proofLogSHA256':H(log),'originalInputManifestSHA256':H(e/'helper-build-inputs.json'),'inputCount':len(inputs),'currentChangedPinnedInputs':changed,'originalRootChangedSourceFiles':d['rootChangedSourceFiles'],'observedProcessCurrentIdentityChecks':states,'liveObservedProcessGroupsNow':currentGroups,'cleanupLimits':'Proof-stage postexit bookkeeping threw before its original process-after fields could be written. Child exit0 and complete5TAP are contemporaneous. Exact tracked PID/startTicks and groups rechecked now, all gone/exited; this is subsequent static verification, not an invented original snapshot.','acceptedObservedProof':True,'runtimeOrBuildReplayed':False};(e/'helper-build-24.22.1-accepted-supplement.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'acceptedObservedProof':result['acceptedObservedProof'],'tap':summary,'inputs':len(inputs),'knownProcesses':len(states),'live':currentGroups,'supplementSHA256':H(e/'helper-build-24.22.1-accepted-supplement.json'),'binarySHA256':actualManifest['binarySHA256']},indent=2))
