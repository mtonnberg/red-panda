from pathlib import Path
import ast,hashlib,json,os,signal,subprocess,sys,time,re
p=Path.cwd();candidate=p/'candidate';mode,sdk=sys.argv[1:];nodes={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/bin/node','24.19.0':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','26.13.0':'/workspace/shared/node26/node_modules/node/bin/node'}
assert mode in['callbacks16','global15','origin4','fronts2','affected18','regressions84']and sdk in nodes
manifest=p/'evidence/local-producer-next-inputs.json';expected=json.loads(manifest.read_text());node=nodes[sdk];stem='local-producer-next-'+mode+'-'+sdk;statusPath=p/('evidence/'+stem+'-status.json');started=time.monotonic();cap=120
assert not statusPath.exists(),'This immutable epoch already has a status; do not retry'
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def inputs():return{n:digest(Path(n))for n in expected}
assert inputs()==expected,'Frozen candidate/source/artifact/Native inputs changed before launch'
proofFile=p/('evidence/helper-build-'+sdk+'-status.json');proof=json.loads(proofFile.read_text());assert proof.get('passed')and not proof.get('changedInputs')and not proof.get('rootChangedSourceFiles'),'Actual helper build/proof prerequisite did not pass'
actualRuntime=candidate/('native/build/linux-x64/node-'+sdk+'/runtime.node');actualManifest=json.loads(Path(str(actualRuntime)+'.json').read_text());assert actualManifest==proof['actualProducedManifest']and actualManifest['binarySHA256']==digest(actualRuntime)and actualManifest['sourceSHA256']==digest(candidate/'native/runtime.cc'),'Actual built runtime proof changed'

def rootState():
 root=Path('/workspace/red-panda');return{str(f):digest(f)for f in sorted((root/'src').rglob('*'))if f.is_file()}
rootBefore=rootState();(p/('evidence/'+stem+'-root-before.json')).write_text(json.dumps(rootBefore,indent=2)+'\n')
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union);env['RED_PANDA_RUNTIME_ADDON']=str(candidate/('native/build/linux-x64/node-'+sdk+'/runtime.node'));env['RED_PANDA_COLLECTIONS_ADDON']=str(candidate/('native/build/linux-x64/node-'+sdk+'/collections.node'))
status={'sourceRevision':'WORKER_LOCAL_R5_CURRENT5ADB_URL_R4','mode':mode,'sdk':sdk,'node':node,'administrativeCap':cap,'cleanupGrace':3,'perNewTestCap':15,'rpcTimeout':2500,'inputs':len(expected),'manifestSHA256':digest(manifest),'phases':[],'runtimeProcesses':[],'rootBeforeSourceFiles':len(rootBefore),'historicalEpochsNotReplayedAsCandidateSuccess':True,'proxyTLSPreserved':all(env.get(n)==os.environ.get(n)for n in['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR']),'canonicalProxyBypassUnionSHA256':hashlib.sha256(env['NO_PROXY'].encode()).hexdigest()};phase=None
# Observe exact process birth identities so exited zombies are not mistaken for
# live jobs and no unrelated service is ever selected for cleanup.
def proc(pid):
 try:
  raw=Path('/proc/'+str(pid)+'/stat').read_text();tail=raw[raw.rindex(')')+2:].split();return{'pid':pid,'state':tail[0],'ppid':int(tail[1]),'pgrp':int(tail[2]),'startTicks':tail[19],'cmdline':Path('/proc/'+str(pid)+'/cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
 except(FileNotFoundError,ProcessLookupError,PermissionError):return None
def observe(child,known):
 for directory in Path('/proc').iterdir():
  if directory.name.isdigit():
   record=proc(int(directory.name))
   if record and(record['pgrp']==child.pid or record['ppid']in known):known.setdefault(record['pid'],record)
def actual(known):
 result=[]
 for pid,identity in known.items():
  now=proc(pid)
  if now and now['startTicks']==identity['startTicks']:result.append(now)
 return result
def checkpoint():
 status['seconds']=time.monotonic()-started;statusPath.write_text(json.dumps(status,indent=2)+'\n')
def run(name,command,cwd):
 global phase
 remaining=cap-(time.monotonic()-started)
 if remaining<=0:raise RuntimeError('Administrative cap exhausted before '+name)
 phase={'name':name,'command':command,'cwd':str(cwd),'startedSeconds':time.monotonic()-started,'complete':False};status['phases'].append(phase);checkpoint();print(json.dumps({'phase':name,'state':'starting','remainingAdminSeconds':remaining}),flush=True)
 logPath=p/('evidence/'+stem+'-'+name+'.log');known={}
 with logPath.open('xb')as log:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);phase['controllerChildPID']=child.pid
  while child.poll()is None:
   observe(child,known)
   if time.monotonic()-started>=cap:
    phase['administrativeExpiry']=True;os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(.1)
  phase['exit']=child.returncode
 phase['seconds']=time.monotonic()-started-phase['startedSeconds'];phase['observedOwnedProcesses']=list(known.values());phase['processesAfterExit']=actual(known);phase['liveProcessesAfterExit']=[x for x in phase['processesAfterExit']if x['state']not in['Z','X']]
 if phase['liveProcessesAfterExit']:
  for record in phase['liveProcessesAfterExit']:
   now=proc(record['pid'])
   if now and now['startTicks']==record['startTicks']:
    try:os.kill(record['pid'],signal.SIGTERM)
    except ProcessLookupError:pass
  until=time.monotonic()+3
  while time.monotonic()<until and any(x['state']not in['Z','X']for x in actual(known)):time.sleep(.05)
  for record in actual(known):
   if record['state']not in['Z','X']:
    try:os.kill(record['pid'],signal.SIGKILL)
    except ProcessLookupError:pass
 phase['processesAfterCleanup']=actual(known);phase['remainingLiveProcesses']=[x for x in phase['processesAfterCleanup']if x['state']not in['Z','X']];phase['logFile']=str(logPath);checkpoint()
 if phase['exit']!=0 or phase.get('administrativeExpiry')or phase['liveProcessesAfterExit']:raise RuntimeError('Actual child failure/resource boundary in '+name)
 return logPath
def testPhase(name,files,count):
 log=run(name,[node,'--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap',*files],candidate);text=log.read_text();summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$',text,re.M)};phase['tapSummary']=summary
 if summary!={'tests':count,'pass':count,'fail':0,'cancelled':0,'skipped':0,'todo':0}:raise RuntimeError('Actual TAP count/failure boundary in '+name)
 phase['complete']=True;checkpoint()

def normalize(value,origin):
 if isinstance(value,str):return value.replace(origin,'<actual-origin>')
 if isinstance(value,list):return[normalize(x,origin)for x in value]
 if isinstance(value,dict):return{k:normalize(v,origin)for k,v in value.items()}
 return value
def observationPhase(name,driver,nativeFile,count):
 output='evidence/'+stem+'-'+name+'.json';run(name,[node,'--experimental-vm-modules',driver,str(candidate),output],p);raw=json.loads((p/output).read_text());native=json.loads((p/nativeFile).read_text());groups=raw.get('groups',[]);phase['rawFile']=str(p/output);phase['actualGroups']=len(groups);phase['completeGroups']=sum(g.get('completed')is True for g in groups);phase['nativeRawSHA256']=digest(p/nativeFile);phase['runtimeExceptions']=[e for e in raw.get('events',[])if e['message'].get('method')=='Runtime.exceptionThrown'];phase['httpReceipts']=len(raw.get('http',[]));phase['wireMessages']=len(raw.get('wire',[]));pid=raw.get('pid');phase['producerPID']=pid;phase['producerStateAfterCleanup']=proc(pid)if pid else None
 if len(groups)!=count or not all(g.get('completed')is True for g in groups)or not raw.get('finished')or raw.get('failure')or raw.get('cleanupErrors'):raise RuntimeError('Actual incomplete actor group boundary in '+name)
 diffs=[]
 for ng,cg in zip(native['groups'],groups):
  if ng['name']!=cg['name']:diffs.append({'nativeName':ng['name'],'candidateName':cg['name']});continue
  nm,cm=ng.get('modes',[]),cg.get('modes',[])
  if len(nm)!=len(cm):diffs.append({'group':ng['name'],'nativeModes':len(nm),'candidateModes':len(cm)});continue
  for na,ca in zip(nm,cm):
   av=normalize(na.get('observation',{}).get('result',{}).get('value'),native['origin']);bv=normalize(ca.get('observation',{}).get('result',{}).get('value'),raw['origin'])
   if na.get('mode')!=ca.get('mode')or av!=bv:diffs.append({'group':ng['name'],'mode':na.get('mode'),'candidateMode':ca.get('mode'),'native':av,'candidate':bv})
 phase['actualPublicValueDifferences']=diffs;phase['comparisonScope']='ALL actual mode observation by-value fields, error topology/fields/constructor/surface/real markers preserved; only actual ephemeral origin normalized. Full wire retained; protocol metadata extras equality unclaimed.'
 checkpoint()
 if diffs or phase['runtimeExceptions']or(phase['producerStateAfterCleanup']and phase['producerStateAfterCleanup']['state']not in['Z','X']):raise RuntimeError('Actual Native/candidate observation/resource mismatch in '+name)
 phase['complete']=True;checkpoint()
try:
 if mode=='callbacks16':observationPhase('callbacks16','evidence/worker-callback-kinds-probe-candidate.mjs','evidence/worker-callback-kinds-r2-native.json',4)
 elif mode=='global15':observationPhase('global15','evidence/worker-global-heldouts-r2-native-probe-candidate.mjs','evidence/worker-global-heldouts-r2-native-native.json',5)
 elif mode=='origin4':observationPhase('origin4','evidence/worker-origin-native-probe-candidate.mjs','evidence/worker-origin-native-native.json',1)
 elif mode=='fronts2':testPhase('fronts2',['test/worker-local-event-fronts.test.js'],2)
 elif mode=='affected18':testPhase('affected18',['test/url-blocking.test.js','test/worker-startup-errors.test.js','test/worker-error-origin.test.js'],18)
 else:testPhase('regressions84',json.loads((p/'evidence/regressions84-files.json').read_text()),84)
 status['passedObservedPhases']=True

except BaseException as error:
 status['failure']={'type':type(error).__name__,'message':str(error)};status['passedObservedPhases']=False
finally:
 after=inputs();status['changedInputs']=[n for n in expected if after[n]!=expected[n]];rootAfter=rootState();status['rootChangedSourceFiles']=[n for n in set(rootBefore)|set(rootAfter)if rootBefore.get(n)!=rootAfter.get(n)];(p/('evidence/'+stem+'-root-after.json')).write_text(json.dumps(rootAfter,indent=2)+'\n');checkpoint();print(json.dumps({'passedObservedPhases':status['passedObservedPhases'],'failure':status.get('failure'),'phases':[{'name':x['name'],'complete':x['complete'],'tapSummary':x.get('tapSummary'),'actualGroups':x.get('actualGroups'),'differences':len(x.get('actualPublicValueDifferences',[]))}for x in status['phases']],'changedInputs':status['changedInputs'],'rootChangedSourceFiles':status['rootChangedSourceFiles'],'seconds':status['seconds']}),flush=True)
sys.exit(0 if status['passedObservedPhases']and not status['changedInputs']and not status['rootChangedSourceFiles']else 1)
