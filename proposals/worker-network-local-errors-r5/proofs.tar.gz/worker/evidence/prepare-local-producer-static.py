from pathlib import Path
import json,hashlib,difflib
p=Path('/workspace/shared/worker-local-errors-r5');c=p/'candidate';e=p/'evidence';H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
f=c/'src/worker-events.js';s=f.read_text();s="import{types}from'node:util';\n"+s;s=s.replace('function factory(g,b){','function factory(g,b,promiseEvents){')
needle=' function options(v){';assert s.count(needle)==1
value=""" function PromiseRejectionEvent(type,init=undefined){
  if(!new.target||!arguments.length)throw invalid();type=text(type);const o=dict(init),bubbles=!!o.bubbles,cancelable=!!o.cancelable,composed=!!o.composed;
  b.eventStore(this,type,bubbles,cancelable,composed);const promise=o.promise??null;if(promise!==null&&!b.promise(promise))throw invalid();const reason=o.reason??null;b.rejection(this,promise,reason);
 }
 g.Object.setPrototypeOf(PromiseRejectionEvent,Event);g.Object.setPrototypeOf(PromiseRejectionEvent.prototype,ep);define(PromiseRejectionEvent,'prototype',{writable:false});
 for(const key of['promise','reason'])define(PromiseRejectionEvent.prototype,key,{get(){validEvent(this);return b.extra(this,key)},enumerable:true,configurable:true});
"""
s=s.replace(needle,value+needle)
s=s.replace('for(const C of[Event,EventTarget,MessageEvent,ErrorEvent])','for(const C of[Event,EventTarget,MessageEvent,ErrorEvent,...(promiseEvents?[PromiseRejectionEvent]:[])])')
s=s.replace('return{Event,EventTarget,MessageEvent,ErrorEvent,allocate','return{Event,EventTarget,MessageEvent,ErrorEvent,...(promiseEvents?{PromiseRejectionEvent}:{}),allocate')
s=s.replace('reportError=()=>{},active=()=>true}={})','reportError=()=>{},active=()=>true,promiseEvents=false}={})')
s=s.replace("['Event','MessageEvent','ErrorEvent','EventTarget']","['Event','MessageEvent','ErrorEvent','EventTarget',...(promiseEvents?['PromiseRejectionEvent']:[])]")
needle="error(value,message,filename,lineno,colno,error){const s=eventState(value);s.extra=slot({message,filename,lineno,colno,error});registerPlatformFactory(value,{kind:'ErrorEvent',implementation:s,globalObject:realm})},extra(v,k)"
replacement="error(value,message,filename,lineno,colno,error){const s=eventState(value);s.extra=slot({message,filename,lineno,colno,error});registerPlatformFactory(value,{kind:'ErrorEvent',implementation:s,globalObject:realm})},promise:value=>types.isPromise(value),rejection(value,promise,reason){const s=eventState(value);s.extra=slot({promise,reason});registerPlatformFactory(value,{kind:'PromiseRejectionEvent',implementation:s,globalObject:realm})},extra(v,k)"
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('handlers:new Map()','handlers:new Map(),globalErrorHandler:false')
needle='  setReceiver(value,receiverValue){targetState(value).receiver=receiverValue},';assert s.count(needle)==1;s=s.replace(needle,needle+"\n  configureGlobalErrorHandler(value){targetState(value).globalErrorHandler=true},\n  rejectionEvent(type,promise,reason){if(!classes.PromiseRejectionEvent)throw new TypeError('Rejection events are not installed');const value=new classes.PromiseRejectionEvent(type,{promise,cancelable:type==='unhandledrejection'});eventState(value).extra.reason=reason;return value},\n  producedError(value,error){const state=eventState(value);if(!Object.hasOwn(state.extra,'error'))throw new TypeError('An actual ErrorEvent is required');state.extra.error=error;return value},")
needle="const result=apply(h.callback,receiver(s),[event]);if(type==='error'&&result===true)"
replacement="const extra=eventState(event).extra,args=type==='error'&&s.globalErrorHandler&&Object.hasOwn(extra,'error')?[extra.message,extra.filename,extra.lineno,extra.colno,extra.error]:[event];const result=apply(h.callback,receiver(s),args);if(type==='error'&&result===true)"
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace(')(realm,bridge);classes=',')(realm,bridge,promiseEvents);classes=');f.write_text(s)
f=c/'src/workers.js';s=f.read_text();s="import{workerErrorOrigins}from'./worker-error-origin.js';\n"+s
s=s.replace('let dispatchError = value => report(value);','let dispatchError = value => report(value),dispatchRejection,dispatchHandled;')
# Host owner authority and state are inaccessible to authored Worker getters.
s=s.replace('  let reportingStartup=false;','  let reportingStartup=false,localErrorDepth=0;\n  let origins;const originCache=new WeakMap();')
needle='    report,\n    timer(';assert s.count(needle)==1
value="""    report,
    beginError(){if(localErrorDepth)return false;localErrorDepth++;return true},
    endError(){localErrorDepth--},
    errorField(value,key){let result;if(value!==null&&(typeof value==='object'||typeof value==='function')){result=originCache.get(value);if(!originCache.has(value)){result=origins.read(value);originCache.set(value,result)}}return result?.[key]??(key==='filename'?'':0)},
    defaultError(value){if(reportingStartup||workerData.shared||workerData.service)report(value)},
    timer("""
s=s.replace(needle,value)
s=s.replace("vm.runInContext(result.source, context, { filename: result.url });","origins.compiled(result.url);vm.runInContext(result.source, context, { filename: result.url });")
s=s.replace("fetchTypeError=realm.TypeError;","fetchTypeError=realm.TypeError;\n  origins=workerErrorOrigins(vm.runInContext('Object.prototype',context));")
s=s.replace("reportError:value=>dispatchError(value),active:()=>!closed}","reportError:value=>dispatchError(value),active:()=>!closed,promiseEvents:!workerData.shared&&!workerData.service}")
s=s.replace('  context.__sharedWorker=Boolean(workerData.shared);','  context.__sharedWorker=Boolean(workerData.shared);\n  context.__dedicatedWorker=!workerData.shared&&!workerData.service;')
s=s.replace("const target = __sharedWorker?globalThis:new EventTarget(); eventPlatform.setReceiver(target,globalThis);", "const target = __sharedWorker?globalThis:new EventTarget(); eventPlatform.setReceiver(target,globalThis);const dedicated=__dedicatedWorker;delete globalThis.__dedicatedWorker;if(dedicated)eventPlatform.configureGlobalErrorHandler(target);")
s=s.replace("for(const key of ['onmessage','onmessageerror','onerror'])", "for(const key of ['onmessage','onmessageerror','onerror',...(dedicated?['onunhandledrejection','onrejectionhandled']:[])])")
old="""    let reportingError = false;
    globalThis.__dispatchError = error => { if (reportingError) return; reportingError = true; try { const event = new ErrorEvent('error', { message: String(error?.message ?? error), error, cancelable: true }); eventPlatform.trust(event); if (dispatchGlobal(event)) bridge.report(error); } finally { reportingError = false; } };"""
new="""    let reportingError = false;
    const actualString=String,symbolDescription=Object.getOwnPropertyDescriptor(Symbol.prototype,'description').get,apply=Reflect.apply;
    const text=value=>typeof value==='symbol'?apply(symbolDescription,value,[])??'':actualString(value);
    globalThis.__dispatchError = error => {
      // Shared/service behavior remains the previously measured producer.
      if(!dedicated){if(reportingError)return;reportingError=true;try{const event=new ErrorEvent('error',{message:String(error?.message??error),error,cancelable:true});eventPlatform.trust(event);if(dispatchGlobal(event))bridge.report(error)}finally{reportingError=false}return}
      if(!bridge.beginError())return;
      try{const event=new ErrorEvent('error',{message:text(error),filename:bridge.errorField(error,'filename'),lineno:bridge.errorField(error,'lineno'),colno:bridge.errorField(error,'colno'),cancelable:true});eventPlatform.producedError(event,error);eventPlatform.trust(event);if(dispatchGlobal(event))bridge.defaultError(error)}finally{bridge.endError()}
    };
    globalThis.__dispatchRejection=(type,promise,reason)=>dispatchGlobal(eventPlatform.rejectionEvent(type,promise,reason));"""
assert s.count(old)==1;s=s.replace(old,new)
needle="  dispatchError=vm.runInContext('__dispatchError',context);\n  vm.runInContext('delete globalThis.__dispatchError',context);";assert s.count(needle)==1
s=s.replace(needle,"  dispatchError=vm.runInContext('__dispatchError',context);\n  const rejectionProducer=vm.runInContext('__dispatchRejection',context);\n  dispatchRejection=(reason,promise)=>rejectionProducer('unhandledrejection',promise,reason);\n  dispatchHandled=promise=>rejectionProducer('rejectionhandled',promise,null);\n  vm.runInContext('delete globalThis.__dispatchError;delete globalThis.__dispatchRejection',context);")
old="""  const rejection=(value,promise)=>{if(!workerData.shared||getHeapBinding().sameRealm(promise,realm))dispatchError(value)};
  process.on('unhandledRejection',rejection);
  lifetime.signal.addEventListener('abort',()=>process.off('unhandledRejection',rejection),{once:true});"""
new="""  const observedRejections=new WeakSet();
  const rejection=(value,promise)=>{
    if(!workerData.shared&&!workerData.service){if(getHeapBinding().sameRealm(promise,realm)){observedRejections.add(promise);dispatchRejection(value,promise)}else report(value);return}
    if(!workerData.shared||getHeapBinding().sameRealm(promise,realm))dispatchError(value);
  };
  const handled=promise=>{if(observedRejections.has(promise)){observedRejections.delete(promise);dispatchHandled(promise)}};
  process.on('unhandledRejection',rejection);process.on('rejectionHandled',handled);
  lifetime.signal.addEventListener('abort',()=>{process.off('unhandledRejection',rejection);process.off('rejectionHandled',handled)},{once:true});"""
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("const compile = (source, url) => {\n", "const compile = (source, url) => {\n        origins.compiled(url);\n")
s=s.replace("} else vm.runInContext(source, context, { filename: workerData.url,", "} else {origins.compiled(workerData.url);vm.runInContext(source, context, { filename: workerData.url,")
needle="importModuleDynamically: (specifier, _script, extra) => dynamicImport(specifier, { identifier: workerData.url }, extra),\n      });";assert s.count(needle)==1;s=s.replace(needle,needle+'}')
f.write_text(s)
# Draft is intentionally unbuilt and unrun; no source/binary manifest is forged.
manifest={'scope':'STATIC_ONLY_UNRUN_UNBUILT local dedicated Worker producer over current5adb+URLR4','nativeSHA256':H(c/'native/runtime.cc'),'workerEventsSHA256':H(c/'src/worker-events.js'),'workersSHA256':H(c/'src/workers.js'),'originAdapterSHA256':H(c/'src/worker-error-origin.js'),'NativeContracts':'actual original16+new15; not brand-filtered Runtime output','unmeasured':['public constructor full coercion/newTarget','sourceURL/stackTraceLimit0/public stack overwrite','foreign realError crossing actualVMs','rejection handler itself throwing','Shared/service remain prior producers'],'buildRequiredBeforeAnyRuntime':True,'RootEdits':False}
(e/'local-producer-draft-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
