from pathlib import Path
import json,hashlib,shutil
p=Path('/workspace/shared/worker-local-errors-r5');c=p/'candidate';e=p/'evidence';H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();artifacts=[]
for sdk in['24.22.1','24.19.0','26.13.0']:
 for basename,source in[('collections.node','collections.cc'),('heap-query.node','heap-query.cc')]:
  old=p/'prior-native-artifacts/linux-x64'/('node-'+sdk)/basename;manifest=json.loads(Path(str(old)+'.json').read_text());assert H(c/'native'/source)==manifest['sourceSHA256'];assert H(old)==manifest['binarySHA256'];new=c/'native/build/linux-x64'/('node-'+sdk)/basename;new.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old,new);shutil.copy2(Path(str(old)+'.json'),Path(str(new)+'.json'));artifacts.append({'source':str(old),'target':str(new),'binarySHA256':H(new),'manifestSHA256':H(Path(str(new)+'.json'))})
(e/'staged-unchanged-heap-collections.json').write_text(json.dumps(artifacts,indent=2)+'\n')
# This controller only builds the genuinely changed runtime addon and runs the
# five actual source/realm/poison controls. It does not run Browser/Native actors.
controller=r'''from pathlib import Path
import os,sys,json,hashlib,subprocess,time,signal,re
p=Path.cwd();candidate=p/'candidate';sdk=sys.argv[1];nodes={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/bin/node','24.19.0':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','26.13.0':'/workspace/shared/node26/node_modules/node/bin/node'};headers={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/node_modules/node-linux-x64/include/node','24.19.0':'/workspace/shared/node-headers/v24.19.0/node-v24.19.0/include/node','26.13.0':'/workspace/shared/node26/node_modules/node/node_modules/node-linux-x64/include/node'};assert sdk in nodes
manifest=p/'evidence/helper-build-inputs.json';expected=json.loads(manifest.read_text());stem='helper-build-'+sdk;statusPath=p/('evidence/'+stem+'-status.json');assert not statusPath.exists(),'Immutable epoch already exists'
def digest(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert all(digest(n)==h for n,h in expected.items()),'Build/source/header/binary inputs changed'
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for key in['NO_PROXY','no_proxy']for v in env.get(key,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NO_PROXY']=env['no_proxy']=','.join(union);env['NODE_USE_ENV_PROXY']='1';env['RED_PANDA_RUNTIME_ADDON']=str(candidate/('native/build/linux-x64/node-'+sdk+'/runtime.node'));env['RED_PANDA_COLLECTIONS_ADDON']=str(candidate/('native/build/linux-x64/node-'+sdk+'/collections.node'));started=time.monotonic();status={'sdk':sdk,'inputs':len(expected),'administrativeCap':45,'cleanupGrace':3,'manifestSHA256':digest(manifest),'phases':[],'originalCaseCap':15000,'network':False}
def run(name,command):
 log=p/('evidence/'+stem+'-'+name+'.log');row={'name':name,'command':command};status['phases'].append(row)
 with log.open('xb')as out:
  child=subprocess.Popen(command,cwd=candidate,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:row['exit']=child.wait(timeout=max(.1,45-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:
   row['administrativeExpiry']=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   row['exit']=child.returncode
 row['pid']=child.pid;row['presentAfterWait']=Path('/proc/'+str(child.pid)).exists()
 if row['exit']or row.get('administrativeExpiry')or row['presentAfterWait']:raise RuntimeError('Actual build/helper-test/resource boundary: '+name)
 return log
try:
 output=Path(env['RED_PANDA_RUNTIME_ADDON']);assert not output.exists(),'A fresh genuine runtime build is required'
 run('compile',[nodes[sdk],'native/build-runtime.mjs','--headers',headers[sdk]])
 actual=json.loads(Path(str(output)+'.json').read_text());assert actual['sourceSHA256']==digest(candidate/'native/runtime.cc')and actual['binarySHA256']==digest(output)
 status['actualProducedManifest']=actual
 log=run('proof',[nodes[sdk],'--test','--test-reporter=tap','test/worker-error-origin.test.js']);summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$',log.read_text(),re.M)};status['tapSummary']=summary;assert summary=={'tests':5,'pass':5,'fail':0,'cancelled':0,'skipped':0,'todo':0},'Actual helper proof failure/count'
 status['passed']=True
except BaseException as error:status['passed']=False;status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 status['seconds']=time.monotonic()-started;status['changedInputs']=[n for n,h in expected.items()if digest(n)!=h];statusPath.write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
sys.exit(0 if status['passed']and not status['changedInputs']else 1)
'''
(e/'helper-build-slot.py').write_text(controller);compile(controller,'HelperBuildController','exec')
inputs={}
for folder in['base-root-5adb9b3/src','candidate/src','candidate/native','candidate/bin','candidate/test','candidate/scripts']:
 for f in(p/folder).rglob('*'):
  if f.is_file():inputs[str(f)]=H(f)
for name in['candidate/package.json','candidate/package-lock.json','candidate/VERSION','evidence/helper-build-slot.py','evidence/staged-unchanged-heap-collections.json']:
 if(p/name).is_file():inputs[str(p/name)]=H(p/name)
for path in['/workspace/shared/rea-tools/node_modules/node/bin/node','/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','/workspace/shared/node26/node_modules/node/bin/node','/usr/bin/g++']:
 f=Path(path);inputs[str(f)]=H(f)
for directory in['/workspace/shared/rea-tools/node_modules/node/node_modules/node-linux-x64/include/node','/workspace/shared/node-headers/v24.19.0/node-v24.19.0/include/node','/workspace/shared/node26/node_modules/node/node_modules/node-linux-x64/include/node']:
 for f in Path(directory).rglob('*'):
  if f.is_file():inputs[str(f)]=H(f)
# Shared dependency graph exactly pinned; no environment/proxy or TLS alteration.
for f in Path('/workspace/red-panda/node_modules').rglob('*'):
 if f.is_file():inputs[str(f)]=H(f)
(e/'helper-build-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n');print(json.dumps({'inputs':len(inputs),'controllerSHA256':H(e/'helper-build-slot.py'),'manifestSHA256':H(e/'helper-build-inputs.json'),'scope':'UNRUN45s+3 perSDK, actualruntimecompile then5actualpublicV8/VM/poison tests; noBrowser orNative actor'},indent=2))
