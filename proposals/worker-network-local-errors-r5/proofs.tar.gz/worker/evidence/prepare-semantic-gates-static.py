from pathlib import Path
import hashlib,json,shutil
p=Path('/workspace/shared/worker-local-errors-r5');e=p/'evidence';old=Path('/workspace/shared/network-url-blocking-recovery');H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();shutil.copytree(old/'helpers',p/'helpers')
for stem in['worker-callback-kinds-probe','worker-global-heldouts-r2-native-probe','worker-origin-native-probe']:
 s=(old/'evidence'/(stem+'.mjs')).read_text().replace("import{startReference}from'../helpers/reference-server.mjs'","import{startRoot}from'../helpers/root-server.mjs'")
 # Keep ALL actual authored HTTP worker bodies/expressions byte-identical.
 a=s.index('const binary=process.argv[2]');b=s.index('\nlet browser,',a)
 header=s[a:b];new="const source=process.argv[2],output=process.argv[3],sha=b=>createHash('sha256').update(b).digest('hex'),record={actor:'candidate-worker-local-r5',source,sourceSHA256:sha(await readFile(source+'/src/workers.js')),driverSHA256:sha(await readFile(new URL(import.meta.url))),rpcTimeout:2500,groups:[],wire:[],events:[],http:[]};"
 s=s[:a]+new+s[b:];s=s.replace("startReference(binary,{args:['--load-resources','worker']})","startRoot(source)");assert'startReference'not in s
 (e/(stem+'-candidate.mjs')).write_text(s)
# Use the already meaningful robust fixed-input/proc-identity controller shape.
s=Path('/workspace/shared/document-encoding-recovery/evidence/candidate-r5-next-slot.py').read_text();a=s.index("p=Path.cwd();candidate=");b=s.index('manifest=p/',a)
s=s[:a]+"p=Path.cwd();candidate=p/'candidate';mode,sdk=sys.argv[1:];nodes={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/bin/node','24.19.0':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','26.13.0':'/workspace/shared/node26/node_modules/node/bin/node'}\nassert mode in['callbacks16','global15','origin4','fronts2','affected18','regressions84']and sdk in nodes\n"+s[b:]
s=s.replace('candidate-r5-next','local-producer-next').replace("'sourceRevision':'R5'","'sourceRevision':'WORKER_LOCAL_R5_CURRENT5ADB_URL_R4'")
# Defer actual output binaries to their successful real build/proof receipts;
# no fabricated build manifests or imported old runtime binaries are admitted.
needle="assert inputs()==expected,'Frozen candidate/source/artifact/Native inputs changed before launch'"
proof="""assert inputs()==expected,'Frozen candidate/source/artifact/Native inputs changed before launch'
proofFile=p/('evidence/helper-build-'+sdk+'-status.json');proof=json.loads(proofFile.read_text());assert proof.get('passed')and not proof.get('changedInputs')and not proof.get('rootChangedSourceFiles'),'Actual helper build/proof prerequisite did not pass'
actualRuntime=candidate/('native/build/linux-x64/node-'+sdk+'/runtime.node');actualManifest=json.loads(Path(str(actualRuntime)+'.json').read_text());assert actualManifest==proof['actualProducedManifest']and actualManifest['binarySHA256']==digest(actualRuntime)and actualManifest['sourceSHA256']==digest(candidate/'native/runtime.cc'),'Actual built runtime proof changed'
"""
assert needle in s;s=s.replace(needle,proof)
# Original16/15/4 each use per-mode observations, not whole-group observation.
a=s.index(' diffs=[]\n',s.index('def observationPhase'));b=s.index(" phase['actualPublicValueDifferences']",a)
s=s[:a]+''' diffs=[]
 for ng,cg in zip(native['groups'],groups):
  if ng['name']!=cg['name']:diffs.append({'nativeName':ng['name'],'candidateName':cg['name']});continue
  nm,cm=ng.get('modes',[]),cg.get('modes',[])
  if len(nm)!=len(cm):diffs.append({'group':ng['name'],'nativeModes':len(nm),'candidateModes':len(cm)});continue
  for na,ca in zip(nm,cm):
   av=normalize(na.get('observation',{}).get('result',{}).get('value'),native['origin']);bv=normalize(ca.get('observation',{}).get('result',{}).get('value'),raw['origin'])
   if na.get('mode')!=ca.get('mode')or av!=bv:diffs.append({'group':ng['name'],'mode':na.get('mode'),'candidateMode':ca.get('mode'),'native':av,'candidate':bv})
''' +s[b:]
s=s.replace("'ALL actual observation/query/dataURL by-value fields, including serialized roots. Only distinct ephemeral server origins normalized. Full raw wire retained; protocol metadata equality unclaimed.'","'ALL actual mode observation by-value fields, error topology/fields/constructor/surface/real markers preserved; only actual ephemeral origin normalized. Full wire retained; protocol metadata extras equality unclaimed.'")
a=s.index("try:\n if mode=='observations':");b=s.index(" status['passedObservedPhases']=True",a)
s=s[:a]+'''try:
 if mode=='callbacks16':observationPhase('callbacks16','evidence/worker-callback-kinds-probe-candidate.mjs','evidence/worker-callback-kinds-r2-native.json',4)
 elif mode=='global15':observationPhase('global15','evidence/worker-global-heldouts-r2-native-probe-candidate.mjs','evidence/worker-global-heldouts-r2-native-native.json',5)
 elif mode=='origin4':observationPhase('origin4','evidence/worker-origin-native-probe-candidate.mjs','evidence/worker-origin-native-native.json',1)
 elif mode=='fronts2':testPhase('fronts2',['test/worker-local-event-fronts.test.js'],2)
 elif mode=='affected18':testPhase('affected18',['test/url-blocking.test.js','test/worker-startup-errors.test.js','test/worker-error-origin.test.js'],18)
 else:testPhase('regressions84',json.loads((p/'evidence/regressions84-files.json').read_text()),84)
''' +s[b:]
(e/'local-producer-next-slot.py').write_text(s);compile(s,'WorkerSemanticController','exec')
for name in['worker-callback-kinds-r2-native.json','worker-global-heldouts-r2-native-native.json','worker-origin-native-native.json']:
 shutil.copy2(old/'evidence'/name,e/name)
shutil.copy2(old/'evidence/candidate-r3-regressions.json',e/'regressions84-files.json')
inputs=json.loads((e/'helper-build-inputs.json').read_text())
for top in['helpers','candidate/src','candidate/test']:
 for f in(p/top).rglob('*'):
  if f.is_file():inputs[str(f)]=H(f)
for f in e.glob('*-candidate.mjs'):inputs[str(f)]=H(f)
for name in['local-producer-next-slot.py','worker-callback-kinds-r2-native.json','worker-global-heldouts-r2-native-native.json','worker-origin-native-native.json','regressions84-files.json']:
 inputs[str(e/name)]=H(e/name)
(e/'local-producer-next-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n');print(json.dumps({'controllerSHA256':H(e/'local-producer-next-slot.py'),'manifestSHA256':H(e/'local-producer-next-inputs.json'),'inputs':len(inputs),'modes':'callbacks16,global15,origin4,fronts2,affected18,regressions84','sdk':'24.22.1 then24.19.0/26.13.0 only if grant','scope':'ALL_UNRUN; actual sameSDK helper-build proof+generated matching artifact is mandatory;120s admin/3cleanup/API2500/originalcases unchanged'},indent=2))
