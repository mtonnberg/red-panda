from pathlib import Path
import os,sys,json,hashlib,subprocess,time,signal,re
p=Path.cwd();candidate=p/'candidate';sdk=sys.argv[1];nodes={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/bin/node','24.19.0':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','26.13.0':'/workspace/shared/node26/node_modules/node/bin/node'};headers={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/node_modules/node-linux-x64/include/node','24.19.0':'/workspace/shared/node-headers/v24.19.0/node-v24.19.0/include/node','26.13.0':'/workspace/shared/node26/node_modules/node/node_modules/node-linux-x64/include/node'};assert sdk in nodes
manifest=p/'evidence/helper-build-inputs.json';expected=json.loads(manifest.read_text());stem='helper-build-'+sdk;statusPath=p/('evidence/'+stem+'-status.json');assert not statusPath.exists(),'Immutable epoch already exists'
def digest(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert all(digest(n)==h for n,h in expected.items()),'Build/source/header/binary inputs changed'
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for key in['NO_PROXY','no_proxy']for v in env.get(key,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NO_PROXY']=env['no_proxy']=','.join(union);env['NODE_USE_ENV_PROXY']='1';env['RED_PANDA_RUNTIME_ADDON']=str(candidate/('native/build/linux-x64/node-'+sdk+'/runtime.node'));env['RED_PANDA_COLLECTIONS_ADDON']=str(candidate/('native/build/linux-x64/node-'+sdk+'/collections.node'));env['CXX']='/usr/bin/g++';started=time.monotonic();root=Path('/workspace/red-panda');rootBefore={str(f):digest(f)for f in sorted((root/'src').rglob('*'))if f.is_file()};status={'sdk':sdk,'inputs':len(expected),'administrativeCap':45,'cleanupGrace':3,'manifestSHA256':digest(manifest),'phases':[],'originalCaseCap':15000,'network':False}
def proc(pid):
 try:
  raw=Path('/proc/'+str(pid)+'/stat').read_text();tail=raw[raw.rindex(')')+2:].split();return{'pid':pid,'state':tail[0],'ppid':int(tail[1]),'pgrp':int(tail[2]),'startTicks':tail[19],'cmdline':Path('/proc/'+str(pid)+'/cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
 except(FileNotFoundError,ProcessLookupError,PermissionError):return None
def observe(child,known):
 for directory in Path('/proc').iterdir():
  if directory.name.isdigit():
   record=proc(int(directory.name))
   if record and(record['pgrp']==child.pid or record['ppid']in known):known.setdefault(record['pid'],record)
def actual(known):
 result=[]
 for pid,identity in known.items():
  now=proc(pid)
  if now and now['startTicks']==identity['startTicks']:result.append(now)
 return result
def run(name,command):
 log=p/('evidence/'+stem+'-'+name+'.log');row={'name':name,'command':command};status['phases'].append(row);known={}
 with log.open('xb')as out:
  child=subprocess.Popen(command,cwd=candidate,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  while child.poll()is None:
   observe(child,known)
   if time.monotonic()-started>=45:
    row['administrativeExpiry']=True;os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(.1)
  row['exit']=child.returncode
 row['pid']=child.pid;row['observedOwnedProcesses']=list(known.values());row['processesAfterExit']=actual(known);live=[r for r in row['processesAfterExit']if r['state']not in['Z','X']];row['remainingLiveBeforeCleanup']=live
 for record in live:
  now=proc(record['pid'])
  if now and now['startTicks']==record['startTicks']:
   try:os.kill(record['pid'],signal.SIGTERM)
   except ProcessLookupError:pass
 until=time.monotonic()+3
 while time.monotonic()<until and any(r['state']not in['Z','X']for r in actual(known)):time.sleep(.05)
 for record in actual(known):
  if record['state']not in['Z','X']:
   try:os.kill(record['pid'],signal.SIGKILL)
   except ProcessLookupError:pass
 row['processesAfterCleanup']=actual(known);row['remainingLiveAfterCleanup']=[r for r in row['processesAfterCleanup']if r['state']not in['Z','X']]
 if row['exit']or row.get('administrativeExpiry')or live:raise RuntimeError('Actual build/helper-test/resource boundary: '+name)
 return log

try:
 output=Path(env['RED_PANDA_RUNTIME_ADDON']);assert not output.exists(),'A fresh genuine runtime build is required'
 run('compile',[nodes[sdk],'native/build-runtime.mjs','--headers',headers[sdk]])
 actual=json.loads(Path(str(output)+'.json').read_text());assert actual['sourceSHA256']==digest(candidate/'native/runtime.cc')and actual['binarySHA256']==digest(output)
 status['actualProducedManifest']=actual
 log=run('proof',[nodes[sdk],'--test','--test-reporter=tap','test/worker-error-origin.test.js']);summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$',log.read_text(),re.M)};status['tapSummary']=summary;assert summary=={'tests':5,'pass':5,'fail':0,'cancelled':0,'skipped':0,'todo':0},'Actual helper proof failure/count'
 status['passed']=True
except BaseException as error:status['passed']=False;status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 rootAfter={str(f):digest(f)for f in sorted((root/'src').rglob('*'))if f.is_file()};status['rootChangedSourceFiles']=[n for n in set(rootBefore)|set(rootAfter)if rootBefore.get(n)!=rootAfter.get(n)];status['seconds']=time.monotonic()-started;status['changedInputs']=[n for n,h in expected.items()if digest(n)!=h];statusPath.write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
sys.exit(0 if status['passed']and not status['changedInputs']and not status['rootChangedSourceFiles']else 1)
