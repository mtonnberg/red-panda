import {pathToFileURL} from 'node:url';
const {serve}=await import(pathToFileURL(process.argv[2]+'/src/cdp.js'));
const server=await serve({host:'127.0.0.1',port:Number(process.argv[3]),loadResources:['worker']});
let closing=false;for(const signal of ['SIGTERM','SIGINT'])process.on(signal,async()=>{if(closing)return;closing=true;await server.close();process.exit(0)});
