import http from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash,randomBytes} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {startRoot} from '../helpers/root-server.mjs';
import {connectRaw} from '../helpers/raw-cdp.mjs';
const binary=process.argv[2],output=process.argv[3],hash=value=>createHash('sha256').update(value).digest('hex');
const run=randomBytes(8).toString('hex'),record={binary,rootCDPSHA256:hash(await readFile(binary+'/src/cdp.js')),driverSHA256:hash(await readFile(new URL(import.meta.url))),run,revision:'R2-continuation',priorEpoch:'native-eight.json',rpcTimeout:2500,groups:[],wire:[],events:[],http:[],expectedRequestURLs:[]};
let writes=Promise.resolve(),browser,origin,activeGroup,clientA,clientB,targetA,sessionA,contextA;const clients=[];const targets=new Set(),contexts=new Set();
function flush(){writes=writes.then(()=>writeFile(output+'.progress.json',JSON.stringify(record,null,2)+'\n'));return writes}
const server=http.createServer(async(request,response)=>{
 const item={sequence:record.http.length+1,receivedAt:performance.now(),method:request.method,url:request.url,headers:request.headers,rawHeaders:request.rawHeaders,bodyBase64:null,response:null};record.http.push(item);void flush();
 try{const chunks=[];for await(const chunk of request)chunks.push(chunk);item.bodyBase64=Buffer.concat(chunks).toString('base64');const parsed=new URL(request.url,origin),token=parsed.searchParams.get('token')??'';let status=200,type='text/plain; charset=utf-8',body;
 if(parsed.pathname==='/page') {type='text/html; charset=utf-8';body='<!doctype html><title>Actual block control</title><script>globalThis.actualPageMarker="live"</script><p>Actual page '+token+'</p>'}
 else if(parsed.pathname==='/blocked-document'){type='text/html; charset=utf-8';body='<!doctype html><p>Actual blocked-document server response</p>'}
 else if(parsed.pathname==='/script.js'){type='text/javascript; charset=utf-8';body='globalThis.actualExternalScript=(globalThis.actualExternalScript||0)+1;'}
 else if(parsed.pathname==='/worker.js'){type='text/javascript; charset=utf-8';const target=origin+'/producer/worker-target?token='+encodeURIComponent(token);body='(async()=>{try{const r=await fetch('+JSON.stringify(target)+');postMessage({producer:"actual-worker",ok:true,status:r.status,body:await r.text()})}catch(e){postMessage({producer:"actual-worker",ok:false,name:e.name,message:e.message})}})();'}
 else if(parsed.pathname==='/redirect'){status=302;body='Actual redirect entity';response.setHeader('location',origin+'/destination?token='+encodeURIComponent(token))}
 else body='actual-server-body:'+parsed.pathname+parsed.search+':receipt='+item.sequence+':🐼\u0000';
 const bytes=Buffer.from(body);response.statusCode=status;response.setHeader('content-type',type);response.setHeader('content-length',String(bytes.length));response.setHeader('cache-control','no-store');response.setHeader('access-control-allow-origin','*');item.response={status,headers:response.getHeaders(),bodyBase64:bytes.toString('base64')};response.end(bytes);await flush();
 }catch(error){item.error={message:error.message,stack:error.stack};if(!response.headersSent)response.writeHead(500);response.end();await flush()}
});
const url=(path,label)=>origin+path+'?token='+encodeURIComponent(run+'-'+label);
async function call(label,method,params,sessionId=sessionA,client=clientA,{allowProtocolError=false}={}){
 const step={label,connection:client.label,method,params,sessionId,httpBefore:record.http.length,wireBefore:record.wire.length,startedAt:performance.now()};activeGroup.steps.push(step);await flush();
 try{step.reply=await client.send(method,params,sessionId);if(step.reply.error&&!allowProtocolError)throw Object.assign(new Error('Observed protocol error: '+step.reply.error.message),{protocolError:step.reply.error});return step.reply}
 catch(error){step.failure={message:error.message,rpcTimeout:!!error.rpcTimeout,connectionLost:!!error.connectionLost,protocolError:error.protocolError};throw error}
 finally{step.finishedAt=performance.now();step.httpAfter=record.http.length;step.wireAfter=record.wire.length;await flush()}
}
const policy=(label,patterns,sessionId=sessionA,client=clientA)=>call(label,'Network.setBlockedURLs',{urlPatterns:patterns},sessionId,client,{allowProtocolError:true});
async function evaluate(label,expression,sessionId=sessionA,client=clientA){const reply=await call(label,'Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},sessionId,client);if(reply.result?.exceptionDetails)throw Error('Actual JavaScript setup failed '+label);return reply.result}
async function fetchActual(label,address,sessionId=sessionA,client=clientA){record.expectedRequestURLs.push({group:activeGroup.name,label,url:address});return evaluate(label,'(async()=>{try{const r=await fetch('+JSON.stringify(address)+');return{ok:true,status:r.status,url:r.url,body:await r.text()}}catch(e){return{ok:false,name:e.name,message:e.message}}})()',sessionId,client)}
async function newTarget(label,{contextId,client=clientA}={}){const created=await call(label+'-target','Target.createTarget',{url:'about:blank',...(contextId?{browserContextId:contextId}:{})},null,client);const targetId=created.result.targetId;targets.add(targetId);const attached=await call(label+'-attach','Target.attachToTarget',{targetId,flatten:true},null,client);const sessionId=attached.result.sessionId;await call(label+'-network','Network.enable',{},sessionId,client);await call(label+'-page-events','Page.enable',{},sessionId,client);await call(label+'-runtime-events','Runtime.enable',{},sessionId,client);return{targetId,sessionId,client}}
async function navigateReady(label,target,address){record.expectedRequestURLs.push({group:activeGroup.name,label,url:address});await call(label,'Page.navigate',{url:address},target.sessionId,target.client);await evaluate(label+'-actual-load','new Promise(resolve=>{if(document.readyState==="complete")resolve({ready:document.readyState,url:location.href});else addEventListener("load",()=>resolve({ready:document.readyState,url:location.href}),{once:true})})',target.sessionId,target.client)}
const group=async(name,body)=>{activeGroup={name,steps:[],completed:false,httpBefore:record.http.length,wireBefore:record.wire.length};record.groups.push(activeGroup);await flush();try{await body();activeGroup.completed=true}catch(error){activeGroup.failure={message:error.message,stack:error.stack,rpcTimeout:!!error.rpcTimeout,connectionLost:!!error.connectionLost};throw error}finally{activeGroup.httpAfter=record.http.length;activeGroup.wireAfter=record.wire.length;await flush()}};
try{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;record.origin=origin;
 browser=await startRoot(binary);record.pid=browser.process.pid;record.endpoint=browser.endpoint;clientA=await connectRaw(browser.endpoint,{label:'A',wire:record.wire,events:record.events,flush,timeout:2500});clients.push(clientA);
 await group('0-minimal-explicit-A-bootstrap',async()=>{
  const created=await call('A-context','Target.createBrowserContext',{},null,clientA);contextA=created.result.browserContextId;contexts.add(contextA);
  const target=await newTarget('A',{contextId:contextA});targetA=target.targetId;sessionA=target.sessionId;
  await call('A-disable-cache','Network.setCacheDisabled',{cacheDisabled:true});await navigateReady('A-harness',target,url('/page','R2-A'));await policy('A-bootstrap-clear',[]);
 });
 await group('3-blocked-document-own-connection-context-policy',async()=>{
  const clientD=await connectRaw(browser.endpoint,{label:'D-document',wire:record.wire,events:record.events,flush,timeout:2500});clients.push(clientD);
  const created=await call('D-context','Target.createBrowserContext',{},null,clientD);const contextD=created.result.browserContextId;contexts.add(contextD);
  const doc=await newTarget('D',{contextId:contextD,client:clientD});await navigateReady('D-harness',doc,url('/page','R2-D'));
  await policy('D-own-document-rule',[{urlPattern:origin+'/blocked-document*',block:true}],doc.sessionId,clientD);
  const blocked=url('/blocked-document','R2-direct');record.expectedRequestURLs.push({group:activeGroup.name,label:'blocked-document',stepLabel:'D-blocked-document-navigation',url:blocked});
  await call('D-blocked-document-navigation','Page.navigate',{url:blocked},doc.sessionId,clientD,{allowProtocolError:true});
  await call('D-blocked-document-state','Runtime.evaluate',{expression:'new Promise(r=>setTimeout(()=>r({url:location.href,ready:document.readyState,marker:globalThis.actualPageMarker}),0))',awaitPromise:true,returnByValue:true},doc.sessionId,clientD,{allowProtocolError:true});
  await call('D-close-own-target','Target.closeTarget',{targetId:doc.targetId},null,clientD);targets.delete(doc.targetId);
  await call('D-dispose-own-context','Target.disposeBrowserContext',{browserContextId:contextD},null,clientD);contexts.delete(contextD);await clientD.close();
 });
 await group('4-pattern-order-case-and-wildcards',async()=>{
  const exact=url('/pattern/exact','exact');await policy('exact-policy',[{urlPattern:exact,block:true}]);await fetchActual('exact-match',exact);await fetchActual('exact-not-prefix',exact+'&tail=1');
  await policy('wildcard-case-policy',[{urlPattern:'*/PATTERN/*.JS*',block:true}]);await fetchActual('wildcard-ascii-case',url('/pattern/Module.Js','case'));await fetchActual('wildcard-outside-extension',url('/pattern/module.css','case'));
  const literal=origin+'/pattern/a?literal='+run;await policy('question-literal-policy',[{urlPattern:literal,block:true}]);await fetchActual('question-literal-match',literal);await fetchActual('question-not-single-character',origin+'/pattern/aXliteral='+run);
  await policy('allow-first',[{urlPattern:'*/pattern/*',block:false},{urlPattern:'*',block:true}]);await fetchActual('first-allow-wins',url('/pattern/order','allow-first'));
  await policy('block-first',[{urlPattern:'*',block:true},{urlPattern:'*/pattern/*',block:false}]);await fetchActual('first-block-wins',url('/pattern/order','block-first'));
  await policy('empty-pattern',[{urlPattern:'',block:true}]);await fetchActual('empty-pattern-is-not-all',url('/pattern/empty','empty'));
  await policy('multiple-stars',[{urlPattern:'**/pattern/**/deep**',block:true}]);await fetchActual('multiple-star-match',url('/pattern/x/deep','stars'));await policy('pattern-clear',[]);
 });
 await group('5-real-clear-and-replacement',async()=>{const address=url('/clear/real','clear');await policy('clear-install',[{urlPattern:'*/clear/*',block:true}]);await fetchActual('before-clear-blocked',address);await policy('clear-empty-list',[]);await fetchActual('after-clear-real-response',address);await policy('replace-unrelated',[{urlPattern:'*/unrelated/*',block:true}]);await fetchActual('replacement-removes-old-rule',address);await policy('clear-end',[])});
 await group('6-real-redirect-destination',async()=>{const address=url('/redirect','redirect');await policy('redirect-rule',[{urlPattern:'*/destination*',block:true}]);await fetchActual('redirect-target-blocked',address);await policy('redirect-clear',[]);await fetchActual('redirect-real-after-clear',address)});
 await group('7-sync-xhr-and-real-worker',async()=>{
  const sync=url('/producer/sync','sync');await policy('sync-rule',[{urlPattern:'*/producer/sync*',block:true}]);record.expectedRequestURLs.push({group:activeGroup.name,label:'sync-xhr',url:sync});await evaluate('sync-xhr','(()=>{const x=new XMLHttpRequest();try{x.open("GET",'+JSON.stringify(sync)+',false);x.send();return{ok:true,status:x.status,body:x.responseText}}catch(e){return{ok:false,status:x.status,name:e.name,message:e.message}}})()');
  await policy('worker-baseline-clear',[]);const baselineWorker=url('/worker.js','worker-baseline');record.expectedRequestURLs.push({group:activeGroup.name,label:'worker-baseline-script',stepLabel:'worker-baseline',url:baselineWorker},{group:activeGroup.name,label:'worker-baseline-fetch',stepLabel:'worker-baseline',url:origin+'/producer/worker-target?token='+encodeURIComponent(run+'-worker-baseline')});await evaluate('worker-baseline','new Promise(resolve=>{const w=new Worker('+JSON.stringify(baselineWorker)+');w.onmessage=e=>{resolve({event:"message",value:e.data});w.terminate()};w.onerror=e=>{resolve({event:"error",message:e.message});w.terminate()}})');
  await policy('worker-target-rule',[{urlPattern:'*/producer/worker-target*',block:true}]);const worker=url('/worker.js','worker-fetch');record.expectedRequestURLs.push({group:activeGroup.name,label:'worker-script-allowed',stepLabel:'worker-real-fetch',url:worker},{group:activeGroup.name,label:'worker-fetch-blocked',stepLabel:'worker-real-fetch',url:origin+'/producer/worker-target?token='+encodeURIComponent(run+'-worker-fetch')});await evaluate('worker-real-fetch','new Promise(resolve=>{const w=new Worker('+JSON.stringify(worker)+');w.onmessage=e=>{resolve({event:"message",value:e.data});w.terminate()};w.onerror=e=>{resolve({event:"error",message:e.message});w.terminate()}})');
  await policy('worker-script-rule',[{urlPattern:'*/worker.js*',block:true}]);const denied=url('/worker.js','worker-denied');record.expectedRequestURLs.push({group:activeGroup.name,label:'worker-script-blocked',stepLabel:'worker-script-denied',url:denied});await evaluate('worker-script-denied','new Promise(resolve=>{try{const w=new Worker('+JSON.stringify(denied)+');w.onmessage=e=>{resolve({event:"message",value:e.data});w.terminate()};w.onerror=e=>{resolve({event:"error",message:e.message});w.terminate()}}catch(e){resolve({event:"constructor-error",name:e.name,message:e.message})}})');await policy('producer-clear',[]);
 });
 await group('8-two-connections-contexts-and-lifetime',async()=>{
  clientB=await connectRaw(browser.endpoint,{label:'B',wire:record.wire,events:record.events,flush,timeout:2500});clients.push(clientB);
  const created=await call('B-context','Target.createBrowserContext',{},null,clientB);const contextB=created.result.browserContextId;contexts.add(contextB);
  const targetB=await newTarget('B',{contextId:contextB,client:clientB});await navigateReady('B-harness',targetB,url('/page','R2-B'));
  await policy('A-installs-owner-rule',[{urlPattern:'*/ownership/*',block:true}]);await fetchActual('B-observes-A-policy',url('/ownership/value','B-A-policy'),targetB.sessionId,clientB);
  await policy('B-installs-own-allow',[{urlPattern:'*/ownership/*',block:false}],targetB.sessionId,clientB);await fetchActual('A-observes-B-allow',url('/ownership/value','A-B-allow'));
  await policy('B-installs-own-block',[{urlPattern:'*/ownership/*',block:true}],targetB.sessionId,clientB);await fetchActual('B-after-own-block',url('/ownership/value','B-own-block'),targetB.sessionId,clientB);
  await navigateReady('B-real-renavigation',targetB,url('/page','R2-B-new-document'));await fetchActual('B-own-policy-after-navigation',url('/ownership/value','B-after-navigation'),targetB.sessionId,clientB);
  await call('A-closes-own-target','Target.closeTarget',{targetId:targetA},null,clientA);targets.delete(targetA);await fetchActual('B-after-A-target-close',url('/ownership/value','B-after-A-target-close'),targetB.sessionId,clientB);
  await clientA.close();await fetchActual('B-after-A-connection-close',url('/ownership/value','B-after-A-connection-close'),targetB.sessionId,clientB);
  await call('B-dispose-own-context','Target.disposeBrowserContext',{browserContextId:contextB},null,clientB);contexts.delete(contextB);targets.delete(targetB.targetId);
  const next=await call('C-context-on-B-connection','Target.createBrowserContext',{},null,clientB);const contextC=next.result.browserContextId;contexts.add(contextC);
  const targetC=await newTarget('C',{contextId:contextC,client:clientB});await navigateReady('C-harness',targetC,url('/page','R2-C'));await fetchActual('C-after-B-context-disposal',url('/ownership/value','C-after-dispose'),targetC.sessionId,clientB);
  await policy('C-clears-policy',[],targetC.sessionId,clientB);await fetchActual('C-after-clear',url('/ownership/value','C-clear'),targetC.sessionId,clientB);
  await call('C-close-own-target','Target.closeTarget',{targetId:targetC.targetId},null,clientB);targets.delete(targetC.targetId);await call('C-dispose-own-context','Target.disposeBrowserContext',{browserContextId:contextC},null,clientB);contexts.delete(contextC);
 });
 record.finished=true;
}catch(error){record.failure={message:error.message,stack:error.stack,rpcTimeout:!!error.rpcTimeout,connectionLost:!!error.connectionLost}}
finally{
 record.ownedResourcesBeforeCleanup={targets:[...targets],contexts:[...contexts],clients:clients.map(client=>client.label)};

 for(const client of clients.reverse())try{await client.close()}catch(error){(record.cleanupErrors??=[]).push({client:client.label,message:error.message})}
 try{await browser?.close()}catch(error){(record.cleanupErrors??=[]).push({browser:true,message:error.message})}
 server.closeAllConnections();await new Promise(resolve=>server.close(resolve));record.stderr=browser?.stderr;record.stderrTruncated=browser?.stderrTruncated;
 record.requestReachability=record.expectedRequestURLs.map(expected=>{const owner=record.groups.find(group=>group.name===expected.group),step=owner?.steps.find(step=>step.label===(expected.stepLabel??expected.label));return{...expected,operationHttpRange:step?{before:step.httpBefore,after:step.httpAfter}:null,receivedDuringObservedOperation:step?record.http.slice(step.httpBefore,step.httpAfter).filter(item=>origin+item.url===expected.url).map(item=>item.sequence):null,receivedByFinalSnapshot:record.http.filter(item=>origin+item.url===expected.url).map(item=>item.sequence)}});
 await flush();await writes;await writeFile(output,JSON.stringify(record,null,2)+'\n',{flag:'wx'});
}
console.log(JSON.stringify({pid:record.pid,groups:record.groups.map(group=>({name:group.name,completed:group.completed,failure:group.failure})),httpReceipts:record.http.length,wireMessages:record.wire.length,failure:record.failure}));
