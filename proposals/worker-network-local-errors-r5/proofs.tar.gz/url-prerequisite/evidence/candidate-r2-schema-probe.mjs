import http from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash,randomBytes} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {startRoot} from '../helpers/root-server.mjs';
import {connectRaw} from '../helpers/raw-cdp.mjs';
const binary=process.argv[2],output=process.argv[3],hash=value=>createHash('sha256').update(value).digest('hex');
const run=randomBytes(8).toString('hex'),record={binary,rootCDPSHA256:hash(await readFile(binary+'/src/cdp.js')),driverSHA256:hash(await readFile(new URL(import.meta.url))),run,rpcTimeout:2500,groups:[],wire:[],events:[],http:[],expectedRequestURLs:[]};
let writes=Promise.resolve(),browser,origin,activeGroup,clientA,clientB,targetA,sessionA;const clients=[];const targets=new Set(),contexts=new Set();
function flush(){writes=writes.then(()=>writeFile(output+'.progress.json',JSON.stringify(record,null,2)+'\n'));return writes}
const server=http.createServer(async(request,response)=>{
 const item={sequence:record.http.length+1,receivedAt:performance.now(),method:request.method,url:request.url,headers:request.headers,rawHeaders:request.rawHeaders,bodyBase64:null,response:null};record.http.push(item);void flush();
 try{const chunks=[];for await(const chunk of request)chunks.push(chunk);item.bodyBase64=Buffer.concat(chunks).toString('base64');const parsed=new URL(request.url,origin),token=parsed.searchParams.get('token')??'';let status=200,type='text/plain; charset=utf-8',body;
 if(parsed.pathname==='/page') {type='text/html; charset=utf-8';body='<!doctype html><title>Actual block control</title><script>globalThis.actualPageMarker="live"</script><p>Actual page '+token+'</p>'}
 else if(parsed.pathname==='/blocked-document'){type='text/html; charset=utf-8';body='<!doctype html><p>Actual blocked-document server response</p>'}
 else if(parsed.pathname==='/script.js'){type='text/javascript; charset=utf-8';body='globalThis.actualExternalScript=(globalThis.actualExternalScript||0)+1;'}
 else if(parsed.pathname==='/worker.js'){type='text/javascript; charset=utf-8';const target=origin+'/producer/worker-target?token='+encodeURIComponent(token);body='(async()=>{try{const r=await fetch('+JSON.stringify(target)+');postMessage({producer:"actual-worker",ok:true,status:r.status,body:await r.text()})}catch(e){postMessage({producer:"actual-worker",ok:false,name:e.name,message:e.message})}})();'}
 else if(parsed.pathname==='/redirect'){status=302;body='Actual redirect entity';response.setHeader('location',origin+'/destination?token='+encodeURIComponent(token))}
 else body='actual-server-body:'+parsed.pathname+parsed.search+':receipt='+item.sequence+':🐼\u0000';
 const bytes=Buffer.from(body);response.statusCode=status;response.setHeader('content-type',type);response.setHeader('content-length',String(bytes.length));response.setHeader('cache-control','no-store');response.setHeader('access-control-allow-origin','*');item.response={status,headers:response.getHeaders(),bodyBase64:bytes.toString('base64')};response.end(bytes);await flush();
 }catch(error){item.error={message:error.message,stack:error.stack};if(!response.headersSent)response.writeHead(500);response.end();await flush()}
});
const url=(path,label)=>origin+path+'?token='+encodeURIComponent(run+'-'+label);
async function call(label,method,params,sessionId=sessionA,client=clientA,{allowProtocolError=false}={}){
 const step={label,connection:client.label,method,params,sessionId,httpBefore:record.http.length,wireBefore:record.wire.length,startedAt:performance.now()};activeGroup.steps.push(step);await flush();
 try{step.reply=await client.send(method,params,sessionId);if(step.reply.error&&!allowProtocolError)throw Object.assign(new Error('Observed protocol error: '+step.reply.error.message),{protocolError:step.reply.error});return step.reply}
 catch(error){step.failure={message:error.message,rpcTimeout:!!error.rpcTimeout,connectionLost:!!error.connectionLost,protocolError:error.protocolError};throw error}
 finally{step.finishedAt=performance.now();step.httpAfter=record.http.length;step.wireAfter=record.wire.length;await flush()}
}
const policy=(label,patterns,sessionId=sessionA,client=clientA)=>call(label,'Network.setBlockedURLs',{urlPatterns:patterns},sessionId,client,{allowProtocolError:true});
async function evaluate(label,expression,sessionId=sessionA,client=clientA){const reply=await call(label,'Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},sessionId,client);if(reply.result?.exceptionDetails)throw Error('Actual JavaScript setup failed '+label);return reply.result}
async function fetchActual(label,address,sessionId=sessionA,client=clientA){record.expectedRequestURLs.push({group:activeGroup.name,label,url:address});return evaluate(label,'(async()=>{try{const r=await fetch('+JSON.stringify(address)+');return{ok:true,status:r.status,url:r.url,body:await r.text()}}catch(e){return{ok:false,name:e.name,message:e.message}}})()',sessionId,client)}
async function newTarget(label,{contextId,client=clientA}={}){const created=await call(label+'-target','Target.createTarget',{url:'about:blank',...(contextId?{browserContextId:contextId}:{})},null,client);const targetId=created.result.targetId;targets.add(targetId);const attached=await call(label+'-attach','Target.attachToTarget',{targetId,flatten:true},null,client);const sessionId=attached.result.sessionId;await call(label+'-network','Network.enable',{},sessionId,client);await call(label+'-page-events','Page.enable',{},sessionId,client);await call(label+'-runtime-events','Runtime.enable',{},sessionId,client);return{targetId,sessionId,client}}
async function navigateReady(label,target,address){record.expectedRequestURLs.push({group:activeGroup.name,label,url:address});await call(label,'Page.navigate',{url:address},target.sessionId,target.client);await evaluate(label+'-actual-load','new Promise(resolve=>{if(document.readyState==="complete")resolve({ready:document.readyState,url:location.href});else addEventListener("load",()=>resolve({ready:document.readyState,url:location.href}),{once:true})})',target.sessionId,target.client)}
const group=async(name,body)=>{activeGroup={name,steps:[],completed:false,httpBefore:record.http.length,wireBefore:record.wire.length};record.groups.push(activeGroup);await flush();try{await body();activeGroup.completed=true}catch(error){activeGroup.failure={message:error.message,stack:error.stack,rpcTimeout:!!error.rpcTimeout,connectionLost:!!error.connectionLost};throw error}finally{activeGroup.httpAfter=record.http.length;activeGroup.wireAfter=record.wire.length;await flush()}};
try{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;record.origin=origin;
 browser=await startRoot(binary);record.pid=browser.process.pid;record.endpoint=browser.endpoint;clientA=await connectRaw(browser.endpoint,{label:'A',wire:record.wire,events:record.events,flush,timeout:2500});clients.push(clientA);
 await group('1-schema-context-and-atomicity',async()=>{
  for(const[label,params]of[['root-valid-empty',{urlPatterns:[]}],['root-missing',{}],['root-legacy-urls',{urls:['*']}]] )await call(label,'Network.setBlockedURLs',params,null,clientA,{allowProtocolError:true});
  const target=await newTarget('A');targetA=target.targetId;sessionA=target.sessionId;await navigateReady('A-harness',target,url('/page','schema'));
  for(const[label,params]of[['missing-list',{}],['null-list',{urlPatterns:null}],['string-list',{urlPatterns:'*'}],['null-entry',{urlPatterns:[null]}],['string-entry',{urlPatterns:['*']}],['missing-pattern',{urlPatterns:[{block:true}]}],['missing-block',{urlPatterns:[{urlPattern:'*'}]}],['numeric-pattern',{urlPatterns:[{urlPattern:3,block:true}]}],['numeric-block',{urlPatterns:[{urlPattern:'*',block:1}]}]])await call(label,'Network.setBlockedURLs',params,sessionA,clientA,{allowProtocolError:true});
  const atomic=url('/atomic/value','atomic');await policy('install-atomic',[{urlPattern:origin+'/atomic/*',block:true}]);await call('mixed-invalid-replacement','Network.setBlockedURLs',{urlPatterns:[{urlPattern:'*',block:false},{urlPattern:7,block:true}]},sessionA,clientA,{allowProtocolError:true});await fetchActual('atomic-policy-after-rejection',atomic);await policy('schema-clear',[]);
 });
 await group('2-real-allowed-baseline',async()=>{await call('disable-cache','Network.setCacheDisabled',{cacheDisabled:true});await navigateReady('allowed-navigation',{sessionId:sessionA,client:clientA},url('/page','baseline'));await fetchActual('allowed-fetch-bytes',url('/bytes/baseline','baseline'))});
 record.finished=true;
}catch(error){record.failure={message:error.message,stack:error.stack,rpcTimeout:!!error.rpcTimeout,connectionLost:!!error.connectionLost}}
finally{
 record.ownedResourcesBeforeCleanup={targets:[...targets],contexts:[...contexts],clients:clients.map(client=>client.label)};

 for(const client of clients.reverse())try{await client.close()}catch(error){(record.cleanupErrors??=[]).push({client:client.label,message:error.message})}
 try{await browser?.close()}catch(error){(record.cleanupErrors??=[]).push({browser:true,message:error.message})}
 server.closeAllConnections();await new Promise(resolve=>server.close(resolve));record.stderr=browser?.stderr;record.stderrTruncated=browser?.stderrTruncated;
 record.requestReachability=record.expectedRequestURLs.map(expected=>{const owner=record.groups.find(group=>group.name===expected.group),step=owner?.steps.find(step=>step.label===(expected.stepLabel??expected.label));return{...expected,operationHttpRange:step?{before:step.httpBefore,after:step.httpAfter}:null,receivedDuringObservedOperation:step?record.http.slice(step.httpBefore,step.httpAfter).filter(item=>origin+item.url===expected.url).map(item=>item.sequence):null,receivedByFinalSnapshot:record.http.filter(item=>origin+item.url===expected.url).map(item=>item.sequence)}});
 await flush();await writes;await writeFile(output,JSON.stringify(record,null,2)+'\n',{flag:'wx'});
}
console.log(JSON.stringify({pid:record.pid,groups:record.groups.map(group=>({name:group.name,completed:group.completed,failure:group.failure})),httpReceipts:record.http.length,wireMessages:record.wire.length,failure:record.failure}));
