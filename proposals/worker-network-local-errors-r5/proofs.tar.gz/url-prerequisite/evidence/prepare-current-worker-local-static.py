from pathlib import Path
import hashlib,json,difflib,shutil,subprocess
p=Path('/workspace/shared/network-url-blocking-recovery');root=Path('/workspace/red-panda');new=Path('/workspace/shared/worker-local-errors-r5');assert not new.exists();(new/'evidence').mkdir(parents=True);base=new/'base-root-5adb9b3';candidate=new/'candidate'
for folder in ['src','test','bin','native','scripts']:
 if(root/folder).exists():shutil.copytree(root/folder,base/folder,ignore=shutil.ignore_patterns('build'))
for name in ['package.json','package-lock.json','VERSION']:
 if(root/name).is_file():shutil.copy2(root/name,base/name)
shutil.copytree(base,candidate)
for target in [base,candidate]:(target/'node_modules').symlink_to(root/'node_modules',target_is_directory=True)
# Copy read-only old SDK artifacts into a separately named archive; candidate
# native/build is deliberately absent until a real matching helper rebuild.
if(p/'candidate-r4/native/build').exists():shutil.copytree(p/'candidate-r4/native/build',new/'prior-native-artifacts')
H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();mapping={};changes=[]
for name in ['src/browser.js','src/cdp.js','src/fetch.js','src/sync-http.js','src/url-blocking.js','src/workers.js','test/url-blocking.test.js','test/worker-startup-errors.test.js']:
 old=p/'root-d41-baseline'/name;target=p/'candidate-r4'/name;dest=candidate/name;actual=dest.read_text()if dest.exists()else None
 if not old.exists():
  assert actual is None,(name,'unexpected existing current leaf');result=target.read_text()
 else:
  result=actual;a=old.read_text().splitlines(True);b=target.read_text().splitlines(True)
  for tag,i,j,k,l in reversed(difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes()):
   if tag=='equal':continue
   removed=''.join(a[i:j]);added=''.join(b[k:l])
   if removed:
    if name=='src/cdp.js' and "case 'Target.createBrowserContext'" in removed:
     composed=removed.replace(';return {browserContextId:id};',';rememberFileInputContext(this,browser.contexts.get(id));return {browserContextId:id};')
     assert result.count(composed)==1,(name,'current genuine File producer context')
     added=added.replace(';return {browserContextId:id};',';rememberFileInputContext(this,browser.contexts.get(id));return {browserContextId:id};')
     result=result.replace(composed,added)
    else:
     assert result.count(removed)==1,(name,'exact replacement');result=result.replace(removed,added)
   elif i==0:result=added+result
   else:
    anchor=''.join(a[max(0,i-2):i]);assert result.count(anchor)==1,(name,'exact insertion');result=result.replace(anchor,anchor+added)
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(result);mapping[name]={'before':H(base/name)if(base/name).exists()else None,'afterPrerequisite':H(dest)};changes.append(name)
# Genuine public V8 metadata extraction is a proposal; not compiled. It returns
# only engine locations, never authored .stack/name/message/getters. NativeError
# gate and the caller's real private compiled-origin registry bound its use.
f=candidate/'native/runtime.cc';s=f.read_text();needle='NODE_MODULE_INIT() {';assert s.count(needle)==1
helper=r'''// Privileged Worker-local error origin reader. No JavaScript property lookup,
// stack formatter, prototype/name test or script evaluation is performed.
void ErrorOrigin(const FunctionCallbackInfo<Value>& info) {
  auto* isolate = info.GetIsolate();
  const auto context = isolate->GetCurrentContext();
  if (info.Length() != 1 || !info[0]->IsNativeError() || info[0]->IsProxy()) {
    info.GetReturnValue().Set(Null(isolate));
    return;
  }
  const auto message = Exception::CreateMessage(isolate, info[0]);
  const auto filename = message->GetScriptResourceName();
  const int line = message->GetLineNumber(context).FromMaybe(0);
  const int column = message->GetStartColumn(context).FromMaybe(-1);
  if (!filename->IsString() || line <= 0 || column < 0) {
    info.GetReturnValue().Set(Null(isolate));
    return;
  }
  const auto result = Object::New(isolate);
  result->CreateDataProperty(context, String::NewFromUtf8Literal(isolate, "filename"), filename).Check();
  result->CreateDataProperty(context, String::NewFromUtf8Literal(isolate, "lineno"), Integer::New(isolate, line)).Check();
  // V8's source column index is zero based; ErrorEvent coordinates are one based.
  result->CreateDataProperty(context, String::NewFromUtf8Literal(isolate, "colno"), Integer::New(isolate, column + 1)).Check();
  info.GetReturnValue().Set(result);
}

'''
s=s.replace(needle,helper+needle);needle='  Isolate* isolate = Isolate::GetCurrent();\n';assert s.count(needle)==1;s=s.replace(needle,needle+'  exports->CreateDataProperty(context, String::NewFromUtf8Literal(isolate, "errorOrigin"), Function::New(context, ErrorOrigin).ToLocalChecked()).Check();\n');f.write_text(s)
# Captured Host wrapper: authentic native trace + actual successful compilation
# origin set; no public worker URL, error stack or user-provided tag authority.
(candidate/'src/worker-error-origin.js').write_text("""import{getRuntimeBinding}from'./native-runtime.js';
export function workerErrorOrigins(){
 const actualOrigins=new Set();
 return Object.freeze({
  compiled(url){actualOrigins.add(url)},
  read(value){const reader=getRuntimeBinding().errorOrigin;if(typeof reader!=='function')throw new Error('A matching Worker error-origin runtime build is required');const result=reader(value);return result&&actualOrigins.has(result.filename)?result:null},
 });
}
""")
# Public surface and forwarding changes will be based on Native heldouts, not
# inferred constructor defaults, primitive throw positions or handler recursion.
manifest={'rootCommit':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'rootBeforeSource':{str(x.relative_to(root)):H(x)for x in sorted((root/'src').rglob('*'))if x.is_file()},'prerequisite':'URLblockingR2 +startupWorkerR3/R4 immutable source deltas only','prerequisiteLeaves':mapping,'helperProposalSHA256':H(candidate/'native/runtime.cc'),'privateOriginAdapterSHA256':H(candidate/'src/worker-error-origin.js'),'status':'STATIC_UNRUN_UNBUILT; no old native artifact installed under new source','rootEdits':False}
(new/'evidence/static-current-root-prerequisite.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'directory':str(new),'helperSHA256':H(candidate/'native/runtime.cc'),'manifestSHA256':H(new/'evidence/static-current-root-prerequisite.json'),'nativeBuildExists':(candidate/'native/build').exists()},indent=2))
