from pathlib import Path
import subprocess,json,hashlib,os,signal,time,sys,re
p=Path.cwd();phase=sys.argv[1];sdk=sys.argv[2];assert phase in ['first','regressions'];nodes={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/bin/node','24.19.0':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','26.13.0':'/workspace/shared/node26/node_modules/node/bin/node'};assert sdk in nodes;manifest=p/'evidence/candidate-r4-inputs.json';expected=json.loads(manifest.read_text())
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as source:
  for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def state():return{n:digest(p/n)for n in expected}
assert state()==expected,'Frozen URL/Worker R3 inputs changed'
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union)
tests=['test/url-blocking.test.js','test/worker-startup-errors.test.js']if phase=='first'else json.loads((p/'evidence/candidate-r3-regressions.json').read_text());command=[nodes[sdk],'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*tests];start=time.monotonic();watchdog=False;stem='candidate-r4-'+phase+'-'+sdk;limit = 45 if phase == 'first' else 120
with(p/('evidence/'+stem+'.log')).open('xb')as log:
 child=subprocess.Popen(command,cwd=p/'candidate-r4',stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env)
 try:code=child.wait(timeout=limit)
 except subprocess.TimeoutExpired:
  watchdog=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
after=state();log=(p/('evidence/'+stem+'.log')).read_text();status={'phase':phase,'sdk':sdk,'command':command,'exit':code,'seconds':time.monotonic()-start,'watchdogTriggered':watchdog,'outerWatchdog':limit,'cleanupGrace':3,'inputs':len(expected),'changed':[n for n in expected if after[n]!=expected[n]],'manifestSHA256':digest(manifest),'passes':len(re.findall(r'^ok [0-9]+ - ',log,re.M)),'failures':len(re.findall(r'^not ok [0-9]+ - ',log,re.M)),'canonicalEnv':{'NODE_USE_ENV_PROXY':env['NODE_USE_ENV_PROXY'],'equalBypassLists':env['NO_PROXY']==env['no_proxy'],'unionSHA256':hashlib.sha256(env['NO_PROXY'].encode()).hexdigest(),'proxyTLSPreserved':all(env.get(n)==os.environ.get(n)for n in['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR'])}};(p/('evidence/'+stem+'-status.json')).write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True);sys.exit(0 if code==0 and not watchdog and not status['changed']and status['passes']==(13 if phase == 'first' else 84)and not status['failures']else 1)
