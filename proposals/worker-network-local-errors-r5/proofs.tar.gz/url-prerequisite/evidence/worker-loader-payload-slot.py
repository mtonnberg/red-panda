from pathlib import Path
import subprocess,json,hashlib,os,signal,time,sys
p=Path.cwd();actor='native';manifest=p/'evidence/worker-loader-payload-inputs.json';expected=json.loads(manifest.read_text())
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as source:
  for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def state():return{n:digest(p/n)for n in expected}
assert state()==expected,'Frozen loader-causal inputs changed'
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union)
source='/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux'if actor=='native'else str(p/'candidate-r2');stem='worker-loader-payload-'+actor;command=['/workspace/shared/rea-tools/node_modules/node/bin/node','--experimental-vm-modules','evidence/worker-loader-payload-probe.mjs',actor,source,'evidence/'+stem+'.json'];start=time.monotonic();watchdog=False
with(p/('evidence/'+stem+'.log')).open('xb')as log:
 child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env)
 try:code=child.wait(timeout=15)
 except subprocess.TimeoutExpired:
  watchdog=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
after=state();final=p/('evidence/'+stem+'.json');progress=p/('evidence/'+stem+'.json.progress.json');raw=json.loads(final.read_text())if final.exists()else json.loads(progress.read_text())if progress.exists()else{};groups=raw.get('groups',[]);pid=raw.get('pid');present=bool(pid)and Path('/proc/'+str(pid)).exists();complete=final.exists()and len(groups)==3 and all(g.get('completed')is True for g in groups)and raw.get('finished')is True and not raw.get('failure')and not raw.get('cleanupErrors');status={'actor':actor,'command':command,'exit':code,'seconds':time.monotonic()-start,'rpcTimeout':2500,'outerWatchdog':15,'cleanupGrace':3,'watchdogTriggered':watchdog,'inputs':len(expected),'changed':[n for n in expected if after[n]!=expected[n]],'manifestSHA256':digest(manifest),'groups':len(groups),'completedGroups':sum(g.get('completed')is True for g in groups),'complete':complete,'producerPID':pid,'producerPresentAfterCleanup':present,'rawFile':str(final if final.exists()else progress),'httpReceipts':len(raw.get('http',[])),'wireMessages':len(raw.get('wire',[])),'canonicalEnv':{'NODE_USE_ENV_PROXY':env['NODE_USE_ENV_PROXY'],'equalBypassLists':env['NO_PROXY']==env['no_proxy'],'unionSHA256':hashlib.sha256(env['NO_PROXY'].encode()).hexdigest(),'proxyTLSPreserved':all(env.get(n)==os.environ.get(n)for n in['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR'])}};(p/('evidence/'+stem+'-status.json')).write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True);sys.exit(0 if code==0 and not watchdog and not status['changed']and complete and not present else 1)
