// SOURCE ONLY, UNCOMPILED/UNRUN. R2 over the exact frozen provider R1.
#include <cppgc/persistent.h>
#include <node.h>
#include <v8.h>
#include "node_contextify.h"
#include "node_test_fixture.h"

using node::contextify::ContextifyContext;
using namespace v8;
class OwnedContextCollisionTest : public EnvironmentTestFixture {};
namespace {
struct Roots {
  Global<Function> retained;
  Global<Context> weak_context;
  Global<Object> weak_carrier;
  Global<Object> weak_wrapper;
  cppgc::WeakPersistent<ContextifyContext> weak_cppgc;
};
V8_NOINLINE void PrepareOrdinaryAfterRejection(
    Isolate* isolate, node::Environment* env, Local<Context> host, Roots* roots) {
  HandleScope handles(isolate);
  Local<Object> carrier = node::LoadEnvironment(env,
      "const vm=require('node:vm');"
      "return vm.createContext(vm.prepareOwnedContext());")
      .ToLocalChecked().As<Object>();
  auto* before = ContextifyContext::ContextFromContextifiedSandbox(env, carrier);
  ASSERT_NE(before, nullptr);
  ASSERT_FALSE(before->is_owned());
  Local<Context> ordinary = before->context();
  Local<Object> original_wrapper = before->object(isolate);
  Local<Value> original_id = carrier->GetPrivate(
      host, env->host_defined_option_symbol()).ToLocalChecked();
  {
    TryCatch caught(isolate);
    node::OwnedContextOptions options;
    ASSERT_TRUE(node::CreateOwnedContext(env, carrier,
        ObjectTemplate::New(isolate), host->GetSecurityToken(), options).IsEmpty());
    ASSERT_TRUE(caught.HasCaught());
    Local<Value> code = caught.Exception().As<Object>()->Get(
        host, String::NewFromUtf8Literal(isolate, "code")).ToLocalChecked();
    ASSERT_TRUE(code->StrictEquals(
        String::NewFromUtf8Literal(isolate, "ERR_INVALID_STATE")));
  }
  auto* after = ContextifyContext::ContextFromContextifiedSandbox(env, carrier);
  ASSERT_EQ(after, before);
  ASSERT_EQ(after->context(), ordinary);
  ASSERT_EQ(after->object(isolate), original_wrapper);
  ASSERT_TRUE(carrier->GetPrivate(host, env->host_defined_option_symbol())
      .ToLocalChecked()->StrictEquals(original_id));
  ASSERT_TRUE(carrier->GetPrivate(host, env->owned_context_pending_symbol())
      .ToLocalChecked()->IsTrue());
  ASSERT_TRUE(ordinary->GetEmbedderData(node::ContextEmbedderIndex::kSandboxObject)
      ->StrictEquals(carrier));
  roots->weak_cppgc = after;
  roots->weak_context.Reset(isolate, ordinary);
  roots->weak_context.SetWeak();
  roots->weak_carrier.Reset(isolate, carrier);
  roots->weak_carrier.SetWeak();
  roots->weak_wrapper.Reset(isolate, original_wrapper);
  roots->weak_wrapper.SetWeak();
  Context::Scope scope(ordinary);
  Local<Function> fn = Script::Compile(ordinary,
      String::NewFromUtf8Literal(isolate, "globalThis.marker=23; ()=>marker"))
      .ToLocalChecked()->Run(ordinary).ToLocalChecked().As<Function>();
  roots->retained.Reset(isolate, fn);
}
V8_NOINLINE void CheckRetained(Isolate* isolate,
                               Local<Context> host, Roots* roots) {
  HandleScope handles(isolate);
  EXPECT_NE(roots->weak_cppgc.Get(), nullptr);
  EXPECT_EQ(roots->retained.Get(isolate)
      ->Call(host, Undefined(isolate), 0, nullptr).ToLocalChecked()
      .As<Number>()->Value(), 23);
}
}  // namespace
TEST_F(OwnedContextCollisionTest, RejectPreservesOrdinaryWrapperAndRetention) {
  const HandleScope handles(isolate_);
  const Argv argv;
  Env env{handles, argv};
  Roots roots;
  PrepareOrdinaryAfterRejection(isolate_, *env, env.context(), &roots);
  ASSERT_FALSE(roots.retained.IsEmpty());
  isolate_->LowMemoryNotification();
  platform->DrainTasks(isolate_);
  ASSERT_FALSE(roots.weak_context.IsEmpty());
  ASSERT_FALSE(roots.weak_carrier.IsEmpty());
  ASSERT_FALSE(roots.weak_wrapper.IsEmpty());
  CheckRetained(isolate_, env.context(), &roots);
  roots.retained.Reset();
  for (int i = 0; i < 8; ++i) {
    isolate_->LowMemoryNotification();
    platform->DrainTasks(isolate_);
  }
  EXPECT_TRUE(roots.weak_context.IsEmpty());
  EXPECT_TRUE(roots.weak_carrier.IsEmpty());
  EXPECT_TRUE(roots.weak_wrapper.IsEmpty());
  EXPECT_EQ(roots.weak_cppgc.Get(), nullptr);
}
