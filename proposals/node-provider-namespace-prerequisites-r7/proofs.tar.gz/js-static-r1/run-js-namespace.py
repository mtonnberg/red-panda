#!/usr/bin/env python3
"""Independent original JSnamespace3 only. No builds, installs, or original-cohort resumption."""
from pathlib import Path
import argparse,hashlib,json,os,resource,signal,subprocess,sys,time
D=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Assertions may not be disabled')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def ident(pid):
 try:
  s=Path(f'/proc/{pid}/stat').read_text();a=s[s.rfind(')')+2:].split();return{'pid':pid,'state':a[0],'ppid':int(a[1]),'pgid':int(a[2]),'sid':int(a[3]),'startTicks':a[19],'argv':Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace').rstrip('\0').split('\0')}
 except(FileNotFoundError,ProcessLookupError):return None
def same(a,b):return a is not None and b is not None and a['pid']==b['pid']and a['startTicks']==b['startTicks']
def session(sid):
 rows=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   row=ident(int(p.name))
   if row and row['sid']==sid:rows.append(row)
 return rows
def check(paths):
 actual={};mismatch={}
 for name,want in paths.items():
  try:value=sha(name)
  except OSError as e:value='UNREADABLE:'+str(e)
  actual[name]=value
  if value!=want:mismatch[name]={'expected':want,'actual':value}
 return{'stable':not mismatch,'count':len(paths),'actual':actual,'mismatches':mismatch}
def strict_equal(actual,expected):
 if type(actual)is not type(expected):return False
 if isinstance(expected,dict):return actual.keys()==expected.keys()and all(strict_equal(actual[k],v)for k,v in expected.items())
 if isinstance(expected,list):return len(actual)==len(expected)and all(strict_equal(a,b)for a,b in zip(actual,expected))
 return actual==expected
def no_duplicates(pairs):
 out={}
 for k,v in pairs:
  if k in out:raise ValueError('Duplicate JSON object key: '+k)
  out[k]=v
 return out
def forbidden_constant(x):raise ValueError('Non-JSON constant: '+x)
p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--epoch',required=True);args=p.parse_args();assert args.epoch and all(c.isalnum()or c in '-_'for c in args.epoch)
assert sha(D/'manifest.json')==args.manifest_sha,'Reviewed exact manifest mismatch'
m=json.loads((D/'manifest.json').read_text());out=D/'evidence'/args.epoch;out.mkdir(parents=True,exist_ok=False)
paths=dict(json.loads((D/'input-guards.json').read_text())['files']);paths.update({str(D/n):h for n,h in m['files'].items()});paths[str(D/'manifest.json')]=args.manifest_sha
plan=json.loads((D/'command-plan.json').read_text());command=plan['exactNodeCommand'];assert len(command)==3 and command[1]=='--experimental-vm-modules'
assert plan['caps']=={'originalNodeStageSeconds':45,'TERMGraceSeconds':3,'scopedAggregateSeconds':65,'outerSeconds':80}
report={'state':'SETUP','scope':'Independent currentRoot646 originalJSnamespace3 families only; not resumed13stage or fullprovider acceptance','sourceCommit':'1d88e2d023a9ed3f074f0de41d531e1fd20117fd','command':command,'cwd':str(out),'caps':plan['caps'],'originalProxy45AndLater10UNRUN':'PRESERVED; independent results cannot rewrite original report','originalNamespaceProgramUnchanged':True,'RootInstallation':'NONE','buildAddonSourceOrCacheChanges':'NONE','observations':None,'python':{'executable':sys.executable,'version':sys.version},'original840GuardRows':840,'guardRowsIncludingOwnSources':len(paths)}
start=time.monotonic();child=None;saved=None;captured={};preflight=None;completed=False

def save():report['elapsedSeconds']=time.monotonic()-start;write(out/'report.json',report)
def interrupted(n,f):raise InterruptedError('Controller signal '+str(n))
def alarm(n,f):report['aggregateAdministrativeTimeout']=True;raise TimeoutError('Independent65s aggregate cap')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,65)
def capture():
 if saved:
  for row in session(saved['sid']):captured.setdefault(row['pid'],row)
def live():
 result=[]
 for old in captured.values():
  now=ident(old['pid'])
  if same(old,now)and now['state']not in ['Z','X']:result.append(now)
 return result
def signal_owned(sig):
 capture();rows=live();report.setdefault('signals',[]).append({'signal':int(sig),'authenticatedMembers':rows})
 for row in rows:
  now=ident(row['pid'])
  if same(row,now):
   assert now['sid']==saved['sid']and now['pid']!=os.getpid()
   try:os.kill(now['pid'],sig)
   except ProcessLookupError:pass
try:
 preflight=check(paths);write(out/'inputs-before.json',preflight);assert preflight['stable'],'Frozen guard mismatch before child'
 old=json.loads((D/'reference/original-controls-1-report.json').read_text());assert old['status']=='STOPPED_FIRST_NONZERO_TIMEOUT_OR_MISSING_OBSERVATION'and old['stages'][-1]['administrativeTimeout']and'r4-namespace-js'in old['unrunStages']
 cpp=json.loads((D/'reference/cpp-namespace2-report.json').read_text());assert cpp['stages'][0]['returnCode']==0 and cpp['stages'][0]['actualGtest']['exactExpectedRUNAndOKOnceEach']and len(cpp['stages'][0]['actualGtest']['actualOK'])==2
 report['antecedents']={'original13StageReportSHA256':sha(D/'reference/original-controls-1-report.json'),'independentCppNamespace2ReportSHA256':sha(D/'reference/cpp-namespace2-report.json'),'priorCppIsNotJSObservation':True}
 env=os.environ.copy();addon=plan['environmentOverrideOnly']['OWNED_PROVIDER_ADDON'];env['OWNED_PROVIDER_ADDON']=addon
 assert env['OWNED_PROVIDER_ADDON']==m['addon']['path']and sha(addon)==m['addon']['sha256']and sha(command[0])==m['customNode']['sha256']
 report['environment']={'onlyOverride':{'OWNED_PROVIDER_ADDON':addon},'inheritedEverythingElsePreserved':all(env.get(k)==v for k,v in os.environ.items()if k!='OWNED_PROVIDER_ADDON'),'recorded':[{'name':k,'present':k in os.environ,'bytes':len(os.environ.get(k,'').encode()),'sha256':hashlib.sha256(os.environ.get(k,'').encode()).hexdigest()}for k in ['NODE_PATH','NODE_OPTIONS','NODE_COMPILE_CACHE','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR','OWNED_PROVIDER_ADDON']]}
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  began=time.monotonic();child=subprocess.Popen(command,cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);saved=ident(child.pid);assert saved is not None and saved['sid']==child.pid,'Actual owned child identity missing';captured[child.pid]=saved;report['identity']=saved;save()
  while child.poll()is None:
   capture()
   if time.monotonic()-began>=45:report['administrativeTimeout']=True;signal_owned(signal.SIGTERM);break
   time.sleep(.02)
  if child.poll()is None:
   try:child.wait(timeout=3)
   except subprocess.TimeoutExpired:signal_owned(signal.SIGKILL);child.wait(timeout=3)
  report['returnCode']=child.returncode;report['stageSeconds']=time.monotonic()-began
  capture()
 raw=(out/'stdout.log').read_bytes();report['stdoutSHA256']=hashlib.sha256(raw).hexdigest();report['stderrSHA256']=sha(out/'stderr.log')
 if child.returncode==0 and not report.get('administrativeTimeout'):
  actual=json.loads(raw.decode('utf-8'),object_pairs_hook=no_duplicates,parse_constant=forbidden_constant);expected=json.loads((D/'expected-rows.json').read_text());report['observations']={'actual':actual,'expectedFamilies':['Host-first','VM-getter','dynamic'],'strictExact3RowsAndBoundary':strict_equal(actual,expected),'actualRows':len(actual.get('rows',[]))if isinstance(actual,dict)else None};assert report['observations']['strictExact3RowsAndBoundary'],'Actual namespace JSON row/value/shape mismatch';completed=True
 else:report['state']='STOPPED_ACTUAL_NONZERO_OR45S_TIMEOUT'
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};report['state']='STOPPED_SETUP_OR_OBSERVATION_OR_CONTROLLER'
finally:
 # Disable the aggregate alarm only during bounded ownership closure/final guard.
 signal.setitimer(signal.ITIMER_REAL,0)
 if child and saved is None and child.poll()is None:
  report['cleanupWithoutStartIdentity']='Only actual unreaped Popen direct child may be terminated; acceptance remains failed'
  child.terminate()
  try:child.wait(timeout=3)
  except subprocess.TimeoutExpired:child.kill();child.wait(timeout=3)
 if child:
  capture();report['membersBeforeCleanup']=list(captured.values());report['liveBeforeCleanup']=live()
  if live():
   signal_owned(signal.SIGTERM);until=time.monotonic()+3
   while live()and time.monotonic()<until:time.sleep(.02)
   if live():signal_owned(signal.SIGKILL)
  if child.poll()is None:
   try:child.wait(timeout=3)
   except subprocess.TimeoutExpired:report['cleanupFailure']='Actual child not reaped after KILL'
  report['leaderAfter']=ident(child.pid);report['finalLiveSurvivors']=live();report['terminatedZombies']=[r for r in session(saved['sid'])if r['state']=='Z']if saved else[]
 after=check(paths);write(out/'inputs-after.json',after);report['inputsStable']=after['stable'];report['rawInputsAndRoot646Native18Guarded']=True
 if completed and after['stable']and not report.get('failure')and not report.get('aggregateAdministrativeTimeout')and not report.get('finalLiveSurvivors')and not report.get('cleanupFailure')and not report.get('liveBeforeCleanup'):report['state']='INDEPENDENT_ORIGINAL_JS_NAMESPACE3_OBSERVED_NOT_FULL_PROVIDER_ACCEPTANCE'
 elif not after['stable']:report['state']='GUARD_FAILURE'
 elif completed:report['state']='OWNED_RESOURCE_CLEANUP_REQUIRED_OR_FAILED'
 save();print(json.dumps({'state':report['state'],'report':str(out/'report.json'),'actualRows':report.get('observations',{}).get('actualRows')if report.get('observations')else 0,'elapsedSeconds':report['elapsedSeconds'],'inputsStable':report['inputsStable'],'liveSurvivors':report.get('finalLiveSurvivors',[])},indent=2))
raise SystemExit(0 if report['state']=='INDEPENDENT_ORIGINAL_JS_NAMESPACE3_OBSERVED_NOT_FULL_PROVIDER_ACCEPTANCE'else 1)
