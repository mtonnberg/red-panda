#!/usr/bin/env python3
"""80s administrative envelope for one separately reviewed65s namespace cohort."""
from pathlib import Path
import argparse,json,os,signal,subprocess,sys,time
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--epoch',required=True);a=p.parse_args();assert a.epoch and all(c.isalnum()or c in '-_'for c in a.epoch)
out=D/'outer-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
command=[sys.executable,'-I',str(D/'run-js-namespace.py'),'--manifest-sha',a.manifest_sha,'--epoch',a.epoch]
started=time.monotonic();child=None;known={};record={'state':'SETUP','outerCapSeconds':80,'command':command,'noEnvironmentOverrides':True}
def interrupted(n,f):raise InterruptedError('Outer controller signal '+str(n))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
def identity(pid):
 try:
  s=Path(f'/proc/{pid}/stat').read_text();x=s[s.rfind(')')+2:].split();return{'pid':pid,'state':x[0],'ppid':int(x[1]),'sid':int(x[3]),'startTicks':x[19]}
 except(FileNotFoundError,ProcessLookupError):return None
def same(old,now):return old and now and old['pid']==now['pid']and old['startTicks']==now['startTicks']
def observe():
 rows=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   x=identity(int(p.name))
   if x:rows.append(x)
 # Fixed point catches each actual descendant even after Node creates its own session.
 changed=True
 while changed:
  changed=False
  for x in rows:
   if x['pid']==child.pid or x['ppid']in known:
    if x['pid']not in known:known[x['pid']]=x;changed=True
    elif not same(known[x['pid']],x):record.setdefault('reusedPIDs',[]).append(x)
def live():return[x for old in known.values()if same(old,x:=identity(old['pid']))and x['state']not in ['Z','X']]
def signal_owned(sig):
 observe();current=live();record.setdefault('signals',[]).append({'signal':int(sig),'members':current})
 for x in reversed(current):
  if same(x,identity(x['pid'])):
   try:os.kill(x['pid'],sig)
   except ProcessLookupError:pass
try:
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  child=subprocess.Popen(command,cwd=D,env=os.environ.copy(),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True);record['childPID']=child.pid
  while child.poll()is None:
   observe()
   if time.monotonic()-started>=80:record['administrativeTimeout']=True;signal_owned(signal.SIGTERM);break
   time.sleep(.03)
  if child.poll()is None:
   try:child.wait(timeout=3)
   except subprocess.TimeoutExpired:signal_owned(signal.SIGKILL);child.wait(timeout=3)
  record['exit']=child.returncode
except BaseException as e:record['failure']={'type':type(e).__name__,'message':str(e)}
finally:
 if child:
  observe();record['ownedBeforeCleanup']=live()
  if live():
   signal_owned(signal.SIGTERM);deadline=time.monotonic()+3
   while live()and time.monotonic()<deadline:time.sleep(.03)
   if live():signal_owned(signal.SIGKILL)
  if child.poll()is None:
   try:child.wait(timeout=3)
   except subprocess.TimeoutExpired:record['cleanupFailure']='Unreaped owned child after KILL'
  record['ownedAfterCleanup']=live();record['identities']=list(known.values())
 record['seconds']=time.monotonic()-started;record['state']='CONTROLLER_EXIT0_AND_OWNED_CLOSED'if record.get('exit')==0 and not record.get('administrativeTimeout')and not record.get('ownedBeforeCleanup')and not record.get('ownedAfterCleanup')and not record.get('failure')and not record.get('cleanupFailure')else'FAILED_OR_TIMEOUT_OR_CLEANUP_REQUIRED';(out/'status.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
raise SystemExit(0 if record['state']=='CONTROLLER_EXIT0_AND_OWNED_CLOSED'else 1)
