#!/usr/bin/env python3
"""UNRUN until separately granted. Two existing C3 CCTest filters; never builds."""
from pathlib import Path
import argparse,hashlib,json,os,re,signal,subprocess,sys,time
D=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Exact python3 -I command required; assertions may not be disabled')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def identity(pid):
    try:
        text=Path(f'/proc/{pid}/stat').read_text();v=text[text.rfind(')')+2:].split()
        return {'pid':int(pid),'state':v[0],'ppid':int(v[1]),'pgid':int(v[2]),'sid':int(v[3]),'startTicks':v[19],
                'argv':Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace').strip('\0').split('\0')}
    except (FileNotFoundError,ProcessLookupError):return None

def same(saved,current):return saved is not None and current is not None and saved['pid']==current['pid']and saved['startTicks']==current['startTicks']
def members(sid):
    rows=[]
    for f in Path('/proc').iterdir():
        if f.name.isdigit():
            row=identity(int(f.name))
            if row and row['sid']==sid:rows.append(row)
    return sorted(rows,key=lambda row:row['pid'])
def check(paths):
    actual={};mismatch={}
    for path,wanted in paths.items():
        try:value=sha(path)
        except OSError as error:value='UNREADABLE:'+str(error)
        actual[path]=value
        if value!=wanted:mismatch[path]={'expected':wanted,'actual':value}
    return {'count':len(paths),'stable':not mismatch,'actual':actual,'mismatches':mismatch}

def gtest_observations(path,expected):
    raw=path.read_bytes();text=raw.decode(errors='replace');clean=re.sub(r'\x1b\[[0-9;]*m','',text)
    run=re.findall(r'^\[\s*RUN\s*\]\s+(\S+)\s*$',clean,re.M)
    ok=re.findall(r'^\[\s*OK\s*\]\s+(\S+)(?:\s+\([^\r\n]*\))?\s*$',clean,re.M)
    failed=re.findall(r'^\[\s*FAILED\s*\]\s+([^\r\n]*)$',clean,re.M)
    skipped=re.findall(r'^\[\s*SKIPPED\s*\]\s+([^\r\n]*)$',clean,re.M)
    valid=bool(expected)and sorted(run)==sorted(expected)and sorted(ok)==sorted(expected)and not failed and not skipped
    return {'expectedCases':expected,'actualRUN':run,'actualOK':ok,'actualFAILED':failed,'actualSKIPPED':skipped,
            'exactExpectedRUNAndOKOnceEach':valid,'zeroSelectedCannotPass':bool(run),'logSHA256':hashlib.sha256(raw).hexdigest(),'logBytes':len(raw),
            'rawPreserved':True,'normalization':'Only ANSI sequences removed for matching; raw log is unchanged'}

p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--epoch',required=True);a=p.parse_args()
assert a.epoch and all(c.isalnum()or c in '-_'for c in a.epoch),'Fresh safe epoch required'
assert sha(D/'manifest.json')==a.manifest_sha,'Exact separately reviewed manifest required'
manifest=json.loads((D/'manifest.json').read_text())
for name,wanted in manifest['files'].items():assert sha(D/name)==wanted,name
out=D/'evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
plan=json.loads((D/'command-plan.json').read_text());commands=plan['commands'];assert len(commands)==2
originalPaths=json.loads((D/'input-guards.json').read_text())['files'];assert len(originalPaths)==840
paths=dict(originalPaths);paths.update(json.loads((D/'original-plan-protection.json').read_text())['files']);paths.update({str(D/name):wanted for name,wanted in manifest['files'].items()});paths[str(D/'manifest.json')]=a.manifest_sha
expectedGroups=json.loads((D/'expected-cases.json').read_text())['filters']
report={'state':'SETUP','scope':'INDEPENDENT7CPPCASE_PREREQUISITE_INVESTIGATION_NOT_RESUMED13STAGEACCEPTANCE',
        'originalProxy45FailureAnd10HistoricalUNRUN':'UNCHANGED; independent cohort does not relabel original run',
        'sourceCommit':'1d88e2d023a9ed3f074f0de41d531e1fd20117fd','metadataCommit':'396365674d8f88d7750a3e44ce6af4b1594195a3','processCapSeconds':45,'TERMGraceSeconds':3,'aggregateSeconds':110,
        'caseBounds':'Original preliminary+8postrelease GC and16namespace checkpoints unchanged inside authentic C3binary',
        'python':{'executable':sys.executable,'version':sys.version},'stages':[],
        'RootInstallation':'NONE','buildAddonOrSourceChanges':'NONE','environment':'Inherited unchanged including managed proxy/CA/TLS/NODE_PATH'}
start=time.monotonic();deadline=start+110;active=None

def interrupted(signum,frame):raise InterruptedError('Controller signal '+str(signum))
def aggregate_expired(signum,frame):
    report['aggregateAdministrativeTimeout']=True
    raise TimeoutError('Independent cohort110s aggregate administrative threshold')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
signal.signal(signal.SIGALRM,aggregate_expired);signal.setitimer(signal.ITIMER_REAL,110)
def save():report['elapsedSeconds']=time.monotonic()-start;write(out/'report.json',report)

def authenticated_group(saved,captured):
    if same(saved,identity(saved['pid'])):return True
    # Captured same-session descendants retain identity even if the leader exits.
    return any(same(row,identity(row['pid']))and row['sid']==saved['sid']and row['pgid']==saved['pgid']for row in captured)

def signal_owned_groups(saved,captured,row,signum):
    current=members(saved['sid'])
    for pgid in sorted({r['pgid']for r in current if r['state']!='Z'}):
        cohort=[r for r in current if r['pgid']==pgid and r['state']!='Z']
        assert pgid!=os.getpgrp(),'Refuse controller process group'
        assert all(r['sid']==saved['sid']for r in cohort),'Foreign session in owned cohort'
        assert authenticated_group(saved,captured)or any(same(r,identity(r['pid']))for r in captured if r['pgid']==pgid),'Owned group identity changed'
        row.setdefault('groupSignals',[]).append({'signal':int(signum),'pgid':pgid,'authenticatedMembers':cohort})
        try:os.killpg(pgid,signum)
        except ProcessLookupError:row.setdefault('groupsAlreadyAbsent',[]).append(pgid)

def close_owned(child,saved,row):
    captured=members(saved['sid']);row['membersBeforeCleanup']=captured
    live=[r for r in captured if r['state']!='Z']
    if live:
        signal_owned_groups(saved,captured,row,signal.SIGTERM);row['sentTERM']=True
        until=time.monotonic()+3
        while time.monotonic()<until and any(r['state']!='Z'for r in members(saved['sid'])):time.sleep(.025)
        current=members(saved['sid']);live=[r for r in current if r['state']!='Z']
        if live:signal_owned_groups(saved,captured,row,signal.SIGKILL);row['sentKILL']=True
    try:child.wait(timeout=1)
    except subprocess.TimeoutExpired:row['reapTimeout']=True
    final=members(saved['sid']);row['membersAfterCleanup']=final;row['liveSurvivors']=[r for r in final if r['state']!='Z'];row['terminatedZombies']=[r for r in final if r['state']=='Z']
    row['leaderAfter']=identity(saved['pid']);row['returnCode']=child.returncode
    row['signal']=-child.returncode if child.returncode is not None and child.returncode<0 else None
    assert not row['liveSurvivors'],'Owned live survivors remain'
    assert not same(saved,row['leaderAfter'])or row['leaderAfter']['state']=='Z','Owned leader remains live'

try:
    write(out/'inputs-before.json',paths);before=check(paths);write(out/'preflight.json',before);assert before['stable'],'Input preflight mismatch'
    pins=json.loads((D/'epoch-pins.json').read_text());assert len(pins['Root646'])==646 and len(pins['native18'])==18
    assert pins['focusedProof']['state']=='PASS'and pins['focusedProof']['actualAudioCases']==50 and pins['focusedProof']['inputCount']==13176
    cctest=pins['C3Outputs']['cctest'];assert cctest['sha256']=='9535d9c7d791648581d390a45de9d77ee2728fd588a2b5a25f33c2addfcb0a5b'and sha(cctest['path'])==cctest['sha256']
    report['actualC3Cctest']=cctest;report['Root646DocAndFocusedProofPins']=sha(D/'epoch-pins.json')
    report['recordedEnvironmentOverrides']={name:{'present':name in os.environ,'bytes':len(os.fsencode(os.environ.get(name,''))),'sha256':hashlib.sha256(os.fsencode(os.environ.get(name,''))).hexdigest()}for name in ['GTEST_FILTER','GTEST_REPEAT','GTEST_SHUFFLE','GTEST_TOTAL_SHARDS','GTEST_SHARD_INDEX','GTEST_OUTPUT','NODE_OPTIONS','NODE_PATH','LD_PRELOAD']}
    for index,(command,group)in enumerate(zip(commands,expectedGroups)):
        assert command['capSeconds']==45 and command['argv']==[cctest['path'],'--gtest_filter='+group['filter']]
        assert command['expectedCases']==group['exactCases']
        # Reserve the whole unmodified process cap+3s original grace+6s closure/guard allowance.
        assert deadline-time.monotonic()>=54,'Aggregate does not admit whole original stage cap; later stage staysUNRUN'
        row={'name':command['name'],'command':command['argv'],'cwd':str(out),'status':'STARTED','capSeconds':45,'administrativeTimeout':False};report['stages'].append(row);save()
        stageStart=time.monotonic();log=out/(command['name']+'.log');child=None;saved=None
        try:
            with log.open('xb')as stream:
                child=subprocess.Popen(command['argv'],cwd=out,env=os.environ.copy(),stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                try:
                    saved=identity(child.pid);assert saved and saved['pid']==saved['pgid']==saved['sid'],'Expected fresh owned leader/session'
                except BaseException as error:
                    row['identityCaptureFailure']={'type':type(error).__name__,'message':str(error)}
                    # Popen owns this unreaped direct child; its signal method first polls it to avoid reused-PID signalling.
                    child.terminate()
                    try:child.wait(timeout=3)
                    except subprocess.TimeoutExpired:child.kill();child.wait(timeout=1)
                    row['unidentifiedDirectChildReaped']=child.returncode is not None
                    raise
                row['identity']=saved;active=(child,saved,row);write(out/(command['name']+'-identity.json'),saved);save()
                try:child.wait(timeout=45)
                except subprocess.TimeoutExpired:row['administrativeTimeout']=True
                finally:close_owned(child,saved,row);row['status']='PROCESS_CLOSED_OBSERVATION_PENDING';active=None
        finally:
            row['elapsedSeconds']=time.monotonic()-stageStart
            if log.exists():row['actualGtest']=gtest_observations(log,command['expectedCases'])
            guard=check(paths);write(out/(command['name']+'-inputs-after.json'),guard);row['inputsStable']=guard['stable'];save()
        assert row.get('returnCode')==0 and not row['administrativeTimeout'],'Actual CCTest nonzero/signal/timeout'
        assert row['actualGtest']['exactExpectedRUNAndOKOnceEach'],'Missing/zero/extra/skipped/duplicate actual RUN+OK cases'
        assert row['inputsStable']and not row.get('liveSurvivors'),'Stage integrity/closure failure'
        row['status']='INDEPENDENT_EXPECTED_CASES_OBSERVED';save()
    report['state']='INDEPENDENT_SEVEN_CPP_CASES_OBSERVED_NOT_FULL_PROVIDER_ACCEPTANCE'
except BaseException as error:
    report['state']='STOPPED_FIRST_SETUP_PROCESS_OBSERVATION_INTEGRITY_OR_CLEANUP_FAILURE';report['error']={'type':type(error).__name__,'message':str(error)}
finally:
    signal.setitimer(signal.ITIMER_REAL,0) # Cleanup follows a fired110s threshold under the separate125s outer cap.
    if active is not None:
        try:close_owned(*active)
        except BaseException as error:report['cleanupError']={'type':type(error).__name__,'message':str(error)}
    report['unrunFilters']=[c['name']for c in commands[len(report['stages']):]]
    allMembers=[]
    for row in report['stages']:
        if row.get('identity'):allMembers.extend(members(row['identity']['sid']))
    report['finalOwnedMembers']=allMembers;report['finalLiveSurvivors']=[r for r in allMembers if r['state']!='Z'];report['finalTerminatedZombies']=[r for r in allMembers if r['state']=='Z']
    after=check(paths);write(out/'inputs-after.json',after);report['inputsStable']=after['stable'];report['originalGuardFiles']=840;report['guardFilesIncludingController']=len(paths)
    if not after['stable']or report['finalLiveSurvivors']or report.get('cleanupError'):report['state']='STOPPED_FINAL_INTEGRITY_OR_OWNERSHIP_FAILURE'
    if time.monotonic()-start>110:report['aggregateAdministrativeTimeout']=True;report['state']='STOPPED_AGGREGATE_THRESHOLD_EXCEEDED'
    save();print(json.dumps({'state':report['state'],'actualStages':len(report['stages']),'unrunFilters':report['unrunFilters'],'inputsStable':report['inputsStable'],'liveSurvivors':report['finalLiveSurvivors'],'report':str(out/'report.json')}),flush=True)
raise SystemExit(0 if report['state']=='INDEPENDENT_SEVEN_CPP_CASES_OBSERVED_NOT_FULL_PROVIDER_ACCEPTANCE'else 1)
