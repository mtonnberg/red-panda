"""New immutable Root525+EOF projection: actual Root605 regression115 after positive separateSDK10."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent;O=R/'eof-root605-regressions-r1';assert not O.exists();O.mkdir();P=Path('/workspace/red-panda');C=P;N='/workspace/shared/rea-tools/node_modules/.bin/node';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(root):
 v={str(p.relative_to(root)):sha(p)for d in['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()};v.update({n:sha(root/n)for n in['package.json','package-lock.json']});return v
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
manifest=json.loads((R/'loaded-eof-root525-manifest.json').read_text());plan=json.loads((R/'loaded-eof-525-static/focused-plan.json').read_text());before=identity(P);candidateBefore=identity(C);previousPath=R/'eof-525-sdk-only-r1/status.json';previous=json.loads(previousPath.read_text());assert previous['complete']and len(previous['commands'])==2 and all(c['exit']==0 and c['actualTAPCounts']['pass']==5 and c['actualTAPCounts']['fail']==0 and c['actualTAPCounts']['skipped']==0 for c in previous['commands']);assert all(json.loads((R/'eof-525-sdk-only-r1/after-guards.json').read_text()).values());consumed=previous['seconds'];assert 0<=consumed<180,'No shared budget remains';contracts={str(p):sha(p)for p in[previousPath,R/'eof-525-sdk-only-r1/after-guards.json',R/'run-eof-525-sdk-only-r1.py',R/'run-eof-root605-regressions-r1.py',R/'loaded-eof-root525-manifest.json',R/'loaded-eof-525-static/focused-plan.json',R/'checkpoint9-eof-r2-positive/manifest.json']};write('before.json',{'actualRootBefore':before,'actualRootHEAD':subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip(),'frozen525SourceIdentity':manifest['rootHEAD'],'projection':candidateBefore,'contracts':contracts,'Root525ProjectionNeverRetargetsOriginal5ad600Proof':True,'actualSDKPhaseReportSHA256':sha(previousPath),'previousActiveSeconds':consumed,'availableActiveSeconds':180-consumed})
env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy;commands=[];failure=None

def run(label,node,args,expected):
 begin=time.monotonic();local=env.copy();local['PATH']=str(Path(node).parent)+':'+env.get('PATH','')
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  p=subprocess.Popen([node,*args],cwd=C,env=local,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'started':label,'pid':p.pid}),flush=True);expired=False
  try:code=p.wait(timeout=max(.01,180-consumed-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;os.killpg(p.pid,signal.SIGKILL);p.wait();code=p.returncode
 text=(O/(label+'.stdout')).read_text();counts={k:int(v)for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};row={'label':label,'pid':p.pid,'command':[node,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin,'actualTAPCounts':counts,'expectedCases':expected};commands.append(row);print(json.dumps(row),flush=True)
 if expired or code:raise RuntimeError('Actual composed-graph command failed: '+label)
 assert counts=={'tests':expected,'suites':0,'pass':expected,'fail':0,'cancelled':0,'skipped':0,'todo':0},counts
try:
 assert before==manifest['composedAfter605'],'Actual Root must exactly equal all605 projected source inputs after exact5leaf integration'
 assert candidateBefore==manifest['composedAfter605'],'Owned605 graph changed'
 files=list(plan['combinedNode24_22Tests']);run('Node24.22-combined115',N,['--experimental-vm-modules','--test-reporter=tap','--test-concurrency=1','--test',*[str(C/file)for file in files]],115)
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 guards={'actualRootUnchanged':before==identity(P),'actualRootSecondReadUnchanged':candidateBefore==identity(C),'contractsUnchanged':all(sha(Path(p))==v for p,v in contracts.items())};write('after-guards.json',guards)
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 write('status.json',{'complete':failure is None,'commands':commands,'failure':failure,'seconds':time.monotonic()-started,'administrative180s':True,'remainingSDKCases10':False,'newRoot525Combined115':True,'phase':'actual-root115','previousSDKActiveSeconds':consumed,'totalBothPhasesActiveSeconds':consumed+time.monotonic()-started,'sharedMaximumActiveAdministrativeSeconds':180,'noNativeRepeat':True,'noRootProductionEdits':True,'oldOriginalBudgetsAndAssertionsUnchanged':True,'fullRootAndSource96Unrun':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
