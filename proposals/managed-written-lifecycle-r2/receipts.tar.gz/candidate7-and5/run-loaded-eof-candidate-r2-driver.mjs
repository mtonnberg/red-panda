import http from 'node:http';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {once} from 'node:events';import {writeFile} from 'node:fs/promises';import {programs} from './causal-loaded-eof-programs.mjs';
import {startReference} from '../registration455-adapted-plan-20261031/harness/scripts/reference-server.mjs';
import {connect} from '../registration455-adapted-plan-20261031/harness/test/cdp-client.js';
const engine=process.argv[2],output=process.argv[3];if(!['loadedEOFR2'].includes(engine)||!output)throw Error('Explicit engine and new output required');
const report={engine,ownedBase:'Current0532 real copy +accepted independentR2; EOFcandidate still unrun',rows:[],wire:[],APIReplyMilliseconds:5000,scriptParameterMilliseconds:1000,actualLoadBarrierMilliseconds:2000,publicUAOverrides:false};
const binary=engine==='Native'?'/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux':'/workspace/shared/census-dom-lifecycle-recovery/loaded-close-candidate-r2/red-panda-launcher';
const expected=new Map(JSON.parse(await readFile(new URL('./checkpoint8-eof-native7/raw/Native.json',import.meta.url),'utf8')).rows.map(row=>[row.name,row.value]));
let server,browser,client;
try{
 report.requests=[];const timers=new Set();report.clearTimers=()=>{for(const timer of timers)clearTimeout(timer);timers.clear()};
 server=http.createServer((request,response)=>{const entry={url:request.url,started:Date.now()};report.requests.push(entry);if(request.url.startsWith('/delay-classic.js')||request.url.startsWith('/delay-module.mjs')){const module=request.url.startsWith('/delay-module.mjs'),source=module?'globalThis.moduleDone=true;globalThis.scriptLog.push("module")':'globalThis.scriptDone=true;globalThis.scriptLog.push("script")';const timer=setTimeout(()=>{timers.delete(timer);response.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8'});response.end(source);entry.responded=Date.now();entry.bytes=Buffer.byteLength(source)},25);timers.add(timer);return}response.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});response.end('<!doctype html><title>Owned causal document</title><body>independent control</body>');entry.responded=Date.now()});server.listen(0,'127.0.0.1');await once(server,'listening');report.origin='http://127.0.0.1:'+server.address().port;
 for(const [name,program]of Object.entries(programs)){
  let browserContextId,session;const row={name};report.rows.push(row);
  try{
   browser=await startReference(binary,{args:['--ws-max-concurrent','50','--load-resources','iframe','--load-resources','worker']});row.pid=browser.process.pid;client=await connect(browser.endpoint,{timeout:5000});
   const send=async(method,params={},sid=session)=>{const request={method,params,sessionId:sid};report.wire.push(request);try{const result=await client.send(method,params,sid,{timeout:5000});request.result=result;return result}catch(error){request.error={message:error.message,code:error.code};throw error}};
   browserContextId=(await send('Target.createBrowserContext')).browserContextId;const target=await send('Target.createTarget',{url:'about:blank',browserContextId});session=(await send('Target.attachToTarget',{targetId:target.targetId,flatten:true})).sessionId;
   await send('Page.enable');await send('Runtime.enable');await send('Page.setLifecycleEventsEnabled',{enabled:true});const offset=client.events.length,started=Date.now(),navigation=await send('Page.navigate',{url:report.origin+'/'+name});
   while(Date.now()-started<2000){const load=client.events.slice(offset).find(event=>event.sessionId===session&&event.method==='Page.lifecycleEvent'&&event.params.name==='load'&&event.params.frameId===navigation.frameId);if(load){const state=await send('Runtime.evaluate',{expression:'JSON.stringify({ready:document.readyState,url:document.URL,UA:navigator.userAgent})',returnByValue:true,timeout:1000});if(state.exceptionDetails)throw Error('Document barrier evaluation exception');const value=JSON.parse(state.result.value);if(value.ready==='complete'&&value.url===report.origin+'/'+name&&Date.now()-started<2000){row.barrier={event:load.params,document:value,elapsedMilliseconds:Date.now()-started};break}}await new Promise(resolve=>setTimeout(resolve,5))}
   if(!row.barrier)throw Error('Original 2000ms actual load+complete barrier');
   const result=await send('Runtime.evaluate',{expression:'('+program.toString()+')('+JSON.stringify(report.origin)+').then(value=>JSON.stringify(value))',awaitPromise:true,returnByValue:true,timeout:1000});
   if(result.exceptionDetails){row.exceptionDetails=result.exceptionDetails;throw Error('Actual causal program exception: '+name)}
   row.value=JSON.parse(result.result.value);row.events=client.events.slice(offset);assert.deepStrictEqual(row.value,expected.get(name));row.exactNativeProjection=true;console.log(JSON.stringify({engine,name,pid:row.pid,observed:true}));
  }finally{
   if(browserContextId&&client)try{await client.send('Target.disposeBrowserContext',{browserContextId},undefined,{timeout:5000})}catch(error){row.cleanupError={message:error.message,code:error.code}}
   await client?.close();client=null;await browser?.close();if(browser){row.exit=browser.process.exitCode;row.signal=browser.process.signalCode;row.stderr=browser.stderr}browser=null;
  }
 }
}catch(error){report.failure={name:error.name,message:error.message,stack:error.stack};process.exitCode=1}finally{
 await client?.close();await browser?.close();report.clearTimers?.();delete report.clearTimers;if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
}
