from pathlib import Path
import gzip,hashlib,io,json,tarfile

root=Path('/workspace/red-panda');packet=Path('/workspace/shared/census-dom-lifecycle-recovery');work=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=json.loads((packet/'eof-525-sdk-only-r1/status.json').read_text());gate=json.loads((packet/'eof-root605-regressions-r1/status.json').read_text());assert sdk['complete']and gate['complete']and gate['totalBothPhasesActiveSeconds']<180
assert all(json.loads((packet/'eof-525-sdk-only-r1/after-guards.json').read_text()).values())and all(json.loads((packet/'eof-root605-regressions-r1/after-guards.json').read_text()).values())
assert [c['actualTAPCounts']['pass']for c in sdk['commands']]==[5,5]and gate['commands'][0]['actualTAPCounts']=={'tests':115,'suites':0,'pass':115,'fail':0,'cancelled':0,'skipped':0,'todo':0}
application=json.loads((work/'application.json').read_text());assert len(application['leaves'])==5
for row in application['leaves']:assert sha(root/row['path'])==row['afterSHA256']
dst=root/'proposals/managed-written-lifecycle-r2';dst.mkdir(exist_ok=False);files={}
for label,path in [('native7',packet/'checkpoint8-eof-native7'),('candidate7-and5',packet/'checkpoint9-eof-r2-positive'),('remaining-sdk',packet/'eof-525-sdk-only-r1'),('actual-root',packet/'eof-root605-regressions-r1'),('projection',packet/'loaded-eof-525-static'),('phased-plan',packet/'loaded-eof-525-phased-r1')]:
    for p in sorted(path.rglob('*')):
        if p.is_file():files[label+'/'+str(p.relative_to(path))]=p
for name in ['loaded-eof-root525-manifest.json','run-eof-525-sdk-only-r1.py','run-eof-root605-regressions-r1.py','run-eof-525-sdk-regressions.py']:files['controllers/'+name]=packet/name
for p in sorted(work.iterdir()):
    if p.is_file():files['root-controllers/'+p.name]=p
for row in application['leaves']:files['accepted/'+row['path']]=root/row['path']
manifest={'baseCommit':'525f9b1e7bd1c6fedcc1d02a129b205dd953387c','scope':'Real completed written-parser lifecycle on already-loaded owned documents, genuine phase/generation suppression and dependency-free inline-module synchronous linking/evaluation. Initial bootstrap/fresh blank/popup, mixed/import-bearing graph timing and full original Source row96 remain open.','rootCases':115,'rootSeconds':gate['seconds'],'remainingSDKCasesEach':5,'remainingSDKSeconds':sdk['seconds'],'sharedActiveSeconds':gate['totalBothPhasesActiveSeconds'],'sharedMaximumActiveSeconds':180,'leaves':application['leaves'],'files':[]}
archive=dst/'receipts.tar.gz'
with archive.open('wb')as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
        with tarfile.open(fileobj=gz,mode='w')as tar:
            for name,p in sorted(files.items()):
                b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b));manifest['files'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(archive,'r:gz')as tar:
    assert tar.getnames()==sorted(files)
    for name,p in files.items():assert tar.extractfile(name).read()==p.read_bytes()
manifest['archive']={'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'allFilesReadBackByteExact':True};(dst/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
text=f'''Already-loaded owned documents now complete genuine written-parser lifecycle work synchronously, preserving measured readystatechange/DOMContentLoaded/load reentry and managed-frame delivery. Actual dependency-free inline modules use real V8 linkRequests/instantiate/evaluate and the existing module cache/Promises before lifecycle completion. No source stripping, synthetic readiness or output filtering is used.

Native7 and candidate7 full values match, including real held bytes, inline-module timing and synthetic-versus-genuine event behavior. Five focused tests passed initially, including actual200ms child interruption and real VM module values; child JSON was asserted by the test, not retained as a fabricated separate transcript/PID claim. Node24.19 and26.13 each pass the same5 cases.

Actual Root passes115 combined module/readiness/reset/frame/parser/classic/checkpoint/dispatch-recovery/error/EventCounts/new-feature tests with zero skips/cancellations/failures in{gate['seconds']:.3f}s. RemainingSDK phase:{sdk['seconds']:.3f}s. Both phases use{gate['totalBothPhasesActiveSeconds']:.3f} of the original shared180 active administrative seconds. Only the actual Root regression phase was run; the earlier owned115 controller remains unrun. All605 composed inputs/18 native artifacts and original assertions/budgets remain unchanged.

The five-leaf integration preserves the EventCounts implementation. Bootstrap/fresh-blank/popup producer paths, import-bearing/mixed module graph timing and the full original Source row96 remain incomplete. The last complete2043/129/13 suite remains the97bb0ac graph. Every archived file is verified byte-for-byte; original raw paths/earlier drafts remain retained. Full independent replication is unfinished; keep Red Panda branding.
'''
(dst/'README.md').write_text(text)
with(root/'docs/COMPATIBILITY.md').open('a')as f:f.write('\n\n### Managed written-document lifecycle and inline modules\n\n'+text)
p=root/'README.md';s=p.read_text();marker='File uploads use real disk bytes and timestamps, atomic path validation and stable\n';assert marker in s;s=s.replace(marker,'Already-loaded document rewrites use genuine synchronous lifecycle phases and\nreal dependency-free inline-module evaluation. [Validation](proposals/managed-written-lifecycle-r2/README.md)\nrecords seven matching Native scenarios, five checks on each remaining SDK and\n115 Root regressions; initial bootstrap and broader module graph timing remain open.\n\n'+marker,1);p.write_text(s)
print(json.dumps({'files':len(files),'archiveBytes':archive.stat().st_size,'RootPass':115,'RootSeconds':gate['seconds'],'SDKSeconds':sdk['seconds']}))
