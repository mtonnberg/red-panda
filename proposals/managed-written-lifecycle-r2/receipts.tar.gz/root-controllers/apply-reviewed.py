from pathlib import Path
import hashlib,json,subprocess

root=Path('/workspace/red-panda');packet=Path('/workspace/shared/census-dom-lifecycle-recovery');out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((packet/'loaded-eof-root525-manifest.json').read_text())
assert sha(packet/'loaded-eof-root525-manifest.json')=='1fa7f9d1ada491c12a168466282d000227d88a899f3d83fb0def8e1ce67ef818'
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()=='525f9b1e7bd1c6fedcc1d02a129b205dd953387c'
status=json.loads((packet/'eof-525-sdk-only-r1/status.json').read_text());assert status['complete']and len(status['commands'])==2 and all(c['actualTAPCounts']['pass']==5 and c['exit']==0 for c in status['commands']);assert all(json.loads((packet/'eof-525-sdk-only-r1/after-guards.json').read_text()).values())
before=m['rootBefore602'];after=m['composedAfter605'];leaves={p:after[p]for p in after if before.get(p)!=after[p]};assert len(leaves)==5
def identity():
    v={str(p.relative_to(root)):sha(p)for directory in ['src','test','native','scripts','bin']for p in(root/directory).rglob('*')if p.is_file()and not p.is_symlink()};v.update({n:sha(root/n)for n in ['package.json','package-lock.json']});return v
assert identity()==before
patch=packet/'loaded-eof-525-static/integration.patch';assert sha(patch)=='1d6e8b6e895aedc54e4e0559763212f885667e3c6278b64d56801c1fa9633f92'
subprocess.run(['git','apply','--check',str(patch)],cwd=root,check=True);subprocess.run(['git','apply',str(patch)],cwd=root,check=True);assert identity()==after
record={'baseCommit':'525f9b1e7bd1c6fedcc1d02a129b205dd953387c','leaves':[{'path':p,'beforeSHA256':before.get(p),'afterSHA256':h}for p,h in sorted(leaves.items())],'beforeFiles':len(before),'afterFiles':len(after),'unchangedOriginalFiles':sum(p not in leaves for p in before),'patchSHA256':sha(patch),'remainingSDKPhaseSeconds':status['seconds'],'root115':'UNRUN'}
with(out/'application.json').open('x')as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'appliedLeaves':len(leaves),'before':len(before),'after':len(after),'unchangedOriginal':record['unchangedOriginalFiles'],'root115':'UNRUN'}))
