#!/usr/bin/env python3
"""UNRUN until explicit parent lease. Guards + one owned stock-Node/Native calibration."""
from pathlib import Path
import argparse, hashlib, json, os, signal, socket, subprocess, sys, time
D=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Assertion-disabled Python unsupported; use exact python3 -I command')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def identity(pid):
    try:
        s=Path(f'/proc/{pid}/stat').read_text();parts=s[s.rfind(')')+2:].split()
        return {'pid':int(pid),'state':parts[0],'ppid':int(parts[1]),'pgid':int(parts[2]),'sid':int(parts[3]),'startTicks':parts[19],
                'argv':Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace').strip('\0').split('\0')}
    except (FileNotFoundError,ProcessLookupError):return None

def same(a,b):return a is not None and b is not None and a['pid']==b['pid'] and a['startTicks']==b['startTicks']
def authenticated_member(leader,out):
    if same(leader,identity(leader['pid'])):return True
    f=out/'native-identity.json'
    if not f.is_file():return False
    native=json.loads(f.read_text());now=identity(native['pid'])
    return same(native,now) and now['sid']==leader['sid'] and now['pgid']==leader['pgid']
def session_members(sid):
    result=[]
    for entry in Path('/proc').iterdir():
        if entry.name.isdigit():
            row=identity(int(entry.name))
            if row and row['sid']==sid:result.append(row)
    return sorted(result,key=lambda r:r['pid'])
def port_open(port):
    with socket.socket() as s:
        s.settimeout(.25)
        return s.connect_ex(('127.0.0.1',port))==0

def check(rows):
    result={}
    for name,wanted in rows.items():
        try:actual=sha(name)
        except OSError as error:actual='UNREADABLE:'+str(error)
        if actual!=wanted:result[name]={'expected':wanted,'actual':actual}
    return {'count':len(rows),'stable':not result,'mismatches':result}

def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--epoch',required=True);a=p.parse_args()
assert a.epoch and all(c.isalnum() or c in '-_' for c in a.epoch),'Fresh safe epoch required'
assert sha(D/'manifest.json')==a.manifest_sha,'Use exact separately reviewed manifest'
manifest=json.loads((D/'manifest.json').read_text())
for name,wanted in manifest['files'].items():assert sha(D/name)==wanted,name
out=D/'evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
report={'status':'SETUP','runtimeSubject':'Actual Native only under pinned stock Node; no provider or candidate code loaded','sourceChanges':'NONE','aggregateProcessCapSeconds':100,
        'nativeCalibrationCapSeconds':80,'cleanupMaxAdditionalSeconds':8,'originalProviderFailures':'UNCHANGED; original45s failure and ten laterUNRUN',
        'python':{'executable':sys.executable,'version':sys.version},'command':None,'rootSource645AndNative18Pinned':True}
rows=json.loads((D/'reference/inputs.json').read_text());rows.update({str(D/name):h for name,h in manifest['files'].items()});rows[str(D/'manifest.json')]=a.manifest_sha
write(out/'inputs-before.json',rows)
proc=None;owned=None;start=time.monotonic();log=None

def interrupt(signum,frame):raise InterruptedError('Controller signal '+str(signum))
signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
try:
    before=check(rows);write(out/'preflight.json',before);assert before['stable'],'Preflight input guard failed'
    report['injectedRuntimeEnvironment']={name:bool(os.environ.get(name)) for name in ['NODE_OPTIONS','NODE_PATH','LD_PRELOAD']}
    assert not any(report['injectedRuntimeEnvironment'][name] for name in ['NODE_OPTIONS','LD_PRELOAD']),'Unexpected runtime preload environment; preserve and stop, do not silently clear'
    managed_node_path=os.fsencode(os.environ.get('NODE_PATH',''))
    report['managedNodePath']={'present':'NODE_PATH' in os.environ,'nonempty':bool(managed_node_path),'bytes':len(managed_node_path),
                               'sha256':hashlib.sha256(managed_node_path).hexdigest(),'valueNotPrinted':True,'preservedUnchanged':True,
                               'sourceAuthority':'Pinned Node24.22.1 doc/api/esm.md664-667; this driver has only node: builtin imports'}
    report['managedProxyAndTLS']='Inherited unchanged; no TLS disabling or environment mutation'
    tool=json.loads((D/'toolchain.json').read_text());command=[tool['stockNode']['path'],str(D/'calibrate.mjs'),str(out)]
    report['command']=command;log=(out/'node.log').open('wb')
    proc=subprocess.Popen(command,cwd=D,env=os.environ.copy(),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    owned=identity(proc.pid);assert owned and owned['pid']==owned['sid']==owned['pgid'],'Expected owned group/session leader'
    report['ownedLeader']=owned;write(out/'active-child.json',owned);write(out/'report.json',report)
    deadline=time.monotonic()+100
    while proc.poll() is None:
        if time.monotonic()>=deadline:report['administrativeTimeout']=True;raise TimeoutError('Separate Native controller100s aggregate cap')
        time.sleep(.05)
    report['returnCode']=proc.returncode
    resultPath=out/'native-observations.json';assert resultPath.is_file(),'Actual Native report missing'
    result=json.loads(resultPath.read_text());report['actualNativeReportSHA256']=sha(resultPath);report['actualStatus']=result['status']
    assert proc.returncode==0,'Actual calibration process returned nonzero'
    assert result['status']=='NATIVE_NAV_METADATA_LOCALIZATION_COMPLETE_RETAINED_ASYNC_UNRUN','Localization stopped/incomplete'
    assert result['actualProducerInvocations']==7 and len(result['phases'])==1,'Missing actual ACTIVE baseline observations'
    assert [r['phase'] for r in result['phases']]==['ACTIVE'],'Actual ACTIVE baseline changed'
    assert [r['label'] for r in result['navigationMetadata']]==['fresh-B:capture','fresh-B:graph','retained-A:read','retained-A:moduleRead','retained-A:documentURL','retained-A:windowIdentity','retained-A:documentIdentity','retained-A:publicGraph'],'Actual metadata order changed'
    assert all(r['status']=='RETURNED' for r in result['navigationMetadata']),'Actual metadata response missing'
    assert all(r['status']=='OBSERVED_FINITE_WINDOW' for r in result['phases']),'Missing actual phase observation'
    assert result.get('nativeIdentity') and result.get('nativeTool'),'Actual Native identity/tool observations missing'
    report['status']='NATIVE_METADATA_LOCALIZATION_COMPLETE_RETAINED_ASYNC_UNRUN'
except BaseException as error:
    report['status']='STOPPED';report['error']={'type':type(error).__name__,'message':str(error)}
finally:
    try:
        members=session_members(owned['sid']) if owned else []
        report['membersBeforeExternalCleanup']=members
        live=[r for r in members if r['state']!='Z']
        if live:
            leader=identity(owned['pid'])
            # Signal only our still-authenticated session, never a guessed/reused process group.
            assert authenticated_member(owned,out),'No authenticated owned leader/Native member remains; no unverified group signal'
            os.killpg(owned['pgid'],signal.SIGTERM)
            limit=time.monotonic()+2
            while time.monotonic()<limit and any(r['state']!='Z' for r in session_members(owned['sid'])):time.sleep(.05)
            if any(r['state']!='Z' for r in session_members(owned['sid'])):
                assert authenticated_member(owned,out),'Owned identities changed before KILL'
                os.killpg(owned['pgid'],signal.SIGKILL)
        if proc is not None:
            try:proc.wait(timeout=2)
            except subprocess.TimeoutExpired:report['cleanupWaitTimeout']=True
        final=session_members(owned['sid']) if owned else []
        report['finalMembers']=final;report['liveSurvivors']=[r for r in final if r['state']!='Z'];report['terminatedZombies']=[r for r in final if r['state']=='Z']
        assert not report['liveSurvivors'],'Owned live survivors remain'
        nativePIDFile=out/'native-identity.json'
        if nativePIDFile.is_file():
            saved=json.loads(nativePIDFile.read_text());report['nativeIdentity']=saved;report['nativeAfter']=identity(saved['pid'])
            assert not same(saved,report['nativeAfter']) or report['nativeAfter']['state']=='Z','Actual Native PID still live'
        partial=out/'native-observations.json'
        if not partial.is_file():partial=out/'partial.json'
        if partial.is_file():
            actual=json.loads(partial.read_text());ports=[actual.get('http',{}).get('port'),actual.get('nativePort')]
            report['portsAfter']={str(port):port_open(port) for port in ports if port is not None}
            assert not any(report['portsAfter'].values()),'Owned HTTP/CDP port remains open'
    except BaseException as error:report['status']='STOPPED_CLEANUP';report['cleanupError']={'type':type(error).__name__,'message':str(error)}
    if log:log.close()
    after=check(rows);write(out/'inputs-after.json',after);report['inputsStable']=after['stable'];report['inputCount']=len(rows)
    if not after['stable']:report['status']='STOPPED_INTEGRITY'
    report['elapsedSeconds']=time.monotonic()-start;write(out/'report.json',report)
    print(json.dumps({'status':report['status'],'report':str(out/'report.json'),'liveSurvivors':report.get('liveSurvivors'),'inputsStable':report['inputsStable']}),flush=True)
raise SystemExit(0 if report['status']=='NATIVE_METADATA_LOCALIZATION_COMPLETE_RETAINED_ASYNC_UNRUN' else 1)
