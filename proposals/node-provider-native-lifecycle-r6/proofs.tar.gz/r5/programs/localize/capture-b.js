() => captureActualChild('B')
