() => {
  const h=retainedHolders.A,currentFrame=document.getElementById('child');
  return {documentPrototypeIsSavedNode:Object.getPrototypeOf(h.document)===h.savedPrototypes.Node,
    documentInstanceOfSavedNode:h.document instanceof h.savedGraph.Node,
    functionPrototypeIsSavedFunction:Object.getPrototypeOf(h.read)===h.savedGraph.Function.prototype,
    savedObjectEqualsCurrentWindowObject:h.savedGraph.Object===currentFrame.contentWindow.Object,
    savedNodeEqualsCurrentWindowNode:h.savedGraph.Node===currentFrame.contentWindow.Node};
}
