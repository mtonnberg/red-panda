() => ({capturedDocumentURL:retainedHolders.A.document.URL})
