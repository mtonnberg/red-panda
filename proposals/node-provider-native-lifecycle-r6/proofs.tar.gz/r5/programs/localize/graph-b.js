() => {
  const h=retainedHolders.B,w=h.window;
  h.savedGraph={Node:w.Node,HTMLParagraphElement:w.HTMLParagraphElement,HTMLElement:w.HTMLElement,EventTarget:w.EventTarget,Object:w.Object,Function:w.Function};
  h.savedPrototypes=Object.fromEntries(Object.entries(h.savedGraph).map(([name,ctor])=>[name,ctor&&ctor.prototype]));
  return {savedNames:Object.keys(h.savedGraph),objectMatchesCurrent:h.savedGraph.Object===w.Object,nodeMatchesCurrent:h.savedGraph.Node===w.Node};
}
