() => ({documentIdentity:retainedHolders.A.document===document.getElementById('child').contentWindow.document})
