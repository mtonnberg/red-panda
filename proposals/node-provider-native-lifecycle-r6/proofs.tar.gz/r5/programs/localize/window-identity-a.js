() => ({windowIdentity:retainedHolders.A.window===document.getElementById('child').contentWindow})
