// UNRUN. One real Native process, unchanged fixture producers, no candidate/provider loading.
import http from 'node:http';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {readFile,writeFile,appendFile} from 'node:fs/promises';
import {readFileSync,writeFileSync,appendFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const DIR=path.dirname(fileURLToPath(import.meta.url)),OUT=process.argv[2];
if(!OUT)throw Error('Explicit fresh owned evidence directory required');
const tool=JSON.parse(await readFile(path.join(DIR,'toolchain.json'),'utf8'));
const routeMap=JSON.parse(await readFile(path.join(DIR,'routes.json'),'utf8')).routes;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const errorRecord=error=>Object.fromEntries(Object.getOwnPropertyNames(error).map(key=>[key,error[key]]));
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const started=performance.now();
const record={status:'SETUP',budgets:{rpcMs:2500,scriptMs:1000,loadMs:2000,parentObservationMs:500,observationBarrierMs:2000,calibrationAggregateMs:80000,cleanupMs:8000},
  node:{execPath:process.execPath,argv:process.argv,execArgv:process.execArgv,versions:process.versions},nativeArgs:[],requests:[],phases:[],operations:[],events:[],fixtureProgramChanges:'NONE',
  interpretation:'Observed lifecycle facts only. Pending at parent500ms is not success or permanent cancellation. No CDP awaitPromise or manual checkpoint.'};
let native,server,socket,nativeIdentity,clientClosed=false,cancelled=false,requestId=0,sessionId,targetId,parentContextId,origin,endpoint,overallTimer;
record.localizationScope='PROMISE_ONLY NAV; optional old Document/public graph reads explicitly outside scope';
const pending=new Map();
function identity(pid){try{const stat=readFileSync(`/proc/${pid}/stat`,'utf8'),tail=stat.slice(stat.lastIndexOf(')')+2).split(' ');return {pid,state:tail[0],ppid:Number(tail[1]),pgid:Number(tail[2]),sid:Number(tail[3]),startTicks:tail[19],argv:readFileSync(`/proc/${pid}/cmdline`,'utf8').split('\0').filter(Boolean)};}catch{return null;}}
const sameIdentity=(saved,now)=>!!saved&&!!now&&saved.pid===now.pid&&saved.startTicks===now.startTicks;
function save(){writeFileSync(path.join(OUT,'partial.json'),JSON.stringify({...record,elapsedMs:performance.now()-started},null,2)+'\n');}
function wire(direction,value){appendFileSync(path.join(OUT,'wire.jsonl'),JSON.stringify({atMs:performance.now()-started,direction,value})+'\n');}
function rejectPending(error){for(const entry of pending.values()){clearTimeout(entry.timer);entry.reject(error);}pending.clear();}
function rpc(method,params={},selectedSession=sessionId,budget=2500){
  if(cancelled||clientClosed)throw Error('Calibration cancelled/closed');
  if(!(budget>0&&budget<=2500))throw Error('Invalid bounded RPC budget');
  const id=++requestId,message={id,method,params,...(selectedSession?{sessionId:selectedSession}:{})};wire('send',message);
  return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},budget);pending.set(id,{timer,resolve,reject});socket.send(JSON.stringify(message));});
}
async function evaluate(label,program,arg,budget=2500){
  const source=await readFile(path.join(DIR,'programs',program),'utf8');
  const expression=`(${source})(${JSON.stringify(arg)??''})`;
  const result=await rpc('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:false,timeout:1000,...(parentContextId?{contextId:parentContextId}:{})},sessionId,budget);
  record.operations.push({label,program,argument:arg,result});save();
  if(result.exceptionDetails)throw Error('Actual setup/observer script exception '+label+': '+JSON.stringify(result.exceptionDetails));
  if(!Object.hasOwn(result.result??{},'value'))throw Error('Missing actual by-value observer output '+label);
  return result.result.value;
}
async function boundedBarrier(label,program,arg,budget=2000){
  const begin=performance.now(),deadline=begin+budget;let last;
  while(performance.now()<deadline){if(cancelled)throw Error('Calibration cancelled');last=await evaluate(label,program,arg,Math.max(1,Math.floor(Math.min(2500,deadline-performance.now()))));
    if(last?.ready===true)return {last,elapsedMs:performance.now()-begin};
    const remaining=deadline-performance.now();if(remaining>0)await sleep(Math.min(20,remaining));
  }
  throw Error('Actual barrier unobserved within '+budget+'ms: '+label+' last='+JSON.stringify(last));
}
async function listen(server){await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',()=>{server.off('error',reject);resolve();});});const port=server.address().port;if([9582,9584].includes(port))throw Error('Canonical port allocation prohibited');return port;}
async function startHTTP(){
  const fixtures=new Map();for(const[route,contract]of Object.entries(routeMap)){const bytes=await readFile(path.join(DIR,contract.file));fixtures.set(route,{bytes,contract,sha256:sha(bytes)});}
  record.fixtures=Object.fromEntries([...fixtures].map(([route,value])=>[route,{...value.contract,sha256:value.sha256,bytes:value.bytes.length}]));
  server=http.createServer((req,res)=>{const url=new URL(req.url,'http://127.0.0.1');const entry=fixtures.get(url.pathname),valid=req.method==='GET'&&entry;
    const bytes=valid?entry.bytes:Buffer.from('Not found\n');res.statusCode=valid?200:404;
    res.setHeader('Content-Type',valid?entry.contract.contentType:'text/plain; charset=utf-8');res.setHeader('Cache-Control','no-store');
    const row={method:req.method,url:req.url,requestHeaders:req.headers,rawRequestHeaders:req.rawHeaders,path:url.pathname,status:res.statusCode,contentType:res.getHeader('Content-Type'),responseSHA256:sha(bytes),bytes:bytes.length,atMs:performance.now()-started};
    record.requests.push(row);appendFileSync(path.join(OUT,'http.jsonl'),JSON.stringify(row)+'\n');res.end(bytes);
  });
  const port=await listen(server);origin=`http://127.0.0.1:${port}`;record.http={origin,port};save();
}
async function launchNative(){
  if(cancelled)throw Error('Calibration cancelled before spawn');
  const reservation=net.createServer();let port;
  try{port=await listen(reservation);}finally{await new Promise(resolve=>reservation.close(resolve));}
  const args=['serve','--host','127.0.0.1','--port',String(port),'--load-resources','iframe'];
  record.nativeArgs=args;record.nativeTool={path:tool.native.path,sha256:sha(await readFile(tool.native.path))};record.nativePort=port;
  native=spawn(tool.native.path,args,{stdio:['ignore','pipe','pipe']});
  native.stdout.on('data',bytes=>appendFileSync(path.join(OUT,'native.stdout.log'),bytes));native.stderr.on('data',bytes=>appendFileSync(path.join(OUT,'native.stderr.log'),bytes));
  native.on('error',error=>{record.nativeSpawnError=errorRecord(error);save();});
  nativeIdentity=identity(native.pid);if(!nativeIdentity)throw Error('Actual Native process identity unavailable');
  if(nativeIdentity.sid!==identity(process.pid)?.sid||nativeIdentity.pgid!==identity(process.pid)?.pgid)throw Error('Native escaped owned process session/group');
  record.nativeIdentity=nativeIdentity;writeFileSync(path.join(OUT,'native-identity.json'),JSON.stringify(nativeIdentity,null,2)+'\n');save();
  const deadline=performance.now()+10000;
  while(performance.now()<deadline){if(cancelled)throw Error('Calibration cancelled during readiness');if(native.exitCode!==null||native.signalCode!==null||record.nativeSpawnError)throw Error('Native exited/spawn failure before readiness');
    try{const response=await fetch(`http://127.0.0.1:${port}/json/version`,{signal:AbortSignal.timeout(Math.max(1,Math.floor(Math.min(2500,deadline-performance.now()))))});
      if(response.ok){record.nativeVersionResponse={status:response.status,headers:[...response.headers],body:await response.text()};endpoint=`ws://127.0.0.1:${port}/`;save();return;}
    }catch(error){record.lastReadinessError=errorRecord(error);}await sleep(20);
  }throw Error('Native readiness not observed within10000ms');
}
async function connect(){
  if(cancelled)throw Error('Calibration cancelled before connect');
  socket=new WebSocket(endpoint);await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('WebSocket handshake2500ms timeout')),2500);socket.addEventListener('open',()=>{clearTimeout(timer);resolve();},{once:true});socket.addEventListener('error',()=>{clearTimeout(timer);reject(Error('WebSocket handshake error'));},{once:true});});
  socket.addEventListener('message',event=>{const raw=String(event.data);appendFileSync(path.join(OUT,'wire-raw.jsonl'),JSON.stringify({atMs:performance.now()-started,raw})+'\n');
    let value;try{value=JSON.parse(raw);}catch(error){record.wireParseError=errorRecord(error);rejectPending(error);return;}wire('receive',value);
    if(!Object.hasOwn(value,'id')){record.events.push(value);return;}const entry=pending.get(value.id);if(!entry)return;pending.delete(value.id);clearTimeout(entry.timer);value.error?entry.reject(Object.assign(Error(value.error.message),value.error)):entry.resolve(value.result);
  });
  socket.addEventListener('close',()=>{clientClosed=true;rejectPending(Error('Actual CDP connection closed'));});
  socket.addEventListener('error',()=>rejectPending(Error('Actual CDP WebSocket error')));
}
async function load(label,child){const barrier=await boundedBarrier(label,'load-ready.js',{parentURL:origin+'/parent.html',childURL:origin+child},2000);record.operations.push({label,loadBarrier:barrier});save();}
async function selectParent(label){
  const frameTree=await rpc('Page.getFrameTree');
  const mainFrameId=frameTree?.frameTree?.frame?.id;if(!mainFrameId)throw Error('No actual main frame ID');
  const actual=record.events.filter(event=>event.method==='Runtime.executionContextCreated'&&event.params?.context?.auxData?.frameId===mainFrameId&&event.params.context.auxData.isDefault===true).at(-1)?.params.context;
  if(!actual?.id)throw Error('Actual main default execution context unobserved');
  if(parentContextId&&parentContextId!==actual.id)throw Error('Parent observing context changed unexpectedly');
  parentContextId=actual.id;record.operations.push({label,frameTree,parentContext:actual});save();
}
async function observeProducers(phase,kinds,capture=false){
  const row={phase,kinds,status:'STARTED'};record.phases.push(row);save();
  row.started=await evaluate(phase+':start','promise-only/start.js',{phase,kinds,capture});
  const observed=await boundedBarrier(phase+':Parent500','promise-only/observe.js',undefined,2000);
  row.observed=observed.last;row.barrierElapsedMs=observed.elapsedMs;
  row.classificationAtParent500=Object.fromEntries(Object.entries(observed.last.values).map(([id,value])=>[id,{producerThrow:value.producerThrow??null,...value.parentTicks.find(tick=>tick.delay===500)}]));
  row.status='OBSERVED_FINITE_WINDOW';save();
}
async function calibrate(){
  await startHTTP();await launchNative();await connect();
  const created=await rpc('Target.createTarget',{url:'about:blank'},null);targetId=created.targetId;if(!targetId)throw Error('No actual target');
  const attached=await rpc('Target.attachToTarget',{targetId,flatten:true},null);sessionId=attached.sessionId;if(!sessionId)throw Error('No actual session');
  await rpc('Runtime.enable');await rpc('Page.enable');
  const nav=await rpc('Page.navigate',{url:origin+'/parent.html'});if(nav.errorText)throw Error('Actual navigation error '+JSON.stringify(nav));
  const kinds=['fulfilled','resolved','async','classicCached','classicFresh','moduleCached','moduleFresh'];
  await load('ACTIVE:actual-load','/child-a.html');await selectParent('ACTIVE:actual-frame-context');
  await observeProducers('ACTIVE',kinds,true);
  await evaluate('NAVIGATED:actual-iframe-navigation','navigate-b.js',origin+'/child-b.html');await load('NAVIGATED:actual-load','/child-b.html');await selectParent('NAVIGATED:actual-frame-context');
  for(const kind of kinds)await observeProducers('NAV-'+kind,[kind]);
  if(native.exitCode!==null||native.signalCode!==null)throw Error('Native exited before controlled cleanup');
  record.actualProducerInvocations=record.phases.reduce((sum,row)=>sum+row.started.ids.length,0);
  if(record.actualProducerInvocations!==14)throw Error('Actual declared ACTIVE7+NAV7 producer count mismatch');
  record.optionalOldDocumentAndGraphReads='OUTSIDE SCOPE; specific prior Native getter error and SIGSEGV preserved';
  record.status='NATIVE_PROMISE_ONLY_NAV_OBSERVATIONS_COMPLETE_NOT_PROVIDER_ACCEPTANCE';
}
async function cleanup(){
  const begin=performance.now();record.cleanup={status:'STARTED',nativeAlreadyExited:!!native&&(native.exitCode!==null||native.signalCode!==null)};save();
  if(!cancelled&&socket&&socket.readyState===WebSocket.OPEN&&!clientClosed&&targetId){try{await rpc('Target.closeTarget',{targetId},null,2500);}catch(error){record.cleanup.targetCloseError=errorRecord(error);}}
  cancelled=true;rejectPending(Error('Owned calibration cleanup'));
  if(socket&&socket.readyState!==WebSocket.CLOSED){try{socket.close();}catch(error){record.cleanup.socketCloseError=errorRecord(error);}const deadline=performance.now()+1000;while(socket.readyState!==WebSocket.CLOSED&&performance.now()<deadline)await sleep(10);record.cleanup.socketClosed=socket.readyState===WebSocket.CLOSED;}
  if(nativeIdentity){const actual=identity(nativeIdentity.pid);if(actual&&!sameIdentity(nativeIdentity,actual))throw Error('Native PID identity changed before cleanup');
    if(actual&&actual.state!=='Z'){native.kill('SIGTERM');const deadline=performance.now()+1500;while(native.exitCode===null&&native.signalCode===null&&performance.now()<deadline)await sleep(10);
      if(native.exitCode===null&&native.signalCode===null){const now=identity(nativeIdentity.pid);if(!sameIdentity(nativeIdentity,now))throw Error('Native identity changed before KILL');native.kill('SIGKILL');await sleep(100);}}
    record.cleanup.native={identity:identity(nativeIdentity.pid),exitCode:native.exitCode,signal:native.signalCode};
  }
  if(server){server.closeAllConnections();await Promise.race([new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve())),sleep(1000).then(()=>{throw Error('Owned HTTP close1000ms timeout');})]);record.cleanup.httpClosed=true;}
  record.cleanup.elapsedMs=performance.now()-begin;
  const failures=record.cleanup.targetCloseError||record.cleanup.socketCloseError||(socket&&socket.readyState!==WebSocket.CLOSED)||record.cleanup.nativeAlreadyExited;
  record.cleanup.status=failures?'FAILED':'CLEANUP_ATTEMPTED_EXTERNAL_CONTROLLER_VERIFIES_PORTS_AND_GROUP';save();
  if(failures)throw Error('Actual cleanup failure; inspect complete cleanup record');
}
process.on('SIGTERM',()=>{cancelled=true;rejectPending(Error('Controller SIGTERM'));});
process.on('SIGINT',()=>{cancelled=true;rejectPending(Error('Controller SIGINT'));});
try{
  if(process.execPath!==tool.stockNode.path||sha(await readFile(process.execPath))!==tool.stockNode.sha256)throw Error('Stock Node identity changed');
  if(sha(await readFile(tool.native.path))!==tool.native.sha256)throw Error('Native binary identity changed');
  record.controllerIdentity=identity(process.pid);save();
  await Promise.race([calibrate(),new Promise((_,reject)=>{overallTimer=setTimeout(()=>{cancelled=true;const error=Error('Separate Native calibration80000ms aggregate timeout');rejectPending(error);reject(error);},80000);})]);
}catch(error){record.status='STOPPED_SETUP_TRANSPORT_OR_AGGREGATE';record.failure=errorRecord(error);process.exitCode=1;}
finally{clearTimeout(overallTimer);try{await cleanup();}catch(error){record.cleanupError=errorRecord(error);record.status='STOPPED_CLEANUP';process.exitCode=1;}
  record.elapsedMs=performance.now()-started;await writeFile(path.join(OUT,'native-observations.json'),JSON.stringify(record,null,2)+'\n');
  console.log(JSON.stringify({status:record.status,phases:record.phases.map(row=>({phase:row.phase,status:row.status})),actualProducerInvocations:record.actualProducerInvocations,report:path.join(OUT,'native-observations.json')}));}
