// Active-parent observer. Actual child producer functions are unchanged fixture allocations.
({phase,kinds,capture}) => {
  if(capture)captureActualChild('A');
  globalThis.promiseOnlyObservations??=Object.create(null);
  const holder=retainedHolders.A;if(!holder)throw Error('Actual retained A holder missing');
  function primitive(value){const type=typeof value;if(value===null)return {type:'object',value:null};
    if(['string','number','boolean'].includes(type))return {type,value};
    if(type==='bigint')return {type,decimal:value.toString()};return {type};}
  function reason(value){
    const result=primitive(value);
    if(value!==null&&(typeof value==='object'||typeof value==='function')){
      result.fields={};
      for(const field of ['name','message']){
        try{result.fields[field]={read:'returned',...primitive(value[field])};}
        catch(error){result.fields[field]={read:'threw',thrownType:typeof error};}
      }
    }
    return result;
  }
  function projection(value){
    if(value===null||typeof value!=='object')return primitive(value);
    const fields={};
    for(const field of ['owner','url','documentURL','lexicalMarker','globalThisMarker']){
      try{fields[field]={read:'returned',...primitive(value[field])};}
      catch(error){fields[field]={read:'threw',reason:reason(error)};}
    }
    return {type:'object',fields};
  }
  const producers={fulfilled:()=>holder.fulfilled,resolved:()=>holder.resolved(),async:()=>holder.asyncValue(),
    classicCached:()=>holder.loadCached(),classicFresh:()=>holder.loadFresh(phase+'-A'),
    moduleCached:()=>holder.moduleLoad('cached-A'),moduleFresh:()=>holder.moduleLoad('fresh-'+phase+'-A')};
  const ids=[];
  for(const kind of kinds){
    if(!Object.hasOwn(producers,kind))throw Error('Undeclared original producer kind '+kind);
    const id=phase+':A:'+kind;ids.push(id);
    const record=promiseOnlyObservations[id]={id,kind,direct:{state:'not-started'},adopted:{state:'not-started'},parentTicks:[]};
    let promise;
    try{promise=producers[kind]();record.producerReturned={type:typeof promise};}
    catch(error){record.producerThrow=reason(error);}
    if(!record.producerThrow){
      record.direct.state='pending';record.adopted.state='pending';
      try{
        promise.then(value=>{record.direct.state='fulfilled';record.direct.value=projection(value);},
          error=>{record.direct.state='rejected';record.direct.reason=reason(error);});
      }catch(error){record.direct={state:'synchronous-throw',reason:reason(error)};}
      try{
        Promise.resolve(promise).then(value=>{record.adopted.state='fulfilled';record.adopted.value=projection(value);},
          error=>{record.adopted.state='rejected';record.adopted.reason=reason(error);});
      }catch(error){record.adopted={state:'synchronous-throw',reason:reason(error)};}
    }
    for(const delay of [0,25,100,500])setTimeout(()=>{record.parentTicks.push({delay,direct:record.direct.state,adopted:record.adopted.state});},delay);
    Promise.resolve().then(()=>{record.parentPromiseControl=true;});
  }
  globalThis.promiseOnlyPhase={phase,ids};return {phase,ids};
}
