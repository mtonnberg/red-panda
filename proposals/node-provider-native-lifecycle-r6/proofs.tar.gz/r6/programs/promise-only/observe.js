() => {
  const phase=globalThis.promiseOnlyPhase;if(!phase)throw Error('Actual promise-only phase absent');
  const values=Object.fromEntries(phase.ids.map(id=>[id,promiseOnlyObservations[id]]));
  const ready=phase.ids.every(id=>promiseOnlyObservations[id]?.parentPromiseControl===true&&
    promiseOnlyObservations[id].parentTicks.length===4&&promiseOnlyObservations[id].parentTicks.every((tick,index)=>tick.delay===[0,25,100,500][index]));
  return {ready,phase:phase.phase,values};
}
