({parentURL,childURL}) => {
  if(document.URL!==parentURL||document.readyState!=='complete')return {ready:false,parentURL:document.URL,parentState:document.readyState};
  const frame=document.getElementById('child'),w=frame&&frame.contentWindow;
  const childDocument=w?w.document:undefined;
  if(!w||childDocument===undefined||childDocument===null)return {ready:false,parentURL:document.URL,
    childWindowPresent:!!w,childDocumentObserved:!!w,childDocumentState:childDocument===undefined?'undefined':'null'};
  return {ready:childDocument.URL===childURL&&childDocument.readyState==='complete'&&
    typeof captureActualChild==='function'&&typeof startActualPromiseObservation==='function'&&!!w.publication&&!!w.modulePublication,
    parentURL:document.URL,childURL:childDocument.URL,childState:childDocument.readyState};
}
