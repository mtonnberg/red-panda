const sourceURL=import.meta.url;
globalThis.modulePublication = {
  read: () => ({owner:'A',url:sourceURL,documentURL:document.URL,lexicalMarker:realmMarker,globalThisMarker:globalThis.realmMarker}),
  load: nonce => import(new URL('./dep-a.mjs?moduleNonce='+encodeURIComponent(nonce),sourceURL).href)
};
