const sourceURL=import.meta.url;
globalThis.modulePublication = {
  read: () => ({owner:'B',url:sourceURL,documentURL:document.URL,lexicalMarker:realmMarker,globalThisMarker:globalThis.realmMarker}),
  load: nonce => import(new URL('./dep-b.mjs?moduleNonce='+encodeURIComponent(nonce),sourceURL).href)
};
