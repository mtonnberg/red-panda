const sourceURL=import.meta.url;
globalThis.modulePublication = {
  read: () => ({owner:'C',url:sourceURL,documentURL:document.URL,lexicalMarker:realmMarker,globalThisMarker:globalThis.realmMarker}),
  load: nonce => import(new URL('./dep-c.mjs?moduleNonce='+encodeURIComponent(nonce),sourceURL).href)
};
