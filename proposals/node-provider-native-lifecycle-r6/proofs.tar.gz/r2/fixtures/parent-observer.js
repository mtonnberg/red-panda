// STATIC fixture, UNRUN. Ordinary active-parent observations, no queue draining.
globalThis.retainedHolders = Object.create(null);
globalThis.observations = Object.create(null);
globalThis.captureActualChild = function (label) {
  const frame = document.getElementById('child');
  const win = frame.contentWindow;
  if (!win || !win.publication || !win.modulePublication) throw new Error('Actual child publication not ready');
  const value = win.publication;
  const holder = {
    window: win, document: win.document, Object: win.Object, Promise: win.Promise,
    read: value.read, resolved: value.resolved, asyncValue: value.asyncValue,
    loadCached: value.loadCached, loadFresh: value.loadFresh,
    fulfilled: value.fulfilled, pending: value.pending, resolvePending: value.resolvePending,
    moduleRead: win.modulePublication.read, moduleLoad: win.modulePublication.load
  };
  retainedHolders[label] = holder;
  return { label, childURL: win.document.URL, currentParentURL: document.URL };
};
globalThis.startActualPromiseObservation = function (id, producer) {
  const record = observations[id] = { id, direct: {state:'not-started'}, adopted: {state:'not-started'}, parentTicks: [] };
  function projection(value) { return value && typeof value === 'object' ? {owner:value.owner,url:value.url,documentURL:value.documentURL,lexicalMarker:value.lexicalMarker,globalThisMarker:value.globalThisMarker} : value; }
  let promise;
  try { promise = producer(); }
  catch (error) { record.producerThrow={name:error && error.name,message:error && error.message}; }
  if (!record.producerThrow) {
    record.direct.state = 'pending'; record.adopted.state = 'pending';
    try {
      promise.then(value => { record.direct={state:'fulfilled',value:projection(value)}; },
        error => { record.direct={state:'rejected',name:error && error.name,message:error && error.message}; });
    } catch (error) { record.direct={state:'synchronous-throw',name:error && error.name,message:error && error.message}; }
    try {
      Promise.resolve(promise).then(value => { record.adopted={state:'fulfilled',value:projection(value)}; },
        error => { record.adopted={state:'rejected',name:error && error.name,message:error && error.message}; });
    } catch (error) { record.adopted={state:'synchronous-throw',name:error && error.name,message:error && error.message}; }
  }
  for (const delay of [0,25,100,500]) setTimeout(() => {
    record.parentTicks.push({delay,direct:record.direct.state,adopted:record.adopted.state});
  }, delay);
  Promise.resolve().then(() => { record.parentPromiseControl=true; });
  return id;
};
