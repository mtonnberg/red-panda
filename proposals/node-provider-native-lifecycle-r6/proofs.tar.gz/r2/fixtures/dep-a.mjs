export const owner='A';
export const url=import.meta.url;
export const documentURL=document.URL;
export const lexicalMarker=realmMarker;
export const globalThisMarker=globalThis.realmMarker;
