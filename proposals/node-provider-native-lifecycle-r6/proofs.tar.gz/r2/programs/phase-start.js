// Parent-authored observer only. Actual child producer functions come unchanged from fixtures.
({phase,holders,capture,pending}) => {
  if(capture){captureActualChild(capture);const h=retainedHolders[capture],w=h.window;
    h.savedGraph={Node:w.Node,HTMLParagraphElement:w.HTMLParagraphElement,HTMLElement:w.HTMLElement,EventTarget:w.EventTarget,Object:w.Object,Function:w.Function};
    h.savedPrototypes=Object.fromEntries(Object.entries(h.savedGraph).map(([name,ctor])=>[name,ctor&&ctor.prototype]));
  }
  const errorRecord=error=>({name:error&&error.name,message:error&&error.message,stack:error&&error.stack});
  const safely=operation=>{try{return {value:operation()};}catch(error){return {error:errorRecord(error)};}};
  const currentFrame=document.getElementById('child');
  const metadata={phase,parentURL:document.URL,actualFramePresent:!!currentFrame,holders:{}};
  const ids=[];
  for(const label of holders){
    const h=retainedHolders[label];if(!h)throw Error('Missing actual retained holder '+label);
    metadata.holders[label]={read:safely(()=>h.read()),moduleRead:safely(()=>h.moduleRead()),
      capturedDocumentURL:safely(()=>h.document.URL),windowIdentity:safely(()=>!!currentFrame&&h.window===currentFrame.contentWindow),
      documentIdentity:safely(()=>!!currentFrame&&h.document===currentFrame.contentWindow.document),
      publicGraph:safely(()=>({documentPrototypeIsSavedNode:Object.getPrototypeOf(h.document)===h.savedPrototypes.Node,
        documentInstanceOfSavedNode:h.document instanceof h.savedGraph.Node,
        functionPrototypeIsSavedFunction:Object.getPrototypeOf(h.read)===h.savedGraph.Function.prototype,
        savedObjectEqualsCurrentWindowObject:!!currentFrame&&h.savedGraph.Object===currentFrame.contentWindow.Object,
        savedNodeEqualsCurrentWindowNode:!!currentFrame&&h.savedGraph.Node===currentFrame.contentWindow.Node}))};
    const producers={fulfilled:()=>h.fulfilled,resolved:()=>h.resolved(),async:()=>h.asyncValue(),
      classicCached:()=>h.loadCached(),classicFresh:()=>h.loadFresh(phase+'-'+label),
      moduleCached:()=>h.moduleLoad('cached-'+label),moduleFresh:()=>h.moduleLoad('fresh-'+phase+'-'+label)};
    for(const [kind,producer] of Object.entries(producers)){const id=phase+':'+label+':'+kind;ids.push(id);startActualPromiseObservation(id,producer);}
  }
  if(pending){const h=retainedHolders[pending],id=phase+':'+pending+':pre-navigation-pending';ids.push(id);
    startActualPromiseObservation(id,()=>h.pending);
    metadata.pendingResolverCall=safely(()=>({type:typeof h.resolvePending(pending+':resolved-after-'+phase)}));
  }
  globalThis.calibrationPhase={phase,ids,metadata};
  return {phase,ids,metadata};
}
