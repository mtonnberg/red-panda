({parentURL,childURL}) => {
  if(document.URL!==parentURL||document.readyState!=='complete')return {ready:false,parentURL:document.URL,parentState:document.readyState};
  const frame=document.getElementById('child'),w=frame&&frame.contentWindow;
  return {ready:!!w&&w.document.URL===childURL&&w.document.readyState==='complete'&&
    typeof captureActualChild==='function'&&typeof startActualPromiseObservation==='function'&&!!w.publication&&!!w.modulePublication,
    parentURL:document.URL,childURL:w&&w.document.URL,childState:w&&w.document.readyState};
}
