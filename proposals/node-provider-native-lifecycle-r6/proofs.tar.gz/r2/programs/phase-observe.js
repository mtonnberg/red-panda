() => {
  const phase=globalThis.calibrationPhase;if(!phase)throw Error('No actual phase started');
  const values=Object.fromEntries(phase.ids.map(id=>[id,observations[id]]));
  const ready=phase.ids.every(id=>observations[id]?.parentPromiseControl===true&&
    observations[id].parentTicks.length===4&&observations[id].parentTicks.every((tick,index)=>tick.delay===[0,25,100,500][index]));
  return {ready,phase:phase.phase,metadata:phase.metadata,values};
}
