url => {const frame=document.getElementById('child');if(!frame)throw Error('Missing real iframe');frame.src=url;return {requested:frame.src};}
