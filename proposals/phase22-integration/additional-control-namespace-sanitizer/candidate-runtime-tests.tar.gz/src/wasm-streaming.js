// Translate genuine browser Response producers to Node's genuine streaming
// compiler input. Neither public lookalikes nor authored Response properties
// supply bytes, status, headers, or brands to this bridge.
import {types} from 'node:util';
const producers = new WeakMap(), installed = new WeakSet();
const nativeErrors = ['CompileError', 'LinkError', 'RuntimeError'].map(name => [name, globalThis.WebAssembly[name]]);
export function registerWasmResponse(value, producer) { producers.set(value, producer); }
export function installWasmStreaming(realm) {
  if (installed.has(realm) || !realm.WebAssembly) return;
  const wasm = realm.WebAssembly;
  const compile = wasm.compileStreaming, instantiate = wasm.instantiateStreaming;
  const errors = nativeErrors.map(([name, Native]) => [Native.prototype, wasm[name]]);
  if (typeof compile !== 'function' || typeof instantiate !== 'function') return;
  const bridge = value => {
    const producer = producers.get(value);
    if (!producer) throw new realm.TypeError('Argument 0 must be a Response or a Promise resolving to a Response');
    return producer(realm.TypeError);
  };
  const error = value => {
    if (!types.isNativeError(value)) return value;
    for (const [prototype, Constructor] of errors) {
      if (Object.getPrototypeOf(value) === prototype) return new Constructor(value.message);
    }
    return value;
  };
  const methods = realm.Function('bridge', 'compile', 'instantiate', 'error', `
    const resolve=Promise.resolve.bind(Promise), then=Promise.prototype.then;
    function run(compiler,source,imports) {
      let rejected=false;
      const input=then.call(resolve(source),bridge,reason=>{rejected=true;throw reason});
      return then.call(compiler(input,imports),undefined,reason=>{throw rejected?reason:error(reason)});
    }
    return {
      compileStreaming(source) { return run(compile,source); },
      instantiateStreaming(source, imports) { return run(instantiate,source,imports); }
    };
  `)(bridge, compile, instantiate, error);
  Object.defineProperty(methods.instantiateStreaming, 'length', { value: 1 });
  for (const name of ['compileStreaming', 'instantiateStreaming']) {
    Object.defineProperty(wasm, name, { ...Object.getOwnPropertyDescriptor(wasm, name), value: methods[name] });
  }
  installed.add(realm);
}
