from pathlib import Path
import subprocess,json,time,hashlib,os,signal,re
nodes=[('24.22.1','/workspace/shared/rea-tools/node_modules/node/bin/node'),('24.19.0','/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'),('26.13.0','/workspace/shared/node26/node_modules/node/bin/node')];files={str(p)for folder in ['src','test','scripts','bin','native','docs/reference']for p in Path(folder).rglob('*')if p.is_file()};before={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()for n in sorted(files)};Path('evidence/focused-before.json').write_text(json.dumps(before,indent=2)+'\n');rows=[]
for version,node in nodes:
 command=[node,'--experimental-vm-modules','--test','--test-concurrency=1','test/css-compat.test.js','test/resize-observer.test.js','test/window-viewport-parity.test.js'];start=time.monotonic();terminated=False
 with open('evidence/focused-'+version+'.log','xb')as output:
  child=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=28)
  except subprocess.TimeoutExpired:
   terminated=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=1)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 log=Path('evidence/focused-'+version+'.log').read_text();row={'version':version,'command':command,'seconds':time.monotonic()-start,'exit':code,'resourceTerminated':terminated,'summary':{n:int(v)for n,v in re.findall(r'ℹ (tests|pass|fail|cancelled|skipped) (\d+)',log)}};rows.append(row);print(json.dumps(row),flush=True)
Path('evidence/focused-status.json').write_text(json.dumps({'rows':rows,'inputCount':len(before),'changed':[n for n,h in before.items()if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h]},indent=2)+'\n')
