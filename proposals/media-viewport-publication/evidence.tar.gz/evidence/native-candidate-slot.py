from pathlib import Path
import subprocess,time,json,hashlib
node='/workspace/shared/rea-tools/node_modules/node/bin/node';commands=[('native',[node,'--experimental-vm-modules','evidence/mql-resize-probe.mjs','/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux','evidence/mql-native.json']),('candidate',[node,'--experimental-vm-modules','evidence/mql-resize-probe.mjs',str(Path('evidence/candidate-cli').resolve()),'evidence/mql-candidate.json']),('direct-layout',[node,'--experimental-vm-modules','evidence/direct-layout-baseline.mjs','evidence/direct-layout-baseline.json']),('resize-lifecycle',[node,'--experimental-vm-modules','evidence/resize-lifecycle-probe.mjs','evidence/resize-lifecycle-baseline.json'])];rows=[]
for name,command in commands:
 start=time.monotonic()
 with open('evidence/'+name+'.log','xb')as output:p=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':command,'seconds':time.monotonic()-start,'exit':p.returncode})
Path('evidence/slot-status.json').write_text(json.dumps(rows,indent=2)+'\n');base=json.loads(Path('evidence/base-manifest.json').read_text());Path('evidence/post-slot-sourceguard.json').write_text(json.dumps({'count':len(base),'changed':[n for n,h in base.items() if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h]},indent=2)+'\n');print(json.dumps(rows))
