from pathlib import Path
import hashlib,json,shutil,re
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';root=Path('/workspace/red-panda');candidate=p/'candidate-r9';projection=p/'projection-root-79ad40d-r9';H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();nodes={'24.22.1':'/workspace/shared/rea-tools/node_modules/node/bin/node','24.19.0':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','26.13.0':'/workspace/shared/node26/node_modules/node/bin/node'}
# These are current Root's exact unchanged source/build helpers, not old Browser
# copies; changed JS leaves remain the previously hunk-composed projection.
for f in (root/'native').glob('*'):
 if f.is_file():
  dest=projection/'native'/f.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
artifacts=[]
for sdk in nodes:
 for binary,source in[('runtime.node','runtime.cc'),('collections.node','collections.cc'),('heap-query.node','heap-query.cc')]:
  before=candidate/'native/build/linux-x64'/('node-'+sdk)/binary;meta=json.loads(Path(str(before)+'.json').read_text());assert meta['sourceSHA256']==H(projection/'native'/source)==H(root/'native'/source);assert meta['binarySHA256']==H(before);dest=projection/'native/build/linux-x64'/('node-'+sdk)/binary;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(before,dest);shutil.copy2(Path(str(before)+'.json'),Path(str(dest)+'.json'));artifacts.append({'binary':str(dest),'source':str(projection/'native'/source),'binarySHA256':H(dest),'manifestSHA256':H(Path(str(dest)+'.json')),'matchingCurrentRootSource':True})
reference=root/'proposals/document-write/native.json';dest=projection/'proposals/document-write/native.json';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(reference,dest);assert H(reference)==H(dest)
(e/'root79-r9-staged-actual-artifacts.json').write_text(json.dumps({'scope':'STATIC artifact staging only; no build/runtime','artifacts':artifacts,'soleAddedReferenceFixture':{'root':str(reference),'owned':str(dest),'SHA256':H(reference)},'RootCppOr18ArtifactsChanged':False},indent=2)+'\n')
# Existing actual Node24 epochs remain separate, unmodified.
rows=[]
for mode in['new24','observations','heldout2','prefix2','factories','regressions']:
 f=e/('candidate-r9-next-'+mode+'-24.22.1-status.json');d=json.loads(f.read_text());assert d['passedObservedPhases']and not d['changedInputs']and not d['rootChangedSourceFiles'];rows.append({'mode':mode,'receiptSHA256':H(f),'seconds':d['seconds'],'phases':[{'name':g['name'],'count':g.get('actualGroups',g.get('tapSummary',{}).get('tests')),'tapSummary':g.get('tapSummary'),'differences':len(g.get('actualPublicValueDifferences',[])),'remainingLiveProcesses':g.get('remainingLiveProcesses'),'producerStateAfterCleanup':g.get('producerStateAfterCleanup')}for g in d['phases']]})
(e/'candidate-r9-node24-complete-seal.json').write_text(json.dumps({'scope':'All actual oldbase R9 Node24 tests126+Native23 complete, separateepochs','tests':126,'nativeGroups':23,'receipts':rows,'otherSDKandRoot79Projection':'ALL_UNRUN','historicalNegativesPreserved':True},indent=2)+'\n')
plan={'scope':'Finite remainingSDK requests only; no oldbase Node24 duplicate; must stopfirst failure and obtain quiet grant','perControllerAdmin':120,'cleanupGrace':3,'perNewCase':15,'actualAPI':2500,'newNativeProducersReplayed':False,'SDKs':{sdk:{'cases':126,'commands':[['python3','evidence/candidate-r9-next-slot.py',mode,sdk]for mode in['new24','factories','regressions']]}for sdk in['24.19.0','26.13.0']},'totalUnrunCases':252,'controllerSHA256':H(e/'candidate-r9-next-slot.py'),'manifestSHA256':H(e/'candidate-r9-next-inputs.json')};(e/'candidate-r9-remaining-sdk-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(e/'candidate-r9-next-slot.py').read_text();s=s.replace("candidate=p/'candidate-r9'","candidate=p/'projection-root-79ad40d-r9'").replace("['observations','regressions','factories','new24','heldout2','prefix2']","['observations','primary126','lifecycle64','heldout2','prefix2']").replace('candidate-r9-next','root79-r9-composed')
a=s.index(" elif mode=='new24':");b=s.index(" status['passedObservedPhases']=True",a)
primary=['test/document-encoding.test.js','test/initial-xhtml-parser.test.js','test/xml-query-policy.test.js','test/document-interface-realms.test.js','test/document-xml.test.js','test/dom-factory-parity.test.js','test/dom-wrapper-realms.test.js','test/location-factory.test.js','test/namespace-serialization.test.js','test/manual-document-realms.test.js','test/url-parse-factory.test.js','test/streams-compat.test.js','test/dom-idl.test.js','test/frames-integration.test.js','test/forms.test.js']
lifecycle=['test/managed-written-lifecycle.test.js','test/document-reset.test.js','test/document-write.test.js','test/module-load-readiness.test.js','test/classic-checkpoint-lifecycle.test.js','test/modules.test.js','test/performance-event-counts.test.js','test/performance-event-counts-cross-realm.test.js'];assert sum(len(re.findall(r'^\s*test\(', (projection/f).read_text(),re.M))for f in lifecycle)==64
s=s[:a]+" elif mode=='primary126':testPhase('primary126',"+repr(primary)+",126)\n elif mode=='lifecycle64':testPhase('lifecycle64',"+repr(lifecycle)+",64)\n elif mode=='prefix2':observationPhase('prefix2','evidence/candidate-r8-prefix-probe.mjs','evidence/native-qualified-prefix.json',2)\n else:observationPhase('heldout2','evidence/candidate-r6-causal-probe.mjs','evidence/native-xhtml-r6-causal.json',2)\n"+s[b:]
s=s.replace("'sourceRevision':'R9'","'sourceRevision':'CURRENT_ROOT79_HUNK_COMPOSED_R9_STATIC_UNRUN'");(e/'root79-r9-composed-slot.py').write_text(s);compile(s,'Root79R9Controller','exec')
inputs=json.loads((e/'candidate-r9-next-inputs.json').read_text())
for top in['src','test','bin','native','scripts','proposals']:
 for f in(projection/top).rglob('*')if(projection/top).exists()else[]:
  if f.is_file():inputs[str(f)]=H(f)
for name in['package.json','package-lock.json','VERSION']:
 if(projection/name).is_file():inputs[str(projection/name)]=H(projection/name)
for name in['root79-r9-composed-slot.py','root79-r9-staged-actual-artifacts.json','candidate-r9-node24-complete-seal.json','candidate-r9-remaining-sdk-plan.json','candidate-r9-on-root-79ad40d-manifest.json','candidate-r9-on-root-79ad40d.patch']:
 inputs[str(e/name)]=H(e/name)
inputs[str(reference)]=H(reference)
(e/'root79-r9-composed-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n');print(json.dumps({'oldBaseNode24SealSHA256':H(e/'candidate-r9-node24-complete-seal.json'),'remainingSDKPlanSHA256':H(e/'candidate-r9-remaining-sdk-plan.json'),'composedControllerSHA256':H(e/'root79-r9-composed-slot.py'),'composedManifestSHA256':H(e/'root79-r9-composed-inputs.json'),'composedPins':len(inputs),'composedTests':'126primary+64affectedlifecycle; strict23Native optionalnewgraph comparisons, no Native rerun; allUNRUN'},indent=2))
