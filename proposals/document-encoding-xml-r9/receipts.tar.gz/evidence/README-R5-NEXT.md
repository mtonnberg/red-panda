# Encoding/XHTML R5 next bounded gates (UNRUN)

The immutable first18 receipt passed 18/18, zero skips/cancellations, 7.973544 seconds, 8,544 pinned inputs unchanged; original Root235 source files unchanged and all owned processes absent. The receipt interpretation is separate in candidate-r5-first-receipt-seal.json. This does not promote the historical R3 strict serialization failure, R4 unrun draft, or the unrun gates below.

Run only under a parent quiet grant from /workspace/shared/document-encoding-recovery:

1. `python3 evidence/candidate-r5-next-slot.py observations 24.22.1` — candidate8+7+4 against already captured Native19. No Native replay. ALL public by-value fields (including Document interfaces, tag/namespace counts, attributes, XML serialization and malformed/script order) compared, only ephemeral HTTP origins normalized. Full wire/errors retained. Stop on first incomplete/mismatch.
2. `python3 evidence/candidate-r5-next-slot.py factories 24.22.1` — 60 canonical Document/interface/factory/namespace/location/actual-VM checks in seven original files; no heap enumeration.
3. `python3 evidence/candidate-r5-next-slot.py regressions 24.22.1` — original42 URL/streams/DOM/frames/forms checks.
4. For each SDK24.19.0 then26.13.0: modes `new18`, `factories`, `regressions`, serially stop-first. SDK24.22 first18 cannot be repeated by this controller.

Every invocation retains 120s administrative cap+3s cleanup, 2,500ms actual API waits and original per-test deadlines (15s for the new cases). 8,551 guarded source/dependency/actual binary/Native raw/controller inputs; canonical prelaunch proxy bypass union, NODE_USE_ENV_PROXY=1, TLS/proxies and genuine native integrity checks unchanged. Each invocation has a unique non-overwritable status and real owned PID/startTicks cleanup. Estimates: observations ~10–20s, factories ~10–30s, old42 ~5–20s; estimates are not acceptance deadlines.

The old-base R5 source is frozen independently from current Root. The new projection-root-5adb9b3-r5 and candidate-r5-on-root-5adb9b3.patch are STATIC and UNRUN. Projection transfers unique literal changed hunks; it does not replace old Browser/CDP/isolated-world wholesale. All unmodified current Root source is byte preserved, including Pointer. The two shared compiler lexical bridges are composed positionally. `git apply --check` succeeds against observed Root5adb source. No change is applied to Root and there is no SDK/producer correctness claim for the projection yet.

Original R5 artifact leaf labels STATIC_UNRUN remain immutable historical preparation labels: the separate receipt records the actual first18 result. Full unchanged page/encoding fixture still needs the separately owned blank-frame generation prerequisite before claiming its complete source behavior. No TextDecoder/Encoder, Worker, general XML, utility HTMLDocument, class-constructor native-toString/newTarget, or broad XML completion claim is made by this slice.
