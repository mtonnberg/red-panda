from pathlib import Path
import json,hashlib,shutil,difflib
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';c=p/'candidate-r6';assert not c.exists();shutil.copytree(p/'candidate-r5',c,symlinks=True);H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();deps=Path('/workspace/red-panda/node_modules/jsdom/lib/jsdom')
pins={name:H(deps/name)for name in['living/domparsing/DOMParser-impl.js','living/node.js','living/helpers/create-element.js','utils.js']}
source=r'''// Actual owned DOM query and parser-error production policy. Generated public
// WebIDL conversions, original backends and genuine live collections remain.
import vm from'node:vm';
import{createRequire}from'node:module';
import{readFileSync}from'node:fs';
import{createHash}from'node:crypto';
import{dirname}from'node:path';
import{ownsNamespaceNode,namespaceCreator}from'./namespace-state.js';
const require=createRequire(import.meta.url),apply=Reflect.apply;
const DocumentImpl=require('jsdom/lib/jsdom/living/nodes/Document-impl.js').implementation;
const ElementImpl=require('jsdom/lib/jsdom/living/nodes/Element-impl.js').implementation;
const Collection=require('jsdom/lib/jsdom/living/generated/HTMLCollection.js');
const Unknown=require('jsdom/lib/jsdom/living/generated/HTMLUnknownElement.js');
const ParserImpl=require('jsdom/lib/jsdom/living/domparsing/DOMParser-impl.js').implementation;
const{getHTMLElementInterface}=require('jsdom/lib/jsdom/living/helpers/create-element.js');
const{domSymbolTree}=require('jsdom/lib/jsdom/living/helpers/internal-constants.js');
const{HTML_NS}=require('jsdom/lib/jsdom/living/helpers/namespaces.js');
const{memoizeQuery}=require('jsdom/lib/jsdom/utils.js');
const lower=value=>value.replace(/[A-Z]/g,letter=>letter.toLowerCase());
const pins=PINS;
let installed=false;
export function installXMLQueryPolicy(){
 if(installed)return;
 for(const[name,digest]of Object.entries(pins)){const actual=createHash('sha256').update(readFileSync(require.resolve('jsdom/lib/jsdom/'+name))).digest('hex');if(actual!==digest)throw new Error('Pinned canonical XML query/parser source changed: '+name)}
 // Recompile the original private catch producer with ONE scalar error-message
 // decision. This creates the genuine parsererror Text node at original birth;
 // no returned tree, public getter or serializer output is patched afterward.
 const full=require.resolve('jsdom/lib/jsdom/living/domparsing/DOMParser-impl.js'),original=readFileSync(full,'utf8'),needle='element.textContent = error.message;';
 if(original.split(needle).length!==2)throw new Error('Canonical DOMParser error-node producer changed');
 const transformed=original.replace(needle,'element.textContent = parserErrorMessage(this, error);'),module={exports:{}};
 vm.compileFunction(transformed,['require','exports','module','__filename','__dirname','parserErrorMessage'],{filename:full})(createRequire(full),module.exports,module,full,dirname(full),(parser,error)=>namespaceCreator(parser._globalObject)?'error':error.message);
 ParserImpl.prototype.parseFromString=module.exports.implementation.prototype.parseFromString;
 for(const Implementation of[DocumentImpl,ElementImpl]){
  const originalQuery=Implementation.prototype.getElementsByTagName;
  Implementation.prototype.getElementsByTagName=memoizeQuery(function(qualifiedName){
   if(!ownsNamespaceNode(this)||qualifiedName==='*')return apply(originalQuery,this,arguments);
   const folded=lower(qualifiedName),known=getHTMLElementInterface(folded)!==Unknown;
   return Collection.createImpl(this._globalObject,[],{element:this,query:()=>domSymbolTree.treeToArray(this,{filter:node=>{
    if(node===this||node.nodeType!==1)return false;
    if(node._namespaceURI!==HTML_NS)return node._qualifiedName===qualifiedName;
    // Known HTML names select their canonical spelling; unknown HTML names
    // compare ASCII-insensitively, while foreign namespaces stay exact.
    return known?node._qualifiedName===folded:lower(node._qualifiedName)===folded;
   }})});
  });
 }
 installed=true;
}
'''.replace('PINS',json.dumps(pins,separators=(',',':')))
(c/'src/xml-query-policy.js').write_text(source)
f=c/'src/namespace-serialization.js';s=f.read_text();s="import{installXMLQueryPolicy}from'./xml-query-policy.js';\n"+s;needle='ownNamespaceGlobal(document._globalObject,creator);patch();';assert s.count(needle)==1;s=s.replace(needle,'ownNamespaceGlobal(document._globalObject,creator);patch();installXMLQueryPolicy();');f.write_text(s)
# New tests are separate from the immutable first18 source.
fixture=(c/'test/initial-xhtml-parser.test.js').read_text().split("test('initial genuine",1)[0]
tests=r'''
test('canonical mixed-case HTML queries keep real live Document and Element collections across XML producers',{timeout:15000},async t=>{
 const f=await fixture(t),w=await f.navigate(open+'<div id="container"><DiV id="mixed"/><div id="known"/><CaseNode id="unknown"/><casenode id="lower"/><svg xmlns="http://www.w3.org/2000/svg"><CaseNode id="foreign"/></svg></div>'+close),source=open+'<div id="container"><DiV id="mixed"/><div id="known"/><CaseNode id="unknown"/><casenode id="lower"/><svg xmlns="http://www.w3.org/2000/svg"><CaseNode id="foreign"/></svg></div>'+close;
 const ids=list=>Array.from(list,n=>n.id);
 for(const d of[w.document,...['application/xhtml+xml','application/xml','text/xml'].map(type=>new w.DOMParser().parseFromString(source,type))]){
  const root=d.getElementById('container'),live=d.getElementsByTagName('CaseNode');
  assert.deepEqual(ids(d.getElementsByTagName('DiV')),['container','known']);assert.deepEqual(ids(root.getElementsByTagName('DiV')),['known']);
  assert.deepEqual(ids(live),['unknown','lower','foreign']);assert.deepEqual(ids(d.getElementsByTagName('CASENODE')),['unknown','lower']);
  assert.deepEqual(ids(d.getElementsByTagNameNS('http://www.w3.org/1999/xhtml','CaseNode')),['unknown']);
  const added=d.createElementNS('http://www.w3.org/1999/xhtml','CASEnode');added.id='added';root.appendChild(added);assert.deepEqual(ids(live),['unknown','lower','foreign','added']);added.remove();assert.deepEqual(ids(live),['unknown','lower','foreign']);
  assert.equal(platformFactoryRecord(live).implementation,implementationForWrapper(live));
 }
});
test('actual malformed XML parser creates generic real error text across syntax failures and preserves later mutation',{timeout:15000},async t=>{
 const f=await fixture(t),w=await f.navigate(open+'<p>actual</p>'+close);
 for(const mime of['application/xhtml+xml','application/xml','text/xml','image/svg+xml'])for(const source of['<r><broken></r>','<r a="x" a="y"/>','<unbound:child/>','<r>&actualUnknown;</r>']){
  const d=new w.DOMParser().parseFromString(source,mime),root=d.documentElement;assert.equal(d.contentType,mime);assert.equal(root.namespaceURI,'http://www.mozilla.org/newlayout/xml/parsererror.xml');assert.equal(root.textContent,'error');assert.equal(new w.XMLSerializer().serializeToString(d),'<parsererror>error</parsererror>');assert.equal(root.firstChild.nodeType,3);assert.equal(root.firstChild.ownerDocument,d);root.firstChild.data='actual-edited';assert.equal(new w.XMLSerializer().serializeToString(d),'<parsererror>actual-edited</parsererror>');
 }
 const valid=new w.DOMParser().parseFromString('<r><a/></r>','application/xml');assert.equal(valid.documentElement.localName,'r');assert.equal(new w.XMLSerializer().serializeToString(valid),'<r><a></a></r>');
});
test('canonical query and parser policy ignores authored getters but leaves genuine unowned JSDOM behavior intact',{timeout:15000},async t=>{
 const f=await fixture(t),w=await f.navigate(open+'<CaseNode id="heldout"/>'+close),element=w.document.getElementById('heldout');let reads=0;
 for(const key of['localName','tagName','namespaceURI'])Object.defineProperty(element,key,{get(){reads++;throw Error('authored query metadata')},configurable:true});
 assert.equal(w.document.getElementsByTagName('casenode')[0],element);assert.equal(reads,0);
 const{JSDOM}=await import('jsdom'),dom=new JSDOM('');try{const d=new dom.window.DOMParser().parseFromString('<r><broken></r>','application/xml');assert.notEqual(d.documentElement.textContent,'error');assert.match(d.documentElement.textContent,/close tag/)}finally{dom.window.close()}
});
'''
(c/'test/xml-query-policy.test.js').write_text(fixture+tests)
# Extend one strict derivative, preserving old driver/routes/Native raw.
s=(e/'candidate-r5-next-slot.py').read_text().replace('candidate-r5','candidate-r6').replace("'sourceRevision':'R5'","'sourceRevision':'R6'")
s=s.replace("['observations','regressions','factories','new18']","['observations','regressions','factories','new21','heldout2']").replace("assert mode!='new18'or sdk!='24.22.1','First18 Node24.22 is accepted and must not be rerun here'\n",'')
s=s.replace("evidence/candidate-r6-xhtml-heldout-probe.mjs","evidence/candidate-r5-xhtml-heldout-probe.mjs")
s=s.replace("elif mode=='new18':testPhase('new18',['test/document-encoding.test.js','test/initial-xhtml-parser.test.js'],18)","elif mode=='new21':testPhase('new21',['test/document-encoding.test.js','test/initial-xhtml-parser.test.js','test/xml-query-policy.test.js'],21)\n elif mode=='heldout2':observationPhase('heldout2','evidence/candidate-r6-causal-probe.mjs','evidence/native-xhtml-r6-causal.json',2)")
(e/'candidate-r6-next-slot.py').write_text(s);compile(s,'R6Controller','exec')
s=(e/'native-xhtml-r6-causal-probe.mjs').read_text().replace("import{startReference}from'../helpers/reference-server.mjs'","import{startRoot}from'../helpers/root-server.mjs'")
s=s.replace("const binary=process.argv[2],output=process.argv[3],sha=v=>createHash('sha256').update(v).digest('hex'),record={actor:'Native-XHTML-R6-Causal',binary,binarySHA256:sha(await readFile(binary))", "const source=process.argv[2],output=process.argv[3],sha=v=>createHash('sha256').update(v).digest('hex'),record={actor:'CandidateR6-XHTML-Causal',source,sourceSHA256:sha(await readFile(source+'/src/browser.js'))")
s=s.replace("startReference(binary,{args:['--load-resources','iframe']})","startRoot(source)");assert 'startReference'not in s
(e/'candidate-r6-causal-probe.mjs').write_text(s)
inputs=json.loads((e/'candidate-r5-next-inputs.json').read_text())
for top in ['src','test','bin','native','scripts']:
 for f in (c/top).rglob('*')if(c/top).exists()else[]:
  if f.is_file():inputs[str(f)]=H(f)
for name in ['package.json','package-lock.json','VERSION']:
 if(c/name).is_file():inputs[str(c/name)]=H(c/name)
for name in ['candidate-r6-next-slot.py','candidate-r6-causal-probe.mjs','native-xhtml-r6-causal.json','native-xhtml-r6-causal-status.json','candidate-r5-strict-negative-seal.json','candidate-r5-xhtml-heldout-probe.mjs']:
 inputs[str(e/name)]=H(e/name)
(e/'candidate-r6-next-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n')
changes={};patch=''
for f in sorted((c/'src').glob('*.js'))+sorted((c/'test').glob('*.test.js')):
 name=f.relative_to(c);old=p/'candidate-r5'/name
 if old.exists()and old.read_bytes()==f.read_bytes():continue
 changes[str(name)]={'before':H(old)if old.exists()else None,'after':H(f),'status':'STATIC_UNRUN'}
 before=old.read_text().splitlines(True)if old.exists()else[];patch+='diff --git a/'+str(name)+' b/'+str(name)+'\n';patch+=('new file mode 100644\n'if not old.exists()else'');patch+=''.join(difflib.unified_diff(before,f.read_text().splitlines(True),fromfile='a/'+str(name)if old.exists()else'/dev/null',tofile='b/'+str(name)))
(e/'candidate-r6-delta.patch').write_text(patch);(e/'candidate-r6-delta-leaves.json').write_text(json.dumps(changes,indent=2)+'\n')
print(json.dumps({'controllerSHA256':H(e/'candidate-r6-next-slot.py'),'manifestSHA256':H(e/'candidate-r6-next-inputs.json'),'inputs':len(inputs),'deltaPatchSHA256':H(e/'candidate-r6-delta.patch'),'newCaseCount':21,'status':'ALL_R6_UNRUN'},indent=2))
