from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
p=Path.cwd();manifest=p/'evidence/xhtml-parser-causal-inputs.json';expected=json.loads(manifest.read_text());node='/workspace/shared/rea-tools/node_modules/node/bin/node';start=time.monotonic();cap=30;statusPath=p/'evidence/xhtml-parser-causal-status.json';assert not statusPath.exists(),'Immutable paired epoch already exists'
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def inputs():return{n:digest(Path(n))for n in expected}
assert inputs()==expected,'Frozen Native/current-Root causal inputs changed'
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union);env['RED_PANDA_RUNTIME_ADDON']='/workspace/red-panda/native/build/linux-x64/node-24.22.1/runtime.node';env['RED_PANDA_COLLECTIONS_ADDON']='/workspace/red-panda/native/build/linux-x64/node-24.22.1/collections.node'
status={'administrativeCap':cap,'cleanupGrace':3,'rpcTimeout':2500,'inputs':len(expected),'manifestSHA256':digest(manifest),'actors':[],'gateScope':'Causal observations only, not an equality/replication acceptance gate','proxyTLSPreserved':all(env.get(n)==os.environ.get(n)for n in['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR']),'canonicalBypassSHA256':hashlib.sha256(env['NO_PROXY'].encode()).hexdigest()}
def proc(pid):
 try:
  raw=Path('/proc/'+str(pid)+'/stat').read_text();tail=raw[raw.rindex(')')+2:].split();return{'pid':pid,'state':tail[0],'ppid':int(tail[1]),'pgrp':int(tail[2]),'startTicks':tail[19],'cmdline':Path('/proc/'+str(pid)+'/cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
 except(FileNotFoundError,ProcessLookupError,PermissionError):return None
def observe(child,known):
 for directory in Path('/proc').iterdir():
  if directory.name.isdigit():
   r=proc(int(directory.name))
   if r and(r['pgrp']==child.pid or r['ppid']in known):known.setdefault(r['pid'],r)
def actual(known):
 out=[]
 for pid,identity in known.items():
  r=proc(pid)
  if r and r['startTicks']==identity['startTicks']:out.append(r)
 return out
def checkpoint():status['seconds']=time.monotonic()-start;statusPath.write_text(json.dumps(status,indent=2)+'\n')
try:
 for actor,source in [('native','/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux'),('root','/workspace/red-panda')]:
  record={'actor':actor,'complete':False};status['actors'].append(record);output='evidence/xhtml-parser-causal-'+actor+'.json';command=[node,'--experimental-vm-modules','evidence/xhtml-parser-causal-probe.mjs',actor,source,output];record['command']=command;checkpoint();print(json.dumps({'actor':actor,'state':'starting'}),flush=True);known={}
  with(p/('evidence/xhtml-parser-causal-'+actor+'.log')).open('xb')as log:
   child=subprocess.Popen(command,cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['controllerChildPID']=child.pid
   while child.poll()is None:
    observe(child,known)
    if time.monotonic()-start>=cap:
     record['administrativeExpiry']=True;os.killpg(child.pid,signal.SIGTERM)
     try:child.wait(timeout=3)
     except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
     break
    time.sleep(.1)
   record['exit']=child.returncode
  record['observedOwnedProcesses']=list(known.values());record['processesAfterExit']=actual(known);record['liveProcessesAfterExit']=[x for x in record['processesAfterExit']if x['state']not in['Z','X']]
  if record['liveProcessesAfterExit']:
   for identity in record['liveProcessesAfterExit']:
    current=proc(identity['pid'])
    if current and current['startTicks']==identity['startTicks']:
     try:os.kill(current['pid'],signal.SIGTERM)
     except ProcessLookupError:pass
   until=time.monotonic()+3
   while time.monotonic()<until and any(x['state']not in['Z','X']for x in actual(known)):time.sleep(.05)
   for current in actual(known):
    if current['state']not in['Z','X']:
     try:os.kill(current['pid'],signal.SIGKILL)
     except ProcessLookupError:pass
  record['processesAfterCleanup']=actual(known);path=p/output;progress=p/(output+'.progress.json');raw=json.loads(path.read_text())if path.exists()else json.loads(progress.read_text())if progress.exists()else{};groups=raw.get('groups',[]);pid=raw.get('pid');record.update({'rawFile':str(path if path.exists()else progress),'groups':len(groups),'completeGroups':sum(x.get('completed')is True for x in groups),'mimeObservations':sum(len(x.get('observations',[]))for x in groups),'httpReceipts':len(raw.get('http',[])),'wireMessages':len(raw.get('wire',[])),'runtimeEvents':[e for e in raw.get('events',[])if e['message'].get('method')=='Runtime.exceptionThrown'],'producerPID':pid,'producerStateAfterCleanup':proc(pid)if pid else None});record['complete']=record['exit']==0 and not record.get('administrativeExpiry')and not record['liveProcessesAfterExit']and path.exists()and len(groups)==3 and all(g.get('completed')is True and len(g.get('observations',[]))==2 for g in groups)and raw.get('finished')is True and not raw.get('failure')and not raw.get('cleanupErrors')and(record['producerStateAfterCleanup']is None or record['producerStateAfterCleanup']['state']in['Z','X']);checkpoint()
  if not record['complete']:raise RuntimeError('Actual causal actor setup/resource boundary: '+actor)
  if inputs()!=expected:raise RuntimeError('Input guard changed after '+actor)
 status['completeActors']=True
except BaseException as error:status['failure']={'type':type(error).__name__,'message':str(error)};status['completeActors']=False
finally:
 after=inputs();status['changedInputs']=[n for n in expected if after[n]!=expected[n]];checkpoint();print(json.dumps({'completeActors':status['completeActors'],'actors':[{'actor':x['actor'],'complete':x['complete'],'groups':x.get('groups'),'mimeObservations':x.get('mimeObservations')}for x in status['actors']],'changedInputs':status['changedInputs'],'seconds':status['seconds'],'failure':status.get('failure')}),flush=True)
sys.exit(0 if status['completeActors']and not status['changedInputs']else 1)
