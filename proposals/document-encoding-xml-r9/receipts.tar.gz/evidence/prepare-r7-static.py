from pathlib import Path
import json,hashlib,shutil,difflib
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';c=p/'candidate-r7';assert not c.exists();shutil.copytree(p/'candidate-r6',c,symlinks=True);H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
# Preserve exact R6 positive and negative epochs, separate from new source.
summary={}
for name in['new21','observations','heldout2']:
 f=e/('candidate-r6-next-'+name+'-24.22.1-status.json');d=json.loads(f.read_text());summary[name]={'statusSHA256':H(f),'passedObservedPhases':d['passedObservedPhases'],'seconds':d['seconds'],'inputs':d['inputs'],'changedInputs':d['changedInputs'],'rootChangedSourceFiles':d['rootChangedSourceFiles'],'failure':d.get('failure'),'phases':[{'name':g['name'],'complete':g['complete'],'actualGroups':g.get('actualGroups'),'differences':len(g.get('actualPublicValueDifferences',[])),'tapSummary':g.get('tapSummary'),'remainingLiveProcesses':g.get('remainingLiveProcesses'),'producerStateAfterCleanup':g.get('producerStateAfterCleanup')}for g in d['phases']]}
(e/'candidate-r6-separate-epoch-seal.json').write_text(json.dumps(summary,indent=2)+'\n')
source=r'''// Preserve qualified HTML tokens as real prefix/local-name private factory
// data. The parser keeps its actual original token spelling in a Host WeakMap,
// so parse5's open-element and closing-tag algorithms use qualified tokens.
import vm from'node:vm';
import{createRequire}from'node:module';
import{readFileSync}from'node:fs';
import{dirname}from'node:path';
import{createHash}from'node:crypto';
import{ownsNamespaceNode}from'./namespace-state.js';
const require=createRequire(import.meta.url),html=require('jsdom/lib/jsdom/browser/parser/html.js');
const{HTML_NS}=require('jsdom/lib/jsdom/living/helpers/namespaces.js');
const Unknown=require('jsdom/lib/jsdom/living/generated/HTMLUnknownElement.js');
const originalDocument=html.parseIntoDocument,originalFragment=html.parseFragment,originalNames=new WeakMap();
let installed=false;
export function installHTMLQualifiedNameParser(){
 if(installed)return;
 if(html.parseIntoDocument!==originalDocument||html.parseFragment!==originalFragment)throw new Error('Canonical HTML qualified-name parser install order changed');
 const full=require.resolve('jsdom/lib/jsdom/browser/parser/html.js'),source=readFileSync(full,'utf8');
 if(createHash('sha256').update(source).digest('hex')!=='d3c8ae7f9330eaa6dfb6b8d9b918b1a6398a43d40d71648b99b7f3e30a0e5333')throw new Error('Pinned canonical HTML token producer changed');
 const allocation='const element = createElement(ownerDocument, localName, namespace, null, isValue, willExecuteScript);',adapter='Object.assign(JSDOMParse5Adapter.prototype, serializationAdapter);';
 if(source.split(allocation).length!==2||source.split(adapter).length!==2)throw new Error('Canonical qualified token allocation seam changed');
 const transformed=source.replace(allocation,'const element = createHTMLToken(createElement, ownerDocument, localName, namespace, isValue, willExecuteScript);').replace(adapter,adapter+'\nconst originalTagName = JSDOMParse5Adapter.prototype.getTagName;\nJSDOMParse5Adapter.prototype.getTagName = function(node) { return tokenName(node, originalTagName); };');
 const module={exports:{}};
 function createHTMLToken(create,document,name,namespace,isValue,script){
  const colon=name.indexOf(':');
  if(!ownsNamespaceNode(document)||namespace!==HTML_NS||colon<=0||colon===name.length-1)return create(document,name,namespace,null,isValue,script);
  // A qualified HTML token is not a registered HTML/custom-element name. The
  // canonical Unknown factory receives its original namespace and split name
  // BEFORE the one genuine frontend allocation/setup; no prototype repair.
  const node=Unknown.createImpl(document._globalObject,[],{ownerDocument:document,localName:name.slice(colon+1),namespace,prefix:name.slice(0,colon),ceState:'uncustomized',ceDefinition:null,isValue});
  originalNames.set(node,name);return node;
 }
 vm.compileFunction(transformed,['require','exports','module','__filename','__dirname','createHTMLToken','tokenName'],{filename:full})(createRequire(full),module.exports,module,full,dirname(full),createHTMLToken,(node,original)=>originalNames.get(node)??original(node));
 // Keep the canonical CommonJS exports identity and all downstream consumers.
 html.parseIntoDocument=module.exports.parseIntoDocument;html.parseFragment=module.exports.parseFragment;installed=true;
}
'''
(c/'src/html-qualified-name-parser.js').write_text(source)
f=c/'src/initial-document-parser.js';s=f.read_text();s="import{installHTMLQualifiedNameParser}from'./html-qualified-name-parser.js';\n"+s;s=s.replace(' if(installed)return;\n',' if(installed)return;\n installHTMLQualifiedNameParser();\n',1);f.write_text(s)
f=c/'src/xml-query-policy.js';s=f.read_text();s="import{installHTMLQualifiedNameParser}from'./html-qualified-name-parser.js';\n"+s;s=s.replace(' if(installed)return;\n',' if(installed)return;\n installHTMLQualifiedNameParser();\n',1);f.write_text(s)
f=c/'test/xml-query-policy.test.js';s=f.read_text()+r'''
test('HTML qualified source tokens are genuinely split at factory birth and retain real closing-tag structure',{timeout:15000},async t=>{
 const{subscribePlatformFactories}=await import('../src/platform-factories.js'),born=[];const unsubscribe=subscribePlatformFactories((value,record)=>{const node=record.implementation;if(node?._prefix==='p'&&node._localName==='casenode')born.push({value,node,local:node._localName,prefix:node._prefix})});t.after(unsubscribe);
 const f=await fixture(t),w=await f.navigate(open+'<p>actual</p>'+close),d=new w.DOMParser().parseFromString('<div id="container"><p:CaseNode id="qualified"><span id="inside">inside</span></p:CaseNode><b id="after">after</b></div>','text/html'),n=d.getElementById('qualified');
 assert.equal(n.localName,'casenode');assert.equal(n.prefix,'p');assert.equal(n.namespaceURI,'http://www.w3.org/1999/xhtml');assert.equal(n.tagName,'P:CASENODE');assert.equal(n.constructor,w.HTMLUnknownElement);assert.equal(d.getElementById('inside').parentElement,n);assert.equal(d.getElementById('after').parentElement,d.getElementById('container'));assert.equal(d.getElementsByTagName('p:CaseNode')[0],n);assert.equal(d.getElementsByTagName('p:casenode')[0],n);assert.equal(born.find(x=>x.value===n)?.node,implementationForWrapper(n));assert.equal(Object.getOwnPropertyDescriptor(n,'localName'),undefined);assert.equal(Object.getOwnPropertyDescriptor(n,'prefix'),undefined);
});
''';f.write_text(s)
s=(e/'candidate-r6-next-slot.py').read_text().replace('candidate-r6','candidate-r7').replace("'sourceRevision':'R6'","'sourceRevision':'R7'").replace("'new21'","'new22'").replace("testPhase('new21'","testPhase('new22'").replace("'test/xml-query-policy.test.js'],21)","'test/xml-query-policy.test.js'],22)")
s=s.replace("evidence/candidate-r7-causal-probe.mjs","evidence/candidate-r6-causal-probe.mjs");(e/'candidate-r7-next-slot.py').write_text(s);compile(s,'R7Controller','exec')
inputs=json.loads((e/'candidate-r6-next-inputs.json').read_text())
for top in ['src','test','bin','native','scripts']:
 for f in(c/top).rglob('*')if(c/top).exists()else[]:
  if f.is_file():inputs[str(f)]=H(f)
for name in['package.json','package-lock.json','VERSION']:
 if(c/name).is_file():inputs[str(c/name)]=H(c/name)
for name in['candidate-r7-next-slot.py','candidate-r6-separate-epoch-seal.json','candidate-r6-causal-probe.mjs']:
 inputs[str(e/name)]=H(e/name)
(e/'candidate-r7-next-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n')
patch='';leaves={}
for name in['src/html-qualified-name-parser.js','src/initial-document-parser.js','src/xml-query-policy.js','test/xml-query-policy.test.js']:
 old=p/'candidate-r6'/name;new=c/name;leaves[name]={'before':H(old)if old.exists()else None,'after':H(new),'status':'STATIC_UNRUN'};patch+='diff --git a/'+name+' b/'+name+'\n';patch+=('new file mode 100644\n'if not old.exists()else'');patch+=''.join(difflib.unified_diff(old.read_text().splitlines(True)if old.exists()else[],new.read_text().splitlines(True),fromfile='a/'+name if old.exists()else'/dev/null',tofile='b/'+name))
(e/'candidate-r7-delta.patch').write_text(patch);(e/'candidate-r7-delta-leaves.json').write_text(json.dumps(leaves,indent=2)+'\n');print(json.dumps({'controllerSHA256':H(e/'candidate-r7-next-slot.py'),'manifestSHA256':H(e/'candidate-r7-next-inputs.json'),'inputs':len(inputs),'deltaPatchSHA256':H(e/'candidate-r7-delta.patch'),'firstMode':'new22','status':'ALL_R7_UNRUN'},indent=2))
