from pathlib import Path
import hashlib,json,shutil,difflib
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';c=p/'candidate-r8';assert not c.exists();shutil.copytree(p/'candidate-r7',c,symlinks=True);H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=r'''// Genuine owned HTML namespace qualified-name factory policy. All other
// namespaces and unprefixed names retain their actual canonical producers.
import vm from'node:vm';import{createRequire}from'node:module';import{readFileSync}from'node:fs';import{createHash}from'node:crypto';import{dirname}from'node:path';
import{ownsNamespaceNode}from'./namespace-state.js';
const require=createRequire(import.meta.url),apply=Reflect.apply;
const{HTML_NS}=require('jsdom/lib/jsdom/living/helpers/namespaces.js');
const{isValidCustomElementName}=require('jsdom/lib/jsdom/living/helpers/custom-elements.js');
const Unknown=require('jsdom/lib/jsdom/living/generated/HTMLUnknownElement.js'),Generic=require('jsdom/lib/jsdom/living/generated/HTMLElement.js');
const DocumentImpl=require('jsdom/lib/jsdom/living/nodes/Document-impl.js').implementation,ScriptImpl=require('jsdom/lib/jsdom/living/nodes/HTMLScriptElement-impl.js').implementation;
const validation=require('jsdom/lib/jsdom/living/helpers/validate-names.js');
const xml=require('jsdom/lib/jsdom/browser/parser/xml.js');
let installed=false;
export function qualifiedHTMLBirth(document,prefix,localName,isValue=null){
 const factory=isValidCustomElementName(localName)?Generic:Unknown;
 // Deliberately no CE definition lookup: the genuine qualified token itself
 // is not an autonomous custom-element name. Both backends are uncustomized.
 return factory.createImpl(document._globalObject,[],{ownerDocument:document,localName,namespace:HTML_NS,prefix,ceState:'uncustomized',ceDefinition:null,isValue});
}
export function installQualifiedElementBirth(){
 if(installed)return;
 const full=require.resolve('jsdom/lib/jsdom/browser/parser/xml.js'),original=readFileSync(full,'utf8');
 if(createHash('sha256').update(original).digest('hex')!=='ca72ac1ac39c424baf6054b0820bb67d0a52f0de5c0f1f5c81c93d20d8cbc5d9')throw new Error('Pinned canonical qualified XML factory changed');
 const allocation='const elem = createElement(ownerDocument, tagLocal, tagNamespace, tagPrefix, isValue, true);',mark='if (tagLocal === "script" && tagNamespace === HTML_NS) {',execute='if (elem.localName === "script" && elem.namespaceURI === HTML_NS) {';
 for(const seam of[allocation,mark,execute])if(original.split(seam).length!==2)throw new Error('Canonical qualified XML factory seam changed');
 const transformed=original.replace(allocation,'const elem = createXMLToken(createElement, ownerDocument, tagLocal, tagNamespace, tagPrefix, isValue);').replace(mark,'if (tagLocal === "script" && tagNamespace === HTML_NS && actualScript(elem)) {').replace(execute,'if (elem.localName === "script" && elem.namespaceURI === HTML_NS && actualScript(elem)) {');
 const module={exports:{}};
 vm.compileFunction(transformed,['require','exports','module','__filename','__dirname','createXMLToken','actualScript'],{filename:full})(createRequire(full),module.exports,module,full,dirname(full),(create,document,name,namespace,prefix,isValue)=>ownsNamespaceNode(document)&&namespace===HTML_NS&&prefix!==null?qualifiedHTMLBirth(document,prefix,name,isValue):create(document,name,namespace,prefix,isValue,true),node=>node instanceof ScriptImpl);
 // Keep the original module identity so namespace scopes wrap these real
 // entries before parsing starts; no returned Document is transformed.
 xml.parseIntoDocument=module.exports.parseIntoDocument;xml.parseFragment=module.exports.parseFragment;
 const create=DocumentImpl.prototype.createElement,createNS=DocumentImpl.prototype.createElementNS;
 DocumentImpl.prototype.createElement=function(name,options){
  if(!ownsNamespaceNode(this)||this._parsingMode!=='html'||!name.includes(':'))return apply(create,this,arguments);
  validation.name(this._globalObject,name);name=name.replace(/[A-Z]/g,letter=>letter.toLowerCase());const colon=name.indexOf(':');
  if(colon<=0||colon===name.length-1)return apply(create,this,arguments);
  return qualifiedHTMLBirth(this,name.slice(0,colon),name.slice(colon+1),options?.is??null);
 };
 DocumentImpl.prototype.createElementNS=function(namespace,name,options){
  if(!ownsNamespaceNode(this)||namespace!==HTML_NS||!name.includes(':'))return apply(createNS,this,arguments);
  const parts=validation.validateAndExtract(this._globalObject,namespace,name);
  return parts.prefix===null?apply(createNS,this,arguments):qualifiedHTMLBirth(this,parts.prefix,parts.localName,options?.is??null);
 };
 installed=true;
}
'''
(c/'src/qualified-element-birth.js').write_text(source)
f=c/'src/html-qualified-name-parser.js';s=f.read_text();s="import{installQualifiedElementBirth,qualifiedHTMLBirth}from'./qualified-element-birth.js';\n"+s;s=s.replace("const Unknown=require('jsdom/lib/jsdom/living/generated/HTMLUnknownElement.js');\n",'');s=s.replace(' if(installed)return;\n',' if(installed)return;\n installQualifiedElementBirth();\n',1)
old="const node=Unknown.createImpl(document._globalObject,[],{ownerDocument:document,localName:name.slice(colon+1),namespace,prefix:name.slice(0,colon),ceState:'uncustomized',ceDefinition:null,isValue});";assert s.count(old)==1;s=s.replace(old,"const node=qualifiedHTMLBirth(document,name.slice(0,colon),name.slice(colon+1),isValue);");s=s.replace('The\n  // canonical Unknown factory receives','The\n  // canonical uncustomized Generic/Unknown factory receives');f.write_text(s)
f=c/'src/namespace-serialization.js';s=f.read_text();s="import{installQualifiedElementBirth}from'./qualified-element-birth.js';\n"+s;needle='ownNamespaceGlobal(document._globalObject,creator);patch();installXMLQueryPolicy();';assert s.count(needle)==1;s=s.replace(needle,'ownNamespaceGlobal(document._globalObject,creator);installQualifiedElementBirth();patch();installXMLQueryPolicy();');f.write_text(s)
f=c/'test/xml-query-policy.test.js';s=f.read_text()+r'''
test('qualified HTML namespace factories choose actual generic custom-name backends without activating CE constructors',{timeout:15000},async t=>{
 const f=await fixture(t),source='<html xmlns="http://www.w3.org/1999/xhtml" xmlns:p="http://www.w3.org/1999/xhtml"><head><script>globalThis.actualPrefixCalls=0;customElements.define("actual-prefix-owned",class extends HTMLElement{constructor(){super();actualPrefixCalls++}})</script></head><body><div id="container"><p:actual-prefix-owned id="qualified"><span id="inside">inside</span></p:actual-prefix-owned><actual-prefix-owned id="plain">plain</actual-prefix-owned><p:div id="known">known</p:div><b id="after">after</b></div></body></html>',w=await f.navigate(source),C=w.customElements.get('actual-prefix-owned');
 assert.equal(w.actualPrefixCalls,1);const prefix=w.document.getElementById('qualified');assert.equal(prefix.constructor,w.HTMLElement);assert.equal(prefix instanceof C,false);assert.equal(prefix.prefix,'p');assert.equal(prefix.localName,'actual-prefix-owned');assert.equal(w.document.getElementById('known').constructor,w.HTMLUnknownElement);assert.equal(w.document.getElementById('inside').parentElement,prefix);assert.equal(w.document.getElementById('after').parentElement.id,'container');
 for(const mime of['text/html','application/xhtml+xml','application/xml']){const before=w.actualPrefixCalls,d=new w.DOMParser().parseFromString(source,mime),element=d.getElementById('qualified');assert.equal(element.constructor,w.HTMLElement);assert.equal(element instanceof C,false);assert.equal(element.prefix,'p');assert.equal(d.getElementById('known').constructor,w.HTMLUnknownElement);assert.equal(w.actualPrefixCalls,before)}
 for(const name of['p:actual-prefix-owned','p:div'])for(const ns of[undefined,'http://www.w3.org/1999/xhtml']){const before=w.actualPrefixCalls,n=ns===undefined?w.document.createElement(name):w.document.createElementNS(ns,name);assert.equal(n.prefix,'p');assert.equal(n.localName,name.slice(2));assert.equal(n.constructor,name.includes('actual-prefix-owned')?w.HTMLElement:w.HTMLUnknownElement);assert.equal(n instanceof C,false);assert.equal(w.actualPrefixCalls,before)}
 const svg=w.document.createElementNS('http://www.w3.org/2000/svg','p:svg');assert.equal(svg.namespaceURI,'http://www.w3.org/2000/svg');assert.ok(svg instanceof w.SVGElement);assert.equal(svg.prefix,'p');const foreign=w.document.createElementNS('urn:actual','p:actual-prefix-owned');assert.equal(foreign.namespaceURI,'urn:actual');assert.equal(foreign.constructor,w.HTMLUnknownElement);
});
''';f.write_text(s)
s=(e/'candidate-r7-next-slot.py').read_text().replace('candidate-r7','candidate-r8').replace("'sourceRevision':'R7'","'sourceRevision':'R8'").replace("'new22'","'new23'").replace("'test/xml-query-policy.test.js'],22)","'test/xml-query-policy.test.js'],23)");s=s.replace("'heldout2']","'heldout2','prefix2']");s=s.replace("elif mode=='heldout2':", "elif mode=='prefix2':observationPhase('prefix2','evidence/candidate-r8-prefix-probe.mjs','evidence/native-qualified-prefix.json',2)\n elif mode=='heldout2':")
(e/'candidate-r8-next-slot.py').write_text(s);compile(s,'R8Controller','exec')
s=(e/'native-qualified-prefix-probe.mjs').read_text().replace("import{startReference}from'../helpers/reference-server.mjs'","import{startRoot}from'../helpers/root-server.mjs'")
s=s.replace("const binary=process.argv[2],output=process.argv[3],sha=v=>createHash('sha256').update(v).digest('hex'),record={actor:'Native-Qualified-HTML-Birth',binary,binarySHA256:sha(await readFile(binary))", "const source=process.argv[2],output=process.argv[3],sha=v=>createHash('sha256').update(v).digest('hex'),record={actor:'CandidateR8-Qualified-HTML-Birth',source,sourceSHA256:sha(await readFile(source+'/src/browser.js'))").replace("startReference(binary,{args:['--load-resources','iframe']})","startRoot(source)");assert 'startReference'not in s;(e/'candidate-r8-prefix-probe.mjs').write_text(s)
inputs=json.loads((e/'candidate-r7-next-inputs.json').read_text())
for top in['src','test','bin','native','scripts']:
 for f in(c/top).rglob('*')if(c/top).exists()else[]:
  if f.is_file():inputs[str(f)]=H(f)
for name in['package.json','package-lock.json','VERSION']:
 if(c/name).is_file():inputs[str(c/name)]=H(c/name)
for name in['candidate-r8-next-slot.py','candidate-r8-prefix-probe.mjs','native-qualified-prefix.json','native-qualified-prefix-status.json','candidate-r6-causal-probe.mjs']:
 inputs[str(e/name)]=H(e/name)
(e/'candidate-r8-next-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n')
leaves={};patch=''
for name in['src/qualified-element-birth.js','src/html-qualified-name-parser.js','src/namespace-serialization.js','test/xml-query-policy.test.js']:
 old=p/'candidate-r7'/name;f=c/name;leaves[name]={'before':H(old)if old.exists()else None,'after':H(f),'status':'STATIC_UNRUN'};patch+='diff --git a/'+name+' b/'+name+'\n';patch+=('new file mode 100644\n'if not old.exists()else'');patch+=''.join(difflib.unified_diff(old.read_text().splitlines(True)if old.exists()else[],f.read_text().splitlines(True),fromfile='a/'+name if old.exists()else'/dev/null',tofile='b/'+name))
(e/'candidate-r8-delta.patch').write_text(patch);(e/'candidate-r8-delta-leaves.json').write_text(json.dumps(leaves,indent=2)+'\n');print(json.dumps({'controllerSHA256':H(e/'candidate-r8-next-slot.py'),'manifestSHA256':H(e/'candidate-r8-next-inputs.json'),'inputs':len(inputs),'deltaPatchSHA256':H(e/'candidate-r8-delta.patch'),'firstMode':'new23','status':'ALL_R8_UNRUN; priorR7UNRUN rejectedstaticCEbackend selection kept'},indent=2))
