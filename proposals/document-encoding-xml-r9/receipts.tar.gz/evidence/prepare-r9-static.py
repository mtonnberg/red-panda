from pathlib import Path
import json,hashlib,shutil,difflib,re
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';c=p/'candidate-r9';assert not c.exists();shutil.copytree(p/'candidate-r8',c,symlinks=True);H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
f=c/'src/qualified-element-birth.js';s=f.read_text();a=s.index("const{HTML_NS}=require(");b=s.index('let installed=false;',a);initializers=s[a:b];s=s[:a]+"let HTML_NS,isValidCustomElementName,Unknown,Generic,DocumentImpl,ScriptImpl,validation,xml;\n"+s[b:]
init=""" HTML_NS=require('jsdom/lib/jsdom/living/helpers/namespaces.js').HTML_NS;
 isValidCustomElementName=require('jsdom/lib/jsdom/living/helpers/custom-elements.js').isValidCustomElementName;
 Unknown=require('jsdom/lib/jsdom/living/generated/HTMLUnknownElement.js');Generic=require('jsdom/lib/jsdom/living/generated/HTMLElement.js');
 DocumentImpl=require('jsdom/lib/jsdom/living/nodes/Document-impl.js').implementation;ScriptImpl=require('jsdom/lib/jsdom/living/nodes/HTMLScriptElement-impl.js').implementation;
 validation=require('jsdom/lib/jsdom/living/helpers/validate-names.js');xml=require('jsdom/lib/jsdom/browser/parser/xml.js');
"""
s=s.replace(' if(installed)return;\n',' if(installed)return;\n // Run only at trusted actual Window/parser installation, after normal jsdom\n // bootstrap. No generated interface is imported during this ESM module birth.\n'+init,1);f.write_text(s)
f=c/'src/html-qualified-name-parser.js';s=f.read_text();old="const require=createRequire(import.meta.url),html=require('jsdom/lib/jsdom/browser/parser/html.js');\nconst{HTML_NS}=require('jsdom/lib/jsdom/living/helpers/namespaces.js');\nconst originalDocument=html.parseIntoDocument,originalFragment=html.parseFragment,originalNames=new WeakMap();";assert s.count(old)==1;s=s.replace(old,"const require=createRequire(import.meta.url),originalNames=new WeakMap();\nlet html,HTML_NS;")
needle=' installQualifiedElementBirth();\n if(html.parseIntoDocument!==originalDocument||html.parseFragment!==originalFragment)throw new Error(\'Canonical HTML qualified-name parser install order changed\');';assert s.count(needle)==1;s=s.replace(needle," installQualifiedElementBirth();\n html=require('jsdom/lib/jsdom/browser/parser/html.js');HTML_NS=require('jsdom/lib/jsdom/living/helpers/namespaces.js').HTML_NS;\n")
f.write_text(s)
f=c/'test/xml-query-policy.test.js';s=f.read_text()+r'''
test('fresh private parser module imports preserve the normal canonical CommonJS bootstrap before first real Window',{timeout:15000},async()=>{
 const{execFileSync}=await import('node:child_process');const script=`import{createRequire}from'node:module';import'./src/qualified-element-birth.js';import'./src/html-qualified-name-parser.js';import'./src/initial-document-parser.js';const require=createRequire(import.meta.url),interfaces=require('jsdom/lib/jsdom/living/interfaces.js'),canonical=require.cache[require.resolve('jsdom/lib/jsdom/living/interfaces.js')].exports;const{JSDOM}=await import('jsdom');if(interfaces!==canonical||typeof interfaces.installInterfaces!=='function')throw Error('canonical interface module not complete');const dom=new JSDOM('<p id="actual">actual body</p>',{runScripts:'outside-only'});try{if(dom.window.document.getElementById('actual').textContent!=='actual body'||typeof dom.window.HTMLElement!=='function')throw Error('actual Window setup failed');if(require.cache[require.resolve('jsdom/lib/jsdom/living/interfaces.js')].exports!==canonical)throw Error('canonical module identity replaced');process.stdout.write('canonical-first-entry-ok')}finally{dom.window.close()}`;
 assert.equal(execFileSync(process.execPath,['--experimental-vm-modules','--input-type=module','-e',script],{cwd:new URL('..',import.meta.url),encoding:'utf8',timeout:15000}),'canonical-first-entry-ok');
});
''';f.write_text(s)
s=(e/'candidate-r8-next-slot.py').read_text().replace('candidate-r8','candidate-r9').replace("'sourceRevision':'R8'","'sourceRevision':'R9'").replace("'new23'","'new24'").replace("'test/xml-query-policy.test.js'],23)","'test/xml-query-policy.test.js'],24)").replace('evidence/candidate-r9-prefix-probe.mjs','evidence/candidate-r8-prefix-probe.mjs');(e/'candidate-r9-next-slot.py').write_text(s);compile(s,'R9Controller','exec')
f=e/'candidate-r8-next-new23-24.22.1-status.json';d=json.loads(f.read_text());log=e/'candidate-r8-next-new23-24.22.1-new23.log';summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$',log.read_text(),re.M)}
seal={'statusSHA256':H(f),'logSHA256':H(log),'tapSummary':summary,'seconds':d['seconds'],'inputs':d['inputs'],'changedInputs':d['changedInputs'],'rootChangedSourceFiles':d['rootChangedSourceFiles'],'failure':d['failure'],'stage':'23/23 fail before real author behavior, canonical createWindow installInterfaces undefined','sourceCause':'New first-import initial-document-parser→html-qualified-name-parser→qualified-element-birth eagerly required generated HTMLElement→html-constructor→create-element→interfaces cycle before normal jsdom entry. OriginalWindow destructured incomplete installInterfaces; no actual markup assertions were reached.','R9Correction':'Both new modules defer ALL private jsdom requires until their existing trusted installation functions, after real canonical Window boot. No cache flush, module exports identity replacement, public retarget, fake warmup or altered body semantics.','R8Strict19Heldout2Prefix2FactoriesSDK':'ALL_UNRUN stop-first','R9':'UNRUN'};(e/'candidate-r8-negative-seal.json').write_text(json.dumps(seal,indent=2)+'\n')
inputs=json.loads((e/'candidate-r8-next-inputs.json').read_text())
for top in['src','test','bin','native','scripts']:
 for f in(c/top).rglob('*')if(c/top).exists()else[]:
  if f.is_file():inputs[str(f)]=H(f)
for name in['package.json','package-lock.json','VERSION']:
 if(c/name).is_file():inputs[str(c/name)]=H(c/name)
for name in['candidate-r9-next-slot.py','candidate-r8-negative-seal.json','candidate-r8-prefix-probe.mjs','candidate-r6-causal-probe.mjs']:
 inputs[str(e/name)]=H(e/name)
(e/'candidate-r9-next-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n')
patch='';leaves={}
for name in['src/qualified-element-birth.js','src/html-qualified-name-parser.js','test/xml-query-policy.test.js']:
 old=p/'candidate-r8'/name;f=c/name;leaves[name]={'before':H(old),'after':H(f),'status':'STATIC_UNRUN'};patch+='diff --git a/'+name+' b/'+name+'\n'+''.join(difflib.unified_diff(old.read_text().splitlines(True),f.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(e/'candidate-r9-delta.patch').write_text(patch);(e/'candidate-r9-delta-leaves.json').write_text(json.dumps(leaves,indent=2)+'\n');print(json.dumps({'controllerSHA256':H(e/'candidate-r9-next-slot.py'),'inputs':len(inputs),'manifestSHA256':H(e/'candidate-r9-next-inputs.json'),'deltaPatchSHA256':H(e/'candidate-r9-delta.patch'),'R8Actual':summary,'R9':'UNRUN firstnew24 thenstrict19/heldout2/prefix2,60/42/SDK unchanged'},indent=2))
