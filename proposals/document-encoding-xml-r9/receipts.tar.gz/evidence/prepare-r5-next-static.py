from pathlib import Path
import json,hashlib,difflib,shutil,subprocess
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';root=Path('/workspace/red-panda');H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
# Derivative retains every authored HTTP byte and expression from Native4.
s=(e/'native-xhtml-heldout-probe.mjs').read_text();s=s.replace("import{startReference}from'../helpers/reference-server.mjs'","import{startRoot}from'../helpers/root-server.mjs'")
s=s.replace("const binary=process.argv[2],output=process.argv[3],sha=v=>createHash('sha256').update(v).digest('hex'),record={actor:'Native-XHTML-Heldout',binary,binarySHA256:sha(await readFile(binary))", "const source=process.argv[2],output=process.argv[3],sha=v=>createHash('sha256').update(v).digest('hex'),record={actor:'CandidateR5-XHTML-Heldout',source,sourceSHA256:sha(await readFile(source+'/src/browser.js'))")
s=s.replace("startReference(binary,{args:['--load-resources','iframe']})","startRoot(source)")
assert 'startReference' not in s and 'binary' not in s
(e/'candidate-r5-xhtml-heldout-probe.mjs').write_text(s)
s=(e/'candidate-r3-next-slot.py').read_text().replace("candidate-r3", "candidate-r5").replace("'sourceRevision':'R3'","'sourceRevision':'R5'")
s=s.replace("['observations','regressions','new12']","['observations','regressions','factories','new18']").replace("mode!='new12'", "mode!='new18'").replace('First12 Node24.22','First18 Node24.22').replace('Native15','Native19')
s=s.replace("evidence/candidate-r5-native-eight-probe.mjs","evidence/candidate-r3-native-eight-probe.mjs").replace("evidence/candidate-r5-native-seven-probe.mjs","evidence/candidate-r3-native-seven-probe.mjs")
s=s.replace("elif mode=='new12':testPhase('new12',['test/document-encoding.test.js'],12)"," observationPhase('heldout4','evidence/candidate-r5-xhtml-heldout-probe.mjs','evidence/native-xhtml-heldout.json',4)\n elif mode=='new18':testPhase('new18',['test/document-encoding.test.js','test/initial-xhtml-parser.test.js'],18)\n elif mode=='factories':testPhase('factories60',['test/document-interface-realms.test.js','test/document-xml.test.js','test/dom-factory-parity.test.js','test/dom-wrapper-realms.test.js','test/location-factory.test.js','test/namespace-serialization.test.js','test/manual-document-realms.test.js'],60)")
assert "mode=='new12'" not in s
# Historical semantic driver filenames stay verbatim; code has no branch on candidate revision.
(e/'candidate-r5-next-slot.py').write_text(s)
compile(s,str(e/'candidate-r5-next-slot.py'),'exec')
# Successful receipt is a separate immutable after-the-fact interpretation.
receipt=json.loads((e/'candidate-r5-first-status.json').read_text());assert receipt['passedObservedPhases'] and not receipt['changedInputs'] and not receipt['rootChangedSourceFiles'];assert receipt['phases'][0]['tapSummary']['pass']==18
seal={'scope':'R5 first18 only; future observations/SDK/regressions UNRUN','receiptSHA256':H(e/'candidate-r5-first-status.json'),'logSHA256':H(e/'candidate-r5-first-new18.log'),'seconds':receipt['seconds'],'inputs':receipt['inputs'],'processesAfterCleanup':receipt['phases'][0]['processesAfterCleanup'],'historicalR3StrictFailureRetained':True,'sourceChangesAfterReceipt':[]}
(e/'candidate-r5-first-receipt-seal.json').write_text(json.dumps(seal,indent=2)+'\n')
# Current Root projection is a separate owned graph. Only exact changed segments
# transfer; all unrelated current Root bytes survive. No old Browser overwrite.
projection=p/'projection-root-5adb9b3-r5';assert not projection.exists()
for folder in ['src','test','bin','native/src','scripts']:
 source=root/folder
 if source.exists():shutil.copytree(source,projection/folder)
for name in ['package.json','package-lock.json','VERSION']:
 if (root/name).is_file():shutil.copy2(root/name,projection/name)
(projection/'node_modules').symlink_to(root/'node_modules',target_is_directory=True)
leaves=json.loads((e/'candidate-r5-leaves.json').read_text());mapped={}
for name in leaves:
 base=p/'base-97bb'/name;target=p/'candidate-r5'/name;dest=projection/name
 current=(root/name).read_text() if (root/name).exists() else None
 if not base.exists():assert current is None;result=target.read_text()
 else:
  a=base.read_text().splitlines(True);b=target.read_text().splitlines(True);result=current
  # Base-only compiler argument line has a current accepted Base-interface
  # bridge; compose both actual lexical dependencies in positional order.
  if name=='src/dom-wrapper-realms.js':
   old=next(x for x in a if 'vm.compileFunction(source,' in x);new=next(x for x in b if 'vm.compileFunction(source,' in x);actual=next(x for x in result.splitlines(True) if 'vm.compileFunction(source,' in x)
   assert actual==old.replace("'installControlInterface']","'installControlInterface','baseInterfaceHelpers']").replace('installControlInterface);','installControlInterface,baseInterfaceHelpers);')
   composed=actual.replace("'baseInterfaceHelpers']","'baseInterfaceHelpers','htmlDocumentBirth']").replace('baseInterfaceHelpers);','baseInterfaceHelpers,htmlDocumentBirth);')
   result=result.replace(actual,composed);b=[old if x==new else x for x in b]
  matcher=difflib.SequenceMatcher(None,a,b,autojunk=False)
  # Edits use unique literal anchors. Appending/prepending preserves Root imports.
  for tag,i,j,k,l in reversed(matcher.get_opcodes()):
   if tag=='equal':continue
   old=''.join(a[i:j]);new=''.join(b[k:l])
   if not old:
    if i==0:result=new+result
    else:
     anchor=''.join(a[max(0,i-2):i]);assert result.count(anchor)==1,(name,'insertion anchor');result=result.replace(anchor,anchor+new)
   else:assert result.count(old)==1,(name,'replacement anchor');result=result.replace(old,new)
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(result)
 mapped[name]={'before':H(root/name) if (root/name).exists() else None,'after':H(dest),'candidateR5':H(target),'composedCurrentRootRatherThanWholeOldFile':True}
# All unmodified current src are byte-identical, notably Pointer and install order.
for source in (root/'src').rglob('*'):
 if source.is_file() and str(source.relative_to(root))not in leaves:assert source.read_bytes()==(projection/source.relative_to(root)).read_bytes()
patch=''
for name in leaves:
 before=(root/name).read_text().splitlines(True) if (root/name).exists()else[];after=(projection/name).read_text().splitlines(True)
 patch+='diff --git a/'+name+' b/'+name+'\n'
 if not before:patch+='new file mode 100644\n'
 patch+=''.join(difflib.unified_diff(before,after,fromfile='a/'+name if before else'/dev/null',tofile='b/'+name))
(e/'candidate-r5-on-root-5adb9b3.patch').write_text(patch)
(e/'candidate-r5-on-root-5adb9b3-leaves.json').write_text(json.dumps({'rootCommit':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'scope':'STATIC_ONLY_UNRUN; does not promote old-base observations','leaves':mapped},indent=2)+'\n')
# Extend frozen successful R5 manifest, leaving source and prior receipt unchanged.
inputs=json.loads((e/'candidate-r5-first-inputs.json').read_text())
for name in ['candidate-r5-next-slot.py','candidate-r5-xhtml-heldout-probe.mjs','candidate-r3-native-eight-probe.mjs','candidate-r3-native-seven-probe.mjs','native-document-encoding.json','native-encoding-continuation.json','native-xhtml-heldout.json','candidate-r5-first-status.json','candidate-r5-first-new18.log','candidate-r5-first-receipt-seal.json']:
 f=e/name;inputs[str(f)]=H(f)
(e/'candidate-r5-next-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n')
print(json.dumps({'inputs':len(inputs),'controllerSHA256':H(e/'candidate-r5-next-slot.py'),'manifestSHA256':H(e/'candidate-r5-next-inputs.json'),'projectionPatchSHA256':H(e/'candidate-r5-on-root-5adb9b3.patch'),'projectionLeavesSHA256':H(e/'candidate-r5-on-root-5adb9b3-leaves.json'),'firstReceiptSealSHA256':H(e/'candidate-r5-first-receipt-seal.json')},indent=2))
