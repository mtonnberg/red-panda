from pathlib import Path
import hashlib,json,difflib,shutil,subprocess
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';root=Path('/workspace/red-panda');c=p/'candidate-r9';out=p/'projection-root-79ad40d-r9';assert not out.exists();H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();commit=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip();assert commit=='79ad40d25030190f6794c4c8d5c1d18d2be42ab4'
for folder in['src','test','bin','native/src','scripts']:
 if(root/folder).exists():shutil.copytree(root/folder,out/folder)
for name in['package.json','package-lock.json','VERSION']:
 if(root/name).is_file():shutil.copy2(root/name,out/name)
(out/'node_modules').symlink_to(root/'node_modules',target_is_directory=True)
leaves={}
for top in['src','test']:
 for f in sorted((c/top).glob('*')):
  if not f.is_file():continue
  name=f.relative_to(c);base=p/'base-97bb'/name
  if base.exists()and base.read_bytes()==f.read_bytes():continue
  current=root/name;actual=current.read_text()if current.exists()else None
  if not base.exists():assert actual is None;result=f.read_text()
  else:
   a=base.read_text().splitlines(True);b=f.read_text().splitlines(True);result=actual
   if str(name)=='src/dom-wrapper-realms.js':
    old=next(x for x in a if'vm.compileFunction(source,'in x);new=next(x for x in b if'vm.compileFunction(source,'in x);now=next(x for x in result.splitlines(True)if'vm.compileFunction(source,'in x)
    assert now==old.replace("'installControlInterface']","'installControlInterface','baseInterfaceHelpers']").replace('installControlInterface);','installControlInterface,baseInterfaceHelpers);')
    result=result.replace(now,now.replace("'baseInterfaceHelpers']","'baseInterfaceHelpers','htmlDocumentBirth']").replace('baseInterfaceHelpers);','baseInterfaceHelpers,htmlDocumentBirth);'));b=[old if x==new else x for x in b]
   for tag,i,j,k,l in reversed(difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes()):
    if tag=='equal':continue
    old=''.join(a[i:j]);new=''.join(b[k:l])
    if not old:
     if i==0:result=new+result
     else:
      anchor=''.join(a[max(0,i-2):i]);assert result.count(anchor)==1,(str(name),'insertion');result=result.replace(anchor,anchor+new)
    else:assert result.count(old)==1,(str(name),'replacement');result=result.replace(old,new)
  dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(result);leaves[str(name)]={'before':H(current)if current.exists()else None,'after':H(dest),'oldCandidateR9':H(f),'status':'STATIC_HUNK_COMPOSED_UNRUN'}
patch=''
for name in sorted(leaves):
 old=root/name;new=out/name;patch+='diff --git a/'+name+' b/'+name+'\n';patch+=('new file mode 100644\n'if not old.exists()else'');patch+=''.join(difflib.unified_diff(old.read_text().splitlines(True)if old.exists()else[],new.read_text().splitlines(True),fromfile='a/'+name if old.exists()else'/dev/null',tofile='b/'+name))
(e/'candidate-r9-on-root-79ad40d.patch').write_text(patch)
rootMap={str(f.relative_to(root)):H(f)for f in sorted((root/'src').rglob('*'))if f.is_file()};projectMap={str(f.relative_to(out)):H(f)for f in sorted((out/'src').rglob('*'))if f.is_file()}
for name in rootMap:
 if name not in leaves:assert rootMap[name]==projectMap[name]
manifest={'rootCommit':commit,'status':'STATIC_ONLY_UNRUN; old97bb-based R9 candidate epochs are not currentRoot validation','leafCount':len(leaves),'leaves':leaves,'rootSourceFiles':rootMap,'projectedSourceFiles':projectMap,'patchSHA256':H(e/'candidate-r9-on-root-79ad40d.patch'),'preservation':'ALL unaffected currentRoot source byte-identical, including new EventCounts/performance/platform-codec,Pointer/File/lifecycle; Browser current imports/installers kept, canonical DOM compiler retains both baseInterfaceHelpers+htmlDocumentBirth lexical arguments. No old CDP/isolated-world overwrite. NoRoot mutation.'}
(e/'candidate-r9-on-root-79ad40d-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'patchSHA256':manifest['patchSHA256'],'manifestSHA256':H(e/'candidate-r9-on-root-79ad40d-manifest.json'),'leaves':len(leaves)},indent=2))
