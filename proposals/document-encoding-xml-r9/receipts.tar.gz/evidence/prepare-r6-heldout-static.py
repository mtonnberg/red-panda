from pathlib import Path
import json,hashlib
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
s=(e/'native-xhtml-heldout-probe.mjs').read_text()
s=s.replace("actor:'Native-XHTML-Heldout'","actor:'Native-XHTML-R6-Causal'")
start=s.index('const html=');end=s.index('\nlet browser,',start)
# All genuine birth modes carry the same actual mixed-case names, namespaces and
# prefixes. Collections are observed before/after actual source-node mutation.
markup='<html xmlns="http://www.w3.org/1999/xhtml" xmlns:p="urn:actual"><head></head><body><div id="container"><DiV id="mixed-known"/><div id="ordinary"/><CaseNode id="mixed-unknown"/><casenode id="lower-unknown"/><p:CaseNode id="foreign-prefix"/><svg xmlns="http://www.w3.org/2000/svg"><CaseNode id="svg-child"/></svg></div></body></html>'
s=s[:start]+'const html='+json.dumps(markup)+';'+s[end:]
s=s.replace("path==='/interfaces'||path==='/order'?'application/xhtml+xml':'text/html; charset=utf-8'", "path==='/collections'?'application/xhtml+xml':'text/html; charset=utf-8'")
s=s.replace("path==='/order'?order:path==='/interfaces'?html:'<!doctype html><p>Actual XML counterparts</p>'", "path==='/collections'?html:'<!doctype html><p>Actual XML parser-error counterparts</p>'")
start=s.index('const expressions={');end=s.index('\ntry{await',start)
collection="""(()=>{const markup=SOURCE;const names=['div','DIV','DiV','CaseNode','casenode','CASENODE','p:CaseNode','p:casenode','*'];const rows=[];const snap=(root)=>Object.fromEntries(names.map(name=>[name,Array.from(root.getElementsByTagName(name),n=>({id:n.id,name:n.localName,ns:n.namespaceURI,prefix:n.prefix,constructor:n.constructor.name}))]));for(const[label,d]of[['active',document],...['application/xhtml+xml','application/xml','text/xml','text/html'].map(mime=>[mime,new DOMParser().parseFromString(markup,mime)])]){const container=d.getElementById('container');const watched=d.getElementsByTagName('CaseNode');const before={document:snap(d),element:snap(container),namespace:Array.from(d.getElementsByTagNameNS('http://www.w3.org/1999/xhtml','CaseNode'),n=>n.id)};const n=d.createElementNS('http://www.w3.org/1999/xhtml','CASEnode');n.id='added-heldout';container.appendChild(n);const after={live:Array.from(watched,n=>n.id),fresh:Array.from(d.getElementsByTagName('casenode'),n=>n.id),addedName:n.localName,addedConstructor:n.constructor.name};n.remove();rows.push({label,before,after,removedLive:Array.from(watched,n=>n.id)})}return rows})()""".replace('SOURCE',json.dumps(markup))
errors="""(()=>{const rows=[];for(const mime of['application/xhtml+xml','application/xml','text/xml','image/svg+xml'])for(const source of['<r><broken></r>','<r a="x" a="y"/>','<unbound:child/>','<r>&actualUnknown;</r>','<r><a/></r>']){const d=new DOMParser().parseFromString(source,mime),n=d.documentElement;rows.push({mime,source,document:d.constructor.name,contentType:d.contentType,root:n.localName,namespace:n.namespaceURI,text:n.textContent,outer:n.outerHTML,serialized:new XMLSerializer().serializeToString(d),script:globalThis.actualUnexpectedParserScript})}return rows})()"""
s=s[:start]+'const expressions='+json.dumps({'/collections':collection,'/errors':errors},ensure_ascii=False)+';'+s[end:]
(e/'native-xhtml-r6-causal-probe.mjs').write_text(s)
c=(e/'native-xhtml-heldout-slot.py').read_text().replace('native-xhtml-heldout','native-xhtml-r6-causal').replace('timeout=20','timeout=15').replace("'outerWatchdog':20","'outerWatchdog':15").replace('len(groups)==4','len(groups)==2')
(e/'native-xhtml-r6-causal-slot.py').write_text(c);compile(c,'R6NativeController','exec')
inputs=json.loads((e/'native-xhtml-heldout-inputs.json').read_text())
for f in [e/'native-xhtml-r6-causal-probe.mjs',e/'native-xhtml-r6-causal-slot.py',e/'candidate-r5-strict-negative-seal.json']:
 inputs[str(f)]=H(f)
(e/'native-xhtml-r6-causal-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n')
print(json.dumps({'driver':H(e/'native-xhtml-r6-causal-probe.mjs'),'controller':H(e/'native-xhtml-r6-causal-slot.py'),'manifest':H(e/'native-xhtml-r6-causal-inputs.json'),'inputs':len(inputs),'scope':'Native2groups5birthmodes collection scopes/live and4MIME5XML errors; originalRPC2500/admin15+3,UNRUN'},indent=2))
