from pathlib import Path
import json,hashlib,tarfile
p=Path('/workspace/shared/document-encoding-recovery');e=p/'evidence';root=Path('/workspace/red-panda');H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();archive=root/'proposals/managed-written-lifecycle-r2/receipts.tar.gz'
with tarfile.open(archive)as t:before=json.load(t.extractfile('actual-root/before.json'))['actualRootBefore'];baselineStatus=json.load(t.extractfile('actual-root/status.json'))
assert len(before)==605 and baselineStatus['complete'];leafDoc=json.loads((e/'candidate-r9-on-root-79ad40d-manifest.json').read_text());leaves=leafDoc['leaves'];assert len(leaves)==16
for name,record in leaves.items():assert before.get(name)==record['before'],(name,'Root605 before leaf mismatch')
after=dict(before)
for name,record in leaves.items():after[name]=record['after']
assert len(after)==615
# Verify the current Root is still the exact approved 605-input baseline. This
# preparation never applies anything; the future gate demands all615 AFTER.
def identity(directory):
 values={str(f.relative_to(directory)):H(f)for d in['src','test','native','scripts','bin']for f in(directory/d).rglob('*')if f.is_file()and not f.is_symlink()};values.update({n:H(directory/n)for n in['package.json','package-lock.json']});return values
assert identity(root)==before,'Current Root79 source baseline drifted before static controller preparation'
artifacts=[]
for sdk in['24.22.1','24.19.0','26.13.0']:
 for binary,source in[('runtime.node','runtime.cc'),('collections.node','collections.cc'),('heap-query.node','heap-query.cc')]:
  path=root/'native/build/linux-x64'/('node-'+sdk)/binary;meta=Path(str(path)+'.json');data=json.loads(meta.read_text());assert data['sourceSHA256']==H(root/'native'/source)and data['binarySHA256']==H(path)
  artifacts.append({'binary':str(path.relative_to(root)),'manifest':str(meta.relative_to(root)),'binarySHA256':H(path),'manifestSHA256':H(meta),'matchingSource':str(Path('native')/source),'sourceSHA256':data['sourceSHA256'],'metadata':data})
contract={'baselineCommit':'79ad40d25030190f6794c4c8d5c1d18d2be42ab4','baseline605':before,'exactChanged16':leaves,'expectedAfter615':after,'RootNative18Files':artifacts,'original605ReceiptArchive':str(archive),'original605ReceiptArchiveSHA256':H(archive),'patch':str(e/'candidate-r9-on-root-79ad40d.patch'),'patchSHA256':H(e/'candidate-r9-on-root-79ad40d.patch'),'scope':'UNRUN actualRoot only AFTER reviewed16-leaf application. No own190 execution; preserves oldbase and ownprojection epochs.'};(e/'actual-root79-r9-apply-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
s=(e/'root79-r9-composed-slot.py').read_text();s=s.replace("candidate=p/'projection-root-79ad40d-r9';mode,sdk=sys.argv[1:];", "candidate=Path('/workspace/red-panda');mode=sys.argv[1];sdk='24.22.1';")
s=s.replace("assert mode in['observations','primary126','lifecycle64','heldout2','prefix2']and sdk in nodes,'Unsupported declared gate'", "assert mode in['primary126','lifecycle64'],'Only two actualRoot composed phases declared'")
s=s.replace("assert mode!='observations'or sdk=='24.22.1','Retained Native19 comparisons are declared only for Node24.22'\n",'').replace('root79-r9-composed','actual-root79-r9')
needle="assert inputs()==expected,'Frozen candidate/source/artifact/Native inputs changed before launch'";assert s.count(needle)==1
replacement="""assert inputs()==expected,'Frozen oldcandidate/Native/controller/dependency inputs changed before launch'
contract=json.loads((p/'evidence/actual-root79-r9-apply-contract.json').read_text())
def actualRootIdentity():
 values={str(f.relative_to(candidate)):digest(f)for d in['src','test','native','scripts','bin']for f in(candidate/d).rglob('*')if f.is_file()and not f.is_symlink()};values.update({n:digest(candidate/n)for n in['package.json','package-lock.json']});return values
assert actualRootIdentity()==contract['expectedAfter615'],'Actual Root must equal ALL605 baseline plus exact16 after hashes (615 resulting inputs), no extra/missing files'
for name,leaf in contract['exactChanged16'].items():assert digest(candidate/name)==leaf['after'],'Exact reviewed Root leaf changed: '+name
for artifact in contract['RootNative18Files']:
 actualMeta=json.loads((candidate/artifact['manifest']).read_text());assert digest(candidate/artifact['binary'])==artifact['binarySHA256']and digest(candidate/artifact['manifest'])==artifact['manifestSHA256']and digest(candidate/artifact['matchingSource'])==artifact['sourceSHA256']and actualMeta==artifact['metadata'],'Actual Root18 matching artifact changed'
assert digest(Path(contract['patch']))==contract['patchSHA256'],'Reviewed exact16 patch changed'
"""
s=s.replace(needle,replacement)
s=s.replace("'sourceRevision':'CURRENT_ROOT79_HUNK_COMPOSED_R9_STATIC_UNRUN',", "'sourceRevision':'ACTUAL_ROOT79_AFTER_REVIEWED_R9_EXACT16','Root605Plus16ContractSHA256':digest(p/'evidence/actual-root79-r9-apply-contract.json'),'actualRootInputs':615,'actualRootNativeArtifacts':18,'own190ControllerExecuted':False,")
a=s.index("try:\n if mode=='observations':");b=s.index(" status['passedObservedPhases']=True",a)
original=(e/'root79-r9-composed-slot.py').read_text();primary=next(l for l in original.splitlines()if"elif mode=='primary126'"in l);lifecycle=next(l for l in original.splitlines()if"elif mode=='lifecycle64'"in l);s=s[:a]+'try:\n'+primary.replace(' elif',' if')+'\n'+lifecycle.replace(' elif',' else:').replace("else: mode=='lifecycle64':","else:")+'\n'+s[b:]
# Record full615 identity after each phase, not merely src hashes.
s=s.replace("after=inputs();status['changedInputs']", "status['actualRoot615Unchanged']=actualRootIdentity()==contract['expectedAfter615'];after=inputs();status['changedInputs']")
s=s.replace("not status['rootChangedSourceFiles']else 1", "not status['rootChangedSourceFiles']and status['actualRoot615Unchanged']else 1")
(e/'actual-root79-r9-slot.py').write_text(s);compile(s,'ActualRoot79R9Controller','exec')
inputs=json.loads((e/'candidate-r9-next-inputs.json').read_text())
for name in['actual-root79-r9-slot.py','actual-root79-r9-apply-contract.json','candidate-r9-on-root-79ad40d.patch','candidate-r9-on-root-79ad40d-manifest.json']:
 inputs[str(e/name)]=H(e/name)
inputs[str(archive)]=H(archive)
# Only original already-consumed Native write fixture outside615 is relevant to
# lifecycle64; no new reference download or changed source fixture.
f=root/'proposals/document-write/native.json';inputs[str(f)]=H(f)
(e/'actual-root79-r9-inputs.json').write_text(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n');print(json.dumps({'controllerSHA256':H(e/'actual-root79-r9-slot.py'),'manifestSHA256':H(e/'actual-root79-r9-inputs.json'),'contractSHA256':H(e/'actual-root79-r9-apply-contract.json'),'fixedInputs':len(inputs),'rootBefore605Verified':True,'rootExpectedAfter':len(after),'exactLeaves':len(leaves),'actualRootCxxAnd18Unchanged':True,'commands':[['python3','evidence/actual-root79-r9-slot.py','primary126'],['python3','evidence/actual-root79-r9-slot.py','lifecycle64']],'status':'UNRUN; controller cannot run against unpatched Root79 baseline'},indent=2))
