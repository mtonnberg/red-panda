import 'jsdom';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {setTimeout as hostTask,clearTimeout as cancelTask} from 'node:timers';
import {createInvocationTrampoline} from './invocation.js';
import {installErrors} from './errors.js';
import {registerProtocolPrototype} from './protocol-classes.js';

// Records and task ownership remain in Host code; page objects carry no private
// symbols, implementation fields, permission grants, or manufactured positions.
const records=new WeakMap(),navigators=new WeakMap(),geolocations=new WeakMap(),errors=new WeakMap(),notifications=new WeakMap();
const positions=new WeakMap(),coordinates=new WeakMap();
const {implForWrapper}=createRequire(import.meta.url)('jsdom/lib/jsdom/living/generated/utils.js');

function factory(g,bridge){
 const {defineProperty,defineProperties,getOwnPropertyDescriptor,getOwnPropertyNames,create,setPrototypeOf}=Object;
 const apply=Reflect.apply,construct=Reflect.construct,EventTargetConstructor=EventTarget,TypeErrorConstructor=TypeError,StringConstructor=String,PromiseConstructor=Promise;
 const resolvePromise=Promise.resolve,primitiveSymbol=Symbol.toPrimitive,symbolDescription=getOwnPropertyDescriptor(Symbol.prototype,'description').get;
 const invalid=()=>{throw new TypeErrorConstructor('invalid argument')};
 const invocation=()=>{throw new TypeErrorConstructor('Illegal invocation')};
 const object=v=>v!==null&&(typeof v==='object'||typeof v==='function'||(v!==undefined&&typeof v==='undefined'));
 function text(value){
  if(object(value)){
   const primitive=value[primitiveSymbol];
   if(primitive!==null&&primitive!==undefined){if(typeof primitive!=='function')invalid();value=apply(primitive,value,['string']);if(object(value))invalid();}
   else{let done=false;for(let i=0;i<2;i++){const method=value[i===0?'toString':'valueOf'];if(typeof method!=='function')continue;const result=apply(method,value,[]);if(!object(result)){value=result;done=true;break;}}if(!done)invalid();}
  }
  return StringConstructor(typeof value==='symbol'?apply(symbolDescription,value,[]):value);
 }
 function options(value){
  if(value===null||value===undefined)return;
  if(!object(value))invalid();
  const high=value.enableHighAccuracy;if(high!==undefined)!!high;
  const age=value.maximumAge;if(age!==undefined)age>>>0;
  const timeout=value.timeout;if(timeout!==undefined&&timeout!==null)timeout>>>0;
 }
 function Geolocation(){'use strict';throw new TypeErrorConstructor(new.target?'Illegal Constructor':'invalid argument');}
 function GeolocationPosition(){'use strict';throw new TypeErrorConstructor(new.target?'Illegal Constructor':'invalid argument');}
 function GeolocationCoordinates(){'use strict';throw new TypeErrorConstructor(new.target?'Illegal Constructor':'invalid argument');}
 function GeolocationPositionError(){'use strict';throw new TypeErrorConstructor(new.target?'Illegal Constructor':'invalid argument');}
 const geoMethods={
  getCurrentPosition(success,error=undefined,value=undefined){
   if(!bridge.hasGeo(this))invocation();if(typeof success!=='function'||(error!==null&&error!==undefined&&typeof error!=='function'))invalid();options(value);bridge.request(this,success,error,false);
  },
  watchPosition(success,error=undefined,value=undefined){
   if(!bridge.hasGeo(this))invocation();if(typeof success!=='function'||(error!==null&&error!==undefined&&typeof error!=='function'))invalid();options(value);return bridge.request(this,success,error,true);
  },
  clearWatch(id){if(!bridge.hasGeo(this))invocation();if(!arguments.length)invalid();bridge.clear(this,id|0);},
 };
 function preparePrototype(C,methods={},getters={}){
  const p=C.prototype,constructor=getOwnPropertyDescriptor(p,'constructor');delete p.constructor;
  for(const name of getOwnPropertyNames(methods))defineProperty(p,name,{value:methods[name],writable:true,enumerable:true,configurable:true});
  for(const name of getOwnPropertyNames(getters))defineProperty(p,name,{...getOwnPropertyDescriptor(getters,name),enumerable:true,configurable:true});
  defineProperty(p,Symbol.toStringTag,{value:C.name,configurable:true});return()=>defineProperty(p,'constructor',constructor);
 }
 preparePrototype(Geolocation,geoMethods)();
 const errorConstructor=preparePrototype(GeolocationPositionError,{}, {
  get code(){if(!bridge.hasError(this))invocation();return bridge.error(this,'code');},
  get message(){if(!bridge.hasError(this))invocation();return bridge.error(this,'message');},
 });
 for(const[key,value]of [['PERMISSION_DENIED',1],['POSITION_UNAVAILABLE',2],['TIMEOUT',3]])for(const target of[GeolocationPositionError,GeolocationPositionError.prototype])defineProperty(target,key,{value,enumerable:true});
 errorConstructor();
 const coordinateConstructor=preparePrototype(GeolocationCoordinates);
 // Denied defaults create no coordinates or positions. A future producer must
 // register actual explicit backend data before these accessors can succeed.
 for(const key of ['latitude','longitude','accuracy','altitude','altitudeAccuracy','heading','speed']){const accessor={get [key](){if(!bridge.hasCoordinates(this))invocation();return bridge.coordinate(this,key);}};defineProperty(GeolocationCoordinates.prototype,key,{...getOwnPropertyDescriptor(accessor,key),enumerable:true,configurable:true});}
 const coordinateMethods={toJSON(){if(!bridge.hasCoordinates(this))invocation();return{accuracy:this.accuracy,latitude:this.latitude,longitude:this.longitude,altitude:this.altitude,altitudeAccuracy:this.altitudeAccuracy,heading:this.heading,speed:this.speed};}};
 defineProperty(GeolocationCoordinates.prototype,'toJSON',{...getOwnPropertyDescriptor(coordinateMethods,'toJSON'),enumerable:true});coordinateConstructor();
 const positionConstructor=preparePrototype(GeolocationPosition,{}, {
  get coords(){if(!bridge.hasPosition(this))invocation();return bridge.position(this,'coords');},
  get timestamp(){if(!bridge.hasPosition(this))invocation();return bridge.position(this,'timestamp');},
 });
 const positionMethods={toJSON(){if(!bridge.hasPosition(this))invocation();return{coords:this.coords.toJSON(),timestamp:this.timestamp};}};
 defineProperty(GeolocationPosition.prototype,'toJSON',{...getOwnPropertyDescriptor(positionMethods,'toJSON'),enumerable:true});positionConstructor();
 function Notification(title){
  'use strict';
  const value=arguments[1];
  if(!new.target||!arguments.length)invalid();
  title=text(title);if(value!==null&&value!==undefined&&!object(value))invalid();
  const data={title,body:'',icon:'',image:'',badge:'',tag:'',lang:'',dir:'auto',silent:false,requireInteraction:false,renotify:false};
  if(value!==null&&value!==undefined){const keys=['badge','body','dir','icon','image','lang','renotify','requireInteraction','silent','tag'];for(let i=0;i<keys.length;i++){const key=keys[i],item=value[key];if(item!==null&&item!==undefined)data[key]=(key==='renotify'||key==='requireInteraction'||key==='silent')?!!item:text(item);}}
  const result=construct(EventTargetConstructor,[],new.target);bridge.notification(result,data);return result;
 }
 setPrototypeOf(Notification,EventTargetConstructor);setPrototypeOf(Notification.prototype,EventTargetConstructor.prototype);
 const finishNotification=preparePrototype(Notification,{close(){if(!bridge.hasNotification(this))invocation();}});
 for(const key of ['title','body','icon','image','badge','tag','lang','dir','silent','requireInteraction','renotify']){const accessor={get [key](){if(!bridge.hasNotification(this))invocation();return bridge.notificationValue(this,key);}};defineProperty(Notification.prototype,key,{...getOwnPropertyDescriptor(accessor,key),enumerable:true,configurable:true});}
 finishNotification();
 const statics={get permission(){return'default'},get maxActions(){return 2},requestPermission(){return apply(resolvePromise,PromiseConstructor,['default'])}};
 for(const key of getOwnPropertyNames(statics))defineProperty(Notification,key,{...getOwnPropertyDescriptor(statics,key),enumerable:true,configurable:true});
 const interfaces={Geolocation,GeolocationPosition,GeolocationCoordinates,GeolocationPositionError,Notification};
 for(const[key,value]of Object.entries(interfaces)){defineProperty(value,'prototype',{writable:false});defineProperty(g,key,{value,writable:true,enumerable:false,configurable:true});}
 const geo=create(Geolocation.prototype);bridge.initializeGeo(geo);
 const navigatorAccessor={get geolocation(){const value=bridge.navigatorGeo(this);if(value===undefined)invocation();return value;}};
 defineProperty(g.Navigator.prototype,'geolocation',{...getOwnPropertyDescriptor(navigatorAccessor,'geolocation'),enumerable:true,configurable:true});
 return{interfaces,geo,makeError(code,message){const value=create(GeolocationPositionError.prototype);bridge.initializeError(value,code,message);return value;}};
}

export function retireDeviceRequests(window){records.get(window)?.cancel();}
export function installDevicePermissions(page,window){
 if(records.has(window))return records.get(window).controller;
 const document=window.document,signal=page.documentAbort?.signal,context=implForWrapper(window)._globalObject;
 if(!vm.isContext(context))throw new TypeError('Device APIs require the actual owning VM context');
 const invocation=createInvocationTrampoline(context),report=installErrors(page,window),tasks=new Set();
 const record={page,window,document,signal,tasks,disposed:false};let api;
 const active=()=>!record.disposed&&!page.closed&&!signal?.aborted&&window.document===document;
 function cancel(job){cancelTask(job.timer);job.owner.tasks.delete(job);if(job.watchId)job.state.watches.delete(job.watchId);job.success=job.error=null;}
 record.cancel=()=>{for(const job of tasks)cancel(job)};
 const bridge={
  initializeGeo(value){geolocations.set(value,{next:0,watches:new Map()});},navigatorGeo:receiver=>navigators.get(receiver)?.geo,
  hasGeo:receiver=>geolocations.has(receiver),hasError:receiver=>errors.has(receiver),error:(receiver,key)=>errors.get(receiver)[key],
  initializeError(value,code,message){errors.set(value,{code,message})},
  hasPosition:value=>positions.has(value),position:(value,key)=>positions.get(value)[key],hasCoordinates:value=>coordinates.has(value),coordinate:(value,key)=>coordinates.get(value)[key],
  notification(value,data){notifications.set(value,Object.freeze({...data}))},hasNotification:value=>notifications.has(value),notificationValue:(value,key)=>notifications.get(value)[key],
  request(receiver,success,error,watch){
   const state=geolocations.get(receiver),watchId=watch?(state.next===0x7fffffff?1:state.next+1):0;if(watch)state.next=watchId;
   if(!active())return watch?watchId:undefined;
   const job={owner:record,state,watchId,success,error};if(watch)state.watches.set(watchId,job);tasks.add(job);
   job.timer=hostTask(()=>{
    tasks.delete(job);if(watchId)state.watches.delete(watchId);
    const callback=job.error;job.success=job.error=null;
    if(!active()||typeof callback!=='function')return;
    const value=api.makeError(1,'User denied Geolocation');
    try{invocation.invoke(callback,window,[value],{timeout:Math.min(page.timeout??10000,2000),displayErrors:false})}catch(error){report.report(error)}
   },0);return watch?watchId:undefined;
  },
  clear(receiver,id){const job=geolocations.get(receiver).watches.get(id);if(job)cancel(job)},
 };
 api=vm.compileFunction(`return (${factory.toString()})(globalThis,bridge)`,['bridge'],{parsingContext:context})(bridge);
 navigators.set(window.navigator,api);for(const[name,C]of Object.entries(api.interfaces))registerProtocolPrototype(C.prototype,name);
 const dispose=()=>{if(record.disposed)return;record.disposed=true;record.cancel();signal?.removeEventListener('abort',dispose);page.off?.('close',dispose)};
 record.controller=Object.freeze({dispose,get pending(){return tasks.size}});records.set(window,record);
 signal?.addEventListener('abort',dispose,{once:true});page.once?.('close',dispose);if(signal?.aborted||page.closed)dispose();return record.controller;
}
