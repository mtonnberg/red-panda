#!/bin/sh
set -eu
cd /workspace/shared/worker-load-diagnostic-recovery
/workspace/shared/rea-tools/node_modules/node/bin/node --experimental-vm-modules evidence/native-tla-control.mjs evidence/native-tla-control.json > evidence/native-tla-control.log 2>&1
/workspace/shared/rea-tools/node_modules/node/bin/node --experimental-vm-modules evidence/readiness-trace.mjs evidence/worker-fetch-trace.json > evidence/worker-fetch-trace.log 2>&1
python3 - <<'PY'
from pathlib import Path
import json,hashlib
a=json.loads(Path('evidence/base-manifest.json').read_text());bad=[n for n,h in a.items() if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h];Path('evidence/post-trace-sourceguard.json').write_text(json.dumps({'count':len(a),'changed':bad},indent=2)+'\n');print({'count':len(a),'changed':bad})
PY
