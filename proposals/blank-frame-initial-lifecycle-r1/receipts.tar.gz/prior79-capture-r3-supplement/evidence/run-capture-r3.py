"""UNRUN revision3 legitimate raw-factory fixture correction; first four positives excluded; no Source96/generation fix inferred."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent.parent;C=R/'candidate';P=Path('/workspace/red-panda');O=R/'run-capture-gate-r3';assert not O.exists();O.mkdir();N='/workspace/shared/rea-tools/node_modules/.bin/node';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(root):
 return {str(p.relative_to(root)):sha(p) for d in ['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()}|{n:sha(root/n)for n in['package.json','package-lock.json']}
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
manifest=json.loads((R/'candidate-r3-manifest.json').read_text());before=identity(P);candidateBefore=identity(C);contracts={str(p):sha(p)for p in[R/'candidate-r3-manifest.json',R/'accepted79-base.json',R/'source-pins.json',R/'candidate-r3.patch',R/'README-r3.md',R/'evidence/run-capture-r3.py',R/'observed615-current2342-receipt.json',R/'r3-fixture-correction.json',R/'checkpoint1-r2-failed/manifest.json',Path(json.loads((R/'r3-fixture-correction.json').read_text())['resourceLoaderConstructorSource'])]};write('before.json',{'actualRootBefore':before,'actualRootHEAD':subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip(),'acceptedOwnedBaselineCommit':manifest['acceptedBaselineCommit'],'candidateBefore':candidateBefore,'contracts':contracts,'nodeExecutableSHA256':sha(Path(N).resolve())});commands=[];failure=None;current=None
local=os.environ.copy();local['PATH']=str(Path(N).parent)+':'+local.get('PATH','')
def run(label,args,expected=None):
 global current
 begin=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  current=subprocess.Popen([N,*args],cwd=C,env=local,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'started':label,'pid':current.pid}),flush=True);expired=False
  try:code=current.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;os.killpg(current.pid,signal.SIGKILL);current.wait();code=current.returncode
 text=(O/(label+'.stdout')).read_text();counts={k:int(v)for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};row={'label':label,'pid':current.pid,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin,'actualTAPCounts':counts,'expectedCases':expected};commands.append(row);current=None;print(json.dumps(row),flush=True)
 if code or expired:raise RuntimeError('Actual capture-only command failed: '+label)
 if expected is not None:
  assert counts.get('pass')==3 and all(counts.get(k)==0 for k in ['suites','fail','cancelled','todo']),counts
  assert counts.get('skipped')in [0,4] and counts.get('tests')==3+counts.get('skipped'),counts
  actualPassed=re.findall(r'^ok \d+ - (.+?)(?: # .*)?$',text,re.M)
  actualPassed=[n for n in actualPassed if n in json.loads((R/'r3-fixture-correction.json').read_text())['selectedCaseTitles']]
  assert actualPassed==json.loads((R/'r3-fixture-correction.json').read_text())['selectedCaseTitles'],actualPassed
try:
 assert candidateBefore==manifest['candidateAfter608'],'Frozen accepted79 candidate changed; preserve and prepare a new epoch'
 for name,value in manifest['pinnedOriginalSources'].items():assert sha(Path(name))==value,'Pinned original jsdom source changed'
 correction=json.loads((R/'r3-fixture-correction.json').read_text());oldLines=(R/'checkpoint1-r2-failed/candidate/test/window-task-capture.test.js').read_text().splitlines();newLines=(C/'test/window-task-capture.test.js').read_text().splitlines();oldCases=[v for v in oldLines if v.startswith('test(')];newCases=[v for v in newLines if v.startswith('test(')];assert oldCases[:4]==newCases[:4] and len(oldCases)==len(newCases)==7
 assert sha(C/'src/window-task-capture.js')==sha(R/'checkpoint1-r2-failed/candidate/src/window-task-capture.js'),'Runtime changed in a fixture-only correction'
 assert sha(Path(correction['resourceLoaderConstructorSource']))==correction['resourceLoaderSourceSHA256']
 for i,name in enumerate(['test/window-task-capture.test.js','test/fixtures/window-task-capture-timeout.mjs']):run('syntax-'+str(i+1),['--check',str(C/name)])
 pattern='^(?:'+'|'.join(re.escape(v)for v in correction['selectedCaseTitles'])+')$'
 run('capture-three-24.22',['--experimental-vm-modules','--test-concurrency=1','--test-reporter=tap','--test-name-pattern='+pattern,'--test',str(C/'test/window-task-capture.test.js')],3)
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 if current is not None and current.poll()is None:os.killpg(current.pid,signal.SIGKILL);current.wait()
 guards={'actualRootUnchanged':before==identity(P),'frozenCandidateUnchanged':candidateBefore==identity(C),'contractsUnchanged':all(sha(Path(p))==value for p,value in contracts.items()),'pinnedOriginalSourcesUnchanged':all(sha(Path(p))==value for p,value in manifest['pinnedOriginalSources'].items())};write('after-guards.json',guards)
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 write('status.json',{'complete':failure is None,'commands':commands,'failure':failure,'seconds':time.monotonic()-started,'administrativeCap90Seconds':True,'actualVMPolicyMilliseconds':200,'ownedChildDeadlineMilliseconds':7000,'captureOnlyNotSource96':True,'initialProducerGenerationReplacementUnimplemented':True,'current2342IntegrationUnrun':True,'noRootEditsOrNativeBuilds':True,'firstFourPositiveCasesNotRepeated':True,'onlyThreePriorSetupFailuresSelected':True,'skipsAreRawNodeSelectionMetadata':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
