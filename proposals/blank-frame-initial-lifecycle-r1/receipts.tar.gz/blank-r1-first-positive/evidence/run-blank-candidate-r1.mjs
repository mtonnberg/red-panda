import http from 'node:http';import {once} from 'node:events';import {readFile,writeFile} from 'node:fs/promises';import {programs,childWindowRewrite,earlyProbeSource} from './initial-programs.mjs';
import {startReference} from '../../registration455-adapted-plan-20261031/harness/scripts/reference-server.mjs';
import {connect} from '../../registration455-adapted-plan-20261031/harness/test/cdp-client.js';
const engine=process.argv[2],output=process.argv[3];if(!['initialBlankR1'].includes(engine)||!output)throw Error('Explicit engine and new output required');
const frozenNative=JSON.parse(await readFile(new URL('../checkpoint1-native-baseline5/raw/Native.json',import.meta.url),'utf8'));
const report={engine,knownNetworkWindowReentryExcluded:true,ownedBase:'Current2342-derived actual owned blank producer R1; network Window bridge remains unchanged',rows:[],wire:[],APIReplyMilliseconds:2500,scriptParameterMilliseconds:1000,actualLoadBarrierMilliseconds:2000,publicUAOverrides:false};
const binary=engine==='Native'?'/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux':'/workspace/shared/initial-window-generation-2342-r1/initial-blank-candidate/red-panda-launcher';
let server,browser,client;
try{
 report.requests=[];const timers=new Set();report.clearTimers=()=>{for(const timer of timers)clearTimeout(timer);timers.clear()};
 server=http.createServer((request,response)=>{const entry={url:request.url,started:Date.now()};report.requests.push(entry);if(request.url==='/windowRewrite'||request.url==='/networkGeneration'){const source=request.url==='/windowRewrite'?'<script>('+childWindowRewrite.toString()+')()</scr'+'ipt><p>network initial window</p>':'<p id="actualNetwork">actual network generation</p><script>parent.postMessage("ownedInitialNetworkReady","*")</scr'+'ipt>';const timer=setTimeout(()=>{timers.delete(timer);response.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});response.end(source);entry.responded=Date.now();entry.bytes=Buffer.byteLength(source)},25);timers.add(timer);return} response.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});response.end('<!doctype html><title>Owned causal document</title><body>independent control</body>');entry.responded=Date.now()});server.listen(Number(new URL(frozenNative.origin).port),'127.0.0.1');await once(server,'listening');report.origin='http://127.0.0.1:'+server.address().port;
 for(const [name,program]of Object.entries(programs).filter(([name])=>name!=='initialWindowLoadRewrite')){
  let browserContextId,session;const row={name};report.rows.push(row);
  try{
   browser=await startReference(binary,{args:['--ws-max-concurrent','50','--load-resources','iframe','--load-resources','worker']});row.pid=browser.process.pid;client=await connect(browser.endpoint,{timeout:2500});
   const send=async(method,params={},sid=session)=>{const request={method,params,sessionId:sid};report.wire.push(request);try{const result=await client.send(method,params,sid,{timeout:2500});request.result=result;return result}catch(error){request.error={message:error.message,code:error.code};throw error}};
   browserContextId=(await send('Target.createBrowserContext')).browserContextId;const target=await send('Target.createTarget',{url:'about:blank',browserContextId});session=(await send('Target.attachToTarget',{targetId:target.targetId,flatten:true})).sessionId;
   await send('Page.enable');await send('Runtime.enable');await send('Page.setLifecycleEventsEnabled',{enabled:true});await send('Page.addScriptToEvaluateOnNewDocument',{source:earlyProbeSource});const offset=client.events.length,started=Date.now(),navigation=await send('Page.navigate',{url:report.origin+'/'+name});
   while(Date.now()-started<2000){const load=client.events.slice(offset).find(event=>event.sessionId===session&&event.method==='Page.lifecycleEvent'&&event.params.name==='load'&&event.params.frameId===navigation.frameId);if(load){const state=await send('Runtime.evaluate',{expression:'JSON.stringify({ready:document.readyState,url:document.URL,UA:navigator.userAgent})',returnByValue:true,timeout:1000});if(state.exceptionDetails)throw Error('Document barrier evaluation exception');const value=JSON.parse(state.result.value);if(value.ready==='complete'&&value.url===report.origin+'/'+name&&Date.now()-started<2000){row.barrier={event:load.params,document:value,elapsedMilliseconds:Date.now()-started};break}}await new Promise(resolve=>setTimeout(resolve,5))}
   if(!row.barrier)throw Error('Original 2000ms actual load+complete barrier');
   const result=await send('Runtime.evaluate',{expression:'('+program.toString()+')('+JSON.stringify(report.origin)+').then(value=>JSON.stringify(value))',awaitPromise:true,returnByValue:true,timeout:1000});
   if(result.exceptionDetails){row.exceptionDetails=result.exceptionDetails;throw Error('Actual causal program exception: '+name)}
   row.value=JSON.parse(result.result.value);row.events=client.events.slice(offset);await writeFile(output+'.incremental',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({engine,name,pid:row.pid,observed:true}));
  }finally{
   if(browserContextId&&client)try{await client.send('Target.disposeBrowserContext',{browserContextId},undefined,{timeout:2500})}catch(error){row.cleanupError={message:error.message,code:error.code}}
   await client?.close();client=null;await browser?.close();if(browser){row.exit=browser.process.exitCode;row.signal=browser.process.signalCode;row.stderr=browser.stderr}browser=null;
  }
 }
}catch(error){report.failure={name:error.name,message:error.message,stack:error.stack};process.exitCode=1}finally{
 await client?.close();await browser?.close();report.clearTimers?.();delete report.clearTimers;if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
}
