"""UNRUN genuine blank-frame producer gate; measured network Window gap excluded explicitly."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent.parent;C=R/'initial-blank-candidate';P=Path('/workspace/red-panda');O=R/'run-blank-r1-gate';assert not O.exists();O.mkdir();N='/workspace/shared/rea-tools/node_modules/.bin/node';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(root):
 return {str(p.relative_to(root)):sha(p)for d in ['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()}|{n:sha(root/n)for n in ['package.json','package-lock.json']}
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
m=json.loads((R/'blank-r1-manifest.json').read_text());base=json.loads((R/'manifest.json').read_text());before=identity(P);baselineBefore=identity(R/'baseline');captureBefore=identity(R/'capture-only-candidate');candidateBefore=identity(C);plan=json.loads((R/'evidence/blank-r1-plan.json').read_text());contracts={str(p):sha(p)for p in[R/'blank-r1-manifest.json',R/'manifest.json',R/'blank-r1.patch',R/'README-blank-r1.md',R/'evidence/blank-r1-plan.json',R/'evidence/run-blank-r1-gate.py',R/'evidence/run-blank-candidate-r1.mjs',R/'evidence/initial-programs.mjs',R/'checkpoint1-native-baseline5/manifest.json',R/'checkpoint1-native-baseline5/raw/Native.json',C/'red-panda-launcher',*map(Path,plan['externalContracts'])]};write('before.json',{'actualExternalRoot':before,'actualRootHEAD':subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip(),'owned2342Baseline615':baselineBefore,'captureOnly618':captureBefore,'initialBlankCandidate620':candidateBefore,'contracts':contracts});env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';env['PATH']=str(Path(N).parent)+':'+env.get('PATH','');proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy;commands=[];failure=None;current=None

def run(label,args,expected=None):
 global current
 begin=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  current=subprocess.Popen([N,*args],cwd=C,env=env,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'started':label,'pid':current.pid}),flush=True);expired=False
  try:code=current.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;os.killpg(current.pid,signal.SIGKILL);current.wait();code=current.returncode
 text=(O/(label+'.stdout')).read_text();counts={k:int(v)for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};row={'label':label,'pid':current.pid,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin,'actualTAPCounts':counts,'expectedCases':expected};commands.append(row);current=None;print(json.dumps(row),flush=True)
 if code or expired:raise RuntimeError('Actual blank producer command failed: '+label)
 if expected is not None:assert counts=={'tests':expected,'suites':0,'pass':expected,'fail':0,'cancelled':0,'skipped':0,'todo':0},counts
try:
 assert baselineBefore==base['baseline615']and captureBefore==base['captureOnlyAfter618']and candidateBefore==m['candidateAfter620'],'Owned frozen graph changed'
 for p,value in plan['externalContracts'].items():assert sha(Path(p))==value,'Actual source/helper/binary pin changed'
 for i,name in enumerate(m['changedPaths']):run('syntax-'+str(i+1),['--check',str(C/name)])
 run('syntax-driver',['--check',str(R/'evidence/run-blank-candidate-r1.mjs')])
 output=O/'candidate.json';run('candidate-four',[str(R/'evidence/run-blank-candidate-r1.mjs'),'initialBlankR1',str(output)]);actual=json.loads(output.read_text());native=json.loads((R/'checkpoint1-native-baseline5/raw/Native.json').read_text());assert actual.get('failure')is None and len(actual['rows'])==4 and actual['origin']==native['origin']
 expected={row['name']:row for row in native['rows']if row['name']in plan['NativeProjectionNames']};assert list(expected)==plan['NativeProjectionNames'];assert [row['name']for row in actual['rows']]==plan['NativeProjectionNames']
 for row in actual['rows']:
  assert row.get('barrier')and row.get('cleanupError')is None and row.get('exit')==0 and row.get('signal')is None,row
  assert row.get('value')==expected[row['name']]['value'],{'name':row['name'],'Native':expected[row['name']]['value'],'candidate':row.get('value')}
 run('new-six-24.22',['--experimental-vm-modules','--test-concurrency=1','--test-reporter=tap','--test',str(C/'test/initial-blank-lifecycle.test.js')],6)
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 if current is not None and current.poll()is None:os.killpg(current.pid,signal.SIGKILL);current.wait()
 guards={'externalRootUnchanged':before==identity(P),'baseline615Unchanged':baselineBefore==identity(R/'baseline'),'captureOnly618Unchanged':captureBefore==identity(R/'capture-only-candidate'),'blankCandidate620Unchanged':candidateBefore==identity(C),'contractsUnchanged':all(sha(Path(p))==value for p,value in contracts.items())};write('after-guards.json',guards)
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 write('status.json',{'complete':failure is None,'failure':failure,'commands':commands,'seconds':time.monotonic()-started,'RPCMilliseconds':2500,'scriptParameterMilliseconds':1000,'actualLoadBarrierMilliseconds':2000,'administrativeCap90Seconds':True,'ownedTimeoutChildrenVM200Deadline7000':True,'exactFrozenNativeBlankProjections':4,'networkInitialWindowReentryExplicitlyUnfixed':True,'originalSource96Unreplayed':True,'NoRootWritesOrNativeBuilds':True,'noCallbackSourceOrPublicEventTrustFiltering':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
