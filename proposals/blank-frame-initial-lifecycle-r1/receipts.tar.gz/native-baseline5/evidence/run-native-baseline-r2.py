"""STATIC, UNRUN: genuine initial producer observations, no Source96 implementation."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent.parent;O=R/'run-native-baseline-r2';assert not O.exists();O.mkdir();P=Path('/workspace/red-panda');N='/workspace/shared/rea-tools/node_modules/.bin/node';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(root):
 return {str(p.relative_to(root)):sha(p)for d in ['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()}|{n:sha(root/n)for n in ['package.json','package-lock.json']}
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
m=json.loads((R/'manifest.json').read_text());before=identity(P);baseBefore=identity(R/'baseline');candidateBefore=identity(R/'capture-only-candidate');plan=json.loads((R/'evidence/plan-r2.json').read_text());contracts={str(p):sha(p)for p in [R/'manifest.json',R/'evidence/plan-r2.json',R/'evidence/initial-programs.mjs',R/'evidence/run-initial-driver-r2.mjs',R/'evidence/run-native-baseline-r2.py',R/'baseline/red-panda-launcher',*map(Path,plan['externalContracts'])]};write('before.json',{'actualExternalRoot':before,'actualRootHEAD':subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip(),'ownedFrozenBaseline2342':baseBefore,'captureOnlyCandidateUnrun':candidateBefore,'contracts':contracts});env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';env['PATH']=str(Path(N).parent)+':'+env.get('PATH','');proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy;commands=[];failure=None;current=None
def run(label,args):
 global current
 begin=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  current=subprocess.Popen([N,*args],cwd=R,env=env,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'started':label,'pid':current.pid}),flush=True);expired=False
  try:code=current.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;os.killpg(current.pid,signal.SIGKILL);current.wait();code=current.returncode
 row={'label':label,'pid':current.pid,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin};commands.append(row);current=None;print(json.dumps(row),flush=True)
 if code or expired:raise RuntimeError('Actual initial producer command failed: '+label)
try:
 assert baseBefore==m['baseline615']and candidateBefore==m['captureOnlyAfter618'],'Owned source graph changed; prepare a new derivative'
 for p,digest in plan['externalContracts'].items():assert sha(Path(p))==digest,'Prepared external source/helper/binary changed'
 for file in ['initial-programs.mjs','run-initial-driver-r2.mjs']:run('syntax-'+file,['--check',str(R/'evidence'/file)])
 for engine in ['Native','baseline2342']:
  output=O/(engine+'.json');run(engine,[str(R/'evidence/run-initial-driver-r2.mjs'),engine,str(output)]);report=json.loads(output.read_text());assert report.get('failure')is None and len(report['rows'])==5
  for row in report['rows']:assert row.get('value')is not None and row.get('barrier')and row.get('cleanupError')is None and row.get('exit')==0 and row.get('signal')is None,row
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 if current is not None and current.poll()is None:os.killpg(current.pid,signal.SIGKILL);current.wait()
 guards={'externalRootUnchanged':before==identity(P),'baseline615Unchanged':baseBefore==identity(R/'baseline'),'captureOnlyCandidate618Unchanged':candidateBefore==identity(R/'capture-only-candidate'),'contractsUnchanged':all(sha(Path(p))==digest for p,digest in contracts.items())};write('after-guards.json',guards)
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 write('status.json',{'complete':failure is None,'failure':failure,'commands':commands,'seconds':time.monotonic()-started,'APIReplyMilliseconds':2500,'ScriptParameterMilliseconds':1000,'actualLoadCompleteMilliseconds':2000,'administrative90Seconds':True,'NativeFiveThenUnchangedBaselineFive':True,'current2342CaptureCandidateStillUnrun':True,'Source96NotReplayedOrImplemented':True,'noRootEdits':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
