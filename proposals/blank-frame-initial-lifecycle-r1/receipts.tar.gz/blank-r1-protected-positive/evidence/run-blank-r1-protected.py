"""UNRUN stop-first: actual standalone13 first, remainingSDK6 each, protected238."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent.parent;C=R/'initial-blank-candidate';P=Path('/workspace/red-panda');O=R/'run-blank-r1-protected';assert not O.exists();O.mkdir();started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(root):
 return {str(p.relative_to(root)):sha(p)for d in ['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()}|{n:sha(root/n)for n in ['package.json','package-lock.json']}
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
m=json.loads((R/'blank-r1-manifest.json').read_text());plan=json.loads((R/'evidence/blank-r1-protected-plan.json').read_text());before=identity(P);candidateBefore=identity(C);baseBefore=identity(R/'baseline');captureBefore=identity(R/'capture-only-candidate');contracts={str(p):sha(p)for p in[R/'blank-r1-manifest.json',R/'blank-r1.patch',R/'evidence/blank-r1-protected-plan.json',R/'evidence/run-blank-r1-protected.py',R/'checkpoint2-blank-r1-positive/manifest.json',R/'run-blank-r1-gate/status.json',*[(C/n)for n in plan['ownedReferenceFixtureSHA256']]]};write('before.json',{'actualExternalRoot':before,'actualRootHEAD':subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip(),'ownedCandidate620':candidateBefore,'original2342Baseline615':baseBefore,'captureOnly618':captureBefore,'ownedReferences24':plan['ownedReferenceFixtureSHA256'],'contracts':contracts});env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy;commands=[];failure=None;current=None

def run(label,node,args,expected):
 global current
 local=env.copy();local['PATH']=str(Path(node).parent)+':'+local.get('PATH','');begin=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  current=subprocess.Popen([node,*args],cwd=C,env=local,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'started':label,'pid':current.pid}),flush=True);expired=False
  try:code=current.wait(timeout=max(.01,180-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;os.killpg(current.pid,signal.SIGKILL);current.wait();code=current.returncode
 text=(O/(label+'.stdout')).read_text();counts={k:int(v)for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};row={'label':label,'pid':current.pid,'command':[node,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin,'actualTAPCounts':counts,'expectedCases':expected};commands.append(row);current=None;print(json.dumps(row),flush=True)
 if code or expired:raise RuntimeError('Actual protected graph command failed: '+label)
 assert counts=={'tests':expected,'suites':0,'pass':expected,'fail':0,'cancelled':0,'skipped':0,'todo':0},counts
try:
 assert candidateBefore==m['candidateAfter620'],'Frozen candidate graph changed'
 assert env.get('NODE_OPTIONS','')==''and env.get('RED_PANDA_WINDOW_TASK_PROOF','')=='','No implicit preload or external proof-output path is allowed'
 assert all(sha(C/n)==digest for n,digest in plan['protectedTestSourceSHA256'].items()),'Unchanged protected test source changed'
 assert all(sha(C/n)==digest for n,digest in plan['ownedReferenceFixtureSHA256'].items()),'Actual existing owned reference fixture changed'
 node='/workspace/shared/rea-tools/node_modules/.bin/node';flags=['--experimental-vm-modules','--test-concurrency=1','--test-reporter=tap','--test']
 run('unchanged-standalone13-24.22',node,[*flags,str(C/plan['firstUnchangedStandaloneFile'])],13)
 for label,sdk in [('24.19','/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'),('26.13','/workspace/shared/node26/node_modules/node/bin/node')]:run('new-six-'+label,sdk,[*flags,str(C/'test/initial-blank-lifecycle.test.js')],6)
 run('protected-remaining238-24.22',node,[*flags,*[str(C/n)for n in plan['remainingUnionFiles']]],238)
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 if current is not None and current.poll()is None:os.killpg(current.pid,signal.SIGKILL);current.wait()
 guards={'externalRootUnchanged':before==identity(P),'candidate620Unchanged':candidateBefore==identity(C),'baseline615Unchanged':baseBefore==identity(R/'baseline'),'captureOnly618Unchanged':captureBefore==identity(R/'capture-only-candidate'),'contractsUnchanged':all(sha(Path(p))==digest for p,digest in contracts.items())};write('after-guards.json',guards)
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 write('status.json',{'complete':failure is None,'failure':failure,'commands':commands,'seconds':time.monotonic()-started,'administrativeCap180Seconds':True,'allOriginalTestAndAPIBudgetsUnchanged':True,'standalone13FirstNoPreloadSeedWarmup':True,'thenRemainingSDK6Each':True,'protectedUnion251IfAllPhasesGreen':True,'actualConsumedSources620PlusFrozenReferences24':True,'networkInitialWindowReentryStillUnfixed':True,'originalSource96NotRun':True,'noNativeRepeatOrRootEdits':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
