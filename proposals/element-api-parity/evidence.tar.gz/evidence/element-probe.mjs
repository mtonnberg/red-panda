import http from'node:http';
import{readFile,writeFile}from'node:fs/promises';
import{createHash}from'node:crypto';
import{performance}from'node:perf_hooks';
import{startReference}from'../helpers/reference-server.mjs';
import{connectRaw}from'../helpers/raw-cdp.mjs';
const binary=process.argv[2],output=process.argv[3],hash=value=>createHash('sha256').update(value).digest('hex');
const record={binary,binarySHA256:hash(await readFile(binary)),driverSHA256:hash(await readFile(new URL(import.meta.url))),rpcTimeout:2500,groups:[],wire:[],events:[],http:[]};
if(record.binarySHA256!=='9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f')throw Error('Pinned Native changed');
let browser,origin,active,client,writes=Promise.resolve();const flush=()=>writes=writes.then(()=>writeFile(output+'.progress.json',JSON.stringify(record,null,2)+'\n'));
const server=http.createServer((request,response)=>{record.http.push({method:request.method,url:request.url,headers:request.headers});response.setHeader('content-type','text/html; charset=utf-8');response.setHeader('cache-control','no-store');response.end('<!doctype html><title>Actual element controls</title><body><p>Actual</p></body>');void flush()});
async function call(method,params,sessionId){const step={method,params,sessionId,startedAt:performance.now()};active.steps.push(step);await flush();try{const reply=await client.send(method,params,sessionId);step.reply=reply;if(reply.error)throw Error('Protocol error: '+reply.error.message);return reply.result}finally{step.finishedAt=performance.now();await flush()}}
try{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;record.origin=origin;browser=await startReference(binary);record.pid=browser.process.pid;record.endpoint=browser.endpoint;
 for(const name of['closest-errors','active-display','inactive-display','shadow-hit','slot-hit','hit-conversions']){
  active={name,completed:false,steps:[]};record.groups.push(active);await flush();
  try{client=await connectRaw(browser.endpoint,{label:name,wire:record.wire,events:record.events,flush,timeout:2500});const{browserContextId}=await call('Target.createBrowserContext',{}),{targetId}=await call('Target.createTarget',{browserContextId,url:'about:blank'}),{sessionId}=await call('Target.attachToTarget',{targetId,flatten:true});for(const method of['Page.enable','Runtime.enable'])await call(method,{},sessionId);
   await call('Page.navigate',{url:origin+'/'+name},sessionId);const load=await call('Runtime.evaluate',{expression:'new Promise(r=>document.readyState==="complete"?r(true):addEventListener("load",()=>r(true),{once:true}))',awaitPromise:true,returnByValue:true},sessionId);if(load.exceptionDetails)throw Error('Actual document readiness failed');
   const expression=await readFile(new URL('../expressions/'+name+'.js',import.meta.url),'utf8');active.expressionSHA256=hash(expression);const result=await call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},sessionId);active.observation=result;if(result.exceptionDetails)throw Error('Actual expression failed');
   await call('Target.closeTarget',{targetId});await call('Target.disposeBrowserContext',{browserContextId});active.completed=true;
  }catch(error){active.failure={message:error.message,stack:error.stack,rpcTimeout:!!error.rpcTimeout,connectionLost:!!error.connectionLost};throw error}finally{await client?.close();client=null;await flush()}
 }
 record.finished=true;
}catch(error){record.failure={message:error.message,stack:error.stack}}
finally{try{await client?.close();await browser?.close()}catch(error){record.cleanupErrors=[{message:error.message}]}server.closeAllConnections();await new Promise(resolve=>server.close(resolve));record.stderr=browser?.stderr;await flush();await writes;await writeFile(output,JSON.stringify(record,null,2)+'\n',{flag:'wx'})}
console.log(JSON.stringify({groups:record.groups.map(g=>({name:g.name,completed:g.completed,failure:g.failure})),failure:record.failure,pid:record.pid}));
