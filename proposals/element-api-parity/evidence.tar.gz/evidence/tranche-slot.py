from pathlib import Path
import subprocess,json,hashlib,os,signal,time,sys,re
p=Path.cwd();phase=sys.argv[1];assert phase in ['closest','display','shadow'];manifest=p/('evidence/'+phase+'-r1-inputs.json');expected=json.loads(manifest.read_text())
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as source:
  for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def state():return{n:digest(p/n)for n in expected}
assert state()==expected,'Frozen independent tranche inputs changed'
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union)
tests=json.loads((p/('evidence/'+phase+'-r1-source-manifest.json')).read_text())['tests'];command=['/workspace/shared/rea-tools/node_modules/node/bin/node','--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*tests];start=time.monotonic();watchdog=False
with(p/('evidence/'+phase+'-r1-focused.log')).open('xb')as log:
 child=subprocess.Popen(command,cwd=p/(phase+'-r1'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env)
 try:code=child.wait(timeout=60)
 except subprocess.TimeoutExpired:
  watchdog=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
after=state();log=(p/('evidence/'+phase+'-r1-focused.log')).read_text();status={'phase':phase,'command':command,'exit':code,'seconds':time.monotonic()-start,'watchdogTriggered':watchdog,'outerWatchdog':60,'cleanupGrace':3,'inputs':len(expected),'changed':[n for n in expected if after[n]!=expected[n]],'manifestSHA256':digest(manifest),'passes':len(re.findall(r'^ok [0-9]+ - ',log,re.M)),'failures':len(re.findall(r'^not ok [0-9]+ - ',log,re.M)),'canonicalEnv':{'NODE_USE_ENV_PROXY':env['NODE_USE_ENV_PROXY'],'equalBypassLists':env['NO_PROXY']==env['no_proxy'],'unionSHA256':hashlib.sha256(env['NO_PROXY'].encode()).hexdigest(),'proxyTLSPreserved':all(env.get(n)==os.environ.get(n)for n in['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR'])}};(p/('evidence/'+phase+'-r1-focused-status.json')).write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True);sys.exit(0 if code==0 and not watchdog and not status['changed']and status['passes']and not status['failures']else 1)
