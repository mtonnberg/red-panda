from pathlib import Path
import subprocess,json,hashlib,os,signal,time,sys
p=Path.cwd();plan=Path('/workspace/shared/registration455-adapted-plan-20261031');manifest=p/'evidence/combined-r1-inputs.json';expected=json.loads(manifest.read_text())
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as source:
  for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def state():return{n:digest(p/n)for n in expected}
assert state()==expected,'Frozen combined element/source inputs changed'
env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union)
results=[];started=time.monotonic()
for name in ['document/element_from_point_shadow.html','element/check_visibility.html','element/closest.html']:
 stem='combined-r1-source-'+name.replace('/','__');report=p/('evidence/'+stem+'.json');command=['/workspace/shared/rea-tools/node_modules/node/bin/node',str(plan/'harness/scripts/conformance.mjs'),'--root',str(plan/'fixtures/adapted'),'--binary',str(p/'evidence/combined-r1-launcher'),'--isolate','--fixture-profile','upstream','--source-load-contract','--websocket-port','9584','--registration-map',str(plan/'maps/registration-map.json'),'--runner-global-arg=--ws-max-concurrent','--runner-global-arg=50','--port','9582','--test',name,'--report',str(report)];watchdog=False;start=time.monotonic()
 with(p/('evidence/'+stem+'.log')).open('xb')as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env)
  try:code=child.wait(timeout=19)
  except subprocess.TimeoutExpired:
   watchdog=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 data=json.loads(report.read_text())if report.exists()else{};rows=data.get('results',[]);result=rows[0]if len(rows)==1 else{};profile=result.get('sourceProfile',{});contract=result.get('sourceLoadContract',{});after=state();changed=[n for n in expected if after[n]!=expected[n]];passed=code==0 and not watchdog and not changed and len(rows)==1 and result.get('path')==name and result.get('status')=='passed'and result.get('nativeHarnessBranch')is True and profile.get('id')=='fa94522d56ca'and profile.get('sourceTimeoutMs')==2000 and contract.get('loadBudgetMs')==2000 and contract.get('assertionBudgetMs')==2000 and contract.get('assertionStartedAfterLoad')is True;row={'fixture':name,'command':command,'exit':code,'seconds':time.monotonic()-start,'outerWatchdog':19,'watchdogTriggered':watchdog,'passed':passed,'changed':changed,'result':result};results.append(row);(p/'evidence/combined-r1-source-status.json').write_text(json.dumps({'results':results,'inputs':len(expected),'manifestSHA256':digest(manifest),'seconds':time.monotonic()-started},indent=2)+'\n');print(json.dumps(row),flush=True)
 if not passed:sys.exit(1)
sys.exit(0)
