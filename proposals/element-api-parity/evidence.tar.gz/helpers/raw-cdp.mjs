import {WebSocket} from 'ws';
import {performance} from 'node:perf_hooks';
export async function connectRaw(endpoint,{label,wire,events,flush,timeout=2500}){
 const socket=new WebSocket(endpoint,{handshakeTimeout:timeout});
 await new Promise((resolve,reject)=>{socket.once('open',resolve);socket.once('error',reject)});
 let next=0;const pending=new Map();
 const failAll=message=>{for(const entry of pending.values()){clearTimeout(entry.timer);entry.reject(Object.assign(new Error(message),{connectionLost:true}))}pending.clear()};
 socket.on('error',error=>{wire.push({connection:label,direction:'transport-error',at:performance.now(),message:error.message});failAll(error.message);void flush()});
 socket.on('close',(code,reason)=>{wire.push({connection:label,direction:'closed',at:performance.now(),code,reason:reason.toString()});failAll('CDP connection closed');void flush()});
 socket.on('message',raw=>{const text=raw.toString();wire.push({connection:label,direction:'received',at:performance.now(),raw:text});let message;try{message=JSON.parse(text)}catch(error){failAll('Invalid protocol JSON: '+error.message);void flush();return}if(message.id===undefined){events.push({connection:label,message});void flush();return}const entry=pending.get(message.id);if(entry){pending.delete(message.id);clearTimeout(entry.timer);entry.resolve(message)}void flush()});
 return{label,socket,send(method,params,sessionId){const id=++next,message={id,method,...(params===undefined?{}:{params}),...(sessionId?{sessionId}:{})};wire.push({connection:label,direction:'sent',at:performance.now(),raw:JSON.stringify(message)});void flush();return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Object.assign(new Error('CDP timeout '+method+' request '+id),{rpcTimeout:true,requestId:id,method}))},timeout);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify(message))})},async close(){failAll('Owned CDP client closed');if(socket.readyState===WebSocket.CLOSED)return;const done=new Promise(resolve=>socket.once('close',resolve)),force=setTimeout(()=>socket.terminate(),1000);force.unref();socket.close();try{await done}finally{clearTimeout(force)}}};
}
