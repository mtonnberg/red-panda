from pathlib import Path
import hashlib,json,os,resource,signal,subprocess,time
BASE=Path(__file__).resolve().parent;ROOT=Path('/workspace/red-panda');NODE=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');NATIVE=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux')
def digest(q):
 h=hashlib.sha256()
 with q.open('rb')as f:
  for z in iter(lambda:f.read(1048576),b''):h.update(z)
 return h.hexdigest()
manifest=BASE/'inputs.json';expected=json.loads(manifest.read_text())
def changed():return[n for n,h in expected.items()if not Path(n).is_file()or digest(Path(n))!=h]
assert not changed(),'Frozen Native/controller/fixture/source/dependency input changed'
closure=json.loads((BASE/'dependency-closure.json').read_text());assert str((ROOT/'node_modules/ws').resolve())==closure['actualWSDirectory'];assert all(not(ROOT/'node_modules'/name).exists()for name in closure['absentOptionalPackages'])
def rootState():return{str(q.relative_to(ROOT)):digest(q)for top in ['src','test','native']for q in sorted((ROOT/top).rglob('*'))if q.is_file()}
def proc(pid):
 try:
  raw=Path('/proc')/str(pid)/'stat';v=raw.read_text();a=v[v.rindex(')')+2:].split();return{'pid':pid,'state':a[0],'ppid':int(a[1]),'pgrp':int(a[2]),'startTicks':a[19]}
 except(FileNotFoundError,ProcessLookupError,PermissionError):return None
def observe(child,known):
 for q in Path('/proc').iterdir():
  if q.name.isdigit():
   v=proc(int(q.name))
   if v and(v['pid']==child.pid or v['pgrp']==child.pid or v['ppid']in known):known.setdefault(v['pid'],v)
def live(known):
 result=[]
 for pid,old in known.items():
  now=proc(pid)
  if now and now['startTicks']==old['startTicks']and now['state']not in ['Z','X']:result.append(now)
 return result
out=BASE/'native-observations-r1';out.mkdir(exist_ok=False);before=rootState();(out/'Root-before.json').write_text(json.dumps(before,indent=2)+'\n');env=os.environ.copy();union=list(dict.fromkeys([v.strip()for name in ['NO_PROXY','no_proxy']for v in env.get(name,'').split(',')if v.strip()]+['localhost','.localhost','127.0.0.1','::1','[::1]','0.0.0.0']));env['NODE_USE_ENV_PROXY']='1';env['NO_PROXY']=env['no_proxy']=','.join(union)
status={'state':'STARTING','meaning':'Native-only newobservations, notcacheparity/rootintegration acceptance','plannedGroups':8,'plannedResourceRows':28,'plannedNativeProcesses':3,'RPCMilliseconds':2500,'NodeWorkMilliseconds':30000,'cleanupGrace':3,'PythonAdministrativeCeilingSeconds':33,'actualReadyMilliseconds':10000,'actualShutdownMilliseconds':1500,'inputs':len(expected),'manifestSHA256':digest(manifest),'rootBeforeInputs':len(before),'canonicalProxyBypassSHA256':hashlib.sha256(env['NO_PROXY'].encode()).hexdigest(),'proxyTLSPreserved':all(env.get(n)==os.environ.get(n)for n in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','NODE_TLS_REJECT_UNAUTHORIZED','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','SSL_CERT_DIR'])};started=time.monotonic();child=None;known={}
def checkpoint():status['seconds']=time.monotonic()-started;(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
try:
 command=[str(NODE),str(BASE/'probe.mjs'),str(NATIVE),str(out/'Native.json')];status['command']=command
 with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  child=subprocess.Popen(command,cwd=BASE,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);status['controllerChildPID']=child.pid;checkpoint()
  while child.poll()is None:
   observe(child,known)
   if time.monotonic()-started>=33:
    status['administrativeExpiry']=True
    for v in live(known):
     try:os.kill(v['pid'],signal.SIGKILL)
     except ProcessLookupError:pass
    child.wait();break
   time.sleep(.05)
  status['exit']=child.returncode
 status['liveBeforeCleanup']=live(known)
 if status['liveBeforeCleanup']:
  for v in live(known):
   try:os.kill(v['pid'],signal.SIGKILL)
   except ProcessLookupError:pass
 status['liveAfterCleanup']=live(known);status['observedOwnedProcesses']=list(known.values())
 rawFile=out/'Native.json'
 if rawFile.exists():
  raw=json.loads(rawFile.read_text());status.update({'rawSHA256':digest(rawFile),'rawStatus':raw.get('status'),'actualCompleteGroups':sum(v.get('complete')is True for v in raw.get('groups',[])),'actualGroups':len(raw.get('groups',[])),'actualResources':sum(v.get('kind')=='resource'for v in raw.get('operations',[])),'NativeProcesses':raw.get('producers',[]),'actualHTTPRequests':len(raw.get('requests',[])),'actualWireMessages':len(raw.get('wire',[])),'actualFailure':raw.get('error'),'watchdogExpired':raw.get('watchdogExpired'),'rawCleanupErrors':raw.get('cleanupErrors'),'fixtureSocketsRemaining':raw.get('fixtureSocketsRemaining')})
 status['state']='OBSERVED_NOT_A_PARITY_PASS'if status.get('exit')==0 and status.get('rawStatus')=='OBSERVED_NOT_A_CACHE_PARITY_PASS'and status.get('actualCompleteGroups')==8 and status.get('actualGroups')==8 and status.get('actualResources')==28 and len(status.get('NativeProcesses',[]))==3 and not status.get('administrativeExpiry')and not status.get('watchdogExpired')and not status.get('liveBeforeCleanup')and not status.get('liveAfterCleanup')and not status.get('rawCleanupErrors')and status.get('fixtureSocketsRemaining')==0 else'INCOMPLETE_OR_FAILED'
except BaseException as error:status['state']='CONTROLLER_FAILURE';status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 if child and child.poll()is None:
  observe(child,known)
  for v in live(known):
   try:os.kill(v['pid'],signal.SIGKILL)
   except ProcessLookupError:pass
  child.wait()
 status['remainingLiveOwnedProcesses']=live(known);after=rootState();(out/'Root-after.json').write_text(json.dumps(after,indent=2)+'\n');status['changedRootInputs']=[n for n in set(before)|set(after)if before.get(n)!=after.get(n)];status['changedInputs']=changed();checkpoint();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='OBSERVED_NOT_A_PARITY_PASS'and not status['changedRootInputs']and not status['changedInputs']and not status['remainingLiveOwnedProcesses']else 1)
