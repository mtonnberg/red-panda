#!/usr/bin/env python3
"""Prepared, UNRUN Native-only controls. No candidate engine import or build."""
import hashlib,json,os,pathlib,signal,subprocess,time,resource,sys
BASE=pathlib.Path(__file__).resolve().parent;ROOT=pathlib.Path('/workspace/red-panda');NODE=pathlib.Path('/workspace/shared/rea-tools/node_modules/node/bin/node');NATIVE=pathlib.Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux')
hashfile=lambda file:hashlib.sha256(pathlib.Path(file).read_bytes()).hexdigest()
for manifest in ['packet-inputs.json','tool-inputs.json','native-source-inputs.json','root-native18-inputs.json','root615-inputs.json']:
 entries=json.loads((BASE/manifest).read_text())
 for name,expected in entries.items():
  file=pathlib.Path(name)if name.startswith('/')else BASE/name
  if not file.is_file()or hashfile(file)!=expected:raise SystemExit('Actual frozen input mismatch: '+str(file))
def root_snapshot():return {str(file.relative_to(ROOT)):hashfile(file)for directory in ['src','test','native']for file in sorted((ROOT/directory).rglob('*'))if file.is_file()}
def owned(group):
 values=[]
 for entry in pathlib.Path('/proc').iterdir():
  if not entry.name.isdecimal():continue
  try:
   text=(entry/'stat').read_text();fields=text[text.rfind(')')+2:].split()
   if int(fields[2])==group:values.append({'pid':int(entry.name),'state':fields[0],'parent':int(fields[1]),'group':int(fields[2])})
  except (OSError,ValueError,IndexError):pass
 return values
cohort=sys.argv[1];assert cohort in ['renewal','capacity'];expectedGroups,expectedResources,expectedProducers={'renewal':(3,12,3),'capacity':(2,18,4)}[cohort];out=BASE/('native-observations-'+cohort+'-1');out.mkdir(exist_ok=False);frozen615=json.loads((BASE/'root615-inputs.json').read_text());before615={path:hashfile(path)for path in frozen615};before=root_snapshot();(out/'Root-source-before.json').write_text(json.dumps(before,indent=2)+'\n');env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1'
bypass=','.join(filter(None,[env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']));env.update({key:bypass for key in ['NO_PROXY','no_proxy']})
status={'state':'STARTING','plannedObservationGroups':expectedGroups,'plannedResourceObservations':expectedResources,'plannedNativeProducers':expectedProducers,'RPCMilliseconds':2500,'NodeOwnedMilliseconds':30000,'parentSeconds':30,'cleanupGraceSeconds':3,'RootGuardMeaning':'Fresh actual launch-time Root sources/tests/native are protected; the Native-only driver imports no candidate engine. This does not bind Native observations to current or future Root behavior.','proxyBypassSHA256':hashlib.sha256((env['NO_PROXY']+'\n'+env['no_proxy']).encode()).hexdigest(),'NodeOptionsSHA256':hashlib.sha256(env.get('NODE_OPTIONS','').encode()).hexdigest()};start=time.monotonic();child=None
try:
 with (out/'Node.stdout').open('wb')as stdout,(out/'Node.stderr').open('wb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  command=[str(NODE),str(BASE/('probe-'+cohort+'.mjs')),str(NATIVE),str(out/'Native.json')];child=subprocess.Popen(command,cwd=BASE,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);status.update({'command':command,'pid':child.pid,'state':'RUNNING'})
  try:status['exit']=child.wait(timeout=30)
  except subprocess.TimeoutExpired:
   cleanup_end=time.monotonic()+3;status['deadlineExpired']=True;status['ownedAtDeadline']=owned(child.pid);os.killpg(child.pid,signal.SIGTERM)
   try:status['exit']=child.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);status['exit']=child.wait();status['forcedGroupKill']=True
  cleanup_end=locals().get('cleanup_end',time.monotonic()+3)
  survivors=[entry for entry in owned(child.pid)if entry['state']!='Z'];status['ownedBeforeCleanup']=survivors
  if survivors:
   os.killpg(child.pid,signal.SIGKILL);status['forcedRemainingGroupKill']=True
   while time.monotonic()<cleanup_end and any(entry['state']!='Z'for entry in owned(child.pid)):time.sleep(.02)
  status['ownedAfterCleanup']=owned(child.pid)
 if (out/'Native.json').exists():
  raw=json.loads((out/'Native.json').read_text());status.update({'rawStatus':raw.get('status'),'actualCompletedGroups':sum(group.get('complete',False)for group in raw.get('groups',[])),'actualResourceRows':sum(row.get('kind')=='resource'for row in raw.get('operations',[])),'actualByteResultRows':sum(row.get('kind')=='resource'and isinstance(row.get('value',{}).get('bytes'),list)for row in raw.get('operations',[])),'actualNativeProducers':[{'label':row.get('label'),'pid':row.get('pid'),'exit':row.get('exit'),'signal':row.get('signal')}for row in raw.get('producers',[])],'actualError':raw.get('error'),'rawSHA256':hashfile(out/'Native.json')})
 status['state']='OBSERVED_NOT_A_PARITY_PASS'if status.get('exit')==0 and status.get('rawStatus')=='OBSERVED_NOT_A_CACHE_PARITY_PASS'and status.get('actualCompletedGroups')==expectedGroups and status.get('actualResourceRows')==expectedResources and status.get('actualByteResultRows')==expectedResources and len(status.get('actualNativeProducers',[]))==expectedProducers and not status.get('deadlineExpired')else'INCOMPLETE_OR_FAILED'
except Exception as error:status['state']='CONTROLLER_FAILURE';status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 if child is not None and child.poll()is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
 after615={path:hashfile(path)for path in frozen615};status['FrozenRoot615Unchanged']=before615==after615;status['FrozenRoot615Inputs']=len(before615);after=root_snapshot();(out/'Root-source-after.json').write_text(json.dumps(after,indent=2)+'\n');status['changedRootInputs']=[name for name in sorted(set(before)|set(after))if before.get(name)!=after.get(name)];status['RootInputs']=len(before);status['elapsedSeconds']=time.monotonic()-start
 status['remainingLiveOwnedProcesses']=[]if child is None else[entry for entry in owned(child.pid)if entry['state']!='Z'];(out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
if status['state']!='OBSERVED_NOT_A_PARITY_PASS'or status['changedRootInputs']or not status['FrozenRoot615Unchanged']or status['remainingLiveOwnedProcesses']:raise SystemExit(1)
