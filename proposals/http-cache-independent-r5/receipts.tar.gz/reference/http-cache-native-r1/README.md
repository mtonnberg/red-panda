# Filesystem HTTP cache — Native-first, STATIC / UNRUN

This packet is source inventory and a prepared Native-only experiment. No JavaScript syntax/import, Node/browser process, server, build, filesystem-cache experiment or Root edit has occurred. No Native implementation is copied or imported. Original fixtures, default CLI tests and public branding remain unchanged.

Source is pinned to 948d773786380bae36f046639fc61e2ddddd212a; the actual reference executable is pinned to SHA-256 9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f. `inventory.json` records sixteen source pins/ownership/keys/storage/admission/freshness/errors/events. These source declarations are not assumed binary support or actual cache success.

The source defaults to **no caching** when `--http-cache-dir` is absent. Supplying it enables a Network/App-owned SQLite store, separately from CacheStorage, cookies or captured response bodies. The default entry limit is 1000; 0 means unlimited, and the limit is soft. Help's session-end wording and the actual maintenance sites (store open/HttpClient.deinit) need a real lifetime test before making a stronger claim.

Two distinctions determine the probe: top-level Document requests explicitly skip cache even when configured; ordinary buffered GET Fetch/XHR can enter the cache path. `Network.setCacheDisabled` actually changes the browser HTTP client's cache pointer, while `LP.configureCDP({disableSetCacheDisabled:true})` can suppress that effect. `canClearBrowserCache` reports configured store availability, not the current bypass state.

The cache key is the captured request URL, with a separate partial prefix when applicable. SQLite keeps one row per URL, with actual bytes/headers/validators/times/Vary data; a later Vary variant replaces that row. Freshness, no-store/private/Set-Cookie exclusions, conditional revalidation and 304 renewal are actual producer operations. They are not a license to claim complete RFC 9111 behavior. Source quirks and unmeasured cases remain explicit in the inventory.

## Prepared bounded cohort

Exact future command, only after a quiet runtime grant:

```
python3 /workspace/shared/http-cache-native-r1/run-native-r1.py
```

It starts one Node driver and one ephemeral loopback fixture, with three Native processes sequentially, never concurrently. Eight groups contain 22 planned resource byte observations:

1. Original no-directory/default profile: two real GETs, actual cache capability response, counters/bytes/headers/events. No configured flag or fallback is supplied.
2. A newly allocated owned cache directory, explicit `--http-cache-dir`, first/repeated resource and real no-store responses.
3. Actual disable/reenable plus the real LP ignore-toggle gate; acknowledgements alone prove nothing.
4. Genuine no-cache ETag request, actual server 304, retained bytes and subsequent freshness/header observations.
5. Real A/A/B/B/A Vary requests against one URL.
6. Both actual reload modes and a sequential real BrowserContext disposal/recreation, retaining the same store/origin.
7. Native process close/reopen against the same owned directory and still-live server, measuring actual persistence.
8. Real `Network.clearBrowserCache` followed by two GETs.

The fixture changes binary bytes and receipt headers **only when an actual HTTP request arrives**, including invalid UTF-8 bytes. It implements a real conditional 304 response. The probe does not populate SQLite, change rows, simulate a browser cache or manufacture served-from-cache/fromDiskCache events. Native Fetch arrayBuffer bytes, whole headers/status, actual server receipts and full CDP wire/event tuples remain unnormalized. The real request ID is obtained from actual events; if none arrives, that absence is recorded and no ID is invented. Body-capture errors remain visible. Missing events or repeated network traffic are outcomes, not a reason to fake a hit.

Cache paths are fresh mkdtemp children of this packet's output only. No user cache or global configuration is touched. Active snapshots record file names/sizes; content hashes are taken after Native closes. Evidence is retained for review, not silently deleted. No SQL query/repair is performed by the harness. Configured CLI acceptance is a new explicit profile; existing default CLI positives are neither replayed nor relabeled.

RPC/handshake/event observation caps are 2500 ms. The original project supervisor keeps its 10000 ms readiness/1500 ms termination grace; its only additive change captures startup-failure PID/exit/stderr, so an unsupported flag cannot disappear behind a generic setup error. Node has a 30000 ms owned watchdog; the parent allows 30 seconds plus one shared 3-second cleanup grace. All wire and lifecycle markers are journaled incrementally. A required setup/byte producer failure or transport closure stops the run without retries, fallback flags or larger budgets. Native cleanup SIGKILL, when needed, is labeled owned cleanup rather than presumed crash.

Normal completion is estimated at 6–15 seconds, unmeasured. Completion means observations were received, not cache parity. Root's eighteen native artifact/receipt inputs are protected; fresh actual Root source/test/native maps are taken at launch and afterward, without old-HEAD behavioral claims. No candidate engine, SDK matrix, build, heap enumeration, canonical ports, service restart, UA override or original fixture change is involved.

Expiry clocks, capacity boundaries, authorization/cookie partitioning, missing/case-sensitive Vary, unsafe-method invalidation, redirects/partial/streaming, gzip/charset/statusText/304 merge edges, inflight toggles/cancellation, parallel SQLite users, corrupt/user-owned directories, workers/synchronous XHR/iframe producers and configured fetch-mode CLI remain later heldouts. Root currently has neither this optional HTTP cache nor its flags; acknowledgement-only setCacheDisabled and CacheStorage do not establish support.
