#!/usr/bin/env python3
"""Requires Root's exclusive runtime grant. Never overwrite an evidence epoch."""
from pathlib import Path
import argparse,hashlib,json,os,re,signal,subprocess,time

ROOT=Path(__file__).resolve().parent;PRODUCTION=Path('/workspace/red-panda');CANDIDATE=ROOT/'candidate'
NODE=Path('/workspace/shared/rea-tools/node_modules/node/bin/node')
parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['focused','cohort']);parser.add_argument('--epoch',required=True);args=parser.parse_args()
OUT=ROOT/'runs'/args.epoch;OUT.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((ROOT/'root-inputs.json').read_text())['files'];guard={PRODUCTION/row['path']:row['sha256']for row in expected}
assert all(sha(p)==digest for p,digest in guard.items()),'Root2342 input changed; prepare a new explicit derivative'
inputs=[*guard,NODE,Path(__file__),ROOT/'root-inputs.json',ROOT/'plan.json',ROOT/'probe-unchanged.mjs']
for tree in ['src','bin','native','test']:inputs.extend(p for p in(CANDIDATE/tree).rglob('*')if p.is_file())
inputs.extend([CANDIDATE/'package.json',CANDIDATE/'package-lock.json'])
inputs.extend(p for p in(ROOT/'helpers').rglob('*')if p.is_file())
for package in(PRODUCTION/'node_modules').iterdir():
 if package.is_dir()and not package.name.startswith('.'):inputs.extend(p for p in package.resolve().rglob('*')if p.is_file())
inputs=sorted(set(p.resolve()for p in inputs));snapshot=lambda:{str(p):sha(p)for p in inputs}
before=snapshot();(OUT/'before.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ);env['PATH']=str(NODE.parent)+':'+env.get('PATH','');env['NODE_USE_ENV_PROXY']='1'
bypass=','.join(filter(None,[env.get('NO_PROXY'),env.get('no_proxy'),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']))
env['NO_PROXY']=bypass;env['no_proxy']=bypass
record={'stage':args.stage,'state':'STARTED','Node':str(NODE),'inputCount':len(before),'commands':[],'remaining':'UNRUN'};child=None;began=time.monotonic();failure=None
def save():(OUT/'status.json').write_text(json.dumps(record,indent=2)+'\n')
def group(pid):
 rows=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   raw=(proc/'stat').read_text();fields=raw[raw.rfind(')')+2:].split()
   if int(fields[2])==pid:rows.append({'pid':int(proc.name),'startTicks':int(fields[19]),'state':fields[0]})
  except (OSError,ValueError,IndexError):pass
 return rows
def terminate_group(pid):
 try:os.killpg(pid,signal.SIGTERM)
 except ProcessLookupError:return
 end=time.monotonic()+3
 while time.monotonic()<end:
  if not any(row['state']!='Z'for row in group(pid)):return
  time.sleep(.02)
 try:os.killpg(pid,signal.SIGKILL)
 except ProcessLookupError:pass
def run(label,command,cwd,cap):
 global child
 row={'label':label,'command':command,'capSeconds':cap};record['commands'].append(row);save();start=time.monotonic()
 with(OUT/(label+'.stdout')).open('xb')as stdout,(OUT/(label+'.stderr')).open('xb')as stderr:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True);row['pid']=child.pid;save()
  try:child.wait(timeout=cap)
  except BaseException:terminate_group(child.pid);child.wait();raise
 row.update(exit=child.returncode,seconds=time.monotonic()-start,ownedAfter=group(child.pid));save()
 if any(item['state']!='Z'for item in row['ownedAfter']):terminate_group(child.pid);raise RuntimeError('Live owned remainder')
 if child.returncode:raise RuntimeError(label+' exit '+str(child.returncode))
 return row
def interrupted(number,frame):raise KeyboardInterrupt('Administrative signal '+str(number))
signal.signal(signal.SIGTERM,interrupted)
try:
 if args.stage=='focused':
  for name in ['src/http-cache.js','src/http-cache-control.js','src/browser.js','src/cdp.js','bin/red-panda.js','test/http-cache.test.js']:
   run('syntax-'+name.replace('/','-'),[str(NODE),'--check',name],CANDIDATE,10)
  run('focused9',[str(NODE),'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1','test/http-cache.test.js'],CANDIDATE,30)
  output=(OUT/'focused9.stdout').read_text();summary={name:int(re.search(r'^# '+name+r' (\d+)$',output,re.M)[1])for name in ['tests','pass','fail','cancelled','skipped']};record['actualTAP']=summary
  assert summary=={'tests':9,'pass':9,'fail':0,'cancelled':0,'skipped':0},'Actual TAP gate failed'
 else:
  prerequisite=ROOT/'runs'/'focused-r2'/'status.json';assert json.loads(prerequisite.read_text())['state']=='ACCEPTED_FOCUSED_ONLY','Focused actual receipt required'
  run('cohort',[str(NODE),'--experimental-vm-modules',str(ROOT/'probe-unchanged.mjs'),str(CANDIDATE/'bin/red-panda.js'),str(OUT/'Candidate.json')],ROOT,30)
  raw=json.loads((OUT/'Candidate.json').read_text());resources=[r for r in raw['operations']if r['kind']=='resource'];record['actualGroups']=raw['groups'];record['actualResources']=len(resources)
  assert raw['normal']and not raw['watchdogExpired']and not raw.get('error')and not raw['cleanupErrors']and raw['fixtureSocketsRemaining']==0
  assert len(resources)==22 and len(raw['groups'])==8 and all(r['complete']for r in raw['groups'])
 record['state']='ACCEPTED_FOCUSED_ONLY'if args.stage=='focused'else'COHORT_OBSERVED_COMPARISON_PENDING';record['remaining']='SDK/regressions/Native comparison/integration UNRUN'
except BaseException as error:failure={'type':type(error).__name__,'message':str(error)};record['state']='STOPPED_FIRST_FAILURE_REMAINDER_UNRUN';record['failure']=failure
finally:
 if child is not None and child.poll()is None:terminate_group(child.pid);child.wait()
 after=snapshot();(OUT/'after.json').write_text(json.dumps(after,indent=2)+'\n');record.update(unchanged=before==after,changed=[p for p in before if before[p]!=after[p]],elapsedSeconds=time.monotonic()-began,Root18Unchanged=all(sha(p)==digest for p,digest in guard.items()if p.suffix=='.node'or p.name.endswith('.node.json')));save();print(json.dumps(record),flush=True)
if failure or before!=after:raise SystemExit(1)
