#!/usr/bin/env python3
"""Read retained observations; never run an engine or edit either raw epoch."""
from pathlib import Path
import json,hashlib

ROOT=Path(__file__).resolve().parent
NATIVE=Path('/workspace/shared/http-cache-native-r1/native-observations-r1/Native.json')
CANDIDATE=ROOT/'runs/cohort-r2/Candidate.json'
native=json.loads(NATIVE.read_text());candidate=json.loads(CANDIDATE.read_text())
selected=lambda data:[row for row in data['operations']if row['kind']=='resource']
rows=[]
for a,b in zip(selected(native),selected(candidate),strict=True):
 ah=dict(a['value']['headers']);bh=dict(b['value']['headers'])
 checks={
  'sameLabel':a['label']==b['label'],
  'actualBytes':a['value']['bytes']==b['value']['bytes'],
  'status':a['value']['status']==b['value']['status'],
  'statusText':a['value']['statusText']==b['value']['statusText'],
  'responseHeadersExceptDate':{k:v for k,v in ah.items()if k!='date'}=={k:v for k,v in bh.items()if k!='date'},
  'actualHTTPDelta':a['requestDelta']==b['requestDelta'],
  'realLoadingFinished':a['loadingFinishedObserved']==b['loadingFinishedObserved']==True,
  'eventMethodSequence':[e['method']for e in a['events']]==[e['method']for e in b['events']],
  'cacheFlag':[e['params']['response']['fromDiskCache']for e in a['events']if e['method']=='Network.responseReceived']==[e['params']['response']['fromDiskCache']for e in b['events']if e['method']=='Network.responseReceived'],
  'eventStatusText':[e['params']['response']['statusText']for e in a['events']if e['method']=='Network.responseReceived']==[e['params']['response']['statusText']for e in b['events']if e['method']=='Network.responseReceived'],
  'actualInspectorBody':a['bodyCommand']['response'].get('result')==b['bodyCommand']['response'].get('result'),
 }
 rows.append({'label':a['label'],'checks':checks,'allDeclaredChecksEqual':all(checks.values()),'retainedDynamicDifferences':{'NativeURL':a['value']['url'],'candidateURL':b['value']['url'],'NativeDate':ah.get('date'),'candidateDate':bh.get('date'),'NativeRequestID':a.get('requestId'),'candidateRequestID':b.get('requestId')}})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out={'status':'DECLARED_22_RESOURCE_CONTRACTS_MATCH'if len(rows)==22 and all(row['allDeclaredChecksEqual']for row in rows)else'DECLARED_CONTRARIES','NativeRaw':{'path':str(NATIVE),'sha256':sha(NATIVE)},'candidateRaw':{'path':str(CANDIDATE),'sha256':sha(CANDIDATE)},'meaning':'Explicit byte/status/statusText/header-except-Date/request-delta/event-name/cache-flag/event-statusText/body-result contracts only. Fresh port authorities, actual Date, request/session/frame/loader IDs, connection/timing/security metadata and clocks remain in raw; no whole-object/CDP-time/branding equality. No raw response field is modified. Date values are retained in each comparison row.','rows':rows,'all8GroupsComplete':len(candidate['groups'])==8 and all(row['complete']for row in candidate['groups']),'actualCandidateProducers':[{'label':row['label'],'args':row['args'],'pid':row['pid'],'version':row['version'],'exit':row['exit'],'signal':row['signal']}for row in candidate['producers']],'remaining':'AdditionalNativeheldouts/cookie304/Range/Varycase/SyncXHR/remainingSDK/regressions/Rootintegration UNRUN'}
path=ROOT/'runs/cohort-r2/declared-contract-comparison.json';assert not path.exists();path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'resources':len(rows),'contraries':[row['label']for row in rows if not row['allDeclaredChecksEqual']],'all3CandidateProcessesExit0':all(row['exit']==0 and row['signal']is None for row in candidate['producers']),'sha256':sha(path)}))
