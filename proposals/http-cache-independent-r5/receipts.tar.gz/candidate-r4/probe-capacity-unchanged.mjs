// STATIC / UNRUN. Real Native GET bytes/receipts/events; no cache simulation.
import http from 'node:http';
import {once} from 'node:events';
import {readFile,writeFile,mkdtemp,readdir,stat} from 'node:fs/promises';
import {appendFileSync,writeFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {startReference} from './helpers/reference-server.mjs';
import {connect} from './helpers/cdp.mjs';
const [binary,output]=process.argv.slice(2);if(!binary||!output)throw Error('Pinned Native binary and unused output file required');
const ROOT=Symbol('root command'),start=Date.now(),groups=[],operations=[],wire=[],requests=[],producers=[],sockets=new Set();let reference,client,server,sessionId,contextId,activeGroup,producerLabel,cacheDirectory,error,normal=false,watchdogExpired=false,cleanupFailed=false;
const stamp=()=>Date.now()-start;writeFileSync(output+'.progress.ndjson','',{flag:'wx'});
const journal=value=>appendFileSync(output+'.progress.ndjson',JSON.stringify({atMS:stamp(),...value})+'\n');
const recordWire=value=>{const entry={producer:producerLabel,...value};wire.push(entry);journal({type:'wire',value:entry})};
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
async function rpc(method,params={},sid=sessionId){sid=sid===ROOT?undefined:sid;const op={kind:'CDP',group:activeGroup,producer:producerLabel,method,params,...(sid?{sessionId:sid}:{})};operations.push(op);op.response=await client.send(method,params,sid);if(op.response.error)throw Error('Actual required command error '+method+': '+JSON.stringify(op.response.error));return op.response.result}
async function evaluate(expression){const result=await rpc('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw Error('Actual authored fixture exception: '+JSON.stringify(result.exceptionDetails));return result.result?.value}
async function eventAfter(method,index,required=true){const began=Date.now();while(Date.now()-began<2500){const found=client.events.slice(index).find(message=>message.method===method);if(found)return found;await new Promise(resolve=>setTimeout(resolve,2))}if(required)throw Error('Actual '+method+' not observed within 2500ms');return null}
function receiptCount(path){return requests.filter(request=>request.path===path).length}
async function cacheSnapshot(label,closed){if(!cacheDirectory)return;const files=[];for(const name of(await readdir(cacheDirectory)).sort()){const path=join(cacheDirectory,name),info=await stat(path);if(info.isFile())files.push({name,size:info.size,...(closed?{sha256:digest(await readFile(path))}:{})})}const row={kind:'owned-cache-files',label,NativeClosed:closed,path:cacheDirectory,files};operations.push(row);journal(row)}
async function documentLoad(method,params){const began=Date.now(),index=client.events.length,before=receiptCount('/page');const response=await rpc(method,params);const event=await eventAfter('Page.loadEventFired',index);const actual=await evaluate('({url:location.href,readyState:document.readyState,title:document.title,userAgent:navigator.userAgent,brands:navigator.userAgentData?.brands})');if(actual?.readyState!=='complete')throw Error('Actual complete Document not observed');operations.push({kind:'actual-document-load',group:activeGroup,producer:producerLabel,method,params,response,event,actual,requestCountBefore:before,requestCountAfter:receiptCount('/page'),elapsedMS:Date.now()-began})}
async function newContext(){({browserContextId:contextId}=await rpc('Target.createBrowserContext',{},ROOT));const{targetId}=await rpc('Target.createTarget',{url:'about:blank',browserContextId:contextId},ROOT);({sessionId}=await rpc('Target.attachToTarget',{targetId,flatten:true},ROOT));await rpc('Page.enable');await rpc('Runtime.enable');await rpc('Network.enable');await documentLoad('Page.navigate',{url:'http://127.0.0.1:'+server.address().port+'/page'})}
async function startProducer(label,args){producerLabel=label;journal({type:'Native-starting',label,args});reference=await startReference(binary,{args});const producer={label,args,pid:reference.process.pid,startedMS:stamp()};producers.push(producer);client=await connect(reference.endpoint,{recordWire,stamp});producer.version=await rpc('Browser.getVersion',{},ROOT);journal({type:'Native-ready',label,pid:reference.process.pid});await newContext()}
async function stopProducer(){const item=producers.at(-1);if(!reference)return;const before={exit:reference.process.exitCode,signal:reference.process.signalCode};await client?.close();await reference.close();Object.assign(item,{beforeOwnedCleanup:before,exit:reference.process.exitCode,signal:reference.process.signalCode,stderr:reference.stderr,stderrTruncated:reference.stderrTruncated,closedMS:stamp()});journal({type:'Native-closed',...item});reference=null;client=null;sessionId=undefined;contextId=undefined}
async function resource(label,path,headers={}){
 const url='http://127.0.0.1:'+server.address().port+path,eventIndex=client.events.length,requestCountBefore=receiptCount(path);const row={kind:'resource',group:activeGroup,producer:producerLabel,label,url,path,headers,requestCountBefore};operations.push(row);journal({type:'resource-start',label,producer:producerLabel,path});
 const init={credentials:'include',headers};
 row.value=await evaluate('(async()=>{const response=await fetch('+JSON.stringify(url)+','+JSON.stringify(init)+');const bytes=Array.from(new Uint8Array(await response.arrayBuffer()));return{url:response.url,status:response.status,statusText:response.statusText,headers:Array.from(response.headers.entries()),bytes}})()');
 if(!row.value||!Array.isArray(row.value.bytes))throw Error('Actual fetch byte result unavailable');
 const began=Date.now();let requestId;
 while(Date.now()-began<2500){const messages=client.events.slice(eventIndex);requestId=messages.find(message=>message.method==='Network.requestWillBeSent'&&message.params?.request?.url===url)?.params?.requestId;if(requestId&&messages.some(message=>message.method==='Network.loadingFinished'&&message.params?.requestId===requestId))break;await new Promise(resolve=>setTimeout(resolve,2))}
 const seen=client.events.slice(eventIndex);row.requestId=requestId;row.events=requestId?seen.filter(message=>message.params?.requestId===requestId):seen;row.loadingFinishedObserved=!!requestId&&row.events.some(message=>message.method==='Network.loadingFinished');row.requestCountAfter=receiptCount(path);row.requestDelta=row.requestCountAfter-requestCountBefore;
 if(requestId){row.bodyCommand={method:'Network.getResponseBody',params:{requestId}};row.bodyCommand.response=await client.send('Network.getResponseBody',{requestId},sessionId)}else row.bodyCaptureUnobserved='No actual request ID received; no ID synthesized';
 journal({type:'resource-observed',value:row});return row;
}
async function group(name,operation){activeGroup=name;const entry={name,startedMS:stamp(),firstOperation:operations.length,complete:false};groups.push(entry);journal({type:'group-start',name});await operation();entry.complete=true;entry.finishedMS=stamp();entry.operations=operations.length-entry.firstOperation;journal({type:'group-complete',...entry})}
const watchdog=setTimeout(()=>{watchdogExpired=true;error??={name:'OwnedDeadline',message:'Original 30000ms owned ceiling expired',group:activeGroup};client?.socket.terminate();reference?.process.kill('SIGTERM');for(const socket of sockets)socket.destroy();server?.closeAllConnections()},30000);watchdog.unref();
try{
 server=http.createServer((request,response)=>{
  const path=request.url,ordinal=requests.length+1,receipt={ordinal,path,method:request.method,rawHeaders:request.rawHeaders,atMS:stamp(),ifNoneMatch:request.headers['if-none-match'],cookie:request.headers.cookie};requests.push(receipt);journal({type:'HTTP-request',value:receipt});response.setHeader('cache-control','public, max-age=600');response.setHeader('x-owned-receipt',String(ordinal));response.setHeader('content-type','application/octet-stream');let body;
  if(path==='/page'){response.setHeader('cache-control','no-store');response.setHeader('content-type','text/html; charset=utf-8');body=Buffer.from('<!doctype html><title>Actual cache continuation</title><body>Actual same-origin document');}
  else if(['/renew-cookie','/renew-no-store','/renew-private'].includes(path)){
   const tag='"actual-'+path.slice(1)+'-v1"';response.setHeader('etag',tag);
   if(request.headers['if-none-match']===tag){response.statusCode=304;response.setHeader('x-owned-renewal-receipt',String(ordinal));body=Buffer.alloc(0);if(path==='/renew-cookie')response.setHeader('set-cookie','future304=actual-receipt-'+ordinal+'; HttpOnly; SameSite=Lax; Path=/');else response.setHeader('cache-control',path==='/renew-no-store'?'no-store':'private, max-age=600');}
   else{response.setHeader('cache-control','no-cache');body=Buffer.concat([Buffer.from('Actual '+path+' initial-receipt '+ordinal+':'),Buffer.from([0,255,128,13,10])]);}
  }else if(path==='/echo-cookie'){response.setHeader('cache-control','no-store');body=Buffer.from(request.headers.cookie??'');}
  else if(['/capacity-A','/capacity-B','/capacity-C'].includes(path)){body=Buffer.concat([Buffer.from('Actual '+path+' network-receipt '+ordinal+':'),Buffer.from([0,255,128])]);}
  else{response.statusCode=404;response.setHeader('cache-control','no-store');body=Buffer.from('Actual unknown resource');}
  receipt.responseStatus=response.statusCode;receipt.responseHeaders=response.getHeaders();receipt.responseBytes=Array.from(body);receipt.responseBase64=body.toString('base64');receipt.responseSHA256=digest(body);journal({type:'HTTP-response',value:receipt});response.end(body);
 });server.on('connection',socket=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket));socket.on('error',()=>{})});server.listen(0,'127.0.0.1');await once(server,'listening');
 for(const limit of[2,0])await group('actual-soft-entry-limit-'+limit,async()=>{
  cacheDirectory=await mkdtemp(join(dirname(output),'owned-soft-limit-'+limit+'-cache-'));const flags=['--http-cache-dir',cacheDirectory,'--http-cache-entry-limit',String(limit)];
  await startProducer('limit-'+limit+'-fresh-owned',flags);
  for(const letter of['A','B','C'])await resource('limit'+limit+' initial '+letter,'/capacity-'+letter);
  await rpc('Target.disposeBrowserContext',{browserContextId:contextId},ROOT);sessionId=undefined;contextId=undefined;await newContext();
  for(const letter of['A','B','C'])await resource('limit'+limit+' afteractualcontextreplacement '+letter,'/capacity-'+letter);
  await stopProducer();await cacheSnapshot('limit'+limit+' afterfirstactualprocessclose',true);
  await startProducer('limit-'+limit+'-same-owned-directory-reopen',flags);
  for(const letter of['A','B','C'])await resource('limit'+limit+' afteractualprocessreopen '+letter,'/capacity-'+letter);
  await stopProducer();await cacheSnapshot('limit'+limit+' afterreopenprocessclose',true);
 });
 normal=true;
}catch(failure){error??={name:failure.name,message:failure.message,stack:failure.stack,group:activeGroup,reference:failure.reference};journal({type:'failure',error})}
finally{const cleanupErrors=[];try{await stopProducer()}catch(failure){cleanupErrors.push({owner:'Native',message:failure.message})}for(const socket of sockets)socket.destroy();if(server){server.closeAllConnections();try{await new Promise((resolve,reject)=>server.close(failure=>failure?reject(failure):resolve()))}catch(failure){cleanupErrors.push({owner:'HTTP',message:failure.message})}}clearTimeout(watchdog);cleanupFailed=cleanupErrors.length>0;journal({type:'cleanup',errors:cleanupErrors,fixtureSocketsRemaining:sockets.size});await writeFile(output,JSON.stringify({status:normal&&!watchdogExpired&&!cleanupFailed?'OBSERVED_NOT_A_CACHE_PARITY_PASS':'INCOMPLETE_OR_FAILED',normal,watchdogExpired,error,groups,operations,wire,requests,producers,cacheDirectory,Node:{pid:process.pid,version:process.version,abi:process.versions.modules,v8:process.versions.v8},cleanupErrors,fixtureSocketsRemaining:sockets.size,elapsedMS:stamp(),policy:'Every cache effect is measured from actual Native bytes, server requests and real CDP events. No fake cache metadata/events, user cache path, UA override, candidate engine, database manipulation or Native implementation copy. Default/no-directory and explicit configured profiles remain separate; original CLI/default test results are not reclassified.'},null,2)+'\n',{flag:'wx'})}
if(!normal||watchdogExpired||cleanupFailed)process.exitCode=1;
