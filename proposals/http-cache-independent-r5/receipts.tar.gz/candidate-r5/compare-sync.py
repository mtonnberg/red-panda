#!/usr/bin/env python3
"""Read actual journals; declared contracts only, no engine or raw edits."""
from pathlib import Path
from urllib.parse import urlsplit
import hashlib,json

ROOT=Path(__file__).resolve().parent
NP=Path('/workspace/shared/http-cache-sync-native-r1/native-observations-r1/Native.json')
CP=ROOT/'runs/sync-cohort-r5/Candidate.json'
n=json.loads(NP.read_text());c=json.loads(CP.read_text())
def headers(value):
 if isinstance(value,str):
  return {line.split(':',1)[0].lower():line.split(':',1)[1].strip()for line in value.splitlines()if ':'in line and line.split(':',1)[0].lower()!='date'}
 return {name.lower():text for name,text in value if name.lower()!='date'}
def events(row):
 ids=set(row['requestIds']);return [event for event in row['events']if event.get('params',{}).get('requestId')in ids]
def response(row):return [event['params']['response']for event in events(row)if event['method']=='Network.responseReceived']
rows=[]
for a,b in zip([r for r in n['operations']if r['kind']=='resource'],[r for r in c['operations']if r['kind']=='resource'],strict=True):
 av=a['value'];bv=b['value']
 checks={'labelAndConsumer':a['label']==b['label']and a['consumer']==b['consumer'],
  'completeAuthoredPayloadExceptURLHeaders':{k:v for k,v in av.items()if k not in ['url','headers']}=={k:v for k,v in bv.items()if k not in ['url','headers']},
  'publicHeadersExceptDate':headers(av['headers'])==headers(bv['headers'])if 'headers'in av and'headers'in bv else('headers'in av)==('headers'in bv),
  'URLPathQuery':[(urlsplit(value.get('url','')).path,urlsplit(value.get('url','')).query)for value in [av]]==[(urlsplit(value.get('url','')).path,urlsplit(value.get('url','')).query)for value in [bv]],
  'actualHTTPDelta':a['requestDelta']==b['requestDelta'],
  'actualRequestIDCount':len(a['requestIds'])==len(b['requestIds']),
  'networkEventMethods':[e['method']for e in events(a)]==[e['method']for e in events(b)],
  'inspectorStatusCaptionCacheFlag':[(r['status'],r['statusText'],r['fromDiskCache'])for r in response(a)]==[(r['status'],r['statusText'],r['fromDiskCache'])for r in response(b)],
  'inspectorRawHeadersExceptDate':[headers(r['headers'].items())for r in response(a)]==[headers(r['headers'].items())for r in response(b)],
  'actualBodyQueryResults':[r['response'].get('result')for r in a['bodyCommands']]==[r['response'].get('result')for r in b['bodyCommands']],
 }
 rows.append({'label':a['label'],'checks':checks,'allDeclaredChecksEqual':all(checks.values()),'dynamicNativeURL':av.get('url'),'dynamicCandidateURL':bv.get('url')})
cookies=lambda raw:[r['response'].get('result')for r in raw['operations']if r.get('method')=='Network.getAllCookies']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out={'status':'DECLARED_28_SYNC_RESOURCE_CONTRACTS_MATCH'if len(rows)==28 and all(r['allDeclaredChecksEqual']for r in rows)and cookies(n)==cookies(c)else'DECLARED_CONTRARIES','NativeRaw':{'path':str(NP),'sha256':sha(NP)},'candidateRaw':{'path':str(CP),'sha256':sha(CP)},'rows':rows,'NativeCookieSnapshots':cookies(n),'candidateCookieSnapshots':cookies(c),'actualProducerCount':len(c['producers']),'allActualProducersExit0':all(p['exit']==0 and p['signal']is None for p in c['producers']),'limits':'Exact declared consumer data, real byte/text/header/body/query/delta/network-event/cache-caption contracts. Raw authorities,Date,request/session/frame/loader IDs,clocks,othernetworkmetadata retained, not whole-object equality. Window responseText code units remain text, not byte evidence. All raw headers and journals unmodified.'}
p=ROOT/'runs/sync-cohort-r5/declared-contract-comparison.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'rows':len(rows),'actualProducers':out['actualProducerCount'],'contraries':[r['label']for r in rows if not r['allDeclaredChecksEqual']],'sha256':sha(p)}))
