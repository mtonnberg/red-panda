// Authored fixture, not a candidate or Native engine implementation.
onmessage = async event => {
  const { id, mode, url } = event.data;
  try {
    if (mode === 'sync') {
      const xhr = new XMLHttpRequest(); xhr.open('GET', url, false);
      xhr.responseType = 'arraybuffer'; xhr.send();
      const actualBuffer = xhr.response instanceof ArrayBuffer;
      postMessage({ id, mode, ok: true, status: xhr.status, statusText: xhr.statusText,
        readyState: xhr.readyState, url: xhr.responseURL, responseType: xhr.responseType,
        headers: xhr.getAllResponseHeaders(), actualArrayBuffer: actualBuffer,
        bytes: actualBuffer ? Array.from(new Uint8Array(xhr.response)) : null });
    } else {
      const response = await fetch(url);
      postMessage({ id, mode, ok: true, status: response.status, statusText: response.statusText,
        url: response.url, headers: Array.from(response.headers.entries()),
        bytes: Array.from(new Uint8Array(await response.arrayBuffer())) });
    }
  } catch (error) {
    postMessage({ id, mode, ok: false, error: { name: error.name, message: error.message,
      actualError: error instanceof Error, actualDOMException: error instanceof DOMException } });
  }
};
