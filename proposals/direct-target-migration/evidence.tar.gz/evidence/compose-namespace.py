from pathlib import Path
import json,hashlib,difflib
proposal=Path('/workspace/red-panda/proposals/direct-target-migration');m=json.loads((proposal/'source-manifest.json').read_text())
for relative in m['files']:
 current=Path(relative).read_text();base=Path('evidence/namespace-base')/relative
 if not base.exists():result=current
 elif relative=='src/dom-wrapper-realms.js':
  s=base.read_text();s="import {transformPrivateWebSocketSource} from './dom-websocket-state.js';\n"+s
  pairs=[("(kind==='Attr'||kind==='NamedNodeMap')?['attributes']:['nodes','events']","kind==='WebSocket'?['websockets']:(kind==='Attr'||kind==='NamedNodeMap')?['attributes']:['nodes','events']"),("&&!event&&Implementation!==EventTargetImpl)continue;","&&!event&&Implementation!==EventTargetImpl&&kind!=='WebSocket')continue;"),("const originalSource=readFileSync(full,'utf8');let source=originalSource;","const originalSource=readFileSync(full,'utf8');let source=kind==='WebSocket'?transformPrivateWebSocketSource(originalSource):originalSource;"),("if(event||Implementation===EventTargetImpl)source=transformEventIDLInstall(source,kind);","if(event||Implementation===EventTargetImpl||kind==='WebSocket')source=transformEventIDLInstall(source,kind);"),("candidates.map(({kind,originalSource})","candidates.filter(({kind})=>kind!=='WebSocket').map(({kind,originalSource})")]
  for old,new in pairs:
   assert s.count(old)==1,(relative,old);s=s.replace(old,new)
  result=s
 elif relative=='src/isolated-world.js':
  result=current
  original=(Path('evidence/base')/relative).read_text();ns=base.read_text()
  # SequenceMatcher on complete lines gives exact deterministic original
  # namespace changes; reject context conflicts instead of guessing offsets.
  a=original.splitlines(True);b=ns.splitlines(True)
  for tag,ai,aj,bi,bj in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
   if tag=='equal':continue
   old=''.join(a[ai:aj]);new=''.join(b[bi:bj])
   if old:
    assert result.count(old)==1,(relative,old);result=result.replace(old,new,1)
   else:
    anchor=''.join(a[max(0,ai-1):ai+1]);replacement=''.join(a[max(0,ai-1):ai])+new+''.join(a[ai:ai+1]);assert result.count(anchor)==1,(relative,anchor);result=result.replace(anchor,replacement,1)
 else:
  assert base.read_text()==(Path('evidence/base')/relative).read_text(),relative;result=current
 p=proposal/'after-namespace-leaves'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(result)
patch=[];entries={}
for relative in m['files']:
 base=Path('evidence/namespace-base')/relative;before=base.read_bytes() if base.exists() else None;after=(proposal/'after-namespace-leaves'/relative).read_bytes();entries[relative]={'before':hashlib.sha256(before).hexdigest() if before is not None else None,'after':hashlib.sha256(after).hexdigest()};patch.extend(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+relative if before is not None else '/dev/null',tofile='b/'+relative))
p=proposal/'integration-after-namespace-event-viewport.patch';p.write_text(''.join(patch));m['namespaceAlternative']={'runtimeStatus':'STATIC ONLY: not executed; standalone results must not be promoted to composition acceptance','prerequisites':['proposals/namespace-serialization/integration-current-composed.patch','proposals/event-api-parity/integration-after-namespace.patch','proposals/window-viewport-parity/integration-after-namespace-event.patch'],'patchSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':entries};(proposal/'source-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(m['namespaceAlternative']['patchSHA256'])
