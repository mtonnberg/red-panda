"""PREPARED ONLY. Serial full validation; original case/API/heap budgets unchanged."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import resource
import shutil
import signal
import subprocess
import time

ROOT = Path('/workspace/red-panda')
HERE = Path(__file__).resolve().parent
ORIGINAL = ROOT / 'proposals/phase26-full-file-element-url/controller.py'
NODE = Path('/workspace/shared/rea-tools/node_modules/node/bin/node')
NATIVE = Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux')
RENDER = Path('/workspace/shared/red-panda-render')
RUNTIME_SOURCE = '95bba30f4013139999dc9b843b45bdb5ddc1802145431fc6386bddc85975cd36'
RUNTIMES = {
    '24.22.1': 'fb4a1e1cbb11c88d27135ec792ab898bc0ead45ecf3556a39ad5fad04418a33b',
    '24.19.0': '10f7c6b539974ad5632a763a7211c6d5743696f34dba885c068cb91c42409f71',
    '26.13.0': 'b8f038cb2f824b3622384002cd6cfad7826b2cee4f9738598e496beca79498e8',
}
STEPS = [
    ('protocol', ['npm', 'run', 'test:protocol'], 1800),
    ('purescript', ['npm', 'run', 'test:puppeteer'], 180),
    ('reference', ['npm', 'run', 'test:reference', '--', str(NATIVE)], 180),
    ('syntax', ['npm', 'run', 'check'], 180),
    ('strict', ['npm', 'run', 'build:automation', '--', '--strict', '--pedantic-packages'], 180),
]

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def save(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def files(folder):
    return (p for p in folder.rglob('*') if p.is_file() and
            '__pycache__' not in p.parts and '.git' not in p.parts)

def environment():
    env = os.environ.copy()
    env['PATH'] = '/workspace/shared/red-panda-render/bin:/workspace/shared/rea-tools/node_modules/.bin:' + env.get('PATH', '')
    env['NPM_CONFIG_CACHE'] = '/workspace/shared/npm-cache'
    env['NODE_USE_ENV_PROXY'] = '1'
    bypass = ','.join(filter(None, [env.get('NO_PROXY'), env.get('no_proxy'),
        '0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']))
    env['NO_PROXY'] = env['no_proxy'] = bypass
    return env

def snapshot(env):
    folders = ['src', 'test', 'native', 'bin', 'scripts', 'helpers', 'node_modules',
               'automation/src', 'automation/test', 'automation/.spago/p', 'oracle',
               'docs/reference', '.cache/lightpanda-reference/browser-948d773786/src/browser/tests']
    paths = {p for name in folders for p in files(ROOT / name)}
    paths.update(ROOT / name for name in ['package.json', 'package-lock.json',
        'automation/spago.yaml', 'automation/spago.lock', 'automation/package-set.json',
        'automation/package-set-provenance.json'])
    paths.update([NATIVE, NODE, ORIGINAL, Path(__file__).resolve(), HERE / 'plan.json'])
    # External npm implementation and actual render dependency bytes, not generated outputs.
    npm = Path(shutil.which('npm', path=env['PATH'])).resolve()
    paths.update(files(npm.parent.parent))
    paths.update(files(RENDER / 'bin'))
    paths.update(files(RENDER / 'lib'))
    for key in ['NODE_EXTRA_CA_CERTS', 'SSL_CERT_FILE', 'REQUESTS_CA_BUNDLE']:
        if env.get(key):
            paths.add(Path(env[key]))
    # Pin the actual executable behind render/python symlinks as well.
    paths.add((RENDER / 'bin/python3').resolve())
    return {str(p): {'sha256': sha(p), **({'target': str(p.resolve())} if p.is_symlink() else {})}
            for p in sorted(paths)}

def identity(pid):
    try:
        raw = (Path('/proc') / str(pid) / 'stat').read_text()
        fields = raw[raw.rfind(')') + 2:].split()
        return {'pid': int(pid), 'state': fields[0], 'parent': int(fields[1]),
                'pgrp': int(fields[2]), 'sid': int(fields[3]), 'startTicks': int(fields[19])}
    except (OSError, ValueError, IndexError):
        return None

def members(leader):
    return [row for p in Path('/proc').iterdir() if p.name.isdigit() and
            (row := identity(p.name)) and (row['pgrp'] == leader or row['sid'] == leader)]

def live(rows):
    return [row for row in rows if row['state'] != 'Z']

def observed_remainder(leader, owned):
    actuals = {(row['pid'], row['startTicks']): row for row in members(leader)}
    for pid, start in owned:
        actual = identity(pid)
        if actual and actual['startTicks'] == start:
            actuals[(pid, start)] = actual
    return list(actuals.values())

def cleanup(leader, owned):
    # Only exact observed PID/start identities in this child's new group/session.
    for sig, cap in [(signal.SIGTERM, 3), (signal.SIGKILL, 3)]:
        for row in members(leader):
            owned[(row['pid'], row['startTicks'])] = row
        for (pid, start), prior in list(owned.items()):
            actual = identity(pid)
            if actual and actual['startTicks'] == start and actual['state'] != 'Z':
                try:
                    os.kill(pid, sig)
                except ProcessLookupError:
                    pass
        end = time.monotonic() + cap
        while time.monotonic() < end:
            if not live(observed_remainder(leader, owned)):
                return observed_remainder(leader, owned)
            time.sleep(.05)
    return observed_remainder(leader, owned)

def resources():
    values = {}
    for name in ['cpu.max', 'cpu.stat', 'memory.current', 'pids.current']:
        try:
            values[name] = (Path('/sys/fs/cgroup') / name).read_text()
        except OSError as error:
            values[name] = {'unavailable': str(error)}
    return values

def observed_counts(name, log):
    text = log.read_text(errors='replace')
    if name == 'protocol':
        values = {}
        for key in ['tests', 'suites', 'pass', 'fail', 'cancelled', 'skipped', 'todo']:
            matches = re.findall(r'(?m)^[ℹ#] ' + key + r' (\d+)\s*$', text)
            if matches:
                values[key] = int(matches[-1])
        return {'actualReporterSummary': values, 'rawLogAuthoritative': True}
    if name == 'purescript':
        lines = [line for line in text.splitlines() if re.search(r'\b\d+ checks passed\b', line)]
        return {'actualPassLines': len(re.findall(r'(?m)^PASS ', text)),
                'actualCheckSummaryLines': lines, 'rawLogAuthoritative': True}
    if name == 'reference':
        return {'actualPassLines': len(re.findall(r'(?m)^PASS ', text)), 'rawLogAuthoritative': True}
    return {'rawLogAuthoritative': True}

def no_core():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

def interrupted(number, frame):
    raise KeyboardInterrupt('Administrative signal ' + str(number))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch', required=True)
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', args.epoch):
        raise ValueError('Epoch must be a single fresh filename')
    out = HERE / args.epoch
    out.mkdir(exist_ok=False)
    env = environment()
    record = {'status': 'STARTING', 'stages': [], 'futureStages': [s[0] for s in STEPS],
              'countsPolicy': 'Only actual raw reporter output; no historical count arithmetic.'}
    before = None
    child = None
    owned = {}
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    def persist():
        save(out / 'status.json', record)
    try:
        assert os.path.samefile(shutil.which('node', path=env['PATH']), NODE)
        assert not env.get('RED_PANDA_RUNTIME_ADDON') and not env.get('RED_PANDA_COLLECTIONS_ADDON'), 'Use actual Root-installed matching addons'
        assert sha(NATIVE) == '9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f'
        assert sha(ROOT / 'native/runtime.cc') == RUNTIME_SOURCE, 'Future combined95 source not installed'
        installed = {}
        for version, expected in RUNTIMES.items():
            folder = ROOT / 'native/build/linux-x64' / ('node-' + version)
            metadata = json.loads((folder / 'runtime.node.json').read_text())
            assert sha(folder / 'runtime.node') == expected == metadata['binarySHA256']
            assert metadata['sourceSHA256'] == RUNTIME_SOURCE
            assert metadata['node'] == 'v' + version
            installed[version] = metadata
        artifacts = list((ROOT / 'native/build/linux-x64').glob('node-*/*.node*'))
        assert len(artifacts) == 18, 'Require all18 ordinary SDK binaries/manifests'
        before = snapshot(env)
        save(out / 'inputs-before.json', before)
        actual_node_version = subprocess.check_output([str(NODE), '--version'], env=env, text=True).strip()
        assert actual_node_version == 'v24.22.1', 'Declared executable must be actualNode24.22.1'
        save(out / 'environment.json', {
            'node': actual_node_version,
            'PATH': env['PATH'], 'NODE_USE_ENV_PROXY': env['NODE_USE_ENV_PROXY'],
            'NO_PROXY': env['NO_PROXY'], 'no_proxy': env['no_proxy'],
            'NPM_CONFIG_CACHE': env['NPM_CONFIG_CACHE'],
            'NODE_OPTIONS': env.get('NODE_OPTIONS'),
            'tlsInheritedKeys': {k: env.get(k) for k in ['NODE_EXTRA_CA_CERTS', 'NODE_TLS_REJECT_UNAUTHORIZED', 'SSL_CERT_FILE', 'SSL_CERT_DIR', 'REQUESTS_CA_BUNDLE']},
            'runtimeInstalled': installed, 'sdkArtifacts': [str(p) for p in sorted(artifacts)],
            'proxyCredentialsNotPrinted': True,
            'policy': 'Canonical Root environment; preserve inherited proxy/TLS values; append all original loopback aliases.'})
        for name, command, cap in STEPS:
            assert snapshot(env) == before, 'Guarded inputs changed before stage'
            started = time.monotonic()
            row = {'name': name, 'command': command, 'administrativeCapSeconds': cap,
                   'status': 'RUNNING', 'resourcesBefore': resources()}
            record['stages'].append(row)
            record['futureStages'].remove(name)
            logpath = out / (name + '.log')
            with logpath.open('xb') as log:
                child = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                    stdout=log, stderr=subprocess.STDOUT, start_new_session=True, preexec_fn=no_core)
                row['identity'] = identity(child.pid)
                assert row['identity'] and row['identity']['pgrp'] == child.pid and row['identity']['sid'] == child.pid
                owned = {(child.pid, row['identity']['startTicks']): row['identity']}
                persist()
                print(json.dumps({'stage': name, 'status': 'RUNNING', 'identity': row['identity']}), flush=True)
                last_progress = started
                while child.poll() is None:
                    now = time.monotonic()
                    for member in members(child.pid):
                        owned[(member['pid'], member['startTicks'])] = member
                    if now - started >= cap:
                        row['administrativeDeadline'] = True
                        break
                    if now - last_progress >= 20:
                        progress = {'stage': name, 'status': 'RUNNING', 'seconds': now - started,
                                    'logBytes': logpath.stat().st_size, 'owned': members(child.pid)}
                        with (out / 'progress.jsonl').open('a') as stream:
                            stream.write(json.dumps(progress) + '\n')
                        print(json.dumps(progress), flush=True)
                        last_progress = now
                    time.sleep(.2)
                row['ownedBeforeCleanup'] = observed_remainder(child.pid, owned)
                row['ownedAfterCleanup'] = cleanup(child.pid, owned)
                child.wait(timeout=5)
                row['exit'] = child.returncode
                row['ownedObserved'] = list(owned.values())
                child = None
            row['seconds'] = time.monotonic() - started
            row['resourcesAfter'] = resources()
            row['rawLog'] = {'path': str(logpath), 'sha256': sha(logpath), 'bytes': logpath.stat().st_size}
            row['counts'] = observed_counts(name, logpath)
            row['inputsUnchanged'] = snapshot(env) == before
            row['status'] = 'PASSED' if row['exit'] == 0 and not row.get('administrativeDeadline') and not live(row['ownedBeforeCleanup']) and not live(row['ownedAfterCleanup']) and row['inputsUnchanged'] else 'FAILED_RETAIN_RAW'
            persist()
            print(json.dumps({k: row[k] for k in ['name', 'status', 'exit', 'seconds', 'counts']}), flush=True)
            if row['status'] != 'PASSED':
                break
        record['status'] = 'PASS' if len(record['stages']) == len(STEPS) and all(row['status'] == 'PASSED' for row in record['stages']) else 'STOPPED_REST_UNRUN'
    except BaseException as error:
        record['status'] = 'STOPPED_REST_UNRUN'
        record['failure'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if child is not None:
            record['interruptedCleanup'] = cleanup(child.pid, owned)
            try:
                record['interruptedChildExit'] = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                record['cleanupFailure'] = 'Owned leader did not exit after bounded cleanup'
        if before is not None:
            after = snapshot(env)
            save(out / 'inputs-after.json', after)
            record['inputsUnchanged'] = before == after
            save(out / 'source-stable.json', {'unchanged': before == after, 'inputs': len(before),
                'changed': sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k))})
            if before != after:
                record['status'] = 'STOPPED_INTEGRITY_FAILURE'
        persist()
        print(json.dumps({'status': record['status'], 'futureStages': record['futureStages'],
                          'inputsUnchanged': record.get('inputsUnchanged')}), flush=True)
    return 0 if record['status'] == 'PASS' and not record.get('cleanupFailure') else 1

if __name__ == '__main__':
    raise SystemExit(main())
