from pathlib import Path
import json,hashlib,collections
R=Path('/workspace/shared/network-private-initial-producer-r4');H=R/'report-observation-r5/handoff-current652';D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];collisions=[]
def add(source,target,group):
 p=Path(source);assert p.is_file() and not p.is_symlink(),p
 assert not {'node_modules','.git','.aws','.codex'}.intersection(p.parts),p
 assert p.suffix not in ['.node','.so','.a','.o','.zip','.tar','.gz'],p
 assert p.read_bytes()[:4]!=b'\x7fELF',p
 t=Path(target);assert not t.is_absolute()and'..'not in t.parts
 rows.append({'source':str(p),'target':t.as_posix(),'SHA256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777,'group':group})
def tree(source,target,group,seal=False):
 for p in sorted(Path(source).rglob('*')):
  if p.is_file():
   rel=p.relative_to(source)
   if seal and str(rel)=='manifest.json':rel=Path('seal-manifest.json')
   add(p,Path(target)/rel,group)
checkpoints=[(Path('/workspace/shared/network-private-initial-producer-r3/checkpoint1-capture-only-positive'),'prerequisites/capture-only','capture-only645'),(R/'checkpoint1-native-mime4-positive','prerequisites/native-mime4','NativeMIME4-old645'),(R/'checkpoint2-first-behavior-gate-negative','epochs/650-first-gate-negative','Native5-and650-firstfailure'),(R/'retirement-generation-r4/checkpoint1-causal-positive-recovery-expectation-negative','epochs/651-retirement-causal-and-old6-negative','651-causals-and-expectationfailure'),(R/'report-observation-r5/checkpoint1-quiet-recovery-positive','epochs/652-quiet-corrected-recovery-positive','652-quiet-and-corrected6to7')]
for source,target,group in checkpoints:
 manifest=json.loads((source/'manifest.json').read_text());fm=manifest.get('files',manifest.get('fileSHA256'));assert fm
 for n,v in fm.items():
  if sha(source/n)!=v:
   assert n=='manifest.json';origin=source.parent/'manifest.json';assert sha(origin)==v
   add(origin,Path(target)/'origin-manifest.json',group)
   collisions.append({'sealedDirectory':str(source),'sealSHA256':sha(source/'manifest.json'),'sealTarget':str(Path(target)/'seal-manifest.json'),'originalFilesManifestEntry':{'path':n,'SHA256':v},'matchingOriginalPath':str(origin),'archivedOriginalTarget':str(Path(target)/'origin-manifest.json'),'interpretation':'Original manifest was copied then same destination name replaced with seal. Both exact original and seal retained; no raw/source mismatch and no old manifest edited.'})
 tree(source,target,group,seal=True)
m=json.loads((H/'manifest-r3.json').read_text());assert all(sha(H/n)==v for n,v in m['fileSHA256'].items());tree(H,'accepted-current652','current652-mixed7-protected188-SDK16-Source96')
J=Path('/workspace/shared/network-initial-root-integration-r1');j=json.loads((J/'journal.json').read_text());assert len(j['RootBefore646'])==646 and len(j['RootExpected652'])==652;assert j['state']=='APPLIED_EXACT_INITIAL12_FULL_INSTALLED_VALIDATION_UNRUN'
add(J/'journal.json','root-application/journal-applied-before-full.json','actualRoot12application-pending-full');add(J/'apply-root12.py','root-application/apply-root12.py','actualRoot12application-pending-full');tree(J/'backup-before','root-application/backup-before','six-real-preapplication-backups')
leaves=json.loads((H/'contracts/leaves.json').read_text());assert j['rows']==leaves
for name,leaf in leaves.items():
 p=Path('/workspace/red-panda')/name;assert sha(p)==leaf['after'];add(p,Path('source-after12')/name,'exact12-Root-applied-leaves')
M=Path('/workspace/shared/registration455-root645-plan-r2')
for rel in ['fixtures/adapted/document/open_load_events.html','fixtures/adapted/testing.js','harness/adapter.json','maps/registration-map.json']:
 add(M/rel,Path('source96-inputs')/rel,'unchanged-source96-and-disclosed-eligibility')
add(R/'retirement-generation-r4/evidence/source96-root645-baseline-positive.json','source96-inputs/historical-Root645-baseline-positive.json','historical-root645-not-retagged')
assert len({r['target']for r in rows})==len(rows)
counts=collections.Counter(r['group']for r in rows)
allow={'schema':'initial-network-lifecycle-r5-archive-allowlist/v1','state':'STATIC_EXPLICIT_ALLOWLIST_NOT_COPIED_NOT_STAGED','plannedRepositoryPrefix':'proposals/initial-network-lifecycle-r5','plannedOwnedStagingRoot':str(D/'archive'),'RootCurrentApplication':'652after12exact; historical646proofs unchanged','nativeArtifactsOnlyHashMetadataNoBinaries':18,'runtimeSource95':'95bba30f4013139999dc9b843b45bdb5ddc1802145431fc6386bddc85975cd36','actualNewMainServiceParentReceipt':{'pid':870516,'startTicks':11030805,'TTY':90638,'authority':'Parent actual launch report, not an invented live-smoke proof'},'rows':rows,'fileCount':len(rows),'totalBytes':sum(r['bytes']for r in rows),'groupCounts':dict(counts),'historicalManifestNameCollisions':collisions,'explicitExcluded':['ELF/native .node/addon build binaries','installed dependencies/node_modules','whole candidate/baseline source trees','browser profiles/cookies/cache/personal or external-service data','protected fixture data beyond exact owned rawlogs/selected12source/disclosedSource96oracle','future full-suite or live-smoke outputs until actual Parent receipt supplied','staging/git operations'],'awaitActualFinalReceiptKinds':['Root installed full JS actual TAP+status+warnings','Root native/syntax/strict and actual PS validation if supplied','new main870516 real health/live-smoke receipt','actual post-full source/native/dependency guard and owned closure','commit/push receipt only if Parent actually supplies it'],'futureReceiptRule':'New exact paths/SHA/bytes added in a separately versioned allowlist after actual supply; existing rows and historical graph labels never rewritten.'}
(D/'allowlist-r1.json').write_text(json.dumps(allow,indent=2)+'\n');print(json.dumps({'allowlist':str(D/'allowlist-r1.json'),'SHA256':sha(D/'allowlist-r1.json'),'files':len(rows),'bytes':allow['totalBytes'],'groups':dict(counts),'manifestCollisionMappings':len(collisions)}))
