#!/usr/bin/env python3
"""Reusable frozen-spec skeleton. No default candidate; no JS until explicit run."""
from pathlib import Path
import argparse,hashlib,json,os,re,resource,signal,subprocess,time,socket

P=Path(__file__).parent;ROOT=Path('/workspace/red-panda');SERVICE=870516
NODE_SHA='e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb'
CPP95='95bba30f4013139999dc9b843b45bdb5ddc1802145431fc6386bddc85975cd36'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise RuntimeError(message)
def load(path):return json.loads(Path(path).read_text())
def readmap(descriptor):
 path=Path(descriptor['path']);require(sha(path)==descriptor['SHA256'],'Map descriptor drift: '+str(path));value=load(path)
 for part in descriptor.get('keyPath',[]):value=value[part]
 require(isinstance(value,dict)and value and all(isinstance(k,str)and isinstance(v,str)and re.fullmatch('[0-9a-f]{64}',v)for k,v in value.items()),'Expected explicit nonempty full-SHA map')
 base=Path(descriptor['base']);return {str(base/name):value for name,value in value.items()}
def verify(table):
 bad=[n for n,h in table.items()if not Path(n).is_file()or sha(n)!=h]
 require(not bad,'Frozen input mismatch: '+str(bad));return len(table)
def inventory(base,scopes):
 paths=set()
 for name in scopes:
  path=base/name;require(path.exists(),'Inventory scope missing '+str(path));require(not path.is_symlink(),'Inventory scope itself must be physical: '+str(path))
  if path.is_dir():
   for file in path.rglob('*'):
    require(not file.is_symlink(),'Unfrozen symlink inside guarded source scope: '+str(file))
    if file.is_file():paths.add(str(file))
  else:paths.add(str(path))
 return paths
def proc(pid,required=False):
 try:
  text=(Path('/proc')/str(pid)/'stat').read_text();f=text[text.rfind(')')+2:].split();return {'pid':int(pid),'state':f[0],'parent':int(f[1]),'pgrp':int(f[2]),'sid':int(f[3]),'startTicks':int(f[19])}
 except(FileNotFoundError,ProcessLookupError):return None
 except(OSError,ValueError,IndexError)as error:
  if required:raise RuntimeError('Cannot verify owned process identity: '+str(pid))from error
  return None
def track(child,owned):
 rows=[]
 for file in Path('/proc').iterdir():
  if file.name.isdecimal()and(row:=proc(file.name)):rows.append(row)
 changed=True
 while changed:
  changed=False;parents={pid for(pid,start),record in owned.items()if(current:=proc(pid,True))and current['startTicks']==start}
  for row in rows:
   if row['pgrp']==child.pid or row['sid']==child.pid or row['parent']in parents:
    require(row['pid']!=SERVICE,'Excluded production service entered job ownership; refuse signalling')
    key=(row['pid'],row['startTicks'])
    if key not in owned:owned[key]=row;changed=True
 live=[]
 for(pid,start),record in owned.items():
  now=proc(pid,True)
  if now and now['startTicks']==start:live.append(now)
 return live
def cleanup(child,owned):
 before=track(child,owned)
 for sig,seconds in [(signal.SIGTERM,2),(signal.SIGKILL,3)]:
  for row in track(child,owned):
   require(row['pid']!=SERVICE,'Never signal excluded main service')
   if row['state']!='Z':
    now=proc(row['pid'],True)
    if now and now['startTicks']==row['startTicks']:
     try:os.kill(row['pid'],sig)
     except ProcessLookupError:pass
  end=time.monotonic()+seconds
  while time.monotonic()<end and any(r['state']!='Z'for r in track(child,owned)):time.sleep(.02)
  if not any(r['state']!='Z'for r in track(child,owned)):break
 child.wait(timeout=3);after=track(child,owned);return {'before':before,'observed':list(owned.values()),'after':after,'liveRemaining':[r for r in after if r['state']!='Z']}

parser=argparse.ArgumentParser();parser.add_argument('--execute-after-root-review',action='store_true');a=parser.parse_args();require(a.execute_after_root_review,'Explicit Parent runtime lease and canonical9582/9584 reservation required')
H=Path(__file__).parent;spec=load(H/'freeze-first.json');plan=load(H/'source96-plan.json');require(sha(H/'freeze-first.json')=='5aa4e2c958e1432544e48eadf8263377edabcc01bc9aa27b2dcd0913194219a1','Protection spec drift');require(sha(H/'source96-plan.json')=='f419c0557ef45c378414997ec3aef7ef3319c2df06dfcb4c308a81b7e0b15b4c','Source96 plan drift');selfSHA=sha(__file__);candidate=Path(spec['candidateRoot']);tables={n:readmap(d)for n,d in spec['guardMaps'].items()}
def guards():
 require(sha(__file__)==selfSHA,'Controller drift');counts={n:verify(v)for n,v in tables.items()}
 for d in spec['guardMaps'].values():readmap(d)
 for name,base in [('root',ROOT),('candidate',candidate)]:require(inventory(base,spec['inventoryScopes'][name])==set(tables[name]),'Full inventory drift '+name)
 for name,value in plan['absoluteInputSHA256'].items():require(sha(name)==value,'Source96 immutable dependency drift '+name)
 require(sha(candidate/'native/runtime.cc')==CPP95,'CPP95 drift');return counts
require((proc(SERVICE,True)or{}).get('startTicks')==11030805,'Actual excluded main start changed');guards();output=H/'run-source96-654';require(not output.exists(),'Fresh output required');output.mkdir();started=time.monotonic();owned={};child=None;status={'state':'RUNNING','command':plan['command'],'aggregateSeconds':90,'originalLoad2000FreshAssertion2000Unchanged':True,'actualUAUnchanged':True,'Source96HistoricalRootPassNotNewFixClaim':True,'sourceDeclaredModuleIDs':plan['originalModuleIDs'],'moduleCoverageBoundary':'IDs are byte-pinned original script declarations. No fabricated per-module observation count; original assertOk requires nonzero observations and no pending async blocks.','mainServiceBefore':proc(SERVICE),'controllerSHA256':selfSHA}
try:
 env=os.environ.copy();require(env.get('NODE_OPTIONS','')==spec['inheritedNodeOptions'],'Inherited Node options differ');env['NODE_USE_ENV_PROXY']='1';env['RED_PANDA_RUNTIME_ADDON']=str(candidate/'native/build/linux-x64/node-24.22.1/runtime.node');env.pop('RED_PANDA_COLLECTIONS_ADDON',None);env.pop('RED_PANDA_HEAP_ADDON',None)
 for key in ['NO_PROXY','no_proxy']:env[key]=','.join(filter(None,[env.get(key,''),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']))
 with(output/'stdout').open('xb')as stdout,(output/'stderr').open('xb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  child=subprocess.Popen(plan['command'],cwd=plan['cwd'],env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);initial=proc(child.pid,True);require(initial and initial['pgrp']==child.pid and initial['sid']==child.pid and child.pid!=SERVICE,'Actual owned session missing');owned[(child.pid,initial['startTicks'])]=initial;status['initialIdentity']=initial;nextprogress=time.monotonic()+20
  while child.poll()is None:
   track(child,owned);now=time.monotonic()
   if now-started>=90:status['deadlineHit']=True;break
   if now>=nextprogress:print(json.dumps({'elapsed':now-started,'owned':track(child,owned)}),flush=True);nextprogress+=20
   time.sleep(.05)
  status['ownedLiveAfterExitBeforeCleanup']=[r for r in track(child,owned)if r['state']!='Z']if child.poll()is not None else None;status['cleanup']=cleanup(child,owned);status['exit']=child.returncode
 require(not status.get('deadlineHit')and status['exit']==0 and not status['cleanup']['liveRemaining']and not status['ownedLiveAfterExitBeforeCleanup'],'Source execution/deadline/cleanup failure');report=load(output/'report.json');require(report['counts']=={'selected':1,'passed':1,'failed':0,'timeout':0,'unobserved':0},'Actual Source96 nonpass');require(len(report['results'])==1,'Unexpected Source selection');r=report['results'][0];loadContract=r['sourceLoadContract'];require(r['path']=='document/open_load_events.html'and r['status']=='passed'and r['nonzeroObservationsEnforced']and r['nativeHarnessBranch']and r['observedUserAgent'].startswith('RedPanda/'),'Actual Source observation/identity failed');require(loadContract['loadBudgetMs']==2000 and loadContract['assertionBudgetMs']==2000 and loadContract['assertionStartedAfterLoad']and loadContract['loadBarrier']['observed']and loadContract['loadBarrier']['document']['readyState']=='complete','Original Source budgets/actual barrier not met');require(not report['publicUserAgentOverrideApplied']and not report['publicClientHintsOverrideApplied']and report['sourceHarnessSHA256']=='2b0e6212c8fce6c8f57d25ec05b1a07b4c1a9448a5dd5510f953b83b10abd92b','Adapter/UA changed');status['result']=r;status['state']='PASS_ACTUAL_SOURCE96_REGRESSION'
except Exception as error:status['state']='FAILED_OR_INCOMPLETE';status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 if child:
  try:
   if child.poll()is None or any(r['state']!='Z'for r in track(child,owned)):status['exceptionalCleanup']=cleanup(child,owned)
   status['finalOwnedLiveRemaining']=[r for r in track(child,owned)if r['state']!='Z'];require(not status['finalOwnedLiveRemaining'],'Owned child remains')
  except Exception as error:status['state']='OWNED_CLEANUP_FAILURE';status['cleanupFailure']=str(error)
 status['secondsIncludingCleanup']=time.monotonic()-started;status['mainServiceAfter']=proc(SERVICE)
 try:
  require((status['mainServiceAfter']or{}).get('startTicks')==11030805,'Excluded actual main changed')
  status['portsAfter']=[]
  for port in[9582,9584]:
   with socket.socket()as check:
    check.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);check.bind(('0.0.0.0',port));check.listen(1);status['portsAfter'].append({'port':port,'bindListenClose':True})
 except Exception as error:status['state']='SERVICE_OR_PORT_CLOSURE_FAILURE';status['closureFailure']=str(error)
 try:status['guardCounts']=guards()
 except Exception as error:status['state']='GUARD_FAILURE';status['guardFailure']=str(error)
 (output/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2),flush=True)
if status['state']!='PASS_ACTUAL_SOURCE96_REGRESSION':raise SystemExit(1)
