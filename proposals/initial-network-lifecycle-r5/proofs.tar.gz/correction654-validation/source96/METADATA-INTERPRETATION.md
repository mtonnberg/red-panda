# Operative metadata for candidate654 Source96

This separate note interprets inherited historical descriptions without changing the reviewed controller, plan, freeze spec, source fixture, assertions or original files.

Inherited source96-plan.require and freeze notes still describe the older source652/Root646/service858354 epoch. They are historical prose, not the operative source or service authority for this job. Operative reviewed guard descriptors are actual candidate654 and RootCurrent652 in network-initial-blocking-frame-r1/evidence/source-r1.json, with excluded servicePID870516/startTicks11030805. The driver binds those real maps and exact start identity; it must stop on drift.

The five listed script IDs are byte-pinned declarations in the unchanged original document/open_load_events.html fixture. A successful real nonzero assertOk with no pending async state establishes that fixture's actual harness acceptance. It does not establish five separately observed per-module counts, and no such counts are fabricated. Prior645/652 passes remain separate historical epochs; the present654 candidate regression is unrun until the separately granted single execution.
