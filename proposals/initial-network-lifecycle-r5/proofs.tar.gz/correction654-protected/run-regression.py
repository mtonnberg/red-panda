#!/usr/bin/env python3
"""Frozen one-invocation regression skeleton; explicit reviewed lease required."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,resource,signal,subprocess,sys,time
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for data in iter(lambda:f.read(1048576),b''):h.update(data)
 return h.hexdigest()
def require(value,message):
 if not value:raise RuntimeError(message)
def load(path):return json.loads(Path(path).read_text())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--scope',choices=['focused24','sdk24-19','sdk26-13'],required=True);p.add_argument('--epoch',required=True);p.add_argument('--execute-after-root-review',action='store_true');a=p.parse_args()
require(a.execute_after_root_review,'A separate Parent runtime lease/review is required')
require(__debug__ and sha(D/'manifest.json')==a.manifest_sha,'Frozen manifest/assertions mismatch')
manifest=load(D/'manifest.json')
for name,wanted in manifest['files'].items():require(sha(D/name)==wanted,'Capsule drift '+name)
spec=load(D/'freeze-spec.json');plan=spec['scopes'][a.scope];ROOT=Path(spec['root']);candidate=Path(spec['candidate']);SERVICE=spec['excludedService']['pid']
hs=importlib.util.spec_from_file_location('reviewed_network_protected_helpers',D/'ownership_helpers.py');helpers=importlib.util.module_from_spec(hs);hs.loader.exec_module(helpers);helpers.SERVICE=SERVICE
require(a.epoch and all(c.isalnum()or c in '-_'for c in a.epoch),'Invalid epoch')
out=D/'evidence'/(a.scope+'-'+a.epoch);out.mkdir(parents=True,exist_ok=False)
source=load(D/'reference/source-r1.json');external=load(D/'reference/external-inputs.json');golden=load(D/'reference/animation-golden-inputs-r1.json')
tables={'root':{str(ROOT/n):h for n,h in source['RootCurrent652'].items()},'candidate':{str(candidate/n):h for n,h in source['candidate654'].items()},'external':external,'golden':golden}
capsule={str(D/n):h for n,h in manifest['files'].items()};capsule[str(D/'manifest.json')]=a.manifest_sha
tables['capsule']=capsule
tables['supplementalContracts']=spec['supplementalContractFiles']
def guards():
 counts={name:helpers.verify(table)for name,table in tables.items()}
 for name,base in [('root',ROOT),('candidate',candidate)]:require(helpers.inventory(base,spec['inventoryScopes'])==set(tables[name]),'Full inventory drift '+name)
 require(counts['root']==652 and counts['candidate']==654,'Wrong source population')
 require(sha(plan['node'])==plan['nodeSHA256'],'Wrong genuine stock SDK')
 for name,wanted in spec['native18'].items():require(source['candidate654'][name]==wanted and sha(candidate/name)==wanted,'Native18 drift '+name)
 require(len(spec['native18'])==18,'Native18 population mismatch')
 require(sha(candidate/'native/runtime.cc')==spec['runtime95SHA256'],'Runtime95 mismatch')
 for path,wanted in spec['prerequisiteReceipts'].items():require(sha(path)==wanted,'Historical prerequisite drift '+path)
 current=helpers.proc(SERVICE,True);require(current and current['startTicks']==spec['excludedService']['startTicks'],'Excluded main service identity changed')
 return counts
def record_tap(stdout,stderr):
 text=stdout.read_text();errors=stderr.read_text();summary={}
 for key in ['tests','pass','fail','cancelled','skipped','todo']:
  found=re.findall(r'^# '+key+r' (\d+)\s*$',text,re.M);summary[key]=int(found[0])if len(found)==1 else None
 return {'summary':summary,'actualOKNames':re.findall(r'^ok \d+ - (.+)$',text,re.M),'actualNotOKNames':re.findall(r'^not ok \d+ - (.+)$',text,re.M),'lateActivity':any(s in text+errors for s in ['asynchronous activity after','triggered an unhandledRejection','generated asynchronous activity']),'stdoutSHA256':sha(stdout),'stderrSHA256':sha(stderr)}
status={'state':'SETUP','scope':a.scope,'oneNodeInvocationOnly':True,'NodeWorkloadAggregateSeconds':90,'TERMSeconds':2,'KILLSeconds':3,'outerSecondsProposed':120,'originalCaseAPIAndVMBudgetsChanged':False,'excludedService':spec['excludedService'],'expectedCaseCount':plan['expectedSourceDerivedCount'],'historicalCountsNotCurrentAcceptance':True,'rawExit':None}
child=None;owned={};workStart=None;start=time.monotonic()
def interrupted(number,frame):raise InterruptedError('Controller signal '+str(number))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 status['guardsBefore']=guards();status['mainBefore']=helpers.proc(SERVICE,True)
 for row in plan['files']:
  require(sha(candidate/row['path'])==row['SHA256'],'Selected file drift')
  if row['path']not in spec['newFiles']:require(tables['root'][str(ROOT/row['path'])]==row['SHA256'],'Original test source changed from Root652')
 command=[plan['node'],'--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap',*[r['path']for r in plan['files']]];status['command']=command
 env=os.environ.copy();require(not env.get('RESOURCE_RETIREMENT_ENGINE_MODULE'),'Unreviewed retirement engine override');require(env.get('NODE_OPTIONS','')=='','Unexpected inherited Node options');env['NODE_USE_ENV_PROXY']='1'
 for key in ['NO_PROXY','no_proxy']:env[key]=','.join(filter(None,[env.get(key,''),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']))
 env['RED_PANDA_RUNTIME_ADDON']=str(candidate/('native/build/linux-x64/node-'+plan['SDK']+'/runtime.node'));env.pop('RED_PANDA_COLLECTIONS_ADDON',None);env.pop('RED_PANDA_HEAP_ADDON',None)
 status['environmentPolicy']='Same protected-controller managed proxy bypass/runtime addon binding; inherited NODE_PATH/CA/TLS retained. No global SDK/toolchain changes.'
 with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  child=subprocess.Popen(command,cwd=candidate,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits)
  identity=helpers.proc(child.pid,True);require(identity and identity['pgrp']==child.pid==identity['sid']and identity['pid']!=SERVICE,'Owned session missing');owned[(child.pid,identity['startTicks'])]=identity;status['initialIdentity']=identity;workStart=time.monotonic();status['state']='RUNNING';save(out/'status.json',status);nextProgress=workStart+20
  while child.poll()is None:
   helpers.track(child,owned);now=time.monotonic()
   if now-workStart>=90:status['NodeWorkloadDeadlineHit']=True;break
   if now>=nextProgress:print(json.dumps({'scope':a.scope,'seconds':now-workStart,'owned':helpers.track(child,owned)}),flush=True);nextProgress+=20
   time.sleep(.025)
  status['ownedLiveAfterNormalExitBeforeCleanup']=[r for r in helpers.track(child,owned)if r['state']!='Z']if child.poll()is not None else None
  status['cleanup']=helpers.cleanup(child,owned);status['rawExit']=child.returncode
 status['actualTAP']=record_tap(out/'stdout',out/'stderr');summary=status['actualTAP']['summary'];actual=status['actualTAP']['actualOKNames'];expected=[name for row in plan['files']for name in row['sourceDerivedNames']]
 status['actualVsSourceCountDifference']=summary['tests']-len(expected)if summary['tests']is not None else None
 require(status['rawExit']==0 and not status.get('NodeWorkloadDeadlineHit')and not status['ownedLiveAfterNormalExitBeforeCleanup'],'Actual process/timeout/owned residual failure')
 require(summary['tests']==summary['pass']==len(expected)and all(summary[k]==0 for k in ['fail','cancelled','skipped','todo']),'Actual TAP nonpass/missing/extra/skip/cancel')
 require(sorted(actual)==sorted(expected)and not status['actualTAP']['actualNotOKNames']and not status['actualTAP']['lateActivity'],'Actual case names differ or late activity')
 status['state']='PASS_ONE_ACTUAL_WHOLE_FILE_SCOPE_NOT_FULL_SUITE'
except BaseException as error:status['state']='FAILED_OR_INCOMPLETE';status['error']={'type':type(error).__name__,'message':str(error)}
finally:
 if child:
  try:
   remaining=helpers.track(child,owned)
   if child.poll()is None or any(r['state']!='Z'for r in remaining):status['exceptionalCleanup']=helpers.cleanup(child,owned)
   status['finalOwnedLive']=[r for r in helpers.track(child,owned)if r['state']!='Z'];status['finalTerminatedZombies']=[r for r in helpers.track(child,owned)if r['state']=='Z'];status['rawExit']=child.returncode
   if status['finalOwnedLive']:status['state']='OWNED_CLEANUP_FAILURE'
  except BaseException as error:status['state']='OWNED_CLEANUP_FAILURE';status['cleanupError']=str(error)
 if(out/'stdout').exists():status['actualTAP']=record_tap(out/'stdout',out/'stderr')
 try:status['guardsAfter']=guards();status['mainAfter']=helpers.proc(SERVICE,True)
 except BaseException as error:status['state']='GUARD_FAILURE';status['guardError']=str(error)
 status['secondsIncludingCleanup']=time.monotonic()-start;save(out/'status.json',status);print(json.dumps({'state':status['state'],'scope':a.scope,'report':str(out/'status.json'),'rawExit':status['rawExit']}),flush=True)
raise SystemExit(0 if status['state']=='PASS_ONE_ACTUAL_WHOLE_FILE_SCOPE_NOT_FULL_SUITE'else 1)
