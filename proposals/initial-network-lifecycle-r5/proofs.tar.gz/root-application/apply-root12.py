"""Apply the reviewed initial-loading component with exact backups and rollback."""
from pathlib import Path
import hashlib, json, os, shutil, signal, tempfile, time

R = Path('/workspace/red-panda')
H = Path('/workspace/shared/network-private-initial-producer-r4/report-observation-r5/handoff-current652')
C = H.parent / 'behavior652'
O = Path(__file__).resolve().parent
B = O / 'backup-before'
MANIFEST = '6174dbde0618373e9a30c58404479e0cf7e1d27b40ef9c72139523c172e41744'
ALLOWED = {
    'src/classic-scripts.js', 'src/document-reset.js', 'src/frames.js',
    'src/initial-load-method-scope.js', 'src/initial-network-load.js',
    'src/managed-document-lifecycle.js', 'src/performance.js', 'src/window-task-capture.js',
    'test/fixtures/initial-network-timeout.mjs', 'test/fixtures/initial-report-error-probe.mjs',
    'test/initial-network-load.test.js', 'test/resource-retirement.test.js',
}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())

def graph(root):
    result = {}
    for name in ['src', 'test', 'native', 'bin', 'scripts']:
        for p in (root / name).rglob('*'):
            assert not p.is_symlink(), 'Unexpected source symlink: ' + str(p)
            if p.is_file():
                result[str(p.relative_to(root))] = sha(p)
    result.update({name: sha(root / name) for name in ['package.json', 'package-lock.json']})
    return result

def proc(pid):
    base = Path('/proc') / str(pid)
    try:
        raw = (base / 'stat').read_text()
        fields = raw[raw.rfind(')') + 2:].split()
        return {'pid': pid, 'startTicks': int(fields[19]), 'uid': base.stat().st_uid,
                'argv': (base / 'cmdline').read_bytes().rstrip(b'\0').decode().split('\0')}
    except FileNotFoundError:
        return None

def atomic(target, data, mode):
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.kernel-stage-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fchmod(stream.fileno(), mode)
            os.fsync(stream.fileno())
        os.replace(name, target)
        directory = os.open(target.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)

assert sha(H / 'manifest-r3.json') == MANIFEST
for name, digest in load(H / 'manifest-r3.json')['fileSHA256'].items():
    assert sha(H / name) == digest, name
accepted = load(H / 'final-acceptance-r3.json')
assert accepted['state'] == 'PASS_BOUNDED_CURRENT652_ALL_PLANNED_PREINTEGRATION_GATES'
assert accepted['RootApplyAndFullSuite'].startswith('UNRUN')
maps = load(H / 'contracts/source-maps.json')
before, after = maps['RootBefore646'], maps['Candidate652']
assert len(before) == 646 and len(after) == 652
assert graph(R) == before and graph(C) == after
rows = load(H / 'contracts/leaves.json')
assert set(rows) == ALLOWED and len(rows) == 12
assert {name for name in before.keys() | after.keys() if before.get(name) != after.get(name)} == ALLOWED
assert len([name for name in before if name.startswith('native/build/')]) == 18
assert all(after[name] == value for name, value in before.items() if name.startswith('native/'))
assert sha(H / 'contracts/integration.patch') == 'fab80846993d5ee79723fe3d30f52c67ed670e61b6a089cdaee920cd15a6e757'
for name, row in rows.items():
    target = R / name
    assert row == {'before': before.get(name), 'after': after[name]}
    assert sha(C / name) == row['after']
    assert (sha(target) if target.exists() else None) == row['before']
    for parent in [target, *target.parents]:
        if parent == R.parent:
            break
        assert not parent.is_symlink(), str(parent)
    if target.exists():
        assert target.stat().st_uid == os.geteuid() and target.stat().st_gid == os.getegid()
assert not B.exists() and not (O / 'journal.json').exists()
B.mkdir()
modes = {}
for name, row in rows.items():
    target = R / name
    modes[name] = (target.stat().st_mode & 0o777) if target.exists() else 0o600
    if target.exists():
        backup = B / name
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, backup)
        assert sha(backup) == row['before']

pid, start = 858354, 10711664
journal = {'state': 'PREPARED_GUARDED_NOT_APPLIED', 'reviewedManifestSHA256': MANIFEST,
           'acceptedReceiptSHA256': sha(H / 'final-acceptance-r3.json'), 'RootBefore646': before,
           'RootExpected652': after, 'rows': rows, 'modes': modes, 'committed': [],
           'oldServicePID': pid, 'oldServiceStartTicks': start,
           'procCwd': 'Not read; cwd authority is the existing owned launcher receipt.',
           'fullInstalledSuite': 'UNRUN', 'native18Unchanged': True}
def save():
    atomic(O / 'journal.json', (json.dumps(journal, indent=2) + '\n').encode(), 0o600)
save()
actual = proc(pid)
journal['oldServiceIdentityBeforeStop'] = actual
if actual:
    assert actual == {'pid': pid, 'startTicks': start, 'uid': os.geteuid(),
                      'argv': ['node', '--experimental-vm-modules', 'bin/red-panda.js', 'serve']}
    assert proc(pid) == actual, 'Owned service identity changed before signal'
    os.kill(pid, signal.SIGTERM)
    journal['oldServiceSignal'] = 'SIGTERM after exact PID/start/uid/argv recheck'
    end = time.monotonic() + 3
    while proc(pid) is not None and time.monotonic() < end:
        time.sleep(.02)
assert proc(pid) is None, 'Old owned service must exit before replacement'
journal['oldServiceAbsentBeforeReplacement'] = True
assert graph(R) == before
journal['state'] = 'APPLYING'
save()
try:
    for name, row in rows.items():
        assert proc(pid) is None
        target = R / name
        assert (sha(target) if target.exists() else None) == row['before']
        atomic(target, (C / name).read_bytes(), modes[name])
        journal['committed'].append(name)
        save()
    assert graph(R) == after
    journal['state'] = 'APPLIED_EXACT_INITIAL12_FULL_INSTALLED_VALIDATION_UNRUN'
    save()
except BaseException as error:
    journal.update(state='ROLLING_BACK', error=str(error))
    save()
    for name, row in reversed(list(rows.items())):
        target = R / name
        actual = sha(target) if target.exists() else None
        if actual == row['before']:
            continue
        assert actual == row['after'], 'Independent target change; refuse overwrite'
        if row['before'] is None:
            target.unlink()
        else:
            atomic(target, (B / name).read_bytes(), modes[name])
    assert graph(R) == before
    journal['state'] = 'ROLLED_BACK'
    save()
    raise
print(json.dumps({'state': journal['state'], 'targets': 12, 'RootAfter': len(after),
                  'nativeArtifactsUnchanged': 18, 'journal': str(O / 'journal.json')}))
