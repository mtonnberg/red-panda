#!/usr/bin/env python3
"""Reusable frozen-spec skeleton. No default candidate; no JS until explicit run."""
from pathlib import Path
import argparse,hashlib,json,os,re,resource,signal,subprocess,time

P=Path(__file__).parent;ROOT=Path('/workspace/red-panda');SERVICE=870516
NODE_SHA='e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb'
CPP95='95bba30f4013139999dc9b843b45bdb5ddc1802145431fc6386bddc85975cd36'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise RuntimeError(message)
def load(path):return json.loads(Path(path).read_text())
def readmap(descriptor):
 path=Path(descriptor['path']);require(sha(path)==descriptor['SHA256'],'Map descriptor drift: '+str(path));value=load(path)
 for part in descriptor.get('keyPath',[]):value=value[part]
 require(isinstance(value,dict)and value and all(isinstance(k,str)and isinstance(v,str)and re.fullmatch('[0-9a-f]{64}',v)for k,v in value.items()),'Expected explicit nonempty full-SHA map')
 base=Path(descriptor['base']);return {str(base/name):value for name,value in value.items()}
def verify(table):
 bad=[n for n,h in table.items()if not Path(n).is_file()or sha(n)!=h]
 require(not bad,'Frozen input mismatch: '+str(bad));return len(table)
def inventory(base,scopes):
 paths=set()
 for name in scopes:
  path=base/name;require(path.exists(),'Inventory scope missing '+str(path));require(not path.is_symlink(),'Inventory scope itself must be physical: '+str(path))
  if path.is_dir():
   for file in path.rglob('*'):
    require(not file.is_symlink(),'Unfrozen symlink inside guarded source scope: '+str(file))
    if file.is_file():paths.add(str(file))
  else:paths.add(str(path))
 return paths
def proc(pid,required=False):
 try:
  text=(Path('/proc')/str(pid)/'stat').read_text();f=text[text.rfind(')')+2:].split();return {'pid':int(pid),'state':f[0],'parent':int(f[1]),'pgrp':int(f[2]),'sid':int(f[3]),'startTicks':int(f[19])}
 except(FileNotFoundError,ProcessLookupError):return None
 except(OSError,ValueError,IndexError)as error:
  if required:raise RuntimeError('Cannot verify owned process identity: '+str(pid))from error
  return None
def track(child,owned):
 rows=[]
 for file in Path('/proc').iterdir():
  if file.name.isdecimal()and(row:=proc(file.name)):rows.append(row)
 changed=True
 while changed:
  changed=False;parents={pid for(pid,start),record in owned.items()if(current:=proc(pid,True))and current['startTicks']==start}
  for row in rows:
   if row['pgrp']==child.pid or row['sid']==child.pid or row['parent']in parents:
    require(row['pid']!=SERVICE,'Excluded production service entered job ownership; refuse signalling')
    key=(row['pid'],row['startTicks'])
    if key not in owned:owned[key]=row;changed=True
 live=[]
 for(pid,start),record in owned.items():
  now=proc(pid,True)
  if now and now['startTicks']==start:live.append(now)
 return live
def cleanup(child,owned):
 before=track(child,owned)
 for sig,seconds in [(signal.SIGTERM,2),(signal.SIGKILL,3)]:
  for row in track(child,owned):
   require(row['pid']!=SERVICE,'Never signal excluded main service')
   if row['state']!='Z':
    now=proc(row['pid'],True)
    if now and now['startTicks']==row['startTicks']:
     try:os.kill(row['pid'],sig)
     except ProcessLookupError:pass
  end=time.monotonic()+seconds
  while time.monotonic()<end and any(r['state']!='Z'for r in track(child,owned)):time.sleep(.02)
  if not any(r['state']!='Z'for r in track(child,owned)):break
 child.wait(timeout=3);after=track(child,owned);return {'before':before,'observed':list(owned.values()),'after':after,'liveRemaining':[r for r in after if r['state']!='Z']}

D=Path(__file__).parent.parent;H=Path('/workspace/shared/network-private-initial-producer-r4/report-observation-r5/handoff-current652');source=load(D/'evidence/source-r1.json');sourceSHA=sha(D/'evidence/source-r1.json');require(sourceSHA=='8a571f0b408facbc46a620167cce52d4d68cc01feae0e4329299c695071fe8ba','Reviewed source map differs');externalDescriptor=load(H/'freeze-first.json')['guardMaps']['external'];external=readmap(externalDescriptor);node=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');golden=load(D/'evidence/animation-golden-inputs-r1.json');require(sha(D/'evidence/animation-golden-inputs-r1.json')=='7a575a8d88604ee7b7abae0465b7e0f19441c028c3852c8fd4bfd44d0db55040','Original golden map drift');selfSHA=sha(__file__);scopes=['src','test','native','bin','scripts','package.json','package-lock.json'];service=proc(SERVICE,True);require(service and service['startTicks']==11030805,'Current excluded main identity changed')
def guards():
 require(sha(__file__)==selfSHA and sha(D/'evidence/source-r1.json')==sourceSHA,'Controller/source manifest drift');require(sha(D/'evidence/probe-blocking-frame.mjs')=='df1e3934e70c87731436c527ff78dfa20e0891e54a95f95c9460cc4a96910d4e','Probe drift');require(sha(H/'freeze-first.json')=='96fafaae10e698fdf2696025de8d028387679caa1f74022260e8cc7a41420425','Original external spec drift');counts={'external':verify(external)};readmap(externalDescriptor)
 for label,key in [('root','RootCurrent652'),('baseline646','baseline646'),('installed652','installed652'),('candidate','candidate654')]:
  base=ROOT if label=='root'else D/label;table={str(base/n):v for n,v in source[key].items()};counts[label]=verify(table);require(inventory(base,scopes)==set(table),'Full source inventory differs '+label)
 require(sha(node)==NODE_SHA and sha(ROOT/'native/runtime.cc')==CPP95,'Stock24/source95 changed');counts['golden']=verify(golden);return counts

out=D/'run-candidate-gate-r1';require(not out.exists(),'Fresh output required');guards();out.mkdir();start=time.monotonic();status={'state':'RUNNING','sourceSHA256':sourceSHA,'commands':[],'aggregateSeconds':90,'originalBrowser1000Load2000NewCase8000AnimationCase10000':True,'RootCurrent652Unchanged':True,'noNativeOrBaselineRepeat':True,'mainBefore':service};child=None;owned={}
def run(label,args,kind=None,expectedTitle=None,expectedPass=None):
 global child,owned
 guards();owned={};row={'label':label,'command':[str(node),*args],'assertionKind':kind,'selectedOriginalTitle':expectedTitle};status['commands'].append(row);env=os.environ.copy();require(env.get('NODE_OPTIONS','')=='','Unexpected Node options');env['NODE_USE_ENV_PROXY']='1'
 for key in ['NO_PROXY','no_proxy']:env[key]=','.join(filter(None,[env.get(key,''),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']))
 env['RED_PANDA_RUNTIME_ADDON']=str(D/'candidate/native/build/linux-x64/node-24.22.1/runtime.node');env.pop('RED_PANDA_COLLECTIONS_ADDON',None);env.pop('RED_PANDA_HEAP_ADDON',None)
 with(out/(label+'.stdout')).open('xb')as stdout,(out/(label+'.stderr')).open('xb')as stderr:
  def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
  child=subprocess.Popen(row['command'],cwd=D/'candidate',env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);identity=proc(child.pid,True);require(identity and identity['pgrp']==child.pid and identity['sid']==child.pid,'Actual owned group missing');owned[(child.pid,identity['startTicks'])]=identity;row['identity']=identity;commandStart=time.monotonic();row['perCommandAdminSeconds']=7 if kind!='tap'else None;lastProgress=commandStart
  while child.poll()is None:
   track(child,owned);now=time.monotonic()
   if now-start>=90 or row['perCommandAdminSeconds']is not None and now-commandStart>=row['perCommandAdminSeconds']:row['deadlineHit']=True;break
   if now-lastProgress>=20:print(json.dumps({'label':label,'elapsed':now-start,'owned':track(child,owned)}),flush=True);lastProgress=now
   time.sleep(.025)
  row['ownedLiveAfterExitBeforeCleanup']=[r for r in track(child,owned)if r['state']!='Z']if child.poll()is not None else None;row['cleanup']=cleanup(child,owned);row['exit']=child.returncode;require(row['exit']==0 and not row.get('deadlineHit')and not row['cleanup']['liveRemaining']and not row['ownedLiveAfterExitBeforeCleanup'],'Actual nonzero/timeout/cleanup; preserve raw and stop')
 text=(out/(label+'.stdout')).read_text()
 if kind=='causal':
  lines=[s[len('actual-blocking-result '):]for s in text.splitlines()if s.startswith('actual-blocking-result ')];require(len(lines)==1,'Actual causal result missing');r=json.loads(lines[0]);row['actual']=r;before=r['beforeRelease'];after=r['afterRelease'];require(before['documentState']=='loading'and before['scriptValue']is None and before['tail']is None,'Held parser precondition differs');require(before['initial']['framePromise']['outcome']=='pending'and before['initial']['pendingParserClose']['stage']=='awaiting-parser','Actual native Promise/parser lease not waiting');require(r['loaded']and r['loadFailure']is None and after['scriptValue']==42 and after['tail']=='real parser tail'and after['documentState']=='complete'and not r['pageErrors']and not r['frameErrors']and r['parentQuery']==42 and r['actualOwnedClose'],'Actual candidate completion differs');initial=after['initial'];require(initial['completed']and initial['framePromise']['outcome']=='resolved'and initial['pendingParserClose']['stage']=='consumed'and not initial['activeParserClose']and initial['activeMethods']==0 and not initial['diagnostics'],'Actual private scope/Promise/EOF custody failed');require(sum(v['kind']=='realEOFSlot'for v in initial['observations'])==2 and sum(v['kind']=='actualDeferredParserCloseEntered'for v in initial['observations'])==1,'Actual canonical source slot accounting differs')
 elif kind=='tap':
  summary={}
  for key in ['tests','pass','fail','cancelled','skipped','todo']:
   m=re.search(r'^# '+key+r' (\d+)\s*$',text,re.M);require(m is not None,'Actual TAP summary missing '+key);summary[key]=int(m.group(1))
  row['actualTAP']=summary;row['actualCaseNames']=re.findall(r'^ok \d+ - (.+)$',text,re.M);row['lateUncaughtActivity']=any(v in text for v in ['asynchronous activity after','triggered an unhandledRejection','generated asynchronous activity']);require(summary['pass']==expectedPass and all(summary[k]==0 for k in ['fail','cancelled','todo'])and not row['lateUncaughtActivity'],'Actual TAP assertions/count/late error failed')
  if expectedTitle:require(expectedTitle in row['actualCaseNames'],'Selected original title not actually passed');row['declaredExclusion']='Explicit --test-name-pattern selects only this original case; all other original cases remain outside this gate. Actual skip count retained.'
  else:require(summary['tests']==2 and summary['skipped']==0,'New2 whole-file selection differs')
 row['guards']=guards();child=None
try:
 for n in ['src/classic-scripts.js','src/initial-network-load.js','test/initial-network-blocking-frame.test.js']:run('syntax-'+Path(n).name,['--check',str(D/'candidate'/n)])
 run('candidate-normal',['--experimental-vm-modules',str(D/'evidence/probe-blocking-frame.mjs'),str(D/'candidate')],'causal')
 run('new2',['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','test/initial-network-blocking-frame.test.js'],'tap',expectedPass=2)
 for label,title,file in [('original-producer','actual Native animation producer checkpoints, deeper chains, state mutations and real frame retirement match','test/animation-checkpoint-composition.test.js'),('original-detail','actual Native animation detail observations match','test/animations.test.js')]:run(label,['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','--test-name-pattern','^'+re.escape(title)+'$',file],'tap',expectedTitle=title,expectedPass=1)
 status['state']='PASS_CANDIDATE_CAUSAL_NEW2_AND_ORIGINAL2_SELECTED'
except Exception as error:status['state']='FAILED_OR_INCOMPLETE';status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 if child:
  try:status['exceptionalCleanup']=cleanup(child,owned)
  except Exception as error:status['state']='OWNED_CLEANUP_FAILURE';status['cleanupFailure']=str(error)
 status['secondsIncludingCleanup']=time.monotonic()-start;status['mainAfter']=proc(SERVICE)
 try:status['guardCounts']=guards()
 except Exception as error:status['state']='GUARD_FAILURE';status['guardFailure']=str(error)
 (out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2),flush=True)
if status['state']!='PASS_CANDIDATE_CAUSAL_NEW2_AND_ORIGINAL2_SELECTED':raise SystemExit(1)
