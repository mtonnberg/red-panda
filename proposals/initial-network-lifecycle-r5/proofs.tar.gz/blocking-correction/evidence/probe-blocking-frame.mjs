import{runBlockingFrameProbe}from'../candidate/test/fixtures/blocking-frame-probe.mjs';
try{const report=await runBlockingFrameProbe(process.argv[2],process.argv[3]??'normal');console.log('actual-blocking-result '+JSON.stringify(report))}catch(error){console.error(error);process.exitCode=1}
