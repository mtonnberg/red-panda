// Original measured programs, unchanged. One real fixture origin is shared by
// both engines so full public payloads compare without origin normalization.
import http from'node:http';import{once}from'node:events';import{readFileSync,writeFileSync}from'node:fs';import assert from'node:assert/strict';
import{profiles,preloadFor,scriptFor,executeProfile}from'../../network-window-bootstrap-r1/evidence/network-controls.mjs';
import{programs,childWindowRewrite,earlyProbeSource}from'../../initial-window-generation-2342-r1/evidence/initial-programs.mjs';
import{startReference}from'../../registration455-adapted-plan-20261031/harness/scripts/reference-server.mjs';import{connect}from'../../registration455-adapted-plan-20261031/harness/test/cdp-client.js';
const output=process.argv[2];if(!output)throw Error('Explicit new report path required');
const report={rows:[],wire:[],requests:[],API2500Milliseconds:true,script1000Milliseconds:true,load2000Milliseconds:true,unchangedMeasuredPrograms:true,sharedOriginNoNormalization:true,Source96Unrun:true};
const identity=pid=>{const text=readFileSync('/proc/'+pid+'/stat','utf8'),parts=text.slice(text.lastIndexOf(')')+2).trim().split(/\s+/);return{pid,startTicks:parts[19],processGroup:Number(parts[2])}};
const save=()=>writeFileSync(output+'.incremental',JSON.stringify(report,null,2)+'\n');let server,browser,client;const timers=new Set();
try{
 server=http.createServer((request,response)=>{
  const entry={url:request.url,started:Date.now()};report.requests.push(entry);
  let source='<!doctype html><title>Owned causal document</title><body>independent control</body>',type='text/html; charset=utf-8',delay=0;
  if(request.url==='/held-defer.js'){type='text/javascript';source='globalThis.__actualDeferred=true';delay=25}
  else if(request.url==='/windowRewrite'){source='<script>('+childWindowRewrite.toString()+')()</scr'+'ipt><p>network initial window</p>';delay=25}
  else if(profiles.includes(request.url.slice(1))){const profile=request.url.slice(1);source='<!doctype html><body><p id="actualBody">real network body</p><script>'+scriptFor(profile)+'</scr'+'ipt>'+(profile==='documentSyntheticPending'?'<script defer src="/held-defer.js"></scr'+'ipt>':'')}
  const send=()=>{response.writeHead(200,{'Content-Type':type});response.end(source);entry.responded=Date.now();entry.bytes=Buffer.byteLength(source)};
  if(delay){const timer=setTimeout(()=>{timers.delete(timer);send()},delay);timers.add(timer)}else send();
 });server.listen(0,'127.0.0.1');await once(server,'listening');report.fixture={...identity(process.pid),port:server.address().port};report.origin='http://127.0.0.1:'+server.address().port;save();
 for(const engine of['Native','candidateRoot646R3'])for(const name of[...profiles,'initialWindowLoadRewrite']){
  const row={engine,name};report.rows.push(row);let contextId,session;
  try{
   const binary=engine==='Native'?'/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux':'/workspace/shared/network-private-initial-producer-r4/projection-root646-r3/red-panda-launcher';
   browser=await startReference(binary,{args:['--ws-max-concurrent','50','--load-resources','iframe','--load-resources','worker']});row.identityBeforeClose=identity(browser.process.pid);row.webSocketPort=Number(new URL(browser.endpoint).port);console.log(JSON.stringify({started:engine+'/'+name,...row.identityBeforeClose,port:row.webSocketPort}));save();client=await connect(browser.endpoint,{timeout:2500});
   const send=async(method,params={},sid=session)=>{const entry={engine,name,method,params,sessionId:sid};report.wire.push(entry);try{const value=await client.send(method,params,sid,{timeout:2500});entry.result=value;return value}catch(error){entry.error={message:error.message,code:error.code};throw error}};
   contextId=(await send('Target.createBrowserContext')).browserContextId;const target=await send('Target.createTarget',{url:'about:blank',browserContextId:contextId});session=(await send('Target.attachToTarget',{targetId:target.targetId,flatten:true})).sessionId;
   await send('Page.enable');await send('Runtime.enable');await send('Page.setLifecycleEventsEnabled',{enabled:true});const preload=name==='initialWindowLoadRewrite'?earlyProbeSource:preloadFor(name);if(preload)await send('Page.addScriptToEvaluateOnNewDocument',{source:preload});
   const offset=client.events.length,start=Date.now(),url=report.origin+'/parent/'+name,navigation=await send('Page.navigate',{url});
   while(Date.now()-start<2000){const event=client.events.slice(offset).find(value=>value.sessionId===session&&value.method==='Page.lifecycleEvent'&&value.params.name==='load'&&value.params.frameId===navigation.frameId);if(event){const result=await send('Runtime.evaluate',{expression:'JSON.stringify({ready:document.readyState,url:document.URL,UA:navigator.userAgent})',returnByValue:true,timeout:1000});if(result.exceptionDetails)throw Error('Actual parent barrier exception');const value=JSON.parse(result.result.value);if(value.ready==='complete'&&value.url===url&&Date.now()-start<2000){row.parentBarrier={event:event.params,value,milliseconds:Date.now()-start};break}}await new Promise(resolve=>setTimeout(resolve,5))}
   if(!row.parentBarrier)throw Error('Original2000ms real parent complete/load barrier');
   const expression=name==='initialWindowLoadRewrite'?'('+programs.initialWindowLoadRewrite.toString()+')('+JSON.stringify(report.origin)+')':'('+executeProfile.toString()+')('+JSON.stringify(report.origin)+','+JSON.stringify(name)+')';
   const result=await send('Runtime.evaluate',{expression:expression+'.then(value=>JSON.stringify(value))',awaitPromise:true,returnByValue:true,timeout:1000});if(result.exceptionDetails){row.exceptionDetails=result.exceptionDetails;throw Error('Actual program exception: '+engine+'/'+name)}row.value=JSON.parse(result.result.value);row.events=client.events.slice(offset);save();
   if(engine==='candidateRoot646R3'){const native=report.rows.find(value=>value.engine==='Native'&&value.name===name);assert.deepEqual(row.value,native.value,'Full unchanged Native program payload mismatch: '+name);row.exactNativeMatch=true}
   console.log(JSON.stringify({observed:engine+'/'+name,exactNativeMatch:row.exactNativeMatch??null}));
  }finally{
   if(contextId&&client)try{await client.send('Target.disposeBrowserContext',{browserContextId:contextId},undefined,{timeout:2500})}catch(error){row.cleanupError={message:error.message,code:error.code}}
   await client?.close();client=null;if(browser){if(browser.process.exitCode===null&&browser.process.signalCode===null)assert.deepEqual(identity(browser.process.pid),row.identityBeforeClose,'PID/start/group changed before normal close');await browser.close();row.exit=browser.process.exitCode;row.signal=browser.process.signalCode;row.stderr=browser.stderr;browser=null}save();
  }
  if(row.cleanupError||row.exit!==0||row.signal!==null)throw Error('Actual owned browser cleanup failed: '+engine+'/'+name);
 }
}catch(error){report.failure={name:error.name,message:error.message,stack:error.stack};process.exitCode=1}finally{
 await client?.close();if(browser){const row=report.rows.at(-1);if(browser.process.exitCode===null&&browser.process.signalCode===null)assert.deepEqual(identity(browser.process.pid),row.identityBeforeClose);await browser.close()}
 for(const timer of timers)clearTimeout(timer);if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
}
