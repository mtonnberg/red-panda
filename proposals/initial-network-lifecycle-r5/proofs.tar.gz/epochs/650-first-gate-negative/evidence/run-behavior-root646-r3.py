"""UNRUN: explicit650 projection on current audio646, no Root application.
Ten JS syntax checks, fresh Native4+network1/candidate same-origin exact pair,
then seven singly selected functional/creation/recovery cases, stop first.
"""
from pathlib import Path
import hashlib,json,os,re,signal,socket,subprocess,time,traceback
R=Path(__file__).resolve().parent.parent;O=R/'run-behavior-root646-r3';assert not O.exists();O.mkdir()
P=Path('/workspace/red-panda');N='/workspace/shared/rea-tools/node_modules/.bin/node';C=R/'projection-root646-r3';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def graph(root):
 files={str(p.relative_to(root)):sha(p)for d in ['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()};files.update({n:sha(root/n)for n in ['package.json','package-lock.json']});return dict(sorted(files.items()))
def identity(pid):
 text=Path('/proc/'+str(pid)+'/stat').read_text();parts=text[text.rfind(')')+2:].split();return{'pid':pid,'startTicks':parts[19],'processGroup':int(parts[2])}
def write(name,value):
 with(O/name).open('x')as file:json.dump(value,file,indent=2);file.write('\n')
source=json.loads((R/'evidence/behavior-root646-r3-source.json').read_text());external=json.loads((R/'evidence/external-root646-r3.json').read_text());plan=json.loads((R/'evidence/behavior-root646-r3-plan.json').read_text());before={'actualRoot646':graph(P),'ownedBaselineRoot646':graph(R/'baseline-root646'),'projectedCandidate650':graph(C),'olderBehavior649':graph(R/'behavior-candidate-r2'),'frozenInitialR4Draft645':graph(R/'candidate'),'frozenInitialRoot645':graph(R/'baseline645')};contracts={str(p):sha(p)for p in [Path(__file__),R/'evidence/behavior-root646-r3-plan.json',R/'evidence/behavior-root646-r3-source.json',R/'evidence/external-root646-r3.json',R/'evidence/common-producer-root646-r3.patch',R/'evidence/run-behavior-pair-root646-r3.mjs',C/'red-panda-launcher',*map(Path,plan['externalContracts'])]};write('before.json',{**before,'contracts':contracts})
env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';env['PATH']=str(Path(N).parent)+':'+env.get('PATH','');proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy
commands=[];current=None;expected=None;failure=None;identities=[];ports=[];pair={}
def stop():
 if current is not None and current.poll()is None:
  assert identity(current.pid)==expected and expected['processGroup']==current.pid,'Refuse signal after actual owned identity change';write('identity-before-signal-'+str(current.pid)+'.json',expected);os.killpg(current.pid,signal.SIGKILL);current.wait()
def run(label,args,passed=None):
 global current,expected
 begin=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  current=subprocess.Popen([N,*args],cwd=C,env=env,stdout=out,stderr=err,start_new_session=True);expected=identity(current.pid);identities.append(expected);write(label+'-identity.json',expected);print(json.dumps({'started':label,**expected}),flush=True);expired=False
  try:code=current.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;stop();code=current.returncode
 row={'label':label,'identity':expected,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin};text=(O/(label+'.stdout')).read_text()
 for match in re.finditer(r'actual-initial-child-start (\{[^\n]+\})',text):identities.append(json.loads(match.group(1)))
 for match in re.finditer(r'actual-initial-fixture (\{[^\n]+\})',text):ports.append(json.loads(match.group(1))['port'])
 # Recovery child output retains its actual listening-port record inside the
 # final actual report, so it can be checked without a /proc descendant guess.
 for match in re.finditer(r'actual-initial-recovery (\{[^\n]+\})',text):
  result=json.loads(match.group(1))
  if result.get('fixture'):ports.append(result['fixture']['port'])
 if passed is not None:row['actualTAPSummary']={name:int(m.group(1))for name in ['pass','fail','cancelled','skipped']if(m:=re.search(r'^# '+name+r' (\d+)\s*$',text,re.M))}
 commands.append(row);current=None;expected=None;write(label+'-result.json',row);print(json.dumps(row),flush=True)
 if code or expired:raise RuntimeError('Actual common producer command failed: '+label)
 if passed is not None:assert row['actualTAPSummary']=={'pass':passed,'fail':0,'cancelled':0,'skipped':0},row
try:
 assert before['actualRoot646']==external['actualRoot646']and before['ownedBaselineRoot646']==source['OwnedBaselineRoot646'],'CurrentRoot646 protection changed: fresh derivative required'
 assert before['projectedCandidate650']==source['ProjectedCandidate650']and before['olderBehavior649']==source['OlderBehavior649']
 assert before['frozenInitialR4Draft645']==plan['frozenInitialR4Draft645']and before['frozenInitialRoot645']==plan['frozenInitialRoot645']
 assert all(sha(P/n)==v for n,v in external['Root18Artifacts'].items())and sha(P/'native/runtime.cc')==external['nativeRuntimeSource95']
 assert all(sha(Path(n))==v for n,v in plan['externalContracts'].items())
 for name in plan['syntaxFiles']:run('syntax-'+Path(name).name,['--check',name])
 run('original-Native5-candidate5-pair',[str(R/'evidence/run-behavior-pair-root646-r3.mjs'),str(O/'paired.json')]);pair=json.loads((O/'paired.json').read_text());assert not pair.get('failure')and len(pair['rows'])==10
 for row in pair['rows']:assert row.get('parentBarrier')and row.get('value')and not row.get('cleanupError')and row.get('exit')==0 and row.get('signal')is None,row
 assert all(row.get('exactNativeMatch')for row in pair['rows']if row['engine']=='candidateRoot646R3')
 for index,title in enumerate(plan['selectedCaseTitles'],1):run('functional-'+str(index),['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','--test-name-pattern','^'+re.escape(title)+'$','test/initial-network-load.test.js'],1)
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 try:stop()
 except BaseException as error:failure={'name':'OwnedCleanupFailure','message':str(error),'previous':failure}
 if not pair:
  for name in ['paired.json','paired.json.incremental']:
   if(O/name).exists():pair=json.loads((O/name).read_text());break
 for row in pair.get('rows',[]):
  if row.get('identityBeforeClose'):identities.append(row['identityBeforeClose'])
  if row.get('webSocketPort'):ports.append(row['webSocketPort'])
 if pair.get('fixture'):ports.append(pair['fixture']['port'])
 closure=[{**value,'procPresent':Path('/proc',str(value['pid'])).exists()}for value in identities];portClosure=[]
 for port in ports:
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.25):portClosure.append({'port':port,'closed':False})
  except ConnectionRefusedError:portClosure.append({'port':port,'closed':True})
  except Exception as error:portClosure.append({'port':port,'closed':None,'inspectionError':str(error)})
 guards={'Root646Unchanged':graph(P)==before['actualRoot646'],'Root18ArtifactsUnchanged':all(sha(P/n)==v for n,v in external['Root18Artifacts'].items()),'Root95RuntimeSourceUnchanged':sha(P/'native/runtime.cc')==external['nativeRuntimeSource95'],'ownedBaseline646Unchanged':graph(R/'baseline-root646')==before['ownedBaselineRoot646'],'projection650Unchanged':graph(C)==before['projectedCandidate650'],'olderBehavior649Unchanged':graph(R/'behavior-candidate-r2')==before['olderBehavior649'],'oldDraft645Unchanged':graph(R/'candidate')==before['frozenInitialR4Draft645'],'oldBaseline645Unchanged':graph(R/'baseline645')==before['frozenInitialRoot645'],'contractsUnchanged':all(sha(Path(n))==v for n,v in contracts.items())};write('after-guards.json',guards);write('closure.json',{'reportedIdentities':closure,'reportedFixtureAndWebSocketPorts':portClosure,'noRecursiveDescendantInventoryClaim':True})
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 if any(row['procPresent']for row in closure)or any(row['closed']is not True for row in portClosure):failure={'name':'OwnedClosureUnconfirmed','previous':failure}
 write('status.json',{'complete':failure is None,'failure':failure,'commands':commands,'seconds':time.monotonic()-started,'expectedSyntaxChecks':10,'expectedOriginalNative5ThenCandidate5':True,'expectedNewExecutedTests':7,'stopFirst':True,'originalRPC2500Script1000Load2000VM200Child7000Case8000Administrative90000':True,'explicitCurrent646Owned650Projection':True,'historical645ProofNotRetargeted':True,'oldR1R2R3PacketsUnchanged':True,'NativeMIME4NotRepeated':True,'frameClassAndMalformedParserDOMParityNotClaimed':True,'Source96NotRun':True,'noRootApply':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
