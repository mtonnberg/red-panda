"""UNRUN. Two changed-source syntax checks; same untouched646 expected-failure
causal, corrected647 and651 causals; original7 unchanged cases. No other work."""
from pathlib import Path
import hashlib,json,os,re,signal,socket,subprocess,time,traceback
D=Path(__file__).resolve().parent.parent;R=D.parent;O=D/'run-causal-original7-r4-r2';assert not O.exists();O.mkdir();P=Path('/workspace/red-panda');N='/workspace/shared/rea-tools/node_modules/.bin/node';C=D/'behavior651';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def graph(root):
 files={str(p.relative_to(root)):sha(p)for x in ['src','test','native','scripts','bin']for p in(root/x).rglob('*')if p.is_file()and not p.is_symlink()};files.update({n:sha(root/n)for n in ['package.json','package-lock.json']});return dict(sorted(files.items()))
def identity(pid):
 text=Path('/proc/'+str(pid)+'/stat').read_text();parts=text[text.rfind(')')+2:].split();return{'pid':pid,'startTicks':parts[19],'processGroup':int(parts[2])}
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
source=json.loads((D/'evidence/source-r4.json').read_text());plan=json.loads((D/'evidence/plan-r4.json').read_text());external=json.loads((R/'evidence/external-root646-r3.json').read_text());roots={'Root646':P,'ownedBaseline646':R/'baseline-root646','frozen650':R/'projection-root646-r3','delivery647':D/'delivery-only647','behavior651':C};before={name:graph(path)for name,path in roots.items()};contracts={str(path):sha(path)for path in [Path(__file__),D/'evidence/source-r4.json',D/'evidence/plan-r4.json',D/'resource-retirement-control.mjs',D/'evidence/delivery-generation-only.patch',D/'evidence/behavior-root646-r4.patch',R/'evidence/external-root646-r3.json',*map(Path,plan['externalContracts'])]};write('before.json',{'graphs':before,'contracts':contracts})
env=os.environ.copy();env.pop('RESOURCE_RETIREMENT_ENGINE_MODULE',None);env['NODE_USE_ENV_PROXY']='1';env['PATH']=str(Path(N).parent)+':'+env.get('PATH','');proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy
commands=[];current=None;expected=None;failure=None;identities=[];ports=[]
def stop():
 if current is not None and current.poll()is None:
  assert identity(current.pid)==expected and expected['processGroup']==current.pid,'Refuse signal after owned identity change';write('before-owned-signal-'+str(current.pid)+'.json',expected);os.killpg(current.pid,signal.SIGKILL);current.wait()
def run(label,args,cwd=C,expectedExit=0,expectedPass=None,engine=None):
 global current,expected
 began=time.monotonic();configured=env.copy()
 if engine:configured['RESOURCE_RETIREMENT_ENGINE_MODULE']=str(engine/'src/browser.js')
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  current=subprocess.Popen([N,*args],cwd=cwd,env=configured,stdout=out,stderr=err,start_new_session=True);expected=identity(current.pid);identities.append(expected);write(label+'-identity.json',expected);print(json.dumps({'started':label,**expected}),flush=True);expired=False
  try:code=current.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;stop();code=current.returncode
 text=(O/(label+'.stdout')).read_text();stderr=(O/(label+'.stderr')).read_text()
 for pattern in [r'actual-retirement-fixture (\{[^\n]+\})',r'actual-initial-fixture (\{[^\n]+\})']:
  for match in re.finditer(pattern,text):ports.append(json.loads(match.group(1))['port'])
 for match in re.finditer(r'actual-initial-child-start (\{[^\n]+\})',text):identities.append(json.loads(match.group(1)))
 for match in re.finditer(r'actual-initial-recovery (\{[^\n]+\})',text):
  value=json.loads(match.group(1))
  if value.get('fixture'):ports.append(value['fixture']['port'])
 numbers={name:int(match.group(1))for name in ['pass','fail','cancelled','skipped']if(match:=re.search(r'^# '+name+r' (\d+)\s*$',text,re.M))}
 row={'label':label,'identity':expected,'command':[N,*args],'cwd':str(cwd),'engineOverride':str(engine)if engine else None,'exit':code,'expectedExit':expectedExit,'administrativeExpiry':expired,'seconds':time.monotonic()-began,'actualTAPSummary':numbers};commands.append(row);current=None;expected=None;write(label+'-result.json',row);print(json.dumps(row),flush=True)
 if code!=expectedExit or expired:raise RuntimeError('Actual causal/original7 command failed: '+label)
 if expectedExit==1:
  assert numbers=={'pass':0,'fail':1,'cancelled':0,'skipped':0},row
  assert re.search(r'''failureType: ['"]unhandledRejection['"]\s*\n\s*error: [^\n]*_virtualConsole''',text) and 'onErrorWrapped'in text and 'per-document-resource-loader.js'in text,'Expected actual untouched-root TAP cause not observed'
 elif expectedPass is not None:assert numbers=={'pass':expectedPass,'fail':0,'cancelled':0,'skipped':0},row
try:
 assert before['Root646']==source['RootBefore646']==external['actualRoot646']and before['ownedBaseline646']==source['OwnedBaselineRoot646']
 assert before['frozen650']==source['FrozenNegative650']and before['delivery647']==source['DeliveryOnly647']and before['behavior651']==source['ProjectedCandidate651']
 assert all(sha(P/n)==v for n,v in external['Root18Artifacts'].items())and sha(P/'native/runtime.cc')==external['nativeRuntimeSource95']
 assert all(sha(Path(n))==v for n,v in plan['externalContracts'].items())
 assert sha(C/'test/initial-network-load.test.js')==source['original7TestFileSHA256']and sha(C/'test/fixtures/initial-network-timeout.mjs')==source['original7TimeoutFixtureSHA256']
 run('syntax-classic',['--check','src/classic-scripts.js']);run('syntax-new-causal',['--check','test/resource-retirement.test.js'])
 run('untouched646-expected-negative',['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap',str(D/'resource-retirement-control.mjs')],cwd=D,expectedExit=1,engine=R/'baseline-root646')
 run('delivery647-causal-positive',['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','test/resource-retirement.test.js'],cwd=D/'delivery-only647',expectedPass=1)
 run('behavior651-causal-positive',['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','test/resource-retirement.test.js'],expectedPass=1)
 for index,title in enumerate(plan['original7CaseTitles'],1):run('original-'+str(index),['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','--test-name-pattern','^'+re.escape(title)+'$','test/initial-network-load.test.js'],expectedPass=1)
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 try:stop()
 except BaseException as error:failure={'name':'OwnedCleanupFailure','message':str(error),'previous':failure}
 closure=[{**value,'procPresent':Path('/proc',str(value['pid'])).exists()}for value in identities];portClosure=[]
 for port in ports:
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.25):portClosure.append({'port':port,'closed':False})
  except ConnectionRefusedError:portClosure.append({'port':port,'closed':True})
  except Exception as error:portClosure.append({'port':port,'closed':None,'inspectionError':str(error)})
 guards={name+'Unchanged':graph(path)==before[name]for name,path in roots.items()};guards.update({'Root18Unchanged':all(sha(P/n)==v for n,v in external['Root18Artifacts'].items()),'Root95Unchanged':sha(P/'native/runtime.cc')==external['nativeRuntimeSource95'],'contractsUnchanged':all(sha(Path(n))==v for n,v in contracts.items())});write('after-guards.json',guards);write('closure.json',{'reportedIdentities':closure,'reportedPorts':portClosure,'noWebSocketsUsed':True,'noRecursiveInventoryClaim':True,'RootServiceExcluded':True})
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 if any(row['procPresent']for row in closure)or any(row['closed']is not True for row in portClosure):failure={'name':'OwnedClosureUnconfirmed','previous':failure}
 write('status.json',{'complete':failure is None,'failure':failure,'commands':commands,'seconds':time.monotonic()-started,'expectedChangedSyntax2':True,'expectedActualUntouched646Negative1':True,'expectedPositiveCausals2':True,'original7SameAssertionsAndBudgets':True,'noNativePairRepeat':True,'Source96AlreadyBaselinePassNewRegressionUnrun':True,'noSource96ProtectedSDKBuildRootApply':True,'globalActivePredicateUnchanged':True,'noProductObserver':True,'originalScript1000Load2000VM200Child7000Case8000Admin90000':True,'stopFirstUnexpectedOutcome':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
