// Exact authored reportError probe on a quiet, untouched646 child Window.
import{writeFileSync}from'node:fs';
import{Browser}from'../../baseline-root646/src/browser.js';
import{initialReportErrorProbe}from'../behavior652/test/fixtures/initial-report-error-probe.mjs';
const output=process.argv[2];if(!output)throw Error('Explicit new report path required');const browser=new Browser({timeout:1000,loadResources:['iframe']}),page=browser.createPage(),report={engine:'untouched646',productErrorSourceUnchanged:true,reportErrorProbeBody:initialReportErrorProbe.toString()};
try{
 await page.navigate('data:text/html,<p>actual quiet report parent</p>');const w=page.dom.window,f=w.document.createElement('iframe');w.document.body.append(f);const frame=page.frames.findElement(f);if(!frame)throw Error('Actual quiet FramePage required');report.forwardedPageErrors=[];frame.on('pageError',error=>report.forwardedPageErrors.push({name:error.name,code:error.code,message:error.message}));
 report.value=JSON.parse(JSON.stringify(frame.evaluate('('+initialReportErrorProbe.toString()+')()')));report.query=frame.evaluate('6*7');report.actualDocumentSame=f.contentDocument===frame.dom.window.document;report.actualState=f.contentDocument.readyState;
}catch(error){report.failure={name:error.name,message:error.message,stack:error.stack};process.exitCode=1}finally{await browser.close();report.closed=page.closed;writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report))}
