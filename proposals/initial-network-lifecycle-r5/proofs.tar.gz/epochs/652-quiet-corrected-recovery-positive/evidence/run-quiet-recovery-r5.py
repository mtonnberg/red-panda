"""UNRUN test-observer correction only: quiet untouched646 then recovery6/7.
No product change, Native/retirement/original1-5 repeat or broad run."""
from pathlib import Path
import hashlib,json,os,re,signal,socket,subprocess,time,traceback
D=Path(__file__).resolve().parent.parent;R=D.parent;O=D/'run-quiet-recovery-r5';assert not O.exists();O.mkdir();P=Path('/workspace/red-panda');N='/workspace/shared/rea-tools/node_modules/.bin/node';C=D/'behavior652';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def graph(root):
 files={str(p.relative_to(root)):sha(p)for x in ['src','test','native','scripts','bin']for p in(root/x).rglob('*')if p.is_file()and not p.is_symlink()};files.update({n:sha(root/n)for n in ['package.json','package-lock.json']});return dict(sorted(files.items()))
def identity(pid):
 text=Path('/proc/'+str(pid)+'/stat').read_text();parts=text[text.rfind(')')+2:].split();return{'pid':pid,'startTicks':parts[19],'processGroup':int(parts[2])}
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
source=json.loads((D/'evidence/source-r5.json').read_text());plan=json.loads((D/'evidence/plan-r5.json').read_text());external=json.loads((R/'evidence/external-root646-r3.json').read_text());roots={'Root646':P,'quiet646':R/'baseline-root646','old650':R/'projection-root646-r3','old651':R/'retirement-generation-r4/behavior651','new652':C};before={name:graph(path)for name,path in roots.items()};contracts={str(p):sha(p)for p in [Path(__file__),D/'evidence/source-r5.json',D/'evidence/plan-r5.json',D/'evidence/run-quiet-root646.mjs',D/'evidence/test-observer-only.patch',*map(Path,plan['externalContracts'])]};write('before.json',{'graphs':before,'contracts':contracts})
env=os.environ.copy();env.pop('RESOURCE_RETIREMENT_ENGINE_MODULE',None);env['NODE_USE_ENV_PROXY']='1';env['PATH']=str(Path(N).parent)+':'+env.get('PATH','');proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy
commands=[];current=None;expected=None;failure=None;identities=[];ports=[];quiet=None;observations=[]
def stop():
 if current is not None and current.poll()is None:
  assert identity(current.pid)==expected and expected['processGroup']==current.pid,'Refuse signal after owned identity change';write('before-owned-signal-'+str(current.pid)+'.json',expected);os.killpg(current.pid,signal.SIGKILL);current.wait()
def run(label,args,passed=None):
 global current,expected
 began=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  current=subprocess.Popen([N,*args],cwd=C,env=env,stdout=out,stderr=err,start_new_session=True);expected=identity(current.pid);identities.append(expected);write(label+'-identity.json',expected);print(json.dumps({'started':label,**expected}),flush=True);expired=False
  try:code=current.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;stop();code=current.returncode
 text=(O/(label+'.stdout')).read_text()
 for match in re.finditer(r'actual-initial-child-start (\{[^\n]+\})',text):identities.append(json.loads(match.group(1)))
 for match in re.finditer(r'actual-initial-recovery (\{[^\n]+\})',text):
  value=json.loads(match.group(1));observations.append(value)
  if value.get('fixture'):ports.append(value['fixture']['port'])
 row={'label':label,'identity':expected,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-began}
 if passed is not None:row['actualTAPSummary']={name:int(m.group(1))for name in ['pass','fail','cancelled','skipped']if(m:=re.search(r'^# '+name+r' (\d+)\s*$',text,re.M))}
 commands.append(row);current=None;expected=None;write(label+'-result.json',row);print(json.dumps(row),flush=True)
 if code or expired:raise RuntimeError('Actual quiet/recovery command failed: '+label)
 if passed is not None:assert row['actualTAPSummary']=={'pass':passed,'fail':0,'cancelled':0,'skipped':0},row
try:
 assert before['Root646']==source['RootBefore646']==external['actualRoot646']and before['quiet646']==source['QuietRoot646']and before['old651']==source['Frozen651']and before['new652']==source['Candidate652']
 assert before['old650']==plan['frozen650']
 assert all(sha(P/n)==v for n,v in external['Root18Artifacts'].items())and sha(P/'native/runtime.cc')==external['nativeRuntimeSource95']
 assert all(sha(Path(n))==v for n,v in plan['externalContracts'].items())
 for name in plan['changedSyntaxFiles']:run('syntax-'+Path(name).name,['--check',name])
 run('quiet-root646',[str(D/'evidence/run-quiet-root646.mjs'),str(O/'quiet.json')]);quiet=json.loads((O/'quiet.json').read_text());assert not quiet.get('failure')and quiet['query']==42 and quiet['closed']and quiet['actualDocumentSame']
 assert quiet['value']==plan['strictObservationContract'],'Quiet actual error contract contradicts corrected observation'
 for i,title in enumerate(plan['twoRecoveryTitles'],6):
  count=len(observations);run('corrected-'+str(i),['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','--test-name-pattern','^'+re.escape(title)+'$','test/initial-network-load.test.js'],1)
  assert len(observations)==count+1;value=observations[-1]
  assert value['laterReportObservation']==quiet['value'],'Post-timeout actual event observation differs from quiet untouched646'
  assert value['laterForwardedPageErrors']==quiet['forwardedPageErrors'],'Actual frame forwarding differs from quiet baseline'
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 try:stop()
 except BaseException as error:failure={'name':'OwnedCleanupFailure','message':str(error),'previous':failure}
 closure=[{**value,'procPresent':Path('/proc',str(value['pid'])).exists()}for value in identities];portClosure=[]
 for port in ports:
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.25):portClosure.append({'port':port,'closed':False})
  except ConnectionRefusedError:portClosure.append({'port':port,'closed':True})
  except Exception as error:portClosure.append({'port':port,'closed':None,'inspectionError':str(error)})
 guards={name+'Unchanged':graph(path)==before[name]for name,path in roots.items()};guards.update({'Root18Unchanged':all(sha(P/n)==v for n,v in external['Root18Artifacts'].items()),'Root95Unchanged':sha(P/'native/runtime.cc')==external['nativeRuntimeSource95'],'contractsUnchanged':all(sha(Path(n))==v for n,v in contracts.items())});write('after-guards.json',guards);write('closure.json',{'reportedIdentities':closure,'reportedPorts':portClosure,'noWebSocketsUsed':True,'noRecursiveInventoryClaim':True,'RootServiceExcluded':True})
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 if any(v['procPresent']for v in closure)or any(v['closed']is not True for v in portClosure):failure={'name':'OwnedClosureUnconfirmed','previous':failure}
 write('status.json',{'complete':failure is None,'failure':failure,'commands':commands,'seconds':time.monotonic()-started,'quiet646Observation':quiet,'actualRecoveryObservations':observations,'productRuntimeBytesIdenticalTo651':True,'threeChangedTestSyntaxQuietAndTwoRecoveriesOnly':True,'noNativeRetirementOriginal1to5Repeat':True,'oldNegativeAndUnrunEpochsPreserved':True,'strictMessageIdentityTrustOwnerCancellationStateComparison':True,'originalScript1000Load2000VM200Child7000Case8000Admin90000':True,'noSourceProtectedSDKBuildRootApply':True,'stopFirst':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
