"""Prepared ONLY. Never call without a separately reviewed execution grant."""
from pathlib import Path
import argparse,json,hashlib,gzip,tarfile,io,stat,sys

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('--plan-manifest',required=True);p.add_argument('--manifest-sha',required=True);p.add_argument('--allowlist-sha',required=True);p.add_argument('--execute-reviewed-plan',action='store_true');a=p.parse_args()
if not a.execute_reviewed_plan:raise SystemExit('Preparation only: a separate reviewed execution grant and flag are required')
M=Path(a.plan_manifest).resolve();D=M.parent;assert sha(M)==a.manifest_sha,'Reviewed exact plan manifest required';manifest=json.loads(M.read_text())
for name,h in manifest['filesSHA256'].items():
 q=D/name;assert q.is_file()and not q.is_symlink()and sha(q)==h,name
allowPath=D/manifest['allowlistFile'];assert sha(allowPath)==a.allowlist_sha==manifest['allowlistSHA256'];allow=json.loads(allowPath.read_text());rows=allow['rows'];R=Path('/workspace/red-panda');O=R/allow['plannedRepositoryPrefix'];assert O==R/'proposals/initial-network-lifecycle-r5'and not O.exists()
assert len(rows)==allow['fileCount']and len({row['target']for row in rows})==len(rows)
# No live source is inferred from old epoch labels. Guard the actual current
# production files against mutations by this archival job; retain old maps raw.
def protection():
 files=[]
 for name in ['src','bin','scripts','test','native']:
  files.extend(q for q in(R/name).rglob('*')if q.is_file()and'__pycache__'not in q.parts)
 files.extend([R/'package.json',R/'package-lock.json'])
 return{str(q):sha(q)for q in sorted(set(files))}
protectedBefore=protection();before={}
for row in rows:
 s=Path(row['source']);t=Path(row['target']);assert s.is_file()and not s.is_symlink()and not t.is_absolute()and'..'not in t.parts
 assert not {'node_modules','.git','.aws','.codex','__pycache__'}.intersection(s.parts)
 assert not str(s).startswith(str(R/'proposals')+'/'),'Protected proposal payload is not an archive input'
 assert s.suffix not in ['.node','.so','.o','.a','.zip','.tar','.gz','.pyc'];data=s.read_bytes();assert not data.startswith(b'\x7fELF');assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['SHA256'];before[str(s)]=row['SHA256']
# The target is created only after ALL exact inputs have passed. Never overwrite
# an earlier proposal; preserve partial output if an archival error occurs.
O.mkdir();write(O/'allowlist.json',allow);write(O/'protected-current-before.json',protectedBefore)
unique={};index={};logical={}
for row in rows:
 key=(row['SHA256'],row['bytes']);target=row['target']
 if key not in index:index[key]=target;unique[target]=row
 logical[target]={'archiveMember':index[key],'SHA256':row['SHA256'],'bytes':row['bytes'],'source':row['source'],'group':row['group']}
write(O/'logical-member-map.json',logical);write(O/'physical-member-list.json',{name:{'SHA256':row['SHA256'],'bytes':row['bytes'],'source':row['source']}for name,row in unique.items()})
archive=O/'proofs.tar.gz'
with archive.open('xb')as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,row in unique.items():
    data=Path(row['source']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['SHA256'];info=tarfile.TarInfo(name);info.size=len(data);info.mode=row['mode'];info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(unique)and{m.name for m in members}==set(unique);observed={}
 for m in members:
  assert m.isfile()and not m.issym()and not m.islnk();data=tar.extractfile(m).read();observed[m.name]=(len(data),hashlib.sha256(data).hexdigest());assert observed[m.name]==(unique[m.name]['bytes'],unique[m.name]['SHA256'])
 for row in logical.values():assert observed[row['archiveMember']]==(row['bytes'],row['SHA256'])
for name,h in before.items():assert sha(name)==h
protectedAfter=protection();assert protectedAfter==protectedBefore;write(O/'protected-current-after.json',protectedAfter)
# This current-plan copy is factual narrative, never an invented future result.
(O/'plan-README.md').write_bytes((D/'README.md').read_bytes())
(O/'source-plan-manifest.json').write_bytes(M.read_bytes())
(O/'README.md').write_text('This factual archive was produced from the separately reviewed plan manifest '+a.manifest_sha+'. The original preparation-time README is retained verbatim as plan-README.md; its UNRUN/future labels describe that planning epoch, not whether this archive copy ran.\n\nOnly exact allowlisted existing inputs are embedded. No product tests, builds, network, source edits, staging or commits ran as part of archiving. Actual observations and remaining holes are preserved in scope-boundaries.json and the unmodified raw receipts. The original animation producer timeout at its10000ms bound remains separate from post-SIGTERM308/34pass/0fail/274cancelled reporter accounting; no full-suite pass or total is inferred.\n\nphysical-member-list.json lists every actual compressed member, while logical-member-map.json preserves every original logical path and explicit duplicate-content alias. verification.json records all original and decompressed byte checks.\n')
write(O/'scope-boundaries.json',{'sourcePlanManifestSHA256':a.manifest_sha,'allowlistSHA256':a.allowlist_sha,'archiveProducedOnlyFromListedActualInputs':True,'remainingHolesPreserved':allow['explicitFutureHoles'],'noInferredFullPassOrPublication':True,'originalRawTimeoutAndPostSignalSummaryDistinct':allow['fullR3TwoDistinctObservations']})
write(O/'verification.json',{'state':'ALL_LISTED_SOURCE_AND_DECOMPRESSED_BYTES_VERIFIED','logicalFiles':len(rows),'physicalMembers':len(unique),'deduplicatedAliases':len(rows)-len(unique),'archiveSHA256':sha(archive),'archiveBytes':archive.stat().st_size,'allLogicalAliasesReadbackVerified':True,'sourceBeforeAfterStable':True,'currentProductionBeforeAfterUnchanged':True,'sourcePlanManifestSHA256':a.manifest_sha,'runtimeBuildNetworkStageCommitPerformed':False})
files={q.name:{'SHA256':sha(q),'bytes':q.stat().st_size}for q in sorted(O.iterdir())if q.is_file()};write(O/'archive-manifest.json',{'state':'STATIC_EVIDENCE_ARCHIVE_WITH_EXPLICIT_SCOPE_BOUNDARIES','files':files,'futureHoles':allow['explicitFutureHoles']});assert all(sha(O/n)==v['SHA256']for n,v in files.items());(O/'SHA256SUMS').write_text(''.join(f"{v['SHA256']}  {n}\n"for n,v in files.items())+f"{sha(O/'archive-manifest.json')}  archive-manifest.json\n")
print(json.dumps({'target':str(O),'members':len(unique),'logical':len(rows),'archiveSHA256':sha(archive),'manifestSHA256':sha(O/'archive-manifest.json')},indent=2))
