from pathlib import Path
import json,hashlib,copy,collections
S=Path('/workspace/shared');R=Path('/workspace/red-panda');D=Path(__file__).resolve().parent;A=S/'initial-network-lifecycle-r5-archive-plan-r2';P=S/'network-initial-blocking-protected654-r1';V=S/'network-frame654-validation-plan-r1';J=S/'network-initial-blocking-root-integration-r1';C=S/'network-initial-blocking-frame-r1/candidate';TARGET=R/'proposals/initial-network-lifecycle-r5';assert not TARGET.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();old=json.loads((A/'allowlist-r2.json').read_text());seal=json.loads((A/'plan-manifest-r2.json').read_text());assert sha(A/'allowlist-r2.json')==seal['filesSHA256']['allowlist-r2.json'];rows=copy.deepcopy(old['rows']);assert len(rows)==468
for row in rows:assert sha(row['source'])==row['SHA256']and Path(row['source']).stat().st_size==row['bytes']
def add(src,target,group):
 p=Path(src);assert p.is_file()and not p.is_symlink(),str(p);assert not {'node_modules','.git','.aws','.codex','__pycache__'}.intersection(p.parts);assert not str(p).startswith(str(R/'proposals')+'/');assert p.suffix not in ['.node','.so','.o','.a','.zip','.tar','.gz','.pyc'];data=p.read_bytes();assert not data.startswith(b'\x7fELF');t=Path(target);assert not t.is_absolute()and'..'not in t.parts
 rows.append({'source':str(p),'target':t.as_posix(),'SHA256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mode':p.stat().st_mode&0o777,'group':group})
def tree(src,target,group):
 for p in sorted(Path(src).rglob('*')):
  if p.is_file():
   if '__pycache__'in p.parts:continue
   add(p,Path(target)/p.relative_to(src),group)
for n in ['README.md','allowlist-r2.json','plan-manifest-r2.json','prepare-allowlist-r2.py','receipt-boundaries-r2.json','source-counts-r2.json']:add(A/n,'prior-archive-plan-r2/'+n,'historical-unbuilt-plan468')
# Only the three completed protected scopes; this sealed capsule has no source
# tree, binary, install, dependency or unfinished full-run directory.
tree(P,'correction654-protected','actual-correction654-protected77-SDK10each-capsule')
receipt=json.loads((P/'evidence/actual-three-scope-receipt.json').read_text());assert sha(P/'evidence/actual-three-scope-receipt.json')=='d85d0fa63fba9e54f5f5fec5037aeba989f3fa5fb8c6ecc0e8f4fbccc3128d11';assert [receipt['actualScopes'][n]['actualTAP']['pass']for n in ['focused24','sdk24-19','sdk26-13']]==[77,10,10]
material=json.loads((P/'materialization-receipt-r1.json').read_text());assert material['preservedExisting6']==6 and len(material['created18'])==18 and len(material['actual24Pairs'])==24
for pair in material['actual24Pairs']:
 dest=Path(pair['destination']);assert dest.is_relative_to(C);assert sha(dest)==pair['bothSHA256']and dest.stat().st_size==pair['bytes'];add(dest,Path('correction654-contract-closure')/dest.relative_to(C),'actual-materialized-candidate-contract24')
# Exact unchanged actual test/helper source closure, without copying candidate654.
spec=json.loads((P/'freeze-spec.json').read_text());selected={}
for scope in spec['scopes'].values():
 for row in scope['files']:selected[row['path']]=row['SHA256']
for row in json.loads((P/'additive-contract-materialization-plan.json').read_text())['helperClosure']:selected[row['path']]=row['candidateSHA256']
for name,h in selected.items():assert sha(C/name)==h;add(C/name,Path('correction654-selected-test-helper-source')/name,'actual-protected-selected-test-helper-closure')
# Complete existing validation packet only. It currently contains Source96 and
# one installed-live receipt; any new unfinished receipt directory is refused.
allowedReceiptRoots={'installed654-live-r1'}
assert {p.name for p in(V/'receipts').iterdir()if p.is_dir()}==allowedReceiptRoots
for p in sorted(V.rglob('*')):
 if p.is_file()and '__pycache__'not in p.parts:
  rel=p.relative_to(V);group='actual-correction654-source96'if rel.parts[0]=='source96'else'actual-installed654-live-and-validation-basis';add(p,Path('correction654-validation')/rel,group)
s96=V/'source96/run-source96-654/status.json';assert sha(s96)=='1f79781227248079fd1084d490f84e1379c2f15f24c0c61fbcc915c429dc05b4'
live=V/'receipts/installed654-live-r1/status.json';assert sha(live)=='bc4a2fc30c773bc0959c1b519ebed8f162305f639d82181f4dfe7ac5adbf3020';l=json.loads(live.read_text());assert l['exit']==0 and l['source654Exact']and l['inputsUnchanged']and l['serviceSameStart']
tree(J,'root-application-correction4','actual-root4-application-and-two-backups');assert sha(J/'journal.json')=='9d6751fc26014e604bdd95fefa81480518bd8d44e755cb0c2844162443a82506';journal=json.loads((J/'journal.json').read_text());assert journal['state']=='APPLIED_EXACT_ROOT4_654_FULL_VALIDATION_UNRUN'and len(journal['backups'])==2 and journal['oldRoot12JournalNotOverwritten']and journal['native18Unchanged']
E=R/'.cache/validation/network-frame654-environment'
for name in ['source-inputs.json','service-launch-878425.json']:add(E/name,'installed654-environment/'+name,'actual-installed654-source-map-and-service-launch')
assert len({row['target']for row in rows})==len(rows)
for row in rows:assert sha(row['source'])==row['SHA256']and Path(row['source']).stat().st_size==row['bytes']
# Two distinct facts, neither may suppress the other.
full=json.loads((S/'network-initial-full-root-r3/full-js-r1/interrupted-run-receipt.json').read_text());timeout=full['originalObservedIssue'];assert timeout['originalDurationMs']==10014.181921 and timeout['preStopPassReporterLines']==34 and timeout['preStopNonpassReporterLines']==1
pending=[{'kind':'Installed654 complete full JS raw/status/final reporter/guards/closure','state':'UNRUN_NOT_ADMITTED','actualPath':None,'SHA256':None},{'kind':'Any remaining installed654 PS/Native/strict/syntax checks actually requested','state':'FUTURE_NOT_ADMITTED','actualPath':None,'SHA256':None},{'kind':'Actual code-publication/remote-equivalence receipt if later supplied','state':'FUTURE_NOT_ADMITTED','actualPath':None,'SHA256':None}]
counts=collections.Counter(row['group']for row in rows);unique={row['SHA256']:row['bytes']for row in rows}
new=copy.deepcopy(old);new.update({'schema':'initial-network-lifecycle-r5-archive-allowlist/v3','state':'STATIC_PLAN_ONLY_NO_ARCHIVE_EXECUTION_NO_ROOT_EDITS','priorR2AllowlistSHA256':sha(A/'allowlist-r2.json'),'original468RowsExactUnchanged':True,'graphAuthority':'Initial12Root652 plus actually applied correction4Root654. Correction97 protected/SDK tests and candidateSource96 actualPASS; installed654 live actualPASS. Full654 remainsUNRUN. OldRoot652 full interrupted/regression remains historical negative.','rows':rows,'fileCount':len(rows),'totalBytes':sum(row['bytes']for row in rows),'uniqueContentDigests':len(unique),'uniqueContentBytes':sum(unique.values()),'groupCounts':dict(counts),'explicitFutureHoles':pending,'actualCorrection654ProtectedReceiptSHA256':sha(P/'evidence/actual-three-scope-receipt.json'),'actualCorrection654Source96StatusSHA256':sha(s96),'actualCorrection654RootApplicationSHA256':sha(J/'journal.json'),'actualInstalled654LiveStatusSHA256':sha(live),'actualSource96CoverageBoundary':'Five byte-pinned script-ID declarations; one actual fixture acceptance, not five independently counted observations. Separate immutable metadata note retained.','fullR3TwoDistinctObservations':{'rawObservedOriginalTimeout':timeout,'postSignalActualReporterSummary':full['postSignalActualReporterSummary'],'interpretation':'The genuine original10s timeout and34pass/1nonpass prefix are actual observations. Later308/34pass/0fail/274cancelled is post-SIGTERM cancellation/file accounting; it neither contradicts nor hides the timeout, and neither gives full-suite totals.'},'explicitNoEnumeration':['network-initial-full-root-r4 unfinished outputs','Any later/new receipt in completed packet roots without a new versioned allowlist'],'archiveExecutionAuthorized':False})
(D/'allowlist-r3.json').write_text(json.dumps(new,indent=2)+'\n')
(D/'receipt-boundaries-r3.json').write_text(json.dumps({'state':'STATICsummaryofactualclosedepochs; oldreceiptsunaltered','protected97':receipt,'materialization':'24actualpairs:18exclusiveadditions+6preservedmatches; selected copies and helper/test closure explicitly allowlisted','source96ActualStatusSHA256':sha(s96),'source96MetadataBoundary':new['actualSource96CoverageBoundary'],'actualRoot4JournalStateUnchanged':journal['state'],'installed654LiveActual':{'exit':l['exit'],'seconds':l['seconds'],'inputCount':l['inputs'],'inputsUnchanged':l['inputsUnchanged'],'ownedAfterCleanup':l['ownedAfterCleanup'],'service':l['service']['process']},'fullR3BothObservations':new['fullR3TwoDistinctObservations'],'pending':pending},indent=2)+'\n')
(D/'source-counts-r3.json').write_text(json.dumps({'state':'STATICsourcecountsnotarchiveexecution','rows':len(rows),'priorRows':468,'addedRows':len(rows)-468,'logicalBytes':new['totalBytes'],'uniqueDigests':len(unique),'uniqueBytes':new['uniqueContentBytes'],'groups':dict(counts),'materializedContractFiles':24,'selectedTestHelperFiles':len(selected),'futureHoles':len(pending),'RootArchivePrefixExists':TARGET.exists()},indent=2)+'\n')
print(json.dumps({'rows':len(rows),'added':len(rows)-468,'bytes':new['totalBytes'],'uniqueDigests':len(unique),'groups':dict(counts),'sourceHelpers':len(selected),'allowlistSHA256':sha(D/'allowlist-r3.json'),'targetExists':TARGET.exists()},indent=2))
