from pathlib import Path
import json,hashlib,collections,copy
S=Path('/workspace/shared');D=Path(__file__).resolve().parent;A=S/'initial-network-lifecycle-r5-archive-plan-r1';P=S/'network-initial-blocking-frame-r1';R=Path('/workspace/red-panda');TARGET=R/'proposals/initial-network-lifecycle-r5';assert not TARGET.exists(),'Archive target must remain absent during planning'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((A/'allowlist-r1.json').read_text());oldseal=json.loads((A/'plan-manifest-r1.json').read_text());assert sha(A/'allowlist-r1.json')==oldseal['filesSHA256']['allowlist-r1.json'];assert len(old['rows'])==349
rows=[];aliases=[];excluded=[]
for original in old['rows']:
 row=copy.deepcopy(original);source=Path(row['source']);assert source.is_file()and sha(source)==row['SHA256']
 # Preserve the original349 target/content identities, but take the12 installed
 # after-bytes from the already frozen owned652 snapshot. This remains valid
 # after a future authorized Root654 change without relabeling oldRoot646.
 if row['group']=='exact12-Root-applied-leaves':
  name=source.relative_to(R);frozen=P/'installed652'/name;assert frozen.is_file()and sha(frozen)==row['SHA256'];aliases.append({'target':row['target'],'originalR1Source':row['source'],'newImmutableSource':str(frozen),'SHA256':row['SHA256'],'reason':'Exactaccepted652after-bytes; protect against futureRoot654apply without rewriting oldplan'});row['priorPlanSource']=row['source'];row['source']=str(frozen)
 rows.append(row)
assert len(aliases)==12

def add(src,target,group):
 p=Path(src);assert p.is_file()and not p.is_symlink(),str(p);assert not {'node_modules','.git','.aws','.codex','__pycache__'}.intersection(p.parts)
 assert not str(p).startswith(str(R/'proposals')+'/'),'No protected proposal payloads'
 assert p.suffix not in ['.node','.so','.a','.o','.zip','.tar','.gz','.pyc'];data=p.read_bytes();assert not data.startswith(b'\x7fELF');t=Path(target);assert not t.is_absolute()and'..'not in t.parts
 rows.append({'source':str(p),'target':t.as_posix(),'SHA256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mode':p.stat().st_mode&0o777,'group':group})
def tree(src,target,group):
 for p in sorted(Path(src).rglob('*')):
  if p.is_file():
   if '__pycache__'in p.parts:excluded.append({'source':str(p),'reason':'Pythoncache not evidence'});continue
   add(p,Path(target)/p.relative_to(src),group)
for name in ['README.md','allowlist-r1.json','plan-manifest-r1.json','prepare-allowlist.py']:add(A/name,'prior-archive-plan-r1/'+name,'historical-unbuilt-plan349')
# Actual installed652 syntax/live receipts replace no original historical bytes.
for name in ['check-status.json','check.log','current-service.json','inputs-after.json','inputs-before.json','run-check.py']:add(R/'.cache/validation/network-initial-check-r1'/name,'installed652-validation/check/'+name,'actual-installed652-check')
for name in ['current-service.json','example.log','inputs-after.json','inputs-before.json','live-status.json','run-live.py','service-launch-870516.json']:add(R/'.cache/validation/network-initial-environment'/name,'installed652-validation/environment/'+name,'actual-installed652-live')
# These finite roots have only source/controllers/guards/logs. Future R4 is NOT
# enumerated or admitted; it has no actual correction integration/full receipt.
for name,group in [('network-initial-full-root-r1','full-preparation-r1'),('network-initial-full-root-r2','full-preparation-r2-and-freeze-negative'),('network-initial-full-root-r3','actual-installed652-full-r3-interrupted')]:tree(S/name,'installed652-full-history/'+name,group)
for name in ['README.md','ACTUAL-CAUSAL-r1.md','candidate-plan-r1.json','initial-source.json','manifest-r1.json','manifest-r2-causal-positive-candidate-unrun.json','plan-r1.json']:add(P/name,'blocking-correction/'+name,'blocking-static-source-and-historical-manifests')
tree(P/'evidence','blocking-correction/evidence','blocking-source-maps-controllers-golden')
tree(P/'run-causal-baselines-r1','blocking-correction/run-causal-baselines-r1','actual-baseline646-to-installed652-regression')
tree(P/'run-candidate-gate-r1','blocking-correction/run-candidate-gate-r1','actual-candidate654-first-positive')
leaves=json.loads((P/'evidence/source-r1.json').read_text())['leaves'];assert len(leaves)==4
for name,meta in leaves.items():
 q=P/'candidate'/name;assert sha(q)==meta['after'];add(q,Path('blocking-correction/selected-after4')/name,'candidate654-narrow-after4')
 if meta['before']is not None:
  q=P/'installed652'/name;assert sha(q)==meta['before'];add(q,Path('blocking-correction/before-runtime2')/name,'installed652-before-correction-runtime2')
assert len({r['target']for r in rows})==len(rows)
for row in rows:assert sha(row['source'])==row['SHA256']and Path(row['source']).stat().st_size==row['bytes']
candidate=json.loads((P/'run-candidate-gate-r1/status.json').read_text());assert sha(P/'run-candidate-gate-r1/status.json')=='b4ae983adbe253e5f99543c744706ea767488dd62a9a209724eade6813ec71b1';assert candidate['state']=='PASS_CANDIDATE_CAUSAL_NEW2_AND_ORIGINAL2_SELECTED'and len(candidate['commands'])==7 and all(x['exit']==0 for x in candidate['commands'])
F=S/'network-initial-full-root-r3/full-js-r1';fr=json.loads((F/'interrupted-run-receipt.json').read_text());assert fr['state']=='FULL_JS_INTERRUPTED_INCOMPLETE_NOT_PASS'
openholes=[{'kind':'Correction654 protected/affected existing regression gate','state':'UNRUN_NOT_ADMITTED','actualPath':None,'SHA256':None},{'kind':'Correction654 remaining SDK validation or explicitly accepted unchanged-code scope','state':'UNRUN_NOT_ADMITTED','actualPath':None,'SHA256':None},{'kind':'Correction654 actual Root application journal and installed source map','state':'UNRUN_NOT_ADMITTED','actualPath':None,'SHA256':None},{'kind':'Correction654 new owned service launch/health/live/check receipt','state':'UNRUN_NOT_ADMITTED','actualPath':None,'SHA256':None},{'kind':'Correction654 installed complete full JS and final input/closure receipts','state':'UNRUN_NOT_ADMITTED','actualPath':None,'SHA256':None},{'kind':'Correction654 PS/Native/strict/Source96 receipts if actually requested and supplied','state':'UNRUN_NOT_ADMITTED','actualPath':None,'SHA256':None},{'kind':'Later actual code commit/push receipt for initial12 plus correction','state':'NO_FUTURE_BYTES_ADMITTED','actualPath':None,'SHA256':None}]
counts=collections.Counter(r['group']for r in rows);unique={r['SHA256']:r['bytes']for r in rows}
allow={'schema':'initial-network-lifecycle-r5-archive-allowlist/v2','state':'STATIC_PREPARATION_ONLY_NO_ARCHIVE_COPY_NO_ROOT_EDIT_NO_STAGING_NO_RUNTIME','plannedRepositoryPrefix':'proposals/initial-network-lifecycle-r5','originalR1PlanSHA256':sha(A/'allowlist-r1.json'),'original349ContentAndTargetIdentitiesPreserved':True,'original349GroupsUnretagged':True,'sourceAuthoritySubstitutions12':aliases,'historicalManifestNameCollisions':old['historicalManifestNameCollisions'],'graphAuthority':'Initial12appliedRoot652 has bounded accepted/live/check receipts but confirmed blocking regression and incomplete/interrupted fullR3. Candidate654 first narrow gate actually positive; it is NOT installed, protected or full acceptance.','rows':rows,'fileCount':len(rows),'totalBytes':sum(r['bytes']for r in rows),'uniqueContentDigests':len(unique),'uniqueContentBytes':sum(unique.values()),'groupCounts':dict(counts),'newActualReceipts':{'installed652Check':'checkExit0/21.536443812s/13182stable','installed652Live':'exampleExit0/4.499737522s/13182stable','installed652FullR3':'INTERRUPTED/incomplete/34pass274cancelled0reportedfail afterParentTERM; remaining unobserved, not274 assertion failures','baselineBlocking':'Actualuntouched646successful vsinstalled652missingcanonicalclose/Promisehandoff withsameHTTPbytes; separateconfirmedregression','candidate654FirstGate':{'statusSHA256':'b4ae983adbe253e5f99543c744706ea767488dd62a9a209724eade6813ec71b1','state':candidate['state'],'seconds':candidate['secondsIncludingCleanup'],'syntaxChecks':3,'realCausalControls':1,'actualNewTests':2,'actualSelectedOriginalTests':2,'notWholeAnimationSuite':True,'Root652Unchanged':candidate['RootCurrent652Unchanged']}},'explicitFutureHoles':openholes,'excludedDuringEnumeration':excluded,'explicitExcluded':old['explicitExcluded']+['UnrunfullRootR4skeleton/outputtree','baseline646/installed652/candidate654wholecopies; onlyselected12+4+2sourceleaves and maps admitted','Any new future correction receipt until nextversioned actual allowlist'],'futureReceiptRule':'Append concrete supplied actual receipts in a new separately versioned plan; do not overwrite old manifests, seals, status labels or source maps. Archive is not authorized or executed by this plan.'}
(D/'allowlist-r2.json').write_text(json.dumps(allow,indent=2)+'\n')
(D/'receipt-boundaries-r2.json').write_text(json.dumps({'state':'STATICinterpretationofexistingactualbytesonly','candidate654OriginalStatusUnchanged':{'path':str(P/'run-candidate-gate-r1/status.json'),'SHA256':sha(P/'run-candidate-gate-r1/status.json')},'installed652InterruptedFull':fr,'candidateSelectedCases':[{'label':x['label'],'actualTAP':x.get('actualTAP'),'selectedOriginalTitle':x.get('selectedOriginalTitle'),'declaredExclusion':x.get('declaredExclusion')}for x in candidate['commands']],'initial12OldAcceptedEpochsNotCompleteProductAcceptance':True,'openHoles':openholes},indent=2)+'\n')
print(json.dumps({'rows':len(rows),'bytes':allow['totalBytes'],'uniqueContentDigests':len(unique),'uniqueBytes':allow['uniqueContentBytes'],'groupCounts':dict(counts),'old349ContentPreserved':True,'immutableSourceSubstitutions':len(aliases),'futureHoles':len(openholes),'targetRootProposalCreated':TARGET.exists(),'allowlistSHA256':sha(D/'allowlist-r2.json')},indent=2))
