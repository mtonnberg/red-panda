Static sibling only; no runtime or graph/service selected. It follows an actual accepted installedRoot654 full-JS pass and does not rerun that suite. The main full-root-r4 controller remains JS-only and unchanged.

Original phase26 commands/caps are preserved exactly: npm run test:puppeteer (180s); npm run test:reference -- /workspace/shared/lightpanda-reference/lightpanda-x86_64-linux (180s); npm run check (180s); npm run build:automation -- --strict --pedantic-packages (180s). Each stage retains all existing case/API/VM/child limits. Results stop on first real failure, owned-live remainder, deadline or guard mismatch; later stages remain UNRUN.

The actual installed full-JS receipt must be immutable PASS with a complete all-pass actual reporter summary, zero cancellation/skip/failure and closed owned scope. The future freeze also binds the same current source/contracts/additional inputs/native18/CPP95 and fresh actual service PID/startTicks/argv/launcher-cwd receipt. It never claims proc cwd was read. No obsolete source map is compared against liveRoot.

PureScript PASS/check-summary lines and Native PASS lines are counted from actual complete logs, with no required129/13 equality. Syntax records actual exit/log; strict records actual warnings/errors rows and original strict exit. Old totals are not promoted. Raw warnings/errors remain untruncated. The accepted new77 first tranche can retain its own epoch; old60 second remains historicalRoot652, not a pass at654. Full installedJS covers broader effects, and any reused prerequisites retain explicit context/equivalence evidence.

The unfilled request refuses execution. Exact future commands and SHA pins are in readiness.json. No Node/npm/browser/network/build, freeze or Root mutation occurred during this preparation.
