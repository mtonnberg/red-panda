"""UNRUN Native-only four real frame MIME controls, original budgets unchanged."""
from pathlib import Path
import hashlib,json,os,signal,socket,subprocess,time,traceback
R=Path(__file__).resolve().parent.parent;O=R/'run-frame-mime-native-only';assert not O.exists();O.mkdir()
P=Path('/workspace/red-panda');N='/workspace/shared/rea-tools/node_modules/.bin/node';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def graph(root):
 files={str(p.relative_to(root)):sha(p)for d in ['src','test','native','scripts','bin']for p in(root/d).rglob('*')if p.is_file()and not p.is_symlink()};files.update({n:sha(root/n)for n in ['package.json','package-lock.json']});return dict(sorted(files.items()))
def identity(pid):
 text=Path('/proc/'+str(pid)+'/stat').read_text();parts=text[text.rfind(')')+2:].split();return{'pid':pid,'startTicks':parts[19],'processGroup':int(parts[2])}
def write(name,value):
 with(O/name).open('x')as file:json.dump(value,file,indent=2);file.write('\n')
base=json.loads((R/'source-root645.json').read_text());plan=json.loads((R/'evidence/mime-native-plan.json').read_text());before={'actualRoot645':graph(P),'ownedBaseline645':graph(R/'baseline645'),'ownedUnrunR4':graph(R/'candidate')};contracts={str(path):sha(path)for path in [R/'origin.json',R/'source-root645.json',R/'evidence/mime-native-plan.json',Path(__file__),R/'evidence/frame-mime-controls.mjs',R/'evidence/run-frame-mime-native.mjs',*map(Path,plan['externalContracts'])]};write('before.json',{**before,'contracts':contracts})
env=os.environ.copy();env['NODE_USE_ENV_PROXY']='1';env['PATH']=str(Path(N).parent)+':'+env.get('PATH','');proxy=','.join([env.get('NO_PROXY',''),env.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]']);env['NO_PROXY']=proxy;env['no_proxy']=proxy
commands=[];current=None;expected=None;failure=None;report={}
def stop():
 if current is not None and current.poll()is None:
  assert identity(current.pid)==expected and expected['processGroup']==current.pid,'Refuse signal after actual owned identity change';write('identity-before-signal-'+str(current.pid)+'.json',expected);os.killpg(current.pid,signal.SIGKILL);current.wait()
def run(name,args):
 global current,expected
 begin=time.monotonic()
 with(O/(name+'.stdout')).open('x')as out,(O/(name+'.stderr')).open('x')as err:
  current=subprocess.Popen([N,*args],cwd=R,env=env,stdout=out,stderr=err,start_new_session=True);expected=identity(current.pid);write(name+'-identity.json',expected);print(json.dumps({'started':name,**expected}),flush=True);expired=False
  try:code=current.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;stop();code=current.returncode
 row={'name':name,'identity':expected,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin};commands.append(row);current=None;print(json.dumps(row),flush=True)
 if code or expired:raise RuntimeError('Actual MIME command failed: '+name)
try:
 assert before['actualRoot645']==base['source645'] and before['ownedBaseline645']==base['source645'],'Root source changed: require fresh external protection derivative'
 assert before['ownedUnrunR4']==plan['ownedR4Draft645'],'Prepared unrun R4 draft changed'
 assert all(sha(P/n)==v for n,v in base['artifacts18'].items())and sha(P/'native/runtime.cc')==base['runtimeSource95']
 assert all(sha(Path(n))==v for n,v in plan['externalContracts'].items())
 for name in ['frame-mime-controls.mjs','run-frame-mime-native.mjs']:run('syntax-'+name,['--check',str(R/'evidence'/name)])
 run('Native4',[str(R/'evidence/run-frame-mime-native.mjs'),str(O/'Native.json')]);report=json.loads((O/'Native.json').read_text());assert not report.get('failure')and len(report['rows'])==4
 for row in report['rows']:assert row.get('parentBarrier')and row.get('value')and not row.get('cleanupError')and row.get('exit')==0 and row.get('signal')is None,row
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 try:stop()
 except BaseException as error:failure={'name':'OwnedCleanupFailure','message':str(error),'previous':failure}
 if not report:
  for name in ['Native.json','Native.json.incremental']:
   if(O/name).exists():report=json.loads((O/name).read_text());break
 closure=[]
 for row in commands:
  pid=row['identity']['pid'];closure.append({'pid':pid,'procPresent':Path('/proc',str(pid)).exists()})
 for row in report.get('rows',[]):
  item=row.get('identityBeforeAnyDriverSignal')
  if item:closure.append({**item,'procPresent':Path('/proc',str(item['pid'])).exists()})
 ports=[row['webSocketPort']for row in report.get('rows',[])if row.get('webSocketPort')]
 if report.get('fixture'):ports.append(report['fixture']['port'])
 portClosure=[]
 for port in ports:
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.25):portClosure.append({'port':port,'closed':False})
  except ConnectionRefusedError:portClosure.append({'port':port,'closed':True})
  except Exception as error:portClosure.append({'port':port,'closed':None,'inspectionError':str(error)})
 guards={'Root645Unchanged':graph(P)==before['actualRoot645'],'Root18ArtifactsUnchanged':all(sha(P/n)==v for n,v in base['artifacts18'].items()),'Root95RuntimeSourceUnchanged':sha(P/'native/runtime.cc')==base['runtimeSource95'],'ownedBaseline645Unchanged':graph(R/'baseline645')==before['ownedBaseline645'],'R4CandidateNeverRunAndUnchanged':graph(R/'candidate')==before['ownedUnrunR4'],'contractsUnchanged':all(sha(Path(n))==v for n,v in contracts.items())};write('after-guards.json',guards);write('closure.json',{'reportedProcessClosure':closure,'reportedPortClosure':portClosure,'noRecursiveInventoryClaim':True})
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 if any(row['procPresent']for row in closure)or any(row['closed']is not True for row in portClosure):failure={'name':'OwnedClosureUnconfirmed','previous':failure}
 write('status.json',{'complete':failure is None,'failure':failure,'commands':commands,'seconds':time.monotonic()-started,'NativeRowsExpected':4,'RPCCeilingMilliseconds':2500,'scriptCeilingMilliseconds':1000,'parentLoadCeilingMilliseconds':2000,'administrative90Seconds':True,'R4StillUnrun':True,'Source96Unrun':True,'frameClassBirthSeparateOpen':True});print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
