// UNRUN Native-first discriminator. No candidate import or behavior replacement.
import http from 'node:http';
import {once} from 'node:events';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {startReference} from '../../registration455-adapted-plan-20261031/harness/scripts/reference-server.mjs';
import {connect} from '../../registration455-adapted-plan-20261031/harness/test/cdp-client.js';
import {frameProfiles,preload,bytes,observeFrame} from './frame-mime-controls.mjs';
const output=process.argv[2];if(!output)throw Error('Explicit new report path required');
const binary='/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux';
const report={engine:'Native',rows:[],wire:[],requests:[],APIReplyMilliseconds:2500,scriptParameterMilliseconds:1000,parentLoadCompleteMilliseconds:2000,publicUAOverride:false,frameClassBirthSeparateOpenQuestion:true};
const identity=pid=>{const text=readFileSync('/proc/'+pid+'/stat','utf8'),parts=text.slice(text.lastIndexOf(')')+2).trim().split(/\s+/);return{pid,startTicks:parts[19],processGroup:Number(parts[2])}};
const save=()=>writeFileSync(output+'.incremental',JSON.stringify(report,null,2)+'\n');
let server,browser,client;
try{
 server=http.createServer((request,response)=>{
  const name=request.url.startsWith('/frame/')?request.url.slice(7):null,payload=frameProfiles.includes(name)?bytes(name):{mime:'text/html; charset=utf-8',source:'<!doctype html><p>actual owned HTTP parent</p>'},data=Buffer.from(payload.source);
  report.requests.push({url:request.url,contentType:payload.mime,bytes:data.length,SHA256:createHash('sha256').update(data).digest('hex'),source:payload.source});
  response.writeHead(200,{'Content-Type':payload.mime});response.end(data);
 });server.listen(0,'127.0.0.1');await once(server,'listening');report.fixture={pid:process.pid,...identity(process.pid),port:server.address().port};report.origin='http://127.0.0.1:'+server.address().port;
 console.log(JSON.stringify({fixtureListening:report.fixture}));save();
 for(const profile of frameProfiles){
  const row={profile};report.rows.push(row);let browserContextId,session;
  try{
   browser=await startReference(binary,{args:['--ws-max-concurrent','50','--load-resources','iframe']});
   row.identityBeforeAnyDriverSignal=identity(browser.process.pid);row.endpoint=browser.endpoint;row.webSocketPort=Number(new URL(browser.endpoint).port);console.log(JSON.stringify({started:profile,...row.identityBeforeAnyDriverSignal,webSocketPort:row.webSocketPort}));save();
   client=await connect(browser.endpoint,{timeout:2500});
   const send=async(method,params={},sid=session)=>{const entry={profile,method,params,sessionId:sid};report.wire.push(entry);try{const value=await client.send(method,params,sid,{timeout:2500});entry.result=value;return value}catch(error){entry.error={message:error.message,code:error.code};throw error}};
   browserContextId=(await send('Target.createBrowserContext')).browserContextId;const target=await send('Target.createTarget',{url:'about:blank',browserContextId});session=(await send('Target.attachToTarget',{targetId:target.targetId,flatten:true})).sessionId;
   await send('Page.enable');await send('Runtime.enable');await send('Page.setLifecycleEventsEnabled',{enabled:true});await send('Page.addScriptToEvaluateOnNewDocument',{source:preload});
   const offset=client.events.length,started=Date.now(),navigation=await send('Page.navigate',{url:report.origin+'/parent'});
   while(Date.now()-started<2000){
    const event=client.events.slice(offset).find(event=>event.sessionId===session&&event.method==='Page.lifecycleEvent'&&event.params.name==='load'&&event.params.frameId===navigation.frameId);
    if(event){const result=await send('Runtime.evaluate',{expression:'JSON.stringify({ready:document.readyState,url:document.URL,UA:navigator.userAgent})',returnByValue:true,timeout:1000});if(result.exceptionDetails)throw Error('Actual parent barrier exception');const value=JSON.parse(result.result.value);if(value.ready==='complete'&&value.url===report.origin+'/parent'&&Date.now()-started<2000){row.parentBarrier={event:event.params,value,elapsedMilliseconds:Date.now()-started};break}}
    await new Promise(resolve=>setTimeout(resolve,5));
   }
   if(!row.parentBarrier)throw Error('Original2000ms actual parent complete/load barrier');
   const result=await send('Runtime.evaluate',{expression:'('+observeFrame.toString()+')('+JSON.stringify(report.origin)+','+JSON.stringify(profile)+').then(value=>JSON.stringify(value))',awaitPromise:true,returnByValue:true,timeout:1000});
   if(result.exceptionDetails){row.exceptionDetails=result.exceptionDetails;throw Error('Actual MIME program exception: '+profile)}
   row.value=JSON.parse(result.result.value);row.events=client.events.slice(offset);
   if(!Array.isArray(row.value.observations))throw Error('Actual pre-parser observer was not installed: '+profile);
   save();console.log(JSON.stringify({observed:profile,...row.identityBeforeAnyDriverSignal}));
  }finally{
   if(browserContextId&&client)try{await client.send('Target.disposeBrowserContext',{browserContextId},undefined,{timeout:2500})}catch(error){row.cleanupError={message:error.message,code:error.code}}
   await client?.close();client=null;
   if(browser){if(browser.process.exitCode===null&&browser.process.signalCode===null){row.identityBeforeClose=identity(browser.process.pid);if(JSON.stringify(row.identityBeforeClose)!==JSON.stringify(row.identityBeforeAnyDriverSignal))throw Error('Refuse browser close after actual PID/start/group changed')};await browser.close();row.exit=browser.process.exitCode;row.signal=browser.process.signalCode;row.stderr=browser.stderr;browser=null}
   save();
  }
 }
}catch(error){report.failure={name:error.name,message:error.message,stack:error.stack};process.exitCode=1}finally{
 await client?.close();if(browser){const expected=report.rows.at(-1)?.identityBeforeAnyDriverSignal;if(expected&&JSON.stringify(identity(browser.process.pid))!==JSON.stringify(expected))throw Error('Refuse final browser close after identity changed');await browser.close()}
 if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}
 report.startReferenceStartupFailureIdentityBound='Frozen helper may close a failed startup before returning its ChildProcess; no pre-signal identity is claimed for such an unobserved failure';
 writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
}
