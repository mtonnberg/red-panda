// New MIME lifecycle controls. Public observations only; no target output filter.
export const frameProfiles=['html','xhtml','xml','xmlMalformed'];
export const preload=`if(self!==top){globalThis.actualLifecycle=[];const d=document;const getter=Object.getOwnPropertyDescriptor(Document.prototype,'readyState').get;const state=()=>Reflect.apply(getter,d,[]);for(const name of ['readystatechange','DOMContentLoaded','load'])d.addEventListener(name,event=>actualLifecycle.push({target:'document',name,trusted:event.isTrusted,state:state()}));for(const name of ['load','pageshow'])addEventListener(name,event=>actualLifecycle.push({target:'window',name,trusted:event.isTrusted,state:state()}));}`;
export function bytes(profile){
 if(profile==='html')return{mime:'text/html; charset=utf-8',source:'<!doctype html><p id="actual">real HTML frame bytes</p>'};
 if(profile==='xhtml')return{mime:'application/xhtml+xml; charset=utf-8',source:'<?xml version="1.0"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>real XHTML</title></head><body><p id="actual">real XHTML frame bytes</p></body></html>'};
 if(profile==='xml')return{mime:'application/xml; charset=utf-8',source:'<?xml version="1.0"?><root id="actual">real XML frame bytes</root>'};
 if(profile==='xmlMalformed')return{mime:'application/xml; charset=utf-8',source:'<?xml version="1.0"?><root>actual malformed XML</different>'};
 throw Error('Explicit known profile required');
}
export async function observeFrame(origin,profile){
 const frame=document.createElement('iframe'),events=[];let settle;
 frame.addEventListener('load',event=>{events.push({kind:'frameLoad',trusted:event.isTrusted,state:frame.contentDocument?.readyState??null});settle?.()});
 frame.addEventListener('error',event=>{events.push({kind:'frameError',trusted:event.isTrusted});settle?.()});
 const done=new Promise(resolve=>{settle=resolve});frame.src=origin+'/frame/'+profile;document.body.append(frame);
 try{
  await done;
  const w=frame.contentWindow,d=frame.contentDocument;
  return {profile,events,observations:Array.isArray(w.actualLifecycle)?Array.from(w.actualLifecycle):null,complete:d.readyState,sameDocument:w.document===d,rootName:d.documentElement?.localName??null,actualText:d.getElementById('actual')?.textContent??null,metadata:{contentType:d.contentType,constructorName:d.constructor.name,tag:Object.prototype.toString.call(d)}};
 }finally{frame.remove()}
}
