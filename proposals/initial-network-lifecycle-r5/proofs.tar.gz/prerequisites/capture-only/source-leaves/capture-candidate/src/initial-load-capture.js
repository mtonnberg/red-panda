// DIAGNOSTIC CAPTURE ONLY. Exact real producer/callback arguments are forwarded
// unchanged. No event/readiness/resource outcome is replaced by this module.
import {createRequire} from 'node:module';import {types} from 'node:util';import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';
import {observeWindowFactoryTask} from './window-task-capture.js';
import {platformFactoryRecord} from './platform-factories.js';
import {beginDispatchRecoveryParticipant,completeDispatchRecoveryParticipant} from './dom-dispatch-recovery.js';
const require=createRequire(import.meta.url),own=Object.getOwnPropertyDescriptor,define=Object.defineProperty,remove=Reflect.deleteProperty,proto=Object.getPrototypeOf,apply=Reflect.apply,schedule=process.nextTick;
const owners=new WeakMap(),live=new Set(),methods=new WeakMap(),identities=new WeakMap(),boundaries=new WeakSet();let enabled=false,serial=0,verified=false;
const nil=value=>Object.assign(Object.create(null),value),object=value=>value!==null&&(typeof value==='object'||typeof value==='function');
function id(value){if(!object(value))return null;let result=identities.get(value);if(result===undefined){result=++serial;identities.set(value,result)}return result}
function unavailable(message){const error=new Error(message);boundaries.add(error);return error}
function ordinary(value){if(!object(value)||types.isProxy(value))throw unavailable('ordinary actual private object unavailable');return value}
function data(value,key){ordinary(value);const d=own(value,key);if(!d||!Object.hasOwn(d,'value'))throw unavailable('private data slot unavailable: '+String(key));return d.value}
function same(a,b){if(a===undefined||b===undefined)return a===b;return ['value','get','set','writable','configurable','enumerable'].every(key=>a[key]===b[key])}
function method(value,key){let cursor=ordinary(value);while(cursor){ordinary(cursor);const d=own(cursor,key);if(d){if(!Object.hasOwn(d,'value')||typeof d.value!=='function')throw unavailable('original method data unavailable');return d.value}cursor=proto(cursor)}throw unavailable('original method missing')}
function note(owner,kind,value={}){owner.rows.push(nil({kind,...value}))}
function attempt(owner,operation){try{return{available:true,value:operation()}}catch(error){if(object(error)&&boundaries.has(error)){note(owner,'unavailable',{reason:error.message});return{available:false}}throw error}}
function verify(){if(verified)return;const pins=[["jsdom/lib/jsdom/living/nodes/Document-impl.js", "28a1ac5b19463cc2db29b59d5721ce20299b998f00a222ac2ab74117dc66ba0d"], ["jsdom/lib/jsdom/living/nodes/HTMLFrameElement-impl.js", "eb8cca6aa971e1746c0c06860c3e8cfa871c0c52deba46ae438ef15f0bed482a"], ["jsdom/lib/jsdom/browser/resources/resource-queue.js", "526b1c0cb48b2bbab812f18580026e88314a41cb0b8dd9fb0f011a4bed0d7691"], ["jsdom/lib/jsdom/browser/resources/async-resource-queue.js", "82a34dd454df5b6d5f4d5feb1da653445af4e74992962744582139e111213e7b"], ["jsdom/lib/jsdom/browser/resources/per-document-resource-loader.js", "2437ba53ffecae4feb156890652dbc3d9f8697da1d522a579fd4b7325af083ac"]];if(require('jsdom/package.json').version!=='26.1.0')throw unavailable('jsdom version changed');for(const[file,hash]of pins)if(createHash('sha256').update(readFileSync(require.resolve(file))).digest('hex')!==hash)throw unavailable('pinned private producer source changed');verified=true}
function restore(token){
 if(!token.active)return;const stack=token.stack,index=stack.indexOf(token);if(index===-1)return;
 for(let i=stack.length-1;i>=index;i--){const current=stack[i];if(!current.active)continue;const actual=own(current.target,current.key);if(!same(actual,current.installed))note(current.owner,'descriptorChangedDuringCapture',{key:current.key});if(current.prior===undefined)remove(current.target,current.key);else define(current.target,current.key,current.prior);current.active=false;stack.pop();note(current.owner,'methodRestored',{method:id(current),key:current.key,exact:same(own(current.target,current.key),current.prior)})}
}
function patch(owner,target,key,behavior){
 ordinary(target);let map=methods.get(target);if(!map){map=new Map();methods.set(target,map)}let stack=map.get(key);if(!stack){stack=[];map.set(key,stack)}
 const prior=own(target,key);if(prior&&!prior.configurable)throw unavailable('temporary private method is not configurable');const base=stack.length?stack[0].base:method(target,key),token=nil({owner,target,key,prior,base,stack,active:true,committed:false});
 const recover=()=>{if(!token.committed)restore(token)};apply(schedule,process,[recover]);const participant=beginDispatchRecoveryParticipant(recover);
 const value=function(...args){if(this!==target||stack.at(-1)!==token)return apply(base,this,args);return behavior(base,this,args,token)};
 token.installed={value,writable:true,enumerable:prior?.enumerable??false,configurable:true};stack.push(token);owner.tokens.push(token);
 try{define(target,key,token.installed);token.committed=true;completeDispatchRecoveryParticipant(participant);return token}catch(error){restore(token);completeDispatchRecoveryParticipant(participant);throw error}
}
function invocation(owner,operation,restoreTransient=()=>{}){
 const state={complete:false,recovered:false,start:owner.tokens.length},recover=()=>{if(!state.complete&&!state.recovered){state.recovered=true;const active=owner.tokens.slice(state.start).filter(token=>token.active);for(const token of active.reverse())restore(token);restoreTransient();note(owner,'abandonedInvocation',{invocation:id(state),restoredMethods:active.map(token=>id(token)),frameDepth:owner.frameDepth})}};apply(schedule,process,[recover]);const participant=beginDispatchRecoveryParticipant(recover);
 try{return operation()}finally{state.complete=true;completeDispatchRecoveryParticipant(participant)}
}

function listeners(owner){
 const table=data(owner.context.document,'_eventListeners');ordinary(table);const result={};
 for(const name of ['load','error']){const d=own(table,name);if(!d){result[name]=[];continue}if(!Object.hasOwn(d,'value')||!Array.isArray(d.value)||types.isProxy(d.value))throw unavailable('private listener array unavailable');const rows=[];for(let i=0;i<d.value.length;i++){const record=data(d.value,String(i));ordinary(record);rows.push(record)}result[name]=rows}return result;
}
function stopOwner(owner){if(owner.stopped)return;owner.stopped=true;for(const token of owner.tokens.slice().reverse())restore(token);note(owner,'ownerStopped');live.delete(owner)}
export function beginInitialLoadCapture(){if(enabled)throw Error('Explicit capture already enabled');enabled=true;return()=>{for(const owner of [...live])stopOwner(owner);enabled=false}}
export function registerInitialLoadCapture(context){
 if(!enabled||owners.has(context.document))return;verify();
 const owner=nil({context,rows:[],tokens:[],stopped:false,lastClose:null,frameDepth:0,task:observeWindowFactoryTask(context.window,context.document),queues:null});owners.set(context.document,owner);live.add(owner);
 const state=attempt(owner,()=>({queue:data(context.document,'_queue'),defer:data(context.document,'_deferQueue'),async:data(context.document,'_asyncQueue')}));if(!state.available)return;owner.queues=state.value;
 note(owner,'registered',{document:id(context.document),queue:id(state.value.queue),defer:id(state.value.defer),async:id(state.value.async),task:owner.task?.inspect()??null});
 for(const kind of ['defer','async'])attempt(owner,()=>patch(owner,state.value[kind],'setListener',(original,receiver,args)=>invocation(owner,()=>{const callback=args[0];const result=apply(original,receiver,args);const stored=attempt(owner,()=>data(receiver,'_listener'));note(owner,'listenerSlot',{queue:kind,callback:id(callback),storedCallback:stored.available?id(stored.value):null,callbackIdentityUnchanged:stored.available&&stored.value===callback,argumentCount:args.length,result:id(result)});return result})));
}
export function captureInitialBackendClose(context,original,receiver,args){
 const owner=context&&owners.get(context.document);if(!enabled||!owner||owner.stopped||!owner.queues||context.current)return apply(original,receiver,args);
 const valid=attempt(owner,()=>data(context.document,'_queue')===owner.queues.queue);if(!valid.available||!valid.value)return apply(original,receiver,args);
 return invocation(owner,()=>{
  const registrations=[];const installed=attempt(owner,()=>patch(owner,owner.queues.queue,'push',(base,target,values)=>{registrations.push(values.slice());const result=apply(base,target,values);note(owner,'queuePush',{slot:registrations.length,originalMethod:id(base),receiver:id(target),argumentCount:values.length,request:id(values[0]),onLoad:id(values[1]),onError:id(values[2]),keepLast:values[3]??null,element:id(values[4]),result:id(result)});return result}));if(!installed.available)return apply(original,receiver,args);const token=installed.value;
  try{return apply(original,receiver,args)}finally{restore(token);const current=attempt(owner,()=>listeners(owner));owner.lastClose=current.available?current.value:null;note(owner,'backendCloseEnd',{registrations:registrations.length,parserDone:context.record.parserDone===true,frameDepth:owner.frameDepth,task:owner.task?.inspect()??null})}
 });
}

export function captureInitialFrameSource(page,original,receiver,args){
 if(typeof original!=='function')return undefined;const document=platformFactoryRecord(page.record?.document)?.implementation,owner=document&&owners.get(document);if(!enabled||!owner||owner.stopped)return apply(original,receiver,args);
 const previousDepth=owner.frameDepth;return invocation(owner,()=>{owner.frameDepth=previousDepth+1;let result;try{result=apply(original,receiver,args)}finally{owner.frameDepth=previousDepth}const checkpoint=owner.lastClose,current=attempt(owner,()=>listeners(owner));
  if(checkpoint&&current.available)attempt(owner,()=>{const facts={};for(const kind of ['load','error']){const added=current.value[kind].filter(value=>!checkpoint[kind].includes(value));facts[kind]=added.map(value=>({record:id(value),callback:id(data(value,'callback')),options:id(data(value,'options'))}))}note(owner,'frameResolveRejectBirth',{...facts,resultPromise:id(result),nativePromise:types.isPromise(result)})});
  if(types.isPromise(result))attempt(owner,()=>patch(owner,result,'then',(base,target,values,token)=>{restore(token);note(owner,'parentContinuationBirth',{promise:id(result),originalMethod:id(base),onFulfilled:id(values[0]),onRejected:id(values[1]),argumentCount:values.length,descriptorRestoredBeforeForward:!token.active&&same(own(target,'then'),token.prior)});return apply(base,target,values)}));
  return result;
 },()=>{owner.frameDepth=previousDepth});
}
export function inspectInitialLoadCapture(document){const owner=owners.get(document);return owner?nil({rows:owner.rows.map(value=>({...value})),stopped:owner.stopped,frameDepth:owner.frameDepth,activeMethods:owner.tokens.filter(token=>token.active).length,task:owner.task?.inspect()??null}):null}
export function inspectInitialLoadCaptureAll(){return [...live].map(owner=>({document:id(owner.context.document),...inspectInitialLoadCapture(owner.context.document)}))}
