// Owned diagnostic controls only; no initial-load outcome is replaced.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {once} from 'node:events';
import {spawn} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {Browser} from '../src/browser.js';
import {platformFactoryRecord} from '../src/platform-factories.js';
import {beginInitialLoadCapture,inspectInitialLoadCapture} from '../src/initial-load-capture.js';
const options={timeout:8000}, own=Object.getOwnPropertyDescriptor;
const backend=page=>platformFactoryRecord(page.dom.window.document).implementation;
const values=snapshot=>snapshot.rows;
const rows=(snapshot,kind)=>values(snapshot).filter(row=>row.kind===kind);
const plain=value=>JSON.parse(JSON.stringify(value));
async function actualLoad(promise){let timer;try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Original2000ms actual load barrier')),2000)})])}finally{clearTimeout(timer)}}
async function serverFor(t){
 const timers=new Set(),requests=[];
 const server=http.createServer((request,response)=>{
  requests.push(request.url);
  const send=()=>{
   response.writeHead(200,{'content-type':request.url.endsWith('.js')?'text/javascript':'text/html; charset=utf-8'});
   if(request.url==='/defer.js')response.end('globalThis.deferBytes="real defer bytes"');
   else if(request.url==='/async.js')response.end('globalThis.asyncBytes="real async bytes"');
   else if(request.url==='/child')response.end('<!doctype html><p id=child>real child bytes</p>');
   else response.end('<!doctype html><script defer src="/defer.js"></script><script async src="/async.js"></script><p id=main>real parent bytes</p>');
  };
  if(request.url.endsWith('.js')){const timer=setTimeout(()=>{timers.delete(timer);send()},request.url==='/defer.js'?20:80);timers.add(timer)}else send();
 });
 server.listen(0,'127.0.0.1');await once(server,'listening');console.log('actual-capture-fixture-listening '+JSON.stringify({pid:process.pid,port:server.address().port}));
 t.after(async()=>{for(const timer of timers)clearTimeout(timer);server.closeAllConnections();await new Promise(resolve=>server.close(resolve));console.log('actual-capture-fixture-closed '+JSON.stringify({pid:process.pid}))});
 return {server,requests,origin:'http://127.0.0.1:'+server.address().port};
}
function ownerFor(t){const stop=beginInitialLoadCapture();t.after(stop);const browser=new Browser({timeout:1000,loadResources:['script','iframe']});t.after(()=>browser.close());return {stop,browser,page:browser.createPage()}}
function clean(snapshot){assert.equal(rows(snapshot,'unavailable').length,0);assert.equal(rows(snapshot,'descriptorChangedDuringCapture').length,0)}
test('capture observes real initial ResourceQueue slots and defer/async callbacks without changing actual bytes',options,async t=>{
 const {origin,requests}=await serverFor(t),{page,stop}=ownerFor(t);
 await page.navigate(origin+'/main');
 const document=backend(page),snapshot=inspectInitialLoadCapture(document),pushes=rows(snapshot,'queuePush');
 assert.equal(pushes.length,2);assert.deepEqual(pushes.map(row=>row.slot),[1,2]);
 assert.deepEqual(pushes.map(row=>row.argumentCount),[3,4]);assert.deepEqual(pushes.map(row=>row.keepLast),[null,true]);
 assert.equal(pushes[0].request,pushes[1].request);assert.notEqual(pushes[0].onLoad,pushes[1].onLoad);
 assert.ok(pushes.every(row=>row.onError===null&&row.element===null&&row.request!==null&&row.result!==null));
 const listeners=rows(snapshot,'listenerSlot');assert.deepEqual(listeners.map(row=>row.queue).sort(),['async','defer']);
 assert.ok(listeners.every(row=>row.callbackIdentityUnchanged&&row.callback===row.storedCallback&&row.argumentCount===1));
 assert.equal(rows(snapshot,'backendCloseEnd').at(-1).registrations,2);
 assert.equal(snapshot.task.taskCount,1);assert.equal(snapshot.task.actualTaskDelivered,true);assert.equal(snapshot.task.initialBlankClaimed,false);
 assert.deepEqual(plain(page.evaluate('({defer:deferBytes,async:asyncBytes,body:document.getElementById("main").textContent,state:document.readyState})')),{defer:'real defer bytes',async:'real async bytes',body:'real parent bytes',state:'complete'});
 assert.ok(requests.includes('/defer.js')&&requests.includes('/async.js'));clean(snapshot);
 stop();const stopped=inspectInitialLoadCapture(document);assert.equal(stopped.activeMethods,0);assert.equal(stopped.stopped,true);
 assert.ok(rows(stopped,'methodRestored').every(row=>row.exact));
 console.log('actual-main-capture '+JSON.stringify(stopped));
});
test('capture observes real HTTP frame resolve/reject and parent continuation with original Promise then restored',options,async t=>{
 const {origin}=await serverFor(t),{page,stop}=ownerFor(t);await page.navigate(origin+'/main');
 const window=page.dom.window,blank=window.document.createElement('iframe');window.document.body.append(blank);const blankDocument=platformFactoryRecord(blank.contentDocument).implementation,blankTask=inspectInitialLoadCapture(blankDocument).task;assert.equal(blankTask.taskCount,1);assert.equal(blankTask.initialBlankClaimed,true);assert.equal(blankTask.actualTaskRetired,true);assert.equal(blankTask.actualTaskDelivered,false);const frame=window.document.createElement('iframe');frame.src=origin+'/child';
 const loaded=new Promise((resolve,reject)=>{frame.addEventListener('load',resolve,{once:true});frame.addEventListener('error',reject,{once:true})});
 window.document.body.append(frame);await actualLoad(loaded);
 const document=platformFactoryRecord(frame.contentDocument).implementation,snapshot=inspectInitialLoadCapture(document);
 assert.notEqual(snapshot.task.capture,blankTask.capture);assert.equal(snapshot.task.actualTaskRetired,false);assert.equal(snapshot.task.actualTaskDelivered,true);const births=rows(snapshot,'frameResolveRejectBirth'),continuations=rows(snapshot,'parentContinuationBirth');
 assert.equal(births.length,1);assert.equal(births[0].nativePromise,true);
 assert.equal(births[0].load.length,1);assert.equal(births[0].error.length,1);
 assert.ok(births[0].load[0].callback!==null&&births[0].error[0].callback!==null);
 assert.notEqual(births[0].load[0].callback,births[0].error[0].callback);
 assert.equal(continuations.length,1);assert.equal(continuations[0].promise,births[0].resultPromise);
 assert.equal(continuations[0].argumentCount,1);assert.notEqual(continuations[0].onFulfilled,null);assert.equal(continuations[0].onRejected,null);
 assert.equal(continuations[0].descriptorRestoredBeforeForward,true);
 assert.equal(rows(snapshot,'backendCloseEnd').at(-1).frameDepth,1);assert.equal(snapshot.frameDepth,0);
 assert.equal(frame.contentDocument.getElementById('child').textContent,'real child bytes');assert.equal(frame.contentDocument.readyState,'complete');clean(snapshot);
 stop();assert.equal(inspectInitialLoadCapture(document).activeMethods,0);
 console.log('actual-frame-capture '+JSON.stringify(inspectInitialLoadCapture(document)));
});
test('capture introduces no additional authored readyState or Document.addEventListener reads',options,async t=>{
 const {origin}=await serverFor(t),actual=[];
 for(const enabled of [false,true]){
  const stop=enabled?beginInitialLoadCapture():()=>{},browser=new Browser({timeout:1000,loadResources:['script','iframe']});
  try{
   const page=browser.createPage();page.newDocumentScripts.set('owned-forwarding-overrides',{source:`globalThis.actualReads=[];const ready=Object.getOwnPropertyDescriptor(Document.prototype,'readyState').get;Object.defineProperty(document,'readyState',{configurable:true,get(){actualReads.push('ready');return ready.call(this)}});const add=document.addEventListener;Object.defineProperty(document,'addEventListener',{configurable:true,writable:true,value:function(...args){actualReads.push('add:'+String(args[0]));return Reflect.apply(add,this,args)}});`});
   await page.navigate(origin+'/main');actual.push(plain(page.evaluate('({reads:actualReads,state:document.readyState,body:document.getElementById("main").textContent,defer:deferBytes,async:asyncBytes})')));
  }finally{await browser.close();stop()}
 }
 assert.deepEqual(actual[1],actual[0]);assert.ok(actual[0].reads.includes('ready')&&actual[0].reads.includes('add:load'));
 console.log('actual-no-additional-author-reads '+JSON.stringify(actual));
});
test('actual ResourceQueue callback exception identity and exact method descriptors survive capture',options,async t=>{
 const {page,stop}=ownerFor(t);await page.navigate('data:text/html,<p>actual queue exception owner</p>');
 const document=backend(page),queue=document._queue,prior=own(queue,'push'),sentinel=new Error('real owned queue callback error');
 queue.paused=true;let calls=0;await queue.push(Promise.resolve(),()=>{calls++;if(calls===1)throw sentinel});
 assert.throws(()=>document.close(),error=>error===sentinel);assert.deepEqual(own(queue,'push'),prior);
 const snapshot=inspectInitialLoadCapture(document);assert.equal(rows(snapshot,'backendCloseEnd').at(-1).registrations,0);assert.equal(calls,1);clean(snapshot);
 stop();assert.equal(inspectInitialLoadCapture(document).activeMethods,0);
 console.log('actual-exception-capture '+JSON.stringify(inspectInitialLoadCapture(document)));
});
function startTicks(pid){const text=readFileSync('/proc/'+pid+'/stat','utf8');return text.slice(text.lastIndexOf(')')+2).trim().split(/\s+/)[19]}
async function child(mode){
 const child=spawn(process.execPath,['--experimental-vm-modules',new URL('./fixtures/initial-load-capture-timeout.mjs',import.meta.url).pathname,mode],{stdio:['ignore','pipe','pipe']});
 const identity={pid:child.pid,startTicks:startTicks(child.pid),mode};console.log('actual-capture-child-start '+JSON.stringify(identity));
 let stdout='',stderr='',expired=false;child.stdout.on('data',value=>stdout+=value);child.stderr.on('data',value=>stderr+=value);
 const timer=setTimeout(()=>{expired=true;assert.equal(startTicks(child.pid),identity.startTicks);child.kill('SIGKILL')},7000);
 const [exit,signal]=await once(child,'exit');clearTimeout(timer);assert.equal(expired,false,stderr);assert.equal(exit,0,stderr);assert.equal(signal,null);
 return {...JSON.parse(stdout.trim()),identity};
}
for(const mode of ['single','nested'])test('actual200ms '+mode+' abandoned close capture restores private descriptors outside the terminated VM',options,async()=>{
 const value=await child(mode);console.log('actual-capture-recovery '+JSON.stringify(value));
 assert.equal(value.timeoutObserved,true);assert.equal(value.actualVMPolicyMilliseconds,200);assert.equal(value.pushDescriptorExact,true);
 assert.equal(value.abandoned.length,1);assert.ok(value.abandoned[0].invocation!==null&&value.abandoned[0].restoredMethods.length===1);
 assert.equal(value.abandoned[0].frameDepth,0);assert.equal(value.activeMethodsBeforeStop,2);assert.equal(value.activeMethodsAfterStop,0);
 assert.ok(value.restorations.every(row=>row.exact));assert.equal(value.futureQuery,42);assert.equal(value.closed,true);
 if(mode==='nested'){assert.equal(value.liveOuterPreserved,true);assert.equal(value.outerActiveMethodsDuringInnerRecovery,3);assert.equal(value.outerPushDescriptorExact,true);assert.equal(value.outerAbandoned,0)}
});
