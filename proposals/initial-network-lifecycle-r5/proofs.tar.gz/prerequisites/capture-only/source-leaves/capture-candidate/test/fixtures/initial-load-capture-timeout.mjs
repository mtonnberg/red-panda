// Real ResourceQueue resumes invoke the actual controlled callback. No event
// output, completion result or recovery state is fabricated by this fixture.
import vm from 'node:vm';
import {Browser} from '../../src/browser.js';
import {platformFactoryRecord} from '../../src/platform-factories.js';
import {beginInitialLoadCapture,inspectInitialLoadCapture} from '../../src/initial-load-capture.js';
import {withOwnedDispatchRecovery} from '../../src/dom-dispatch-recovery.js';
const mode=process.argv[2];if(!['single','nested'].includes(mode))throw Error('Explicit owned mode required');
const own=Object.getOwnPropertyDescriptor,same=(a,b)=>a===undefined||b===undefined?a===b:['value','get','set','writable','configurable','enumerable'].every(key=>a[key]===b[key]);
const stop=beginInitialLoadCapture(),browser=new Browser({timeout:1000}),inner=browser.createPage();let outer,report;
try{
 await inner.navigate('data:text/html,<p>real inner queue owner</p>');
 const innerDocument=platformFactoryRecord(inner.dom.window.document).implementation,innerQueue=innerDocument._queue,prior=own(innerQueue,'push');
 const context=vm.createContext({}),loop=vm.runInContext('(function(){while(true){}})',context);let calls=0,error,liveOuterPreserved=false,outerActiveMethodsDuringInnerRecovery=null,outerPrior;
 innerQueue.paused=true;await innerQueue.push(Promise.resolve(),()=>{if(++calls===1)Reflect.apply(loop,undefined,[])});
 context.closeInner=()=>innerDocument.close();
 function timed(){try{vm.runInContext('closeInner()',context,{timeout:200,displayErrors:false})}catch(value){error=value;if(value.code!=='ERR_SCRIPT_EXECUTION_TIMEOUT')throw value}}
 if(mode==='single')withOwnedDispatchRecovery(timed);
 else{
  outer=browser.createPage();await outer.navigate('data:text/html,<p>real outer queue owner</p>');
  const outerDocument=platformFactoryRecord(outer.dom.window.document).implementation,outerQueue=outerDocument._queue;outerPrior=own(outerQueue,'push');
  outerQueue.paused=true;await outerQueue.push(Promise.resolve(),()=>{
   const activeOuter=own(outerQueue,'push');withOwnedDispatchRecovery(timed);
   liveOuterPreserved=same(own(outerQueue,'push'),activeOuter);
   outerActiveMethodsDuringInnerRecovery=inspectInitialLoadCapture(outerDocument).activeMethods;
  });
  outerDocument.close();
 }
 await new Promise(resolve=>setImmediate(resolve));
 const before=inspectInitialLoadCapture(innerDocument),outerDocument=outer&&platformFactoryRecord(outer.dom.window.document).implementation;
 report={mode,pid:process.pid,actualVMPolicyMilliseconds:200,ownedChildDeadlineMilliseconds:7000,timeoutObserved:error?.code==='ERR_SCRIPT_EXECUTION_TIMEOUT',actualError:error?{name:error.name,code:error.code,message:error.message}:null,pushDescriptorExact:same(own(innerQueue,'push'),prior),abandoned:before.rows.filter(row=>row.kind==='abandonedInvocation'),activeMethodsBeforeStop:before.activeMethods,liveOuterPreserved,outerActiveMethodsDuringInnerRecovery,outerPushDescriptorExact:outerDocument?same(own(outerDocument._queue,'push'),outerPrior):null,outerAbandoned:outerDocument?inspectInitialLoadCapture(outerDocument).rows.filter(row=>row.kind==='abandonedInvocation').length:null,futureQuery:inner.evaluate('6*7')};
 stop();const after=inspectInitialLoadCapture(innerDocument);report.activeMethodsAfterStop=after.activeMethods;report.restorations=after.rows.filter(row=>row.kind==='methodRestored');
}finally{stop();await browser.close();if(report){report.closed=inner.closed;console.log(JSON.stringify(report))}}
