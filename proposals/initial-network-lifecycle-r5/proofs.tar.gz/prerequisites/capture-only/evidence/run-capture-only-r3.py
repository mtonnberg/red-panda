"""UNRUN. Six syntax checks, then six singly selected actual capture controls.
No Native repeat, delivery replacement, Source replay or Root edit is authorized.
"""
from pathlib import Path
import hashlib,json,os,re,signal,socket,subprocess,time,traceback
R=Path(__file__).resolve().parent.parent
O=R/'run-capture-only-r3'
assert not O.exists(), 'Preserve prior epoch; never reuse its output directory'
O.mkdir()
P=Path('/workspace/red-panda')
N='/workspace/shared/rea-tools/node_modules/.bin/node'
started=time.monotonic()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def graph(root):
 files={str(p.relative_to(root)):sha(p) for d in ['src','test','native','scripts','bin'] for p in(root/d).rglob('*') if p.is_file() and not p.is_symlink()}
 files.update({n:sha(root/n)for n in ['package.json','package-lock.json']})
 return dict(sorted(files.items()))
def identity(pid):
 text=Path('/proc/'+str(pid)+'/stat').read_text();parts=text[text.rfind(')')+2:].split()
 return {'pid':pid,'startTicks':parts[19],'processGroup':int(parts[2])}
def write(name,value):
 with(O/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
def absence(pid):
 try:return {'pid':pid,'present':True,'actual':identity(pid)}
 except FileNotFoundError:return {'pid':pid,'present':False}
 except Exception as error:return {'pid':pid,'present':None,'inspectionError':str(error)}
m=json.loads((R/'evidence/source-candidate-r3.json').read_text())
base=json.loads((R/'root645-base.json').read_text())
plan=json.loads((R/'evidence/probe-plan-r3.json').read_text())
contracts={str(path):sha(path) for path in [R/'root645-base.json',R/'evidence/source-candidate-r3.json',R/'evidence/probe-plan-r3.json',Path(__file__),R/'evidence/capture-only.patch',*map(Path,plan['externalContracts'])]}
before={'externalRoot645':graph(P),'ownedBaseline645':graph(R/'baseline645'),'ownedCapture648':graph(R/'capture-candidate'),'contracts':contracts}
write('before.json',before)
commands=[];failure=None;current=None;currentIdentity=None;observed=[];ports=[];guard=None
ENV=os.environ.copy();ENV['NODE_USE_ENV_PROXY']='1';ENV['PATH']=str(Path(N).parent)+':'+ENV.get('PATH','')
proxy=','.join([ENV.get('NO_PROXY',''),ENV.get('no_proxy',''),'0.0.0.0','127.0.0.1','127.0.0.2','127.255.1.2','localhost','::1','[::1]'])
ENV['NO_PROXY']=proxy;ENV['no_proxy']=proxy

def terminate_current():
 if current is not None and current.poll()is None:
  actual=identity(current.pid)
  assert actual==currentIdentity,'Refuse signal after actual PID/start/group identity change'
  assert actual['processGroup']==current.pid,'Only the owned new-session process group may be signaled'
  write('before-owned-group-signal-'+str(current.pid)+'.json',actual)
  os.killpg(current.pid,signal.SIGKILL);current.wait()

def run(label,args,expected_pass=None):
 global current,currentIdentity
 begin=time.monotonic()
 with(O/(label+'.stdout')).open('x')as out,(O/(label+'.stderr')).open('x')as err:
  current=subprocess.Popen([N,*args],cwd=R/'capture-candidate',env=ENV,stdout=out,stderr=err,start_new_session=True)
  currentIdentity=identity(current.pid);observed.append(currentIdentity);write(label+'-identity-before-wait.json',currentIdentity)
  print(json.dumps({'started':label,**currentIdentity}),flush=True)
  expired=False
  try:code=current.wait(timeout=max(.01,90-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:expired=True;terminate_current();code=current.returncode
 row={'label':label,'identity':currentIdentity,'command':[N,*args],'exit':code,'administrativeExpiry':expired,'seconds':time.monotonic()-begin}
 text=(O/(label+'.stdout')).read_text()
 for match in re.finditer(r'actual-capture-child-start (\{[^\n]+\})',text):
  child=json.loads(match.group(1));observed.append(child)
 for match in re.finditer(r'actual-capture-fixture-listening (\{[^\n]+\})',text):ports.append(json.loads(match.group(1)))
 if expected_pass is not None:
  numbers={name:int(match.group(1))for name in ['pass','fail','cancelled','skipped']if(match:=re.search(r'^# '+name+r' (\d+)\s*$',text,re.M))}
  row['actualTAPSummary']=numbers;row['expectedExecutedPasses']=expected_pass
 commands.append(row);current=None;currentIdentity=None;write(label+'-result.json',row);print(json.dumps(row),flush=True)
 if code or expired:raise RuntimeError('Actual capture gate failed: '+label)
 if expected_pass is not None:assert numbers.get('pass')==expected_pass and numbers.get('fail')==0 and numbers.get('cancelled')==0,row
try:
 assert before['externalRoot645']==base['source645'],'Current Root changed; create a fresh protection derivative'
 assert before['ownedBaseline645']==base['source645']
 assert before['ownedCapture648']==m['ownedCandidate648']
 assert all(sha(P/n)==value for n,value in base['artifacts18'].items())
 assert sha(P/'native/runtime.cc')==base['runtimeSource95']
 for path,digest in plan['externalContracts'].items():assert sha(Path(path))==digest, path
 for name in plan['syntaxFiles']:run('syntax-'+Path(name).name,['--check',name])
 for index,title in enumerate(plan['selectedCaseTitles'],1):
  run('capture-'+str(index),['--experimental-vm-modules','--test','--test-concurrency=1','--test-reporter=tap','--test-name-pattern','^'+re.escape(title)+'$', 'test/initial-load-capture.test.js'],1)
except BaseException as error:failure={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 try:terminate_current()
 except BaseException as error:failure={'name':'OwnedCleanupFailure','message':str(error),'previous':failure}
 closures=[absence(value['pid'])for value in observed]
 portRows=[]
 for value in ports:
  try:
   with socket.create_connection(('127.0.0.1',value['port']),timeout=.25):portRows.append({**value,'closed':False})
  except ConnectionRefusedError:portRows.append({**value,'closed':True})
  except Exception as error:portRows.append({**value,'closed':None,'inspectionError':str(error)})
 guards={'externalRoot645Unchanged':graph(P)==before['externalRoot645'],'ownedBaseline645Unchanged':graph(R/'baseline645')==before['ownedBaseline645'],'ownedCapture648Unchanged':graph(R/'capture-candidate')==before['ownedCapture648'],'Root18ArtifactsUnchanged':all(sha(P/n)==value for n,value in base['artifacts18'].items()),'Root95NativeSourceUnchanged':sha(P/'native/runtime.cc')==base['runtimeSource95'],'contractsUnchanged':all(sha(Path(path))==value for path,value in contracts.items())}
 write('after-guards.json',guards);write('closure-readback.json',{'reportedIdentities':observed,'processReadback':closures,'fixturePortReadback':portRows,'noWebSocketPortsUsed':True,'noRecursiveDescendantInventoryClaim':True})
 if not all(guards.values()):failure={'name':'SourceGuardChanged','previous':failure}
 if any(value['present']is not False for value in closures)or any(value['closed']is not True for value in portRows):failure={'name':'OwnedClosureUnconfirmed','previous':failure}
 write('status.json',{'complete':failure is None,'failure':failure,'commands':commands,'seconds':time.monotonic()-started,'expectedExecutedCases':6,'separateSinglySelectedCasesStopFirst':True,'unmatchedCaseSelectionSkipsReportedAsActual':True,'API2500CeilingNotExercisedNoCDP':True,'PageScript1000Milliseconds':True,'frameLoad2000Milliseconds':True,'actualRecoveryVM200Milliseconds':True,'ownedRecoveryChild7000Milliseconds':True,'testCase8000Milliseconds':True,'administrative90Seconds':True,'captureOnlyNoProducerReplacement':True,'NativeFourPreviouslyObservedNotRepeated':True,'R1R2CandidatesStillUnrun':True,'Source96NotRun':True,'RootUnchanged':guards['externalRoot645Unchanged']})
 print(json.dumps({'complete':failure is None,'failure':failure,'seconds':time.monotonic()-started}),flush=True)
if failure:raise SystemExit(1)
