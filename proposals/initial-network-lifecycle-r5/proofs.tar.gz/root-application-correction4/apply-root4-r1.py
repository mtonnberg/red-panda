#!/usr/bin/env python3
"""UNEXECUTED explicit Root application. No tests/build/restart/git are chained."""
from pathlib import Path
import argparse,hashlib,json,os,signal,time
P=Path(__file__).parent;ROOT=Path('/workspace/red-panda');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise RuntimeError(message)
def load(p):return json.loads(Path(p).read_text())
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
def identity(pid):
 try:
  p=Path('/proc')/str(pid);raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split();start=int(f[19]);uid=int(next(s.split()[1]for s in(p/'status').read_text().splitlines()if s.startswith('Uid:')));argv=(p/'cmdline').read_bytes().rstrip(b'\0').decode().split('\0');again=(p/'stat').read_text();a=again[again.rfind(')')+2:].split();require(int(a[19])==start,'PID identity changed while reading');return{'pid':pid,'startTicks':start,'uid':uid,'argv':argv}
 except(FileNotFoundError,ProcessLookupError):return None

def inventory(base,scopes):
 out=set()
 for n in scopes:
  p=base/n;require(p.exists()and not p.is_symlink(),'Missing or linked source scope '+str(p))
  for f in p.rglob('*')if p.is_dir()else[p]:
   require(not f.is_symlink(),'Unexpected linked source '+str(f))
   if f.is_file():out.add(str(f.relative_to(base)))
 return out

def verify(base,table,scopes):
 require(inventory(base,scopes)==set(table),'Full source inventory differs '+str(base))
 require(all((base/n).is_file()and sha(base/n)==v for n,v in table.items()),'Frozen source bytes differ '+str(base))

def atomic(path,body,mode):
 # One same-directory exclusive temporary; no directory-wide replacement.
 temporary=path.with_name('.'+path.name+'.initial-blocking-'+str(os.getpid())+'.tmp')
 try:
  fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
  with os.fdopen(fd,'wb')as stream:stream.write(body);stream.flush();os.fsync(stream.fileno())
  os.chmod(temporary,mode);os.replace(temporary,path)
 finally:
  if temporary.exists():temporary.unlink()

a=argparse.ArgumentParser();a.add_argument('--execute-reviewed-root-apply',action='store_true');opts=a.parse_args();require(opts.execute_reviewed_root_apply,'Explicit Parent review and exclusive Root application grant required')
planPath=P/'application-plan-r1.json';require(sha(planPath)=='e566bb10e07abd0e5a7f40db3b842aa0a40fad478b2f0e1a7bab78340c08bd8e','Reviewed application plan differs');plan=load(planPath);sourcePath=Path(plan['sourcePath']);require(sha(sourcePath)==plan['sourceSHA256'],'Reviewed source map differs');source=load(sourcePath);before=source[plan['RootBeforeKey']];after=source[plan['candidateAfterKey']];candidate=Path(plan['candidateRoot']);rows=plan['rows'];scopes=plan['sourceScopes'];expected=plan['expectedService'];require(len(before)==652 and len(after)==654 and len(rows)==4,'Exact source populations/leaf count required');require(set(n for n,v in rows.items()if v['before']is not None)==set(plan['requireBackups'])and len(plan['requireBackups'])==2,'Exactly two original-file backups required');require(source['leaves']==rows,'Reviewed leaves differ');require(sha(plan['patchPath'])==plan['patchSHA256'],'Patch drift')
for name in ['actualNarrowPositiveStatus','causalPositiveAndActual652Negative','oldRoot12ApplicationJournalPreserved']:
 item=plan[name];require(sha(item['path'])==item['SHA256'],'Actual receipt drift '+name)
require(load(plan['actualNarrowPositiveStatus']['path'])['state']=='PASS_CANDIDATE_CAUSAL_NEW2_AND_ORIGINAL2_SELECTED','No actual reviewed positive gate')
externalDescriptor=load('/workspace/shared/network-private-initial-producer-r4/report-observation-r5/handoff-current652/freeze-first.json')['guardMaps']['external'];externalFile=Path(externalDescriptor['path']);require(sha(externalFile)==externalDescriptor['SHA256'],'External input map drift');external=load(externalFile)
def immutableInputs():
 require(sha(planPath)=='e566bb10e07abd0e5a7f40db3b842aa0a40fad478b2f0e1a7bab78340c08bd8e'and sha(sourcePath)==plan['sourceSHA256'],'Plan/source drift');verify(candidate,after,scopes)
 require(all(Path(n).is_file()and sha(n)==v for n,v in external.items()),'Installed dependency/contract input drift')
 require(len(plan['native18'])==18 and sha(ROOT/'native/runtime.cc')==plan['CPP95'],'Runtime95 changed')
 for n,v in plan['native18'].items():require(sha(ROOT/n)==sha(candidate/n)==v,'Native18 changed '+n)
immutableInputs();verify(ROOT,before,scopes);require(identity(expected['pid'])==expected,'Current exact owned service identity differs; no stop or application')
backup=P/'backup-before';journal=P/'journal.json';require(not backup.exists()and not journal.exists(),'Fresh backup/journal required');backup.mkdir();modes={};staged={}
for n,leaf in rows.items():
 p=ROOT/n;q=candidate/n;require(sha(q)==leaf['after'],'Candidate leaf differs '+n);staged[n]=q.read_bytes()
 if leaf['before']is not None:
  require(sha(p)==leaf['before'],'Before leaf differs '+n);b=backup/n;b.parent.mkdir(parents=True,exist_ok=True);body=p.read_bytes()
  with b.open('xb')as stream:stream.write(body)
  require(sha(b)==leaf['before'],'Backup verification failed '+n);modes[n]=p.stat().st_mode&0o777
 else:require(not p.exists(),'New target already exists '+n);modes[n]=q.stat().st_mode&0o777
j={'state':'PRECHECKED_BACKED_UP_NOT_APPLIED','RootBefore652':before,'RootExpected654':after,'rows':rows,'modes':modes,'oldServiceExpected':expected,'backups':{n:sha(backup/n)for n in plan['requireBackups']},'applicationPlanSHA256':sha(planPath),'sourceMapSHA256':sha(sourcePath),'patchSHA256':plan['patchSHA256'],'actualNarrowPositiveStatusSHA256':plan['actualNarrowPositiveStatus']['SHA256'],'applied':[],'rollback':[],'oldRoot12JournalNotOverwritten':True,'native18Unchanged':True,'installedFullAndLiveSmoke':'UNRUN','automaticTestsBuildRestartOrGit':False};save(journal,j)
try:
 verify(ROOT,before,scopes);immutableInputs();require(identity(expected['pid'])==expected,'Exact service changed before stop')
 require(hasattr(os,'pidfd_open')and hasattr(signal,'pidfd_send_signal'),'Native PID handle signalling unavailable; refuse unchecked stop')
 fd=os.pidfd_open(expected['pid'])
 try:
  require(identity(expected['pid'])==expected,'Exact service changed after PID handle capture');j['actualServiceIdentityBeforeStop']=identity(expected['pid']);signal.pidfd_send_signal(fd,signal.SIGTERM);j['serviceSignal']='SIGTERM via captured pidfd after exact PID/start/uid/argv recheck';save(journal,j)
 finally:os.close(fd)
 deadline=time.monotonic()+3
 while identity(expected['pid'])is not None and time.monotonic()<deadline:time.sleep(.01)
 require(identity(expected['pid'])is None,'Old owned service not absent before Root mutation');j['oldServiceAbsentBeforeMutation']=True;save(journal,j)
 for n,leaf in rows.items():
  p=ROOT/n
  if leaf['before']is None:require(not p.exists(),'New target appeared '+n)
  else:require(sha(p)==leaf['before'],'Root target changed before replacement '+n)
  j['pendingTarget']=n;save(journal,j);atomic(p,staged[n],modes[n]);j['applied'].append(n);j['pendingTarget']=None;require(sha(p)==leaf['after'],'After byte verification failed '+n);save(journal,j)
 verify(ROOT,after,scopes);immutableInputs();j['state']='APPLIED_EXACT_ROOT4_654_FULL_VALIDATION_UNRUN';j['allOther652InputsPreserved']=all(after.get(n)==v for n,v in before.items()if n not in rows);save(journal,j)
except BaseException as error:
 j['failure']={'type':type(error).__name__,'message':str(error)}
 attempted=j['applied']+([j['pendingTarget']]if j.get('pendingTarget')and j['pendingTarget']not in j['applied']else[])
 for n in reversed(attempted):
  leaf=rows[n];p=ROOT/n
  try:
   if leaf['before']is None and not p.exists():j['rollback'].append({'path':n,'notCreated':True});continue
   if leaf['before']is not None and sha(p)==leaf['before']:j['rollback'].append({'path':n,'unchangedBefore':True});continue
   require(sha(p)==leaf['after'],'Refuse clobbering externally modified after-file '+n)
   if leaf['before']is None:p.unlink()
   else:require(sha(backup/n)==leaf['before'],'Rollback backup differs '+n);atomic(p,(backup/n).read_bytes(),modes[n])
   j['rollback'].append({'path':n,'restoredBefore':leaf['before']})
  except BaseException as rollbackError:j.setdefault('rollbackFailures',[]).append({'path':n,'type':type(rollbackError).__name__,'message':str(rollbackError)})
 try:verify(ROOT,before,scopes);j['rollbackFull652Verified']=True
 except BaseException as verifyError:j['rollbackFull652Verified']=False;j['rollbackVerificationError']=str(verifyError)
 j['state']='APPLICATION_FAILED_ROLLBACK_RECORDED';save(journal,j);raise
print(json.dumps({'state':j['state'],'journal':str(journal),'RootCount':len(after),'applied':j['applied'],'oldServiceStopped':j.get('oldServiceAbsentBeforeMutation'),'restartAndFullValidation':'NOT_EXECUTED'},indent=2))
