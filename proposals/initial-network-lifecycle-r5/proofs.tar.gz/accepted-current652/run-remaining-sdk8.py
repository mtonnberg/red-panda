#!/usr/bin/env python3
"""Reusable frozen-spec skeleton. No default candidate; no JS until explicit run."""
from pathlib import Path
import argparse,hashlib,json,os,re,resource,signal,subprocess,time

P=Path(__file__).parent;ROOT=Path('/workspace/red-panda');SERVICE=858354
NODE_SHA='e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb'
CPP95='95bba30f4013139999dc9b843b45bdb5ddc1802145431fc6386bddc85975cd36'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise RuntimeError(message)
def load(path):return json.loads(Path(path).read_text())
def readmap(descriptor):
 path=Path(descriptor['path']);require(sha(path)==descriptor['SHA256'],'Map descriptor drift: '+str(path));value=load(path)
 for part in descriptor.get('keyPath',[]):value=value[part]
 require(isinstance(value,dict)and value and all(isinstance(k,str)and isinstance(v,str)and re.fullmatch('[0-9a-f]{64}',v)for k,v in value.items()),'Expected explicit nonempty full-SHA map')
 base=Path(descriptor['base']);return {str(base/name):value for name,value in value.items()}
def verify(table):
 bad=[n for n,h in table.items()if not Path(n).is_file()or sha(n)!=h]
 require(not bad,'Frozen input mismatch: '+str(bad));return len(table)
def inventory(base,scopes):
 paths=set()
 for name in scopes:
  path=base/name;require(path.exists(),'Inventory scope missing '+str(path));require(not path.is_symlink(),'Inventory scope itself must be physical: '+str(path))
  if path.is_dir():
   for file in path.rglob('*'):
    require(not file.is_symlink(),'Unfrozen symlink inside guarded source scope: '+str(file))
    if file.is_file():paths.add(str(file))
  else:paths.add(str(path))
 return paths
def proc(pid,required=False):
 try:
  text=(Path('/proc')/str(pid)/'stat').read_text();f=text[text.rfind(')')+2:].split();return {'pid':int(pid),'state':f[0],'parent':int(f[1]),'pgrp':int(f[2]),'sid':int(f[3]),'startTicks':int(f[19])}
 except(FileNotFoundError,ProcessLookupError):return None
 except(OSError,ValueError,IndexError)as error:
  if required:raise RuntimeError('Cannot verify owned process identity: '+str(pid))from error
  return None
def track(child,owned):
 rows=[]
 for file in Path('/proc').iterdir():
  if file.name.isdecimal()and(row:=proc(file.name)):rows.append(row)
 changed=True
 while changed:
  changed=False;parents={pid for(pid,start),record in owned.items()if(current:=proc(pid,True))and current['startTicks']==start}
  for row in rows:
   if row['pgrp']==child.pid or row['sid']==child.pid or row['parent']in parents:
    require(row['pid']!=SERVICE,'Excluded production service entered job ownership; refuse signalling')
    key=(row['pid'],row['startTicks'])
    if key not in owned:owned[key]=row;changed=True
 live=[]
 for(pid,start),record in owned.items():
  now=proc(pid,True)
  if now and now['startTicks']==start:live.append(now)
 return live
def cleanup(child,owned):
 before=track(child,owned)
 for sig,seconds in [(signal.SIGTERM,2),(signal.SIGKILL,3)]:
  for row in track(child,owned):
   require(row['pid']!=SERVICE,'Never signal excluded main service')
   if row['state']!='Z':
    now=proc(row['pid'],True)
    if now and now['startTicks']==row['startTicks']:
     try:os.kill(row['pid'],sig)
     except ProcessLookupError:pass
  end=time.monotonic()+seconds
  while time.monotonic()<end and any(r['state']!='Z'for r in track(child,owned)):time.sleep(.02)
  if not any(r['state']!='Z'for r in track(child,owned)):break
 child.wait(timeout=3);after=track(child,owned);return {'before':before,'observed':list(owned.values()),'after':after,'liveRemaining':[r for r in after if r['state']!='Z']}

parser=argparse.ArgumentParser();parser.add_argument('--execute-after-root-review',action='store_true');a=parser.parse_args();require(a.execute_after_root_review,'Explicit Parent lease required')
H=Path(__file__).parent;spec=load(H/'freeze-first.json');plan=load(H/'remaining-sdk-plan.json');require(sha(H/'freeze-first.json')=='96fafaae10e698fdf2696025de8d028387679caa1f74022260e8cc7a41420425','Frozen source protection spec differs');require(sha(H/'remaining-sdk-plan.json')=='3505e9232f2692198efa5af60bfc6703a0495fc39089c0a6bfaf61a5ed12a1f5','SDK plan differs')
require(sha('/workspace/shared/network-initial-protected-root646-r1/run-protected-tranche.py')==spec['controllerSHA256'],'Original ownership/guard helper source differs')
selfSHA=sha(__file__);candidate=Path(spec['candidateRoot']);tables={n:readmap(d)for n,d in spec['guardMaps'].items()}
def guards():
 require(sha(__file__)==selfSHA,'Controller drift');counts={n:verify(v)for n,v in tables.items()}
 for d in spec['guardMaps'].values():readmap(d)
 for name,base in [('root',ROOT),('candidate',candidate)]:require(inventory(base,spec['inventoryScopes'][name])==set(tables[name]),'Full inventory drift '+name)
 require(sha(candidate/'native/runtime.cc')==CPP95,'CPP95 drift')
 for sdk in plan['sdkScopes']:
  require(sha(sdk['node'])==sdk['nodeSHA256'],'Actual SDK executable drift')
  for name,value in sdk['matchingNativeFiles'].items():require(sha(candidate/name)==value,'Matching native artifact drift')
 return counts
guards();output=H/'run-remaining-sdk8';require(not output.exists(),'Fresh output required');output.mkdir();started=time.monotonic();status={'state':'RUNNING','commands':[],'aggregateSeconds':90,'noOriginalLimitsChanged':True,'mainServiceBefore':proc(SERVICE),'planSHA256':sha(H/'remaining-sdk-plan.json'),'controllerSHA256':selfSHA};child=None;owned={}
try:
 for sdk in plan['sdkScopes']:
  guards();env=os.environ.copy();require(env.get('NODE_OPTIONS','')==spec['inheritedNodeOptions'],'Inherited Node options differ');env.update(sdk['environment'])
  for key in ['NO_PROXY','no_proxy']:env[key]=','.join(filter(None,[env.get(key,''),'0.0.0.0,127.0.0.1,127.0.0.2,127.255.1.2,localhost,::1,[::1]']))
  env.pop('RED_PANDA_COLLECTIONS_ADDON',None);env.pop('RED_PANDA_HEAP_ADDON',None);owned={};label='node-'+sdk['version'];row={'label':label,'command':sdk['command'],'actualNodeSHA256':sdk['nodeSHA256']};status['commands'].append(row)
  with(output/(label+'.stdout')).open('xb')as stdout,(output/(label+'.stderr')).open('xb')as stderr:
   def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
   child=subprocess.Popen(sdk['command'],cwd=candidate,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=limits);initial=proc(child.pid,True);require(initial and initial['pgrp']==child.pid and initial['sid']==child.pid and child.pid!=SERVICE,'Actual owned session missing');owned[(child.pid,initial['startTicks'])]=initial;row['initialIdentity']=initial;nextprogress=time.monotonic()+20
   while child.poll()is None:
    track(child,owned);now=time.monotonic()
    if now-started>=90:row['deadlineHit']=True;break
    if now>=nextprogress:print(json.dumps({'label':label,'elapsed':now-started,'owned':track(child,owned)}),flush=True);nextprogress+=20
    time.sleep(.05)
   row['ownedLiveAfterExitBeforeCleanup']=[r for r in track(child,owned)if r['state']!='Z']if child.poll()is not None else None;row['cleanup']=cleanup(child,owned);row['exit']=child.returncode
  text=(output/(label+'.stdout')).read_text();summary={}
  for key in ['tests','pass','fail','cancelled','skipped','todo']:
   m=re.search(r'^# '+key+r' (\d+)\s*$',text,re.M);require(m is not None,'Actual TAP summary missing '+key);summary[key]=int(m.group(1))
  row['actualTAP']=summary;row['lateUncaughtActivity']=any(s in text for s in ['asynchronous activity after','triggered an unhandledRejection','generated asynchronous activity']);require(not row.get('deadlineHit')and row['exit']==0 and not row['cleanup']['liveRemaining']and not row['ownedLiveAfterExitBeforeCleanup'],'Actual SDK exit/deadline/cleanup failure');require(summary=={'tests':8,'pass':8,'fail':0,'cancelled':0,'skipped':0,'todo':0}and not row['lateUncaughtActivity'],'Actual SDK assertions/count/late activity failed');row['guards']=guards();child=None
 status['state']='PASS_ACTUAL_TWO_SDK_NEW8_EACH'
except Exception as error:status['state']='FAILED_OR_INCOMPLETE';status['failure']={'type':type(error).__name__,'message':str(error)}
finally:
 if child:
  try:status['exceptionalCleanup']=cleanup(child,owned);require(not status['exceptionalCleanup']['liveRemaining'],'Owned child remains')
  except Exception as error:status['state']='OWNED_CLEANUP_FAILURE';status['cleanupFailure']=str(error)
 status['secondsIncludingCleanup']=time.monotonic()-started;status['mainServiceAfter']=proc(SERVICE)
 try:status['guardCounts']=guards()
 except Exception as error:status['state']='GUARD_FAILURE';status['guardFailure']=str(error)
 (output/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2),flush=True)
if status['state']!='PASS_ACTUAL_TWO_SDK_NEW8_EACH':raise SystemExit(1)
