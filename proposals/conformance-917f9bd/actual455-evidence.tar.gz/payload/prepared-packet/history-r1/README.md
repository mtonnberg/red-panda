# Root645 adapted455 census — static plan, unrun

The authoritative latest whole census is `/workspace/red-panda/proposals/conformance-d41/receipt/run/summary.json`: d41fd697 completed455 rows under8 profiles,402 adapted-harness passes/50 assertion failures/3source-load timeouts in761.863s. Its ledger, negatives and reports remain unchanged. Historical full compatibility inventories are `docs/reference/compatibility-remaining-audit.json`, its manifest/plan, and `upstream-fixture-inventory.json`; copies here are source inventories and older evidence, not current functional support or a new score.

This version keeps the exact same455 registration order, all689 original fixture/support identities, route helpers and8profiles. Original/adapted fixture trees,9 external harness files,7 original helpers and maps were statically byte-compared to d41. Only the previously disclosed testing.js runner-eligibility predicate recognizes RedPanda alongsideLightpanda. Actual publicUA/clientHints and all original assertions remain unchanged. Literal branding failures stay nonpasses and later unexecuted assertions stay unverified. No fixture is removed, no score is projected, and the run is never labeled strict unchanged Native fullPASS.

The future export copies actual approved RootAfter645 source/native files tied to applicationjournal149951e87259b49815fa2d2f341c786e38dc4d6ad37a6c89829f167b5d3ed3c0. It must not export the older currentGitHEAD and omit applied57 leaves. All18 real installed addon/manifests must match actual source and binary metadata; no builds, SDK substitution, install, Git root or downloads occur. Exact Rootfull/provider acceptance receipt paths are recorded and hashed after Root reviews their actual successful outcomes; their mere presence is not acceptance. Rootfull workflow89933 and provider acceptance remain pending in this static plan.

After both gates and a separate preparation lease, freeze with actual receipt paths:

    python3 /workspace/shared/registration455-root645-plan-r1/freeze-candidate.py --gate-receipt ACTUAL_ROOT_FULL_REPORT --gate-receipt ACTUAL_PROVIDER_ACCEPTANCE_REPORT

After freeze review and a separate exclusive long lease/canonical9582+9584 reservation:

    python3 /workspace/shared/registration455-root645-plan-r1/run-census-stop-setup.py --epoch adapted455-root645-r1 --overall-resource-seconds 3600

Concurrency1. Original load2s then fresh assertion2s for450 rows/8s for5rows; automation setup10s, WSglobal50, settle0, original API/VM/heap boundaries and shutdown behavior remain unchanged. Perrow administrative19/25s and aggregate3600s are retained. Expected12–25minutes is an estimate, not an increase to the original caps. No enclosing timeout is added here.

Actual candidate/tool/dependency/oracle bytes and live approved Root645/18artifacts plus relevant PS/reference/dependencies are pinned before/after. Exact fixtures/routes/helpers are unchanged, so their original metadata limits (request log10000, internal child-stderr64KiB with truncation flag) stay disclosed. External controller stdout/stderr files and raw reports are captured complete. A new Python-only orchestration helper records actual PID/startTicks/group/session, original-cap waits,20s progress during a long row and every-row checkpoints, with bounded exact owned TERM2/KILL3 cleanup. It adds no authored code or protocol-response filtering. Incomplete/setup/report/integrity/resource/owned-cleanup failures stop and leave later rowsUNRUN; ordinary observed assertion/load/assertion-timeout nonpasses retain original continue behavior. No automatic retries. A passed report with abnormal controller exit is not promoted.

Prepared scripts were Python-AST parsed only. No export, Node/browser/native/helper execution, network, tests or build has run; no Root guarded file was changed. Current pins fail closed if the approved Root645 epoch changes, requiring a new derivative. The full-controllerR2 and historical census inputs remain untouched.
