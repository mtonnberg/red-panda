// SOURCE ONLY, UNCOMPILED/UNRUN. Shared eligibility, not provenance or branding.
#include <cppgc/persistent.h>
#include <memory>
#include <node.h>
#include <v8.h>
#include "env-inl.h"
#include "node_contextify.h"
#include "node_test_fixture.h"

using node::contextify::ContextifyContext;
using namespace v8;
class OwnedProxyReservationsTest : public EnvironmentTestFixture {};
namespace {
void RejectRaw(Local<Context> host,
               Local<Function> ordinary_factory,
               node::Environment* env,
               Local<Object> raw) {
  auto* isolate=host->GetIsolate();
  Context::Scope scope(host);
  EXPECT_TRUE(env->isolate_data()->IsReservedOwnedGlobalProxy(raw));
  TryCatch caught(isolate);
  Local<Value> args[]={raw};
  EXPECT_TRUE(ordinary_factory->Call(host,Undefined(isolate),1,args).IsEmpty());
  ASSERT_TRUE(caught.HasCaught());
  auto code=caught.Exception().As<Object>()->Get(host,
      String::NewFromUtf8Literal(isolate,"code")).ToLocalChecked();
  EXPECT_TRUE(code->StrictEquals(String::NewFromUtf8Literal(isolate,"ERR_INVALID_STATE")));
  EXPECT_FALSE(raw->HasPrivate(host,env->contextify_context_private_symbol()).FromJust());
  EXPECT_FALSE(raw->HasPrivate(host,env->host_defined_option_symbol()).FromJust());
}
struct WeakRoots {
  Global<Function> retained;
  Global<Context> context;
  Global<Object> carrier;
  Global<Object> wrapper;
  Global<Object> proxy;
  cppgc::WeakPersistent<ContextifyContext> cppgc;
};
V8_NOINLINE void PrepareWeak(Isolate* isolate,node::Environment* env,
                             Local<Context> host,WeakRoots* roots) {
  HandleScope handles(isolate);
  auto carrier=node::LoadEnvironment(env,
      "return require('node:vm').prepareOwnedContext();").ToLocalChecked().As<Object>();
  node::OwnedContextOptions options;
  auto context=node::CreateOwnedContext(env,carrier,ObjectTemplate::New(isolate),
      host->GetSecurityToken(),options).ToLocalChecked();
  auto* cppgc=ContextifyContext::FromOwnedCarrier(env,carrier);
  ASSERT_NE(cppgc,nullptr);
  roots->cppgc=cppgc;
  roots->context.Reset(isolate,context);roots->context.SetWeak();
  roots->carrier.Reset(isolate,carrier);roots->carrier.SetWeak();
  roots->wrapper.Reset(isolate,cppgc->object(isolate));roots->wrapper.SetWeak();
  roots->proxy.Reset(isolate,context->Global());roots->proxy.SetWeak();
  EXPECT_TRUE(env->isolate_data()->IsReservedOwnedGlobalProxy(context->Global()));
  Context::Scope scope(context);
  auto fn=Script::Compile(context,String::NewFromUtf8Literal(isolate,"()=>42"))
      .ToLocalChecked()->Run(context).ToLocalChecked().As<Function>();
  roots->retained.Reset(isolate,fn);
}
V8_NOINLINE void CheckKept(Isolate* isolate,Local<Context> host,WeakRoots* roots) {
  HandleScope handles(isolate);
  EXPECT_NE(roots->cppgc.Get(),nullptr);
  EXPECT_EQ(roots->retained.Get(isolate)->Call(host,Undefined(isolate),0,nullptr)
      .ToLocalChecked().As<Number>()->Value(),42);
}
}  // namespace

TEST_F(OwnedProxyReservationsTest, TwoLiveDataShareActiveDetachedReusedReservation) {
  const HandleScope handles(isolate_);
  const Argv argv;
  Env first{handles,argv};
  auto host=first.context();
  auto prepare=node::LoadEnvironment(*first,
      "return require('node:vm').prepareOwnedContext;").ToLocalChecked().As<Function>();
  auto carrier=prepare->Call(host,Undefined(isolate_),0,nullptr).ToLocalChecked().As<Object>();
  auto global_template=ObjectTemplate::New(isolate_);
  node::OwnedContextOptions options;
  auto owned=node::CreateOwnedContext(*first,carrier,global_template,
      host->GetSecurityToken(),options).ToLocalChecked();
  auto raw=owned->Global();
  uv_loop_t other_loop;
  ASSERT_EQ(uv_loop_init(&other_loop),0);
  auto free_data=[](node::IsolateData* value){node::FreeIsolateData(value);};
  std::unique_ptr<node::IsolateData,decltype(free_data)> other_data{
      node::CreateIsolateData(isolate_,&other_loop,platform.get()),free_data};
  ASSERT_NE(other_data.get(),isolate_data_);
  ASSERT_EQ(other_data->isolate(),isolate_data_->isolate());
  {
    auto other_context=node::NewContext(isolate_);
    Context::Scope scope(other_context);
    auto free_env=[](node::Environment* value){node::FreeEnvironment(value);};
    std::unique_ptr<node::Environment,decltype(free_env)> other_env{
        node::CreateEnvironment(other_data.get(),other_context,{},{}),free_env};
    ASSERT_NE(other_env.get(),nullptr);
    // Shared-token control isolates the eligibility gate from an earlier SOP
    // denial. It does not establish distinct-origin policy or Promise support.
    other_context->SetSecurityToken(host->GetSecurityToken());
    auto factory=node::LoadEnvironment(other_env.get(),
        "return value=>require('node:vm').createContext(value);")
        .ToLocalChecked().As<Function>();
    RejectRaw(other_context,factory,other_env.get(),raw);
    EXPECT_EQ(node::DetachOwnedContext(*first,carrier).ToLocalChecked(),raw);
    RejectRaw(other_context,factory,other_env.get(),raw);
    Local<Object> fresh;
    {
      Context::Scope first_scope(host);
      fresh=prepare->Call(host,Undefined(isolate_),0,nullptr).ToLocalChecked().As<Object>();
      EXPECT_EQ(node::CreateOwnedContext(*first,fresh,global_template,
          host->GetSecurityToken(),options,carrier).ToLocalChecked()->Global(),raw);
    }
    RejectRaw(other_context,factory,other_env.get(),raw);
    // Nonreserved values still receive actual canonical ordinary contexts.
    auto plain=Object::New(isolate_);
    plain->CreateDataProperty(other_context,
        String::NewFromUtf8Literal(isolate_,"answer"),Integer::New(isolate_,40)).Check();
    Local<Value> argument[]={plain};
    EXPECT_EQ(factory->Call(other_context,Undefined(isolate_),1,argument)
        .ToLocalChecked(),plain);
    auto* ordinary=ContextifyContext::ContextFromContextifiedSandbox(other_env.get(),plain);
    ASSERT_NE(ordinary,nullptr);
    Context::Scope ordinary_scope(ordinary->context());
    EXPECT_EQ(Script::Compile(ordinary->context(),
        String::NewFromUtf8Literal(isolate_,"answer+=2;answer")).ToLocalChecked()
        ->Run(ordinary->context()).ToLocalChecked().As<Number>()->Value(),42);
  }
  other_data.reset(); // First Data remains; weak reservations must survive.
  EXPECT_TRUE(isolate_data_->IsReservedOwnedGlobalProxy(raw));
  EXPECT_EQ(uv_loop_close(&other_loop),0);
}

TEST_F(OwnedProxyReservationsTest, ReservationDoesNotRootActualContextOrProxy) {
  const HandleScope handles(isolate_);
  const Argv argv;
  Env env{handles,argv};
  auto roots = std::make_unique<WeakRoots>();
  PrepareWeak(isolate_,*env,env.context(),roots.get());
  ASSERT_FALSE(roots->retained.IsEmpty());
  isolate_->LowMemoryNotification();platform->DrainTasks(isolate_);
  EXPECT_FALSE(roots->context.IsEmpty());
  EXPECT_FALSE(roots->carrier.IsEmpty());
  EXPECT_FALSE(roots->wrapper.IsEmpty());
  EXPECT_FALSE(roots->proxy.IsEmpty());
  CheckKept(isolate_,env.context(),roots.get());
  roots->retained.Reset();
  for(int i=0;i<8;++i){isolate_->LowMemoryNotification();platform->DrainTasks(isolate_);}
  EXPECT_TRUE(roots->context.IsEmpty());
  EXPECT_TRUE(roots->carrier.IsEmpty());
  EXPECT_TRUE(roots->wrapper.IsEmpty());
  EXPECT_TRUE(roots->proxy.IsEmpty());
  EXPECT_EQ(roots->cppgc.Get(),nullptr);
  // Force pruning without resurrecting a collected proxy or guessing an address.
  EXPECT_FALSE(isolate_data_->IsReservedOwnedGlobalProxy(Object::New(isolate_)));
}
