// UNCOMPILED/UNRUN. Real Node-internal cppgc lifetime observation; no addon
// private-slot writes or synthetic wrapper identities.
#include <cppgc/persistent.h>
#include <memory>
#include <node.h>
#include <v8.h>
#include "node_contextify.h"
#include "node_test_fixture.h"

using node::contextify::ContextifyContext;
using namespace v8;
class OwnedContextProviderTest : public EnvironmentTestFixture {};

namespace {
struct ObservedRoots {
  Global<Function> retained;
  Global<Context> weak_context;
  Global<Object> weak_carrier;
  Global<Object> weak_wrapper;
  cppgc::WeakPersistent<ContextifyContext> weak_cppgc;
};
// Keep raw setup pointers and temporary Local handles out of the collecting
// caller's live frame; otherwise a conservative stack root can spoil the test.
V8_NOINLINE void PrepareRoots(Isolate* isolate,
                              node::Environment* env,
                              Local<Context> host,
                              ObservedRoots* roots) {
  HandleScope handles(isolate);
  Local<Value> ticket = node::LoadEnvironment(
      env, "return require('node:vm').prepareOwnedContext();").ToLocalChecked();
  ASSERT_TRUE(ticket->IsObject());
  Local<Object> carrier = ticket.As<Object>();
  Local<ObjectTemplate> global_template = ObjectTemplate::New(isolate);
  node::OwnedContextOptions options;
  Local<Context> owned = node::CreateOwnedContext(
      env, carrier, global_template, host->GetSecurityToken(), options)
      .ToLocalChecked();
  auto* backend = ContextifyContext::FromOwnedCarrier(env, carrier);
  ASSERT_NE(backend, nullptr);
  ASSERT_EQ(backend->context(), owned);
  roots->weak_cppgc = backend;
  roots->weak_context.Reset(isolate, owned);
  roots->weak_context.SetWeak();
  roots->weak_carrier.Reset(isolate, carrier);
  roots->weak_carrier.SetWeak();
  roots->weak_wrapper.Reset(isolate, backend->object(isolate));
  roots->weak_wrapper.SetWeak();
  Context::Scope owner_scope(owned);
  Local<Function> function = Script::Compile(
      owned, String::NewFromUtf8Literal(isolate, "()=>42"))
      .ToLocalChecked()->Run(owned).ToLocalChecked().As<Function>();
  roots->retained.Reset(isolate, function);
}
V8_NOINLINE void CheckActualRetainedFunction(Isolate* isolate,
                                            Local<Context> host,
                                            ObservedRoots* roots) {
  HandleScope handles(isolate);
  EXPECT_NE(roots->weak_cppgc.Get(), nullptr);
  Local<Value> answer = roots->retained.Get(isolate)
      ->Call(host, Undefined(isolate), 0, nullptr).ToLocalChecked();
  EXPECT_EQ(answer.As<Number>()->Value(), 42);
}
}  // namespace

TEST_F(OwnedContextProviderTest, RetainedClosureRootsActualCarrierAndCppgc) {
  const HandleScope outer_handles(isolate_);
  const Argv argv;
  Env env{outer_handles, argv};
  auto roots = std::make_unique<ObservedRoots>();
  PrepareRoots(isolate_, *env, env.context(), roots.get());
  ASSERT_FALSE(roots->retained.IsEmpty());
  // Only the real old function is a strong application root.
  isolate_->LowMemoryNotification();
  platform->DrainTasks(isolate_);
  ASSERT_FALSE(roots->weak_context.IsEmpty());
  ASSERT_FALSE(roots->weak_carrier.IsEmpty());
  ASSERT_FALSE(roots->weak_wrapper.IsEmpty());
  CheckActualRetainedFunction(isolate_, env.context(), roots.get());
  roots->retained.Reset();
  // Bounded observation, not an assertion replacement if collection fails.
  for (int i = 0; i < 8; ++i) {
    isolate_->LowMemoryNotification();
    platform->DrainTasks(isolate_);
  }
  EXPECT_TRUE(roots->weak_context.IsEmpty());
  EXPECT_TRUE(roots->weak_carrier.IsEmpty());
  EXPECT_TRUE(roots->weak_wrapper.IsEmpty());
  EXPECT_EQ(roots->weak_cppgc.Get(), nullptr);
}

TEST_F(OwnedContextProviderTest, RejectsTicketFromDifferentEnvironment) {
  const HandleScope handles(isolate_);
  const Argv argv;
  Env first{handles, argv};
  Local<Object> ticket = node::LoadEnvironment(
      *first, "return require('node:vm').prepareOwnedContext();")
      .ToLocalChecked().As<Object>();
  {
    Env second{handles, argv};
    node::LoadEnvironment(*second, "return 1;").ToLocalChecked();
    TryCatch caught(isolate_);
    node::OwnedContextOptions options;
    EXPECT_TRUE(node::CreateOwnedContext(
        *second, ticket, ObjectTemplate::New(isolate_),
        second.context()->GetSecurityToken(), options).IsEmpty());
    ASSERT_TRUE(caught.HasCaught());
    Local<Value> code = caught.Exception().As<Object>()->Get(
        second.context(), String::NewFromUtf8Literal(isolate_, "code"))
        .ToLocalChecked();
    EXPECT_TRUE(code->StrictEquals(
        String::NewFromUtf8Literal(isolate_, "ERR_INVALID_STATE")));
  }
}
