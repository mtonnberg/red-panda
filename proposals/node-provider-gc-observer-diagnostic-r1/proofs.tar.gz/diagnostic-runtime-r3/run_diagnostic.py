#!/usr/bin/env python3
"""One separately leased45s process; never builds or reruns namespace/JS controls."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,signal,subprocess,sys,time
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Use exact python3 -I -B; assertions must remain active')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--epoch',required=True);a=p.parse_args()
assert a.epoch and all(c.isalnum()or c in '-_'for c in a.epoch)
assert sha(D/'manifest.json')==a.manifest_sha
manifest=json.loads((D/'manifest.json').read_text())
for name,h in manifest['files'].items():assert sha(D/name)==h,name
spec=importlib.util.spec_from_file_location('frozen_build_guard_helpers',D/'guard_helpers.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
proof=json.loads((D/'build-provenance-pins.json').read_text());frozen=json.loads((D/'reference/build-r2-input-freeze.json').read_text());casePlan=json.loads((D/'reference/build-r2-future-runtime-case-plan.json').read_text());expected=[x['name']for x in casePlan['cases']];assert len(expected)==7 and len(set(expected))==7
extra=dict(proof['files']);extra.update({str(D/name):h for name,h in manifest['files'].items()});extra[str(D/'manifest.json')]=a.manifest_sha
out=D/'evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
report={'state':'SETUP','scope':'ONE_SOURCE_DERIVED7CASE_STORAGE_DIAGNOSTIC_NOT_PROVIDER_ACCEPTANCE','original3CollectionFailuresAndNamespace2Positive':'UNCHANGED','originalProxy45FailureAnd10HistoricalUNRUN':'UNCHANGED',
        'processCapSeconds':45,'TERMGraceSeconds':3,'aggregateSeconds':65,'outerSeconds':80,'assertionAnd8GCBodiesChanged':False,'actualCommand':None,'stages':[]}
start=time.monotonic();deadline=start+65;active=None

def save():report['elapsedSeconds']=time.monotonic()-start;write(out/'report.json',report)
def stop(n,f):raise InterruptedError('Controller signal '+str(n))
def aggregate(n,f):report['aggregateAdministrativeTimeout']=True;raise TimeoutError('65s diagnostic administrative threshold')
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGALRM,aggregate);signal.setitimer(signal.ITIMER_REAL,65)

def outcomes(path):
 raw=path.read_bytes();text=re.sub(r'\x1b\[[0-9;]*m','',raw.decode(errors='replace'))
 run=re.findall(r'^\[\s*RUN\s*\]\s+(\S+)\s*$',text,re.M)
 ok=re.findall(r'^\[\s*OK\s*\]\s+(\S+)\s+\([^\r\n]*\)\s*$',text,re.M)
 failed=re.findall(r'^\[\s*FAILED\s*\]\s+(\S+)\s+\([^\r\n]*\)\s*$',text,re.M)
 skipped=re.findall(r'^\[\s*SKIPPED\s*\]\s+([^\r\n]*)$',text,re.M)
 terminal=ok+failed
 return {'expectedCases':expected,'actualRUN':run,'actualOK':ok,'actualFAILED':failed,'actualSKIPPED':skipped,'allRawFAILEDLines':re.findall(r'^\[\s*FAILED\s*\]\s+([^\r\n]*)$',text,re.M),
         'exactSevenRUNAndTerminalOnceEach':sorted(run)==sorted(expected)and sorted(terminal)==sorted(expected)and not skipped,
         'caseOutcomes':{name:'OK'if name in ok else'FAILED'if name in failed else'UNOBSERVED'for name in expected},'logSHA256':hashlib.sha256(raw).hexdigest(),'logBytes':len(raw),'rawExitNeverNormalized':True,'syntheticExpectedValuesNeverSubstituted':True}
try:
 before=helper.guard(frozen,extra);write(out/'inputs-before.json',before);assert before['stable'],'Fullsource/cache/header/tool/build/outputguard mismatch'
 build=json.loads(Path(proof['buildReport']).read_text());assert sha(proof['buildReport'])==proof['buildReportSHA256']and build['state']=='DIAGNOSTIC_TEST_BINARY_BUILT_RUNTIME_UNRUN'
 binary=proof['actualDiagnosticBinary'];assert sha(binary['path'])==binary['sha256']=='a512dfc5ea0da1f400cf3ab6516b0aefec49d4cf999e61beb9b0fdf052ac106f'
 assert deadline-time.monotonic()>=54,'No wholeoriginal45s+3s+6s admission; no shrinking/raisingcaps'
 command=[binary['path'],'--gtest_filter='+casePlan['filter']];report['actualCommand']=command;report['expectedSourceCases']=expected;report['actualBinary']=binary
 report['GtestEnvironmentHashes']={name:{'present':True,'sha256':hashlib.sha256(os.fsencode(value)).hexdigest()}for name,value in os.environ.items()if name.startswith('GTEST_')}
 assert not report['GtestEnvironmentHashes'],'Inherited GTEST_ customization unsupported; preserve environment and stop without spawning'
 row={'name':'storage-observer-seven-case-diagnostic','argv':command,'cwd':str(out),'capSeconds':45,'administrativeTimeout':False,'state':'STARTED','groupSignals':[]};report['stages'].append(row);save();log=out/'diagnostic.log';begin=time.monotonic()
 with log.open('xb')as stream:
  child=subprocess.Popen(command,cwd=out,env=os.environ.copy(),stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  try:saved=helper.ident(child.pid);assert saved and saved['pid']==saved['sid']==saved['pgid']
  except BaseException:
   child.terminate()
   try:child.wait(timeout=3)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=1)
   raise
  row['identity']=saved;active=(child,saved,row);write(out/'actual-process.json',saved);save()
  try:child.wait(timeout=45)
  except subprocess.TimeoutExpired:row['administrativeTimeout']=True
  finally:helper.close(child,saved,row);active=None
 row['elapsedSeconds']=time.monotonic()-begin;row['actualOutcomes']=outcomes(log);row['state']='PROCESS_CLOSED_ACTUAL_RESULTS_RECORDED';save()
 assert not row['administrativeTimeout']and row['returnCode']in [0,1],'Actual crash/signal/timeout/non-test failure'
 assert row['actualOutcomes']['exactSevenRUNAndTerminalOnceEach'],'Missing/zero/extra/duplicate/skipped actual case observations'
 failures=row['actualOutcomes']['actualFAILED']
 if row['returnCode']==0:
  assert not failures and len(row['actualOutcomes']['actualOK'])==7,'Rawexit0 conflicts with actualfailed/missingcase'
  report['state']='SEVEN_DIAGNOSTIC_CASES_OBSERVED_ZERO_EXIT_NOT_PROVIDER_ACCEPTANCE'
 else:
  assert failures,'Rawexit1 outside actualobservedcasefailures; preservefailure'
  report['state']='SEVEN_DIAGNOSTIC_CASES_OBSERVED_WITH_ASSERTION_FAILURES_RAW_EXIT1'
except BaseException as e:report['state']='STOPPED_FIRST_SETUP_PROCESS_OBSERVATION_GUARD_OR_CLEANUP_FAILURE';report['error']={'type':type(e).__name__,'message':str(e)}
finally:
 signal.setitimer(signal.ITIMER_REAL,0)
 if active is not None:
  try:helper.close(*active)
  except BaseException as e:report['cleanupError']={'type':type(e).__name__,'message':str(e)}
 allMembers=[]
 for row in report['stages']:
  if row.get('identity'):allMembers.extend(helper.members(row['identity']['sid']))
  if(out/'diagnostic.log').exists()and'actualOutcomes'not in row:row['actualOutcomes']=outcomes(out/'diagnostic.log')
 report['finalMembers']=allMembers;report['finalLiveSurvivors']=[x for x in allMembers if x['state']!='Z'];report['finalTerminatedZombies']=[x for x in allMembers if x['state']=='Z']
 after=helper.guard(frozen,extra);write(out/'inputs-after.json',after);report['guardsStable']=after['stable'];report['fullGuardCount']=after['fileCount']
 if not after['stable']or report['finalLiveSurvivors']or report.get('cleanupError'):report['state']='STOPPED_FINAL_GUARD_OR_OWNERSHIP_FAILURE'
 if time.monotonic()-start>65:report['aggregateAdministrativeTimeout']=True;report['state']='STOPPED_AGGREGATE_THRESHOLD'
 save();print(json.dumps({'state':report['state'],'rawChildExit':report['stages'][0].get('returnCode')if report['stages']else None,'guardsStable':report['guardsStable'],'liveSurvivors':report['finalLiveSurvivors'],'report':str(out/'report.json')}),flush=True)
# A real assertion-failure cohort keeps controller exit1; never call it a passing acceptance.
raise SystemExit(0 if report['state']=='SEVEN_DIAGNOSTIC_CASES_OBSERVED_ZERO_EXIT_NOT_PROVIDER_ACCEPTANCE'else 1)
