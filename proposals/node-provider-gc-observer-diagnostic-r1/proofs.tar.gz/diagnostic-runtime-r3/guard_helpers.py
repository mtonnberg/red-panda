"""Exact reviewed build-R2 guard/ownedcleanup function bodies, no top-level builder code."""
from pathlib import Path
import hashlib,os,signal,time,subprocess
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def ident(pid):
 try:
  s=Path(f'/proc/{pid}/stat').read_text();v=s[s.rfind(')')+2:].split()
  try:exe=str(Path(f'/proc/{pid}/exe').resolve(strict=True))
  except OSError:exe=None
  return {'pid':int(pid),'state':v[0],'ppid':int(v[1]),'pgid':int(v[2]),'sid':int(v[3]),'startTicks':v[19],
          'argv':Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace').strip('\0').split('\0'),'executable':exe}
 except(FileNotFoundError,ProcessLookupError):return None

def same(a,b):return a is not None and b is not None and a['pid']==b['pid']and a['startTicks']==b['startTicks']

def members(sid):
 result=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   x=ident(int(p.name))
   if x and x['sid']==sid:result.append(x)
 return sorted(result,key=lambda x:x['pid'])

def tree(root):
 root=Path(root);rows=[]
 if not root.exists():return {'path':str(root),'exists':False,'entries':[]}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():rows.append({'path':str(p.relative_to(root)),'kind':'symlink','target':os.readlink(p)})
  elif p.is_file():rows.append({'path':str(p.relative_to(root)),'kind':'file'})
  elif p.is_dir():rows.append({'path':str(p.relative_to(root)),'kind':'dir'})
 return {'path':str(root),'exists':True,'entries':rows}

def guard(frozen,extra):
 files={**frozen['files'],**extra};bad={}
 for p,wanted in files.items():
  try:actual=sha(p)
  except OSError as e:actual='UNREADABLE:'+str(e)
  if actual!=wanted:bad[p]={'expected':wanted,'actual':actual}
 other=[]
 for p,expected in frozen['pathResolutions'].items():
  try:actual={'resolved':str(Path(p).resolve()),'directLink':os.readlink(p)if Path(p).is_symlink()else None}
  except OSError as e:actual={'error':str(e)}
  if actual!=expected:other.append({'pathResolution':p,'expected':expected,'actual':actual})
 for expected in frozen['rootInventories']:
  actual=tree(expected['path'])
  if actual!=expected:other.append({'changedRootInventory':expected['path']})
 for expected in frozen['explicitIncludeDirectoryNames']:
  p=Path(expected['path']);actual={'path':str(p),'exists':p.is_dir(),'entries':sorted(x.name for x in p.iterdir())if p.is_dir()else[]}
  if actual!=expected:other.append({'changedIncludeSearchDirectory':str(p)})
 for name,expected in frozen['linkSearchDirectoryNames'].items():
  p=Path(name);actual={'exists':p.is_dir(),'entries':sorted(x.name for x in p.iterdir())if p.is_dir()else[]}
  if actual!=expected:other.append({'changedLinkSearchDirectory':name})
 for name,expected in frozen['environment'].items():
  raw=os.fsencode(os.environ.get(name,''));actual={'present':name in os.environ,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  if actual!=expected:other.append({'changedEnvironment':name,'expected':expected,'actual':actual})
 return {'stable':not bad and not other,'fileCount':len(files),'frozen8226Files':len(frozen['files']),'fileMismatches':bad,'metadataMismatches':other}

def signal_groups(saved,captured,row,signum):
 now=members(saved['sid'])
 for pgid in sorted({x['pgid']for x in now if x['state']!='Z'}):
  assert pgid!=os.getpgrp()
  current=[x for x in now if x['pgid']==pgid and x['state']!='Z']
  assert same(saved,ident(saved['pid']))or any(same(x,ident(x['pid']))for x in captured if x['pgid']==pgid),'No actual ownedidentity authority'
  row.setdefault('groupSignals',[]).append({'pgid':pgid,'signal':int(signum),'actualMembers':current})
  try:os.killpg(pgid,signum)
  except ProcessLookupError:pass

def close(child,saved,row):
 before=members(saved['sid']);row['membersBeforeCleanup']=before
 if any(x['state']!='Z'for x in before):
  signal_groups(saved,before,row,signal.SIGTERM);until=time.monotonic()+3
  while time.monotonic()<until and any(x['state']!='Z'for x in members(saved['sid'])):time.sleep(.025)
  if any(x['state']!='Z'for x in members(saved['sid'])):signal_groups(saved,before,row,signal.SIGKILL)
 try:child.wait(timeout=1)
 except subprocess.TimeoutExpired:row['reapTimeout']=True
 after=members(saved['sid']);row['membersAfterCleanup']=after;row['liveSurvivors']=[x for x in after if x['state']!='Z'];row['terminatedZombies']=[x for x in after if x['state']=='Z'];row['returnCode']=child.returncode;row['signal']=-child.returncode if child.returncode is not None and child.returncode<0 else None
 assert not row['liveSurvivors'],'Owned compiler/linker survivors remain'
