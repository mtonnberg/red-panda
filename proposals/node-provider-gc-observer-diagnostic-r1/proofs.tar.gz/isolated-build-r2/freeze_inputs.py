"""STATIC authenticated source/cache/header/tool byte freeze; never invokes a tool/compiler."""
from pathlib import Path
import hashlib,json,os,shutil,sys
sys.dont_write_bytecode=True
from metadata_readers import ninja_deps,elf_dependencies
D=Path(__file__).resolve().parent
S=Path('/workspace/shared/node-provider-build-r4/source');R=S/'out/Release'
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(name,x):(D/name).write_text(json.dumps(x,indent=2)+'\n')
def inventory(root):
 root=Path(root);rows=[]
 if not root.exists():return {'path':str(root),'exists':False,'entries':[]}
 for f in sorted(root.rglob('*')):
  if f.is_symlink():rows.append({'path':str(f.relative_to(root)),'kind':'symlink','target':os.readlink(f)})
  elif f.is_file():rows.append({'path':str(f.relative_to(root)),'kind':'file'})
  elif f.is_dir():rows.append({'path':str(f.relative_to(root)),'kind':'dir'})
 return {'path':str(root),'exists':True,'entries':rows}
files={};roles={};symlinks={}
def add(path,role):
 p=Path(path);assert p.is_file(),str(p)
 raw=str(p.absolute());resolved=str(p.resolve());roles.setdefault(resolved,[]).append(role);files[resolved]=None
 if raw!=resolved:symlinks[raw]={'resolved':resolved,'directLink':os.readlink(p)if p.is_symlink()else None}
 return resolved
base=json.loads(Path('/workspace/shared/node-provider-cctest-prerequisites-root646-r1/input-guards.json').read_text())['files'];assert len(base)==840
for p,wanted in base.items():resolved=add(p,'current646/C3/original-boundary');assert sha(p)==wanted,p
inv=json.loads((D/'cache-inventory-provisional.json').read_text())
for path in inv['files']:add(path,'actualLinkInputOrTransitiveThinMember')
for edge in inv['thinEdges']:
 assert edge['nestedMemberOffset']is None,'Explicit nested-member review required'
 assert Path(edge['path']).stat().st_size==edge['sizeFromHeader']
plan=json.loads((D/'compile-link-plan.json').read_text());deps=ninja_deps(R/'.ninja_deps');project=[]
for item in plan['compiles'][:3]:
 original=item['originalArgv'];obj=original[original.index('-o')+1];row=deps['latestDeps'][obj];assert row['mtime']==(R/obj).stat().st_mtime_ns
 paths=[]
 for name in row['dependencyPaths']:
  p=Path(name)if Path(name).is_absolute()else R/name;paths.append(add(p,'authenticNinja-MMD-projectDependency'))
 project.append({'target':obj,'actualObjectMtimeMatches':True,'ninjaRecordedMtime':row['mtime'],'dependencyPaths':paths})
add(R/'.ninja_deps','authenticNinjaDependencyDatabase')
# MMD omits system includes: conservatively guard the complete actual installed default roots.
roots=[Path('/usr/include'),Path('/usr/local/include'),Path('/usr/lib/gcc/x86_64-linux-gnu/14/include'),Path('/usr/lib/gcc/x86_64-linux-gnu/14/include-fixed')]
affecting=['PATH','CPATH','CPLUS_INCLUDE_PATH','C_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','LD_LIBRARY_PATH','LD_PRELOAD','DEPENDENCIES_OUTPUT','SUNPRO_DEPENDENCIES','GCC_COMPARE_DEBUG','SOURCE_DATE_EPOCH','LANG','LC_ALL','TMPDIR']
environment={}
for name in affecting:
 value=os.environ.get(name,'');environment[name]={'present':name in os.environ,'bytes':len(os.fsencode(value)),'sha256':hashlib.sha256(os.fsencode(value)).hexdigest()}
 if name in ['CPATH','CPLUS_INCLUDE_PATH','C_INCLUDE_PATH']and value:
  for part in value.split(os.pathsep):
   assert part and Path(part).is_absolute(),'Relative/current-directory include override needs separate review'
   roots.append(Path(part))
 if name in ['GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','LD_PRELOAD','DEPENDENCIES_OUTPUT','SUNPRO_DEPENDENCIES','GCC_COMPARE_DEBUG']:
  assert not value,'Nondefault compiler/preload search needs explicit metadata review, never silently clear'
rootInventories=[]
for root in dict.fromkeys(roots):
 rootInventories.append(inventory(root))
 if root.exists():
  for f in root.rglob('*'):
   if f.is_file():add(f,'systemOrCompilerIncludeSuperset-MMDomissionCovered')
# Quote-source directory must remain source-only: no newly injected header can shadow real C3 headers.
rootInventories.append(inventory(D/'candidate/test/cctest'))
# Pin top-level names of each explicit include search directory (plus actual MMD file bytes).
includeNames=[]
for arg in plan['compiles'][0]['argv']:
 if arg.startswith('-I'):
  root=(R/arg[2:]).resolve();rootInventories.append(inventory(root));includeNames.append({'path':str(root),'exists':root.is_dir(),'entries':sorted(x.name for x in root.iterdir())if root.is_dir()else[]})
toolPaths=[plan['compiler']['resolvedPath'],'/usr/libexec/gcc/x86_64-linux-gnu/14/cc1plus','/usr/libexec/gcc/x86_64-linux-gnu/14/collect2','/usr/libexec/gcc/x86_64-linux-gnu/14/liblto_plugin.so',shutil.which('as'),shutil.which('ld')]
assert all(toolPaths)
# Link-driver specs/startup/static support candidates, actual installed bytes rather than guessed headers.
for f in Path('/usr/lib/gcc/x86_64-linux-gnu/14').iterdir():
 if f.is_file()and(f.suffix in ['.o','.a','.so','.spec']or f.name=='specs'):toolPaths.append(str(f))
libroot=Path('/usr/lib/x86_64-linux-gnu')
for pattern in ['crt*.o','libc.so*','libc_nonshared.a','libm.so*','libmvec.so*','libdl.*','libpthread.*','libstdc++.*','libgcc_s.*','ld-linux*']:
 toolPaths.extend(str(x)for x in libroot.glob(pattern)if x.is_file())
search=[Path(p)for p in os.environ.get('LD_LIBRARY_PATH','').split(':')if p]+[Path('/lib/x86_64-linux-gnu'),Path('/usr/lib/x86_64-linux-gnu'),Path('/lib64'),Path('/usr/lib64')]
elfRows=[];queue=list(dict.fromkeys(toolPaths));visited=set()
while queue:
 name=queue.pop();resolved=add(name,'actualCompilerAssemblerLinkerStartupOrELFDependency')
 if resolved in visited:continue
 visited.add(resolved);meta=elf_dependencies(resolved)
 if meta is None:continue
 resolvedDeps=[]
 if meta['interpreter']:queue.append(meta['interpreter'])
 local=[]
 for group in meta['searchPaths']:
  for entry in group.split(':'):
   entry=entry.replace('${ORIGIN}',str(Path(resolved).parent)).replace('$ORIGIN',str(Path(resolved).parent));assert '$'not in entry
   local.append(Path(entry))
 for needed in meta['needed']:
  candidates=[root/needed for root in local+search];found=next((p for p in candidates if p.is_file()),None);assert found,needed
  resolvedDeps.append({'soname':needed,'path':str(found.resolve())});queue.append(str(found))
 elfRows.append({'path':resolved,**meta,'resolvedDependencies':resolvedDeps})
# Keep link search-directory entry names stable against a newly shadowing library.
linkSearchRoots=set(search+[Path('/usr/lib'),Path('/lib'),Path('/usr/local/lib'),Path('/usr/lib/gcc/x86_64-linux-gnu/14'),Path('/usr/x86_64-linux-gnu/lib')])
linkDirNames={str(root):{'exists':root.is_dir(),'entries':sorted(x.name for x in root.iterdir())if root.is_dir()else[]}for root in linkSearchRoots}
# Original immutable source-only proposal + failing/positive runtime evidence, current edited candidate files.
for root,role in [(Path('/workspace/shared/node-provider-gc-observer-storage-r1'),'immutableR1proposal'),(D/'candidate','exactStorageOnlyAndOrdinaryBaselineCandidate')]:
 for p in root.rglob('*'):
  if p.is_file()and'__pycache__'not in p.parts:add(p,role)
for name in ['config.gypi','common.gypi','node.gyp']:
 if(S/name).exists():add(S/name,'actualC3configuration')
for p in [R/'build.ninja',R/'obj/cctest.ninja',Path('/workspace/shared/node-provider-build-r4/metadata/ninja-compile-commands.json')]:add(p,'authenticCommandMetadata')
for root,prefix,names in [('/workspace/shared/node-provider-cctest-prerequisites-root646-controller-r2/evidence/cpp-1','originalFailedCpp',['report.json','independent-cppgc.log','closure-receipt.json']),('/workspace/shared/node-provider-namespace-only-root646-r3/evidence/namespace-1','namespacePositive',['report.json','independent-r4-namespace-cpp.log','interpretation-supplement.json'])]:
 for name in names:add(Path(root)/name,prefix)
for p in files:files[p]=sha(p)
thinEdges=[]
for edge in inv['thinEdges']:thinEdges.append({**edge,'actualSHA256':files[str(Path(edge['path']).resolve())],'actualBytes':Path(edge['path']).stat().st_size})
write('input-freeze.json',{'kind':'STATIC actual fullbytes freeze; no compiler/linker/runtime','files':files,'roles':{k:sorted(set(v))for k,v in roles.items()},'pathResolutions':symlinks,'rootInventories':rootInventories,'explicitIncludeDirectoryNames':includeNames,'linkSearchDirectoryNames':linkDirNames,'environment':environment,'ninjaProjectDependencies':project,'elfToolDependencyClosure':elfRows,'thinArchiveMemberEdges':thinEdges,'cacheFileCount':len(inv['files']),'cacheBytes':sum(inv['files'].values()),'cacheMemberCount':len(thinEdges),'headerPolicy':'Actual MMD projectdeps +complete actualsystem/compilerinclude roots; no header substitution. Newbaseline includes subsetoriginalprovider plusalreadytransitive memory.','toolPolicy':'Actual resolved tool bytes and static ELF interpreter/DT_NEEDED closure pluslinkstartup/specsupport bytes. No compiler print/invocation.'})
print(json.dumps({'state':'STATIC_BYTE_FREEZE_COMPLETE','files':len(files),'bytes':sum(Path(p).stat().st_size for p in files),'thinMembers':len(thinEdges),'cacheFiles':len(inv['files']),'ninjaHeaderRecords':[len(x['dependencyPaths'])for x in project],'toolELFRows':len(elfRows),'inputFreezeSHA256':sha(D/'input-freeze.json')},indent=2))
