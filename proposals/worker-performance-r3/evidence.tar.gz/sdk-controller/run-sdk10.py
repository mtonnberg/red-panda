#!/usr/bin/env python3
"""Parent-granted serial regression/remaining-SDK gate, no source mutations."""
from pathlib import Path
import json,hashlib,os,subprocess,sys,time,signal,re
START=time.monotonic();ROOT=Path(__file__).resolve().parents[1];SOURCE=Path('/workspace/shared/worker-performance-r3-regression-gate-r1');TARGET=SOURCE/'candidate';PRODUCTION=Path('/workspace/red-panda');CAP=45;CLEANUP=2
SDKS=[('24.19.0',Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')),('26.13.0',Path('/workspace/shared/node26/node_modules/node/bin/node'))]
EPOCH=os.environ.get('PROBE_EPOCH','initial');OUT=ROOT/'runs'/EPOCH;OUT.mkdir(parents=True,exist_ok=False);sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((ROOT/'manifest.json').read_text());assert all(sha(ROOT/r['path'])==r['sha256']for r in manifest['files']),'Owned frozen bytes differ'
assert all((ROOT/r['path']).is_symlink()and str((ROOT/r['path']).resolve())==r['target']for r in manifest['links']),'Frozen dependency link differs'
source={r['path']:r['sha256']for r in json.loads((ROOT/'evidence/root-before.json').read_text())['files']};actual={f.relative_to(PRODUCTION).as_posix()for d in ['src','test','native','bin','scripts']for f in(PRODUCTION/d).rglob('*')if f.is_file()}|{'package.json','package-lock.json'}
assert actual==set(source)and all(sha(PRODUCTION/p)==h for p,h in source.items()),'External Root2342/615 changed; prepare explicit derivative'
immutable=json.loads((ROOT/'evidence/immutable-regression-manifest.json').read_text());assert all(sha(SOURCE/r['path'])==r['sha256']for r in immutable['files']),'Exact prior-owned runtime/dependencies differ'
assert all((SOURCE/r['path']).is_symlink()and str((SOURCE/r['path']).resolve())==r['target']for r in immutable['links']),'Prior immutable link differs'
paths=[ROOT/r['path']for r in manifest['files']]+[ROOT/'manifest.json']+[SOURCE/r['path']for r in immutable['files']]+[SOURCE/'manifest.json']+[PRODUCTION/p for p in source]+[node for _,node in SDKS]
for package in(PRODUCTION/'node_modules').iterdir():
 if package.is_dir()and not package.name.startswith('.'):paths.extend(p for p in package.resolve().rglob('*')if p.is_file())
paths=list(dict.fromkeys(p.resolve()for p in paths));guard=lambda:{str(p):sha(p)for p in paths}
record={'scope':'SDK10-only supplementary continuation after actual protected108 PASS; exact owned R3 runtime unchanged','priorOwnedInputsExact':True,'protected108NotRepeated':True,'sourceAndPrimary5NotRepeated':True,'before':guard(),'capSeconds':CAP,'cleanupSeconds':CLEANUP,'commands':[],'creationProofs':[],'status':'started','heapScope':'Only sameRealm/creationGlobal physical API; no heap enumeration/GC/snapshots','firstgate5NotRepeatedPrimary':True}
primary=json.loads((ROOT/'evidence/prior-primary-context.json').read_text());assert primary['node']=='v24.22.1'and len(primary['rows'])==26 and len({r['name']for r in primary['rows']})==26
assert all(r['VM']and not r['Host']and r['creationGlobal']and r['VMNull']and not r['HostNull']for r in primary['rows'])
receipt=json.loads((ROOT/'evidence/source-firstgate-receipt.json').read_text());assert sha(ROOT/'evidence/prior-primary-context.json')==next(r['sha256']for r in receipt['files']if r['path']=='creation-context-proof.json')
record['priorPrimary26VerifiedMetadataOnly']=True
environment=os.environ.copy()
for key in ['NO_PROXY','no_proxy']:
 pieces=[v for v in environment.get(key,'').split(',')if v];environment[key]=','.join(dict.fromkeys(pieces+['127.0.0.1','localhost']))
def save():(OUT/'controller.json').write_text(json.dumps(record,indent=2)+'\n')
def kill(pid,sig):
 try:os.killpg(pid,sig)
 except ProcessLookupError:pass
def run(version,node,kind,tests,expected):
 remaining=CAP-(time.monotonic()-START)
 if remaining<=CLEANUP:raise TimeoutError('Administrative cap before next job')
 sdk=TARGET/'native/build/linux-x64'/('node-'+version);env=environment.copy();env.update(RED_PANDA_COLLECTIONS_ADDON=str(sdk/'collections.node'),RED_PANDA_RUNTIME_ADDON=str(sdk/'runtime.node'))
 label=version+'-'+kind;row={'label':label,'command':[str(node),'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*tests],'cwd':str(TARGET),'startedMonotonic':time.monotonic()};record['commands'].append(row);child=None;save()
 try:
  with(OUT/(label+'.stdout')).open('wb')as stdout,(OUT/(label+'.stderr')).open('wb')as stderr:
   child=subprocess.Popen(row['command'],cwd=TARGET,env=env,stdout=stdout,stderr=stderr,start_new_session=True);row['pid']=child.pid;save()
   while True:
    available=CAP-(time.monotonic()-START)
    try:row['exitCode']=child.wait(timeout=max(0.001,min(20,available)));break
    except subprocess.TimeoutExpired:
     if time.monotonic()-START<CAP:
      partial=(OUT/(label+'.stdout')).read_text();row['lastObservedTopLevelOkLines']=len(re.findall(r'^ok \d+ - ',partial,re.M));save();print(json.dumps({'progress':label,'elapsedSec':time.monotonic()-row['startedMonotonic'],'observedTopLevelOkLines':row['lastObservedTopLevelOkLines'],'acceptance':'not complete'}),flush=True);continue
     row['administrativeWatchdog']=True;kill(child.pid,signal.SIGTERM)
     try:child.wait(timeout=CLEANUP)
     except subprocess.TimeoutExpired:kill(child.pid,signal.SIGKILL);child.wait()
     raise

  text=(OUT/(label+'.stdout')).read_text();summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};row['actualTAP']=summary
  if row['exitCode']!=0:raise RuntimeError(label+' actual nonpass; later phases UNRUN')
  assert summary=={'tests':expected,'pass':expected,'fail':0,'cancelled':0,'skipped':0,'todo':0},'Actual TAP accounting differs'
  if kind=='remaining-feature5':
   found=re.findall(r'WORKER_PERFORMANCE_CREATION_CONTEXT (.+)',text);assert len(found)==1,'Missing physical Context proof'
   proof=json.loads(found[0]);assert proof['node']=='v'+version and len(proof['rows'])==26 and len({r['name']for r in proof['rows']})==26
   assert all(r['VM']and not r['Host']and r['creationGlobal']and r['VMNull']and not r['HostNull']for r in proof['rows']),'Actual creation Context contrary'
   (OUT/(label+'-context.json')).write_text(json.dumps(proof,indent=2)+'\n');record['creationProofs'].append({'node':proof['node'],'uniqueRows':26,'allVerified':True})
 finally:
  if child is not None and child.poll()is None:kill(child.pid,signal.SIGKILL);child.wait()
  row['closed']=child is None or child.poll()is not None;row['durationSec']=time.monotonic()-row['startedMonotonic'];save();print(json.dumps(row),flush=True)
try:
 for version,node in SDKS:run(version,node,'remaining-feature5',['test/worker-performance.test.js'],5)
 record['allThreeActualContextRows']=26+sum(p['uniqueRows']for p in record['creationProofs']);assert record['allThreeActualContextRows']==78
 record['status']='remainingSDK10pass; priorProtected108+primary5+SourcePASS-retained-separate; no-full-suite-claim'
except Exception as error:record['status']='stopped-first-contrary';record['error']={'name':type(error).__name__,'message':str(error)}
finally:
 record['after']=guard();record['stable']=record['before']==record['after'];record['durationSec']=time.monotonic()-START;record['allOwnedGroupsExited']=all(r.get('closed')for r in record['commands']);save();print(json.dumps({'status':record['status'],'stable':record['stable'],'durationSec':record['durationSec']}),flush=True)
if not record['stable']or record['status']=='stopped-first-contrary':sys.exit(1)
