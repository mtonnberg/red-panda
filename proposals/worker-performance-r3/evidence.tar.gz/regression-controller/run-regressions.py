#!/usr/bin/env python3
"""Parent-granted serial regression/remaining-SDK gate, no source mutations."""
from pathlib import Path
import json,hashlib,os,subprocess,sys,time,signal,re
START=time.monotonic();ROOT=Path(__file__).resolve().parents[1];TARGET=ROOT/'candidate';PRODUCTION=Path('/workspace/red-panda');CAP=180;CLEANUP=2
SDKS=[('24.22.1',Path('/workspace/shared/rea-tools/node_modules/node/bin/node')),('24.19.0',Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')),('26.13.0',Path('/workspace/shared/node26/node_modules/node/bin/node'))]
EPOCH=os.environ.get('PROBE_EPOCH','initial');OUT=ROOT/'runs'/EPOCH;OUT.mkdir(parents=True,exist_ok=False);sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((ROOT/'manifest.json').read_text());assert all(sha(ROOT/r['path'])==r['sha256']for r in manifest['files']),'Owned frozen bytes differ'
assert all((ROOT/r['path']).is_symlink()and str((ROOT/r['path']).resolve())==r['target']for r in manifest['links']),'Frozen dependency link differs'
source={r['path']:r['sha256']for r in json.loads((ROOT/'evidence/root-before.json').read_text())['files']};actual={f.relative_to(PRODUCTION).as_posix()for d in ['src','test','native','bin','scripts']for f in(PRODUCTION/d).rglob('*')if f.is_file()}|{'package.json','package-lock.json'}
assert actual==set(source)and all(sha(PRODUCTION/p)==h for p,h in source.items()),'External Root2342/615 changed; prepare explicit derivative'
frozen=json.loads((ROOT/'evidence/frozen-r3-manifest.json').read_text());runtime={r['path'][len('candidate/'):]:r['sha256']for r in frozen['files']if r['path'].startswith('candidate/')};assert len(runtime)==617
assert all(sha(TARGET/p)==h for p,h in runtime.items()),'Runtime/test/native inputs differ from actual firstgate R3'
plan=json.loads((ROOT/'evidence/regression-plan.json').read_text());assert all(sha(PRODUCTION/r['path'])==r['sha256']and sha(TARGET/r['path'])==r['sha256']for r in plan['closedReferenceFiles']),'Actual closed reference dependency differs'
paths=[ROOT/r['path']for r in manifest['files']]+[ROOT/'manifest.json']+[PRODUCTION/p for p in source]+[PRODUCTION/r['path']for r in plan['closedReferenceFiles']]+[TARGET/r['path']for r in plan['closedReferenceFiles']]+[node for _,node in SDKS]
for package in(PRODUCTION/'node_modules').iterdir():
 if package.is_dir()and not package.name.startswith('.'):paths.extend(p for p in package.resolve().rglob('*')if p.is_file())
paths=list(dict.fromkeys(p.resolve()for p in paths));guard=lambda:{str(p):sha(p)for p in paths}
record={'scope':'Protected101 once on primary +remaining SDK5each, exact accepted R3 runtime unchanged','runtimeVerified617':True,'before':guard(),'capSeconds':CAP,'cleanupSeconds':CLEANUP,'commands':[],'creationProofs':[],'status':'started','heapScope':'Only sameRealm/creationGlobal physical API; no heap enumeration/GC/snapshots','firstgate5NotRepeatedPrimary':True}
environment=os.environ.copy()
for key in ['NO_PROXY','no_proxy']:
 pieces=[v for v in environment.get(key,'').split(',')if v];environment[key]=','.join(dict.fromkeys(pieces+['127.0.0.1','localhost']))
def save():(OUT/'controller.json').write_text(json.dumps(record,indent=2)+'\n')
def kill(pid,sig):
 try:os.killpg(pid,sig)
 except ProcessLookupError:pass
def run(version,node,kind,tests,expected):
 remaining=CAP-(time.monotonic()-START)
 if remaining<=CLEANUP:raise TimeoutError('Administrative cap before next job')
 sdk=TARGET/'native/build/linux-x64'/('node-'+version);env=environment.copy();env.update(RED_PANDA_COLLECTIONS_ADDON=str(sdk/'collections.node'),RED_PANDA_RUNTIME_ADDON=str(sdk/'runtime.node'))
 label=version+'-'+kind;row={'label':label,'command':[str(node),'--experimental-vm-modules','--test','--test-reporter=tap','--test-concurrency=1',*tests],'cwd':str(TARGET),'startedMonotonic':time.monotonic()};record['commands'].append(row);child=None;save()
 try:
  with(OUT/(label+'.stdout')).open('wb')as stdout,(OUT/(label+'.stderr')).open('wb')as stderr:
   child=subprocess.Popen(row['command'],cwd=TARGET,env=env,stdout=stdout,stderr=stderr,start_new_session=True);row['pid']=child.pid;save()
   while True:
    available=CAP-(time.monotonic()-START)
    try:row['exitCode']=child.wait(timeout=max(0.001,min(20,available)));break
    except subprocess.TimeoutExpired:
     if time.monotonic()-START<CAP:
      partial=(OUT/(label+'.stdout')).read_text();row['lastObservedTopLevelOkLines']=len(re.findall(r'^ok \d+ - ',partial,re.M));save();print(json.dumps({'progress':label,'elapsedSec':time.monotonic()-row['startedMonotonic'],'observedTopLevelOkLines':row['lastObservedTopLevelOkLines'],'acceptance':'not complete'}),flush=True);continue
     row['administrativeWatchdog']=True;kill(child.pid,signal.SIGTERM)
     try:child.wait(timeout=CLEANUP)
     except subprocess.TimeoutExpired:kill(child.pid,signal.SIGKILL);child.wait()
     raise

  text=(OUT/(label+'.stdout')).read_text();summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};row['actualTAP']=summary
  if row['exitCode']!=0:raise RuntimeError(label+' actual nonpass; later phases UNRUN')
  assert summary=={'tests':expected,'pass':expected,'fail':0,'cancelled':0,'skipped':0,'todo':0},'Actual TAP accounting differs'
  if kind=='remaining-feature5':
   found=re.findall(r'WORKER_PERFORMANCE_CREATION_CONTEXT (.+)',text);assert len(found)==1,'Missing physical Context proof'
   proof=json.loads(found[0]);assert proof['node']=='v'+version and len(proof['rows'])==26 and len({r['name']for r in proof['rows']})==26
   assert all(r['VM']and not r['Host']and r['creationGlobal']and r['VMNull']and not r['HostNull']for r in proof['rows']),'Actual creation Context contrary'
   (OUT/(label+'-context.json')).write_text(json.dumps(proof,indent=2)+'\n');record['creationProofs'].append({'node':proof['node'],'uniqueRows':26,'allVerified':True})
 finally:
  if child is not None and child.poll()is None:kill(child.pid,signal.SIGKILL);child.wait()
  row['closed']=child is None or child.poll()is not None;row['durationSec']=time.monotonic()-row['startedMonotonic'];save();print(json.dumps(row),flush=True)
try:
 version,node=SDKS[0];run(version,node,'protected101',[r['path']for r in plan['protected']],101)
 for version,node in SDKS[1:]:run(version,node,'remaining-feature5',['test/worker-performance.test.js'],5)
 record['status']='protected101+remaining10-pass; firstgate5+26proof-separate; no-full-suite-claim'
except Exception as error:record['status']='stopped-first-contrary';record['error']={'name':type(error).__name__,'message':str(error)}
finally:
 record['after']=guard();record['stable']=record['before']==record['after'];record['durationSec']=time.monotonic()-START;record['allOwnedGroupsExited']=all(r.get('closed')for r in record['commands']);save();print(json.dumps({'status':record['status'],'stable':record['stable'],'durationSec':record['durationSec']}),flush=True)
if not record['stable']or record['status']=='stopped-first-contrary':sys.exit(1)
