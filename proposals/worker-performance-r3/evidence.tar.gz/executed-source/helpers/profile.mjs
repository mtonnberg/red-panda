import http from 'node:http';
import {once} from 'node:events';
import {spawn} from 'node:child_process';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const profile=process.argv[2];if(!['native','root'].includes(profile))throw Error('Use native or root');
const root=new URL('../',import.meta.url),out=new URL('runs/'+(process.env.PROBE_EPOCH??'initial')+'/',root);await mkdir(out,{recursive:true});
const binary=profile==='native'?'/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux':new URL('root-launcher',root).pathname;
const sha=value=>createHash('sha256').update(value).digest('hex'),files=new Map();
for(const name of ['performance.html','performance-worker.js','testing.js']){const bytes=await readFile(new URL('fixtures/'+name,root));files.set('/src/browser/tests/'+name,{bytes,sha256:sha(bytes),contentType:name.endsWith('.js')?'text/javascript':'text/html'});}
const record={profile,node:process.version,nodeExecutable:process.execPath,binary,binarySHA256:sha(await readFile(binary)),sourceLoadBudgetMs:2000,freshAssertionBudgetMs:2000,actualUserAgentOverride:false,actualClientHintsOverride:false,wire:[],status:'started'};
let server,child,writes=Promise.resolve(),stdout='',stderr='';const save=()=>{const bytes=JSON.stringify(record,null,2)+'\n';writes=writes.then(()=>writeFile(new URL(profile+'-wire.json',out),bytes));return writes;};await writeFile(new URL(profile+'-wire.json',out),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
try{
 server=http.createServer((request,response)=>{
  const path=new URL(request.url,'http://owned.invalid').pathname,file=files.get(path),body=file?.bytes??Buffer.from('Unknown owned fixture path');
  const item={method:request.method,url:request.url,path,requestHeaders:request.headers,requestHTTPVersion:request.httpVersion,arrivedHostNow:performance.now(),known:!!file,responseBodyLength:body.byteLength,responseBodySHA256:sha(body),status:file?200:404};record.wire.push(item);
  response.once('finish',()=>{item.finishedHostNow=performance.now();item.actualSerializedHeaders=response._header;void save();});
  response.writeHead(item.status,{'content-type':file?.contentType??'text/plain','content-length':String(body.byteLength)});response.end(body);
 });server.listen(0,'127.0.0.1');await once(server,'listening');record.origin='http://127.0.0.1:'+server.address().port;
 const report=new URL(profile+'-source-report.json',out).pathname;
 record.command=[process.execPath,new URL('harness/scripts/conformance.mjs',root).pathname,'--root',new URL('fixtures/',root).pathname,'--binary',binary,'--test','performance.html','--isolate','--registration-map',new URL('evidence/registration-map.json',root).pathname,'--source-load-contract','--fixture-origin',record.origin,'--runner-global-arg=--ws-max-concurrent','--runner-global-arg=50','--report',report];await save();
 child=spawn(record.command[0],record.command.slice(1),{cwd:root.pathname,env:process.env,stdio:['ignore','pipe','pipe']});record.runnerPID=child.pid;await save();child.stdout.on('data',chunk=>{stdout+=chunk;});child.stderr.on('data',chunk=>{stderr+=chunk;});
 const [code,signal]=await once(child,'exit');record.runnerExitCode=code;record.runnerSignal=signal;record.stdout=stdout;record.stderr=stderr;
 await writeFile(new URL(profile+'-source.stdout',out),stdout,{flag:'wx'});await writeFile(new URL(profile+'-source.stderr',out),stderr,{flag:'wx'});
 if(code!==0)throw Error('Original source profile did not pass; full raw assertion/load/setup outcome retained');
 record.sourceReport=JSON.parse(await readFile(report,'utf8'));const results=record.sourceReport.results;
 if(results.length!==1||results[0].status!=='passed')throw Error('Original source non-pass');
 const unexpected=record.wire.filter(r=>!r.known||r.status!==200);if(unexpected.length)throw Error('Unexpected actual fixture/helper request; no transitive source coverage claim');
 for(const name of ['performance.html','testing.js','performance-worker.js'])if(!record.wire.some(r=>r.path==='/src/browser/tests/'+name&&r.known&&r.status===200))throw Error('Expected actual script path was never received: '+name);
 record.status='passed-original-assertion-source-with-explicit-eligibility-adaptation';
}catch(error){record.status='source-or-setup-or-receipt-nonpass';record.error={name:error.name,message:error.message};process.exitCode=1;}
finally{
 if(child&&child.exitCode===null&&child.signalCode===null){child.kill('SIGTERM');await once(child,'exit');}
 if(server?.listening){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}record.cleanup={runnerClosed:!child||child.exitCode!==null||child.signalCode!==null,ownedHTTPServerClosed:true};await save();
}
console.log(JSON.stringify({profile,status:record.status,origin:record.origin}));
