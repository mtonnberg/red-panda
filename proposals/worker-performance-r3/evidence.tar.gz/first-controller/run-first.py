#!/usr/bin/env python3
"""Frozen independent phases; Parent grants each mode before execution."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,time,signal,re
START=time.monotonic();ROOT=Path(__file__).resolve().parents[1];PRODUCTION=Path('/workspace/red-panda');CANDIDATE=ROOT/'candidate';NODE=Path('/workspace/shared/rea-tools/node_modules/node/bin/node');NATIVE=Path('/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux');CAP=90;CLEANUP=2
MODE=sys.argv[1]if len(sys.argv)==2 else '';assert MODE in ['native-heldouts','candidate'], 'Use native-heldouts or candidate, each separately granted'
CAP=45 if MODE=='native-heldouts' else 90
EPOCH=os.environ.get('PROBE_EPOCH','initial')+'-'+MODE;OUT=ROOT/'runs'/EPOCH;OUT.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();expected={r['path']:r['sha256']for r in json.loads((ROOT/'evidence/root-before.json').read_text())['files']}
actual={f.relative_to(PRODUCTION).as_posix()for d in ['src','native','bin','scripts','test']for f in(PRODUCTION/d).rglob('*')if f.is_file()}|{'package.json','package-lock.json'}
assert actual==set(expected),'Actual Root pathset differs; preserve packet and prepare explicit derivative'
assert all(sha(PRODUCTION/p)==h for p,h in expected.items()),'Actual Root bytes differ; do not silently relabel candidate base'
manifest=json.loads((ROOT/'manifest.json').read_text());assert all((ROOT/r['path']).is_symlink()and str((ROOT/r['path']).resolve())==r['target']for r in manifest['links']),'Frozen dependency link differs'
assert all(sha(ROOT/r['path'])==r['sha256']for r in manifest['files']),'Frozen owned inputs differ'
paths=[PRODUCTION/p for p in expected]+[ROOT/r['path']for r in manifest['files']]+[ROOT/'manifest.json',NODE,NATIVE]
for package in(PRODUCTION/'node_modules').iterdir():
 if package.is_dir()and not package.name.startswith('.'):paths.extend(f for f in package.resolve().rglob('*')if f.is_file())
paths=list(dict.fromkeys(p.resolve()for p in paths));guard=lambda:{str(p):sha(p)for p in paths}
record={'mode':MODE,'scope':'Genuine Worker VM Performance, Native heldouts before independent candidate acceptance','before':guard(),'capSeconds':CAP,'cleanupSeconds':CLEANUP,'originalRPCMs':2500,'VMandWorkerMs':2000,'commands':[],'status':'started'}
environment=os.environ.copy()
for key in ['NO_PROXY','no_proxy']:
 parts=[v for v in environment.get(key,'').split(',')if v];environment[key]=','.join(dict.fromkeys(parts+['127.0.0.1','localhost']))
sdk=CANDIDATE/'native/build/linux-x64/node-24.22.1';environment.update(RED_PANDA_COLLECTIONS_ADDON=str(sdk/'collections.node'),RED_PANDA_RUNTIME_ADDON=str(sdk/'runtime.node'))
def save():(OUT/'controller.json').write_text(json.dumps(record,indent=2)+'\n')
def kill(pid,sig):
 try:os.killpg(pid,sig)
 except ProcessLookupError:pass
def run(label,args,cwd,epoch=None,tests=None):
 remaining=CAP-(time.monotonic()-START)
 if remaining<=CLEANUP:raise TimeoutError('Administrative cap before next phase')
 child=None;row={'label':label,'command':args,'cwd':str(cwd),'startedMonotonic':time.monotonic()};record['commands'].append(row);save();env=environment.copy()
 if epoch:env['PROBE_EPOCH']=epoch
 try:
  with(OUT/(label+'.stdout')).open('wb')as stdout,(OUT/(label+'.stderr')).open('wb')as stderr:
   child=subprocess.Popen(args,cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True);row['pid']=child.pid;save()
   try:row['exitCode']=child.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    row['administrativeWatchdog']=True;kill(child.pid,signal.SIGTERM)
    try:child.wait(timeout=CLEANUP)
    except subprocess.TimeoutExpired:kill(child.pid,signal.SIGKILL);child.wait()
    raise
  if row['exitCode']!=0:raise RuntimeError(label+' actual nonpass; later phases UNRUN')
  if tests is not None:
   text=(OUT/(label+'.stdout')).read_text();summary={k:int(v)for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M)};row['TAP']=summary
   if summary!={'tests':tests,'pass':tests,'fail':0,'cancelled':0,'skipped':0,'todo':0}:raise RuntimeError('Actual TAP accounting contrary')
 finally:
  if child is not None and child.poll()is None:kill(child.pid,signal.SIGKILL);child.wait()
  row['closed']=child is None or child.poll()is not None;row['durationSec']=time.monotonic()-row['startedMonotonic'];save();print(json.dumps(row),flush=True)
try:
 if MODE=='native-heldouts':
  run('native-heldouts',[str(NODE),'helpers/profile-heldouts.mjs','native'],ROOT/'causal',EPOCH)
  raw=json.loads((ROOT/'causal/runs'/EPOCH/'native.json').read_text());assert not raw['unobserved'];record['actualHeldoutRows']=raw['results'][0]['payload']['rows'];record['status']='Native-heldouts-observed-REQUIRES-review-not-candidate-acceptance'
 else:
  for name in ['src/worker-performance.js','src/workers.js','src/platform-codec.js','test/worker-performance.test.js']:
   run('syntax-'+Path(name).stem,[str(NODE),'--check',name],CANDIDATE)
  run('new5',[str(NODE),'--test','--test-reporter=tap','--test-concurrency=1','test/worker-performance.test.js'],CANDIDATE,tests=5)
  run('candidate-five',[str(NODE),'helpers/profile.mjs','root'],ROOT/'causal',EPOCH)
  baseline=json.loads((ROOT/'evidence/native-five.json').read_text());raw=json.loads((ROOT/'causal/runs'/EPOCH/'root.json').read_text());assert not raw['unobserved']
  record['original4']=[{'name':a['name'],'equalPayload':a['payload']==b['payload'],'native':a['payload'],'candidate':b['payload']}for a,b in zip(baseline['results'][:4],raw['results'][:4])]
  assert len(record['original4'])==4 and all(r['equalPayload']for r in record['original4']),'Original actual Worker payload contrary'
  import copy
  a=copy.deepcopy(baseline['results'][4]['payload']);b=copy.deepcopy(raw['results'][4]['payload']);record['actualDynamicClockFields']={}
  for profile,value in [('native',a),('candidate',b)]:
   surface=value['rows'][0]['value'];record['actualDynamicClockFields'][profile]={k:surface.pop(k)for k in ['now','origin','epochDelta']}
  record['stableSurfaceEqual']=a==b;record['stableSurfaceNative']=a;record['stableSurfaceCandidate']=b
  assert record['stableSurfaceEqual'],'Actual stable surface contrary; full raw retained, no clock equality claim'
  # Reproduce both independently authored Native heldout programs, retaining all raw.
  heldout_epoch=EPOCH+'-heldouts';run('candidate-heldouts',[str(NODE),'helpers/profile-heldouts.mjs','root'],ROOT/'causal',heldout_epoch)
  native_heldouts=json.loads((ROOT/'evidence/native-heldouts.json').read_text());candidate_heldouts=json.loads((ROOT/'causal/runs'/heldout_epoch/'root.json').read_text());assert not candidate_heldouts['unobserved']
  left=copy.deepcopy(native_heldouts['results'][0]['payload']);right=copy.deepcopy(candidate_heldouts['results'][0]['payload']);record['heldoutDynamicClockFields']={}
  for profile,value in [('native',left),('candidate',right)]:
   dynamic={};one=value['rows'][0]['value'];two=value['rows'][1]['value'];dynamic['brandMark.startTime']=one['json'].pop('startTime')
   for row in two['errorResults']:
    if row['name']in ['symbol','null-options']:dynamic[row['name']+'.startTime']=row['value'].pop('startTime')
   for row in two['stableOrder']:
    if row['name']in ['x','null']:dynamic['ordered.'+row['name']+'.start']=row.pop('start')
   record['heldoutDynamicClockFields'][profile]=dynamic
  record['heldoutStableEqual']=left==right;record['heldoutStableNative']=left;record['heldoutStableCandidate']=right
  assert record['heldoutStableEqual'],'Actual independently heldout stable values contrary; later source UNRUN'
  final_epoch=EPOCH+'-final';run('candidate-final',[str(NODE),'helpers/profile-final.mjs','root'],ROOT/'causal',final_epoch)
  final_native=json.loads((ROOT/'evidence/native-final.json').read_text());final_candidate=json.loads((ROOT/'causal/runs'/final_epoch/'root.json').read_text());assert not final_candidate['unobserved']
  record['finalFullPayloadEqual']=final_native['results'][0]['payload']==final_candidate['results'][0]['payload'];record['finalNative']=final_native['results'][0]['payload'];record['finalCandidate']=final_candidate['results'][0]['payload']
  assert record['finalFullPayloadEqual'],'Actual final authority/allocation controls contrary; later source UNRUN'
  run('candidate-original-source',[str(NODE),'helpers/profile.mjs','root'],ROOT/'source',EPOCH)
  report=json.loads((ROOT/'source/runs'/EPOCH/'root-source-report.json').read_text());result=report['results'][0];contract=result['sourceLoadContract'];configuration=result['configuration']
  assert report['counts']=={'selected':1,'passed':1,'failed':0,'timeout':0,'unobserved':0}
  assert result['harnessObserved']and result['nativeHarnessBranch']and result['nonzeroObservationsEnforced']
  assert contract['loadBudgetMs']==2000 and contract['assertionBudgetMs']==2000 and contract['loadBarrier']['observed']and contract['assertionStartedAfterLoad']
  assert configuration['browserArgs']==['--ws-max-concurrent','50','--load-resources','iframe','--load-resources','worker']
  assert not report['publicUserAgentOverrideApplied']and not report['publicClientHintsOverrideApplied']
  record['sourceCounts']=report['counts'];record['status']='candidate-first-gate-pass-NOT-full-Worker-Performance-equivalence'
except Exception as e:record['status']='stopped-first-contrary';record['error']={'name':type(e).__name__,'message':str(e)}
finally:
 record['after']=guard();record['stable']=record['before']==record['after'];record['durationSec']=time.monotonic()-START;record['browserReadback']=[]
 for folder in ['causal','source']:
  parent=ROOT/folder/'runs'
  for path in sorted(parent.glob(EPOCH+'*'))if parent.exists()else[]:
   for f in path.glob('*.json'):
    d=json.loads(f.read_text());pid=d.get('pid');
    if pid:record['browserReadback'].append({'file':str(f),'pid':pid,'procPresent':Path('/proc',str(pid)).exists(),'cleanup':d.get('cleanup')})
    for r in d.get('results',[]):
     owned=r.get('ownedBrowser',{});pid=owned.get('pid')
     if pid:record['browserReadback'].append({'file':str(f),'pid':pid,'procPresent':Path('/proc',str(pid)).exists(),**owned})
 save();print(json.dumps({'status':record['status'],'stable':record['stable'],'durationSec':record['durationSec']}),flush=True)
if not record['stable']or record['status']=='stopped-first-contrary':sys.exit(1)
