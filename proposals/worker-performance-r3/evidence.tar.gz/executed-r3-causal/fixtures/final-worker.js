onmessage=()=>{
 const rows=[],call=fn=>{try{return{value:fn()}}catch(e){return{error:{name:e.name,message:e.message,ownTypeError:e instanceof TypeError}}}},phase=(name,fn)=>{try{rows.push({name,value:fn()})}catch(e){rows.push({name,error:{name:e.name,message:e.message}})}};
 phase('mutable-supported-array-identity-and-static-getter',()=>{
  const a=PerformanceObserver.supportedEntryTypes,b=PerformanceObserver.supportedEntryTypes,original=Array.from(a),beforeSame=a===b;a.push('authored-mutation');const c=PerformanceObserver.supportedEntryTypes;
  const getter=Object.getOwnPropertyDescriptor(PerformanceObserver,'supportedEntryTypes').get;
  return{original,beforeSame,afterSame:c===a,actualMutatedA:Array.from(a),actualB:Array.from(b),actualC:Array.from(c),frozen:Object.isFrozen(a),ownArray:Object.getPrototypeOf(a)===Array.prototype,borrow:call(()=>Array.from(getter.call({})))};
 });
 phase('actual-global-performance-getter-receiver-authority',()=>{
  const getter=Object.getOwnPropertyDescriptor(globalThis,'performance').get,p=performance,result=[];
  for(const[name,value]of[['self',globalThis],['ordinary',{}],['inherited',Object.create(globalThis)],['proxy',new Proxy(globalThis,{})],['undefined',undefined],['null',null]])result.push({name,...call(()=>{const returned=Reflect.apply(getter,value,[]);return{same:returned===p,tag:Object.prototype.toString.call(returned)}})});
  return result;
 });
 phase('actual-symbol-name-conversion-and-observer-no-new',()=>{
  const result=[];for(const[name,value]of[['description',Symbol('x')],['undefined-description',Symbol()],['registry',Symbol.for('actual-registry')],['object-returning-symbol',{[Symbol.toPrimitive](){return Symbol('object')}}]])result.push({name,...call(()=>{const e=performance.mark(value,{startTime:1});return{name:e.name,start:e.startTime}})});
  result.push({name:'observer-valid-no-new',...call(()=>{const value=PerformanceObserver(()=>{});return{tag:Object.prototype.toString.call(value),instance:value instanceof PerformanceObserver}})});return result;
 });
 postMessage({kind:'independent-surface-report',rows});
};
