onmessage=async()=>{
 const rows=[],describe=e=>({name:e.name,message:e.message,ownTypeError:e instanceof TypeError}),call=fn=>{try{const value=fn();return{value:value===undefined?'[actual undefined]':value}}catch(e){return{error:describe(e)}}},phase=async(name,fn)=>{try{rows.push({name,value:await fn()})}catch(e){rows.push({name,error:describe(e)})}};
 const descriptor=(o,k)=>{const d=Object.getOwnPropertyDescriptor(o,k);return d?{configurable:d.configurable,enumerable:d.enumerable,writable:d.writable,valueType:typeof d.value,get:d.get?.name,set:d.set?.name}:null};
 await phase('actual-constructor-descriptor-and-brand-boundaries',()=>{
  const constructors={};for(const name of['Performance','PerformanceEntry','PerformanceMark','PerformanceMeasure','PerformanceResourceTiming','PerformanceNavigationTiming','PerformanceObserver','PerformanceObserverEntryList']){
   const C=globalThis[name];constructors[name]={name:C?.name,length:C?.length,prototype:descriptor(C,'prototype'),direct:call(()=>{const x=new C('actual');return{tag:Object.prototype.toString.call(x)}}),bare:call(()=>C('actual'))};
  }
  const mark=performance.mark('brand'),fakes=[{},Object.create(Performance.prototype),new Proxy(performance,{})];
  return{constructors,globalPerformance:descriptor(globalThis,'performance'),now:descriptor(Performance.prototype,'now'),timeOrigin:descriptor(Performance.prototype,'timeOrigin'),markDetail:descriptor(PerformanceMark.prototype,'detail'),supported:descriptor(PerformanceObserver,'supportedEntryTypes'),supportedFrozen:Object.isFrozen(PerformanceObserver.supportedEntryTypes),brands:fakes.map(value=>call(()=>Performance.prototype.now.call(value))),markBrand:call(()=>Object.getOwnPropertyDescriptor(PerformanceMark.prototype,'detail').get.call(Object.create(PerformanceMark.prototype))),json:mark.toJSON()};
 });
 await phase('actual-options-conversions-and-entries',()=>{
  performance.clearMarks();performance.clearMeasures();const trace=[],detail={real:1};const mark=performance.mark({toString(){trace.push('name');return'converted'}},{get startTime(){trace.push('startTime');return{valueOf(){trace.push('number');return 3}}},get detail(){trace.push('detail');return detail}});
  const entryReport=value=>({name:value.name,startTime:value.startTime,duration:value.duration}),errors=[];for(const[name,fn]of[['negative',()=>performance.mark('negative',{startTime:-1})],['negative-measure',()=>performance.measure('negative',{start:8,end:2})],['missing-mark',()=>performance.measure('missing','absent')],['symbol',()=>performance.mark(Symbol('x'))],['bigint',()=>performance.mark('bigint',{startTime:1n})],['null-options',()=>performance.mark('null',null)]])errors.push({name,...call(()=>entryReport(fn()))});
  return{trace,alias:mark.detail===detail,json:mark.toJSON(),errorResults:errors,stableOrder:performance.getEntries().map(e=>({name:e.name,start:e.startTime})),measure:performance.measure('span',{start:1,end:4,duration:2}).toJSON()};
 });
 await phase('actual-buffering-takeRecords-mode-and-errors',async()=>{
  performance.clearMarks();performance.mark('past',{startTime:1});const reports=[],observer=new PerformanceObserver((list,source)=>reports.push({same:source===observer,names:list.getEntries().map(e=>e.name)}));
  observer.observe({type:'mark',buffered:true});await new Promise(r=>setTimeout(r,10));performance.mark('pending',{startTime:2});const pending=observer.takeRecords().map(e=>e.name);await new Promise(r=>setTimeout(r,10));observer.disconnect();
  const mode=call(()=>observer.observe({entryTypes:['mark']})),empty=call(()=>new PerformanceObserver(()=>{}).observe({})),both=call(()=>new PerformanceObserver(()=>{}).observe({type:'mark',entryTypes:['mark']}));
  const exceptionReports=[];addEventListener('error',e=>{exceptionReports.push({message:e.message,name:e.error?.name});e.preventDefault()},{once:true});
  const first=new PerformanceObserver(()=>{first.disconnect();throw new Error('authored observer failure')}),second=new PerformanceObserver(list=>{reports.push({afterThrow:list.getEntries().map(e=>e.name)});second.disconnect()});first.observe({type:'mark'});second.observe({type:'mark'});performance.mark('after-failure');await new Promise(r=>setTimeout(r,10));
  return{reports,pending,mode,empty,both,exceptionReports};
 });
 await phase('actual-clone-successful-producer-vs-lookalikes',async()=>{
  const mark=performance.mark('clone'),measure=performance.measure('clone-span',{duration:1}),observer=new PerformanceObserver(()=>{});let list;const received=new Promise(resolve=>{const o=new PerformanceObserver(value=>{list=value;o.disconnect();resolve()});o.observe({type:'mark'});performance.mark('list')});await received;
  const values={performance,mark,measure,observer,list,fakeMark:Object.create(PerformanceMark.prototype),fakeObserver:Object.create(PerformanceObserver.prototype),fakeList:Object.create(PerformanceObserverEntryList.prototype)};const result=[];for(const[name,value]of Object.entries(values))result.push({name,...call(()=>{const copy=structuredClone(value);return{tag:Object.prototype.toString.call(copy),keys:Reflect.ownKeys(copy).map(String)}})});return result;
 });
 postMessage({kind:'independent-surface-report',rows});
};
