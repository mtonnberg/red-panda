import http from 'node:http';
import {once} from 'node:events';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {startReference} from './reference-server.mjs';
import {connect} from './cdp-client.js';
const profile=process.argv[2];if(!['native','root'].includes(profile))throw Error('Use native/root');
const base=new URL('../',import.meta.url),out=new URL('runs/'+(process.env.PROBE_EPOCH??'initial')+'/',base);await mkdir(out,{recursive:true});
const binary=profile==='native'?'/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux':new URL('root-launcher',base).pathname;
const hash=bytes=>createHash('sha256').update(bytes).digest('hex'),control=await readFile(new URL('helpers/single-control.js',base),'utf8'),original=await readFile(new URL('fixtures/original-worker.js',base)),surface=await readFile(new URL('fixtures/heldout-worker.js',base));
const record={profile,binary,binarySHA256:hash(await readFile(binary)),control,controlSHA256:hash(control),args:['--ws-max-concurrent','50','--load-resources','iframe','--load-resources','worker'],rpcMs:2500,loadMs:2000,perWorkerReportMs:2000,asyncControlEvalMs:2000,asyncControlRPCMs:2500,wire:[],status:'started'};
let browser,client,server,writes=Promise.resolve();const save=()=>{const bytes=JSON.stringify(record,null,2)+'\n';writes=writes.then(()=>writeFile(new URL(profile+'.json',out),bytes));return writes;};await writeFile(new URL(profile+'.json',out),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
try{
 server=http.createServer((req,res)=>{let body,type,known=true;const path=new URL(req.url,'http://owned.invalid').pathname;
  if(path==='/main'){body=Buffer.from('<!doctype html><body>Independent real Worker Performance controls');type='text/html';}
  else if(path==='/original-worker.js'){body=original;type='text/javascript';}
  else if(path==='/surface-worker.js'){body=surface;type='text/javascript';}
  else{body=Buffer.from('Unknown authored path');type='text/plain';known=false;}
  const row={url:req.url,path,method:req.method,headers:req.headers,requestHTTPVersion:req.httpVersion,status:known?200:404,known,bodyLength:body.length,bodySHA256:hash(body)};record.wire.push(row);res.once('finish',()=>{row.actualSerializedHeaders=res._header;void save();});res.writeHead(row.status,{'content-type':type,'content-length':String(body.length)});res.end(body);
 });server.listen(0,'127.0.0.1');await once(server,'listening');record.origin='http://127.0.0.1:'+server.address().port;await save();
 browser=await startReference(binary,{args:record.args});record.pid=browser.process.pid;await save();client=await connect(browser.endpoint,{timeout:2500});const{targetId}=await client.send('Target.createTarget',{url:'about:blank'}),{sessionId}=await client.send('Target.attachToTarget',{targetId,flatten:true}),send=(method,params,options)=>client.send(method,params,sessionId,options);
 await send('Page.enable');await send('Runtime.enable');const before=client.events.length;record.navigation=await send('Page.navigate',{url:record.origin+'/main'});await save();const deadline=Date.now()+2000;
 while(!client.events.slice(before).some(e=>e.sessionId===sessionId&&e.method==='Page.loadEventFired')){if(Date.now()>=deadline)throw Error('Actual document load not observed within2000ms');await new Promise(r=>setTimeout(r,10));}
 record.calls=[];record.results=[];record.unobserved=[];
 for(const kind of ['independent-surface']){
  const expression=control.replace('__ACTUAL_COMMAND__',JSON.stringify(kind)),call={kind,expression,expressionSHA256:hash(expression),rpcMs:2500,evalMs:2000,workerReportMs:2000};record.calls.push(call);await save();
  call.response=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,timeout:2000},{timeout:2500});await save();
  if(call.response.exceptionDetails)throw Error('Actual independent Worker control Runtime exception for '+kind);
  const row=call.response.result.value;record.results.push(row);if(!row.observed)record.unobserved.push({name:row.name,status:row.status,error:row.error});await save();
  if(!row.observed)break;
 }
 record.observations={result:{type:'object',value:{results:record.results,boundary:'Five separate serialized actual Worker controls, each2500msRPC/2000msWorker; not whole-source acceptance'}}};
 if(record.wire.some(r=>!r.known||r.status!==200))throw Error('Unexpected script request; preserve actual setup/transport contrary');
 record.status='observed-independent-payloads-and-surfaces-NOT-source-acceptance';
}catch(error){record.status='driver-setup-or-control-failure';record.error={name:error.name,message:error.message};process.exitCode=1;}
finally{await client?.close();await browser?.close();record.events=client?.events;record.stderr=browser?.stderr;record.exitCode=browser?.process.exitCode;if(server?.listening){server.closeAllConnections();await new Promise(r=>server.close(r));}record.cleanup={clientClosed:true,browserExitObserved:!browser||browser.process.exitCode!==null||browser.process.signalCode!==null,ownedHTTPClosed:true};await save();}
console.log(JSON.stringify({profile,status:record.status,pid:record.pid}));
