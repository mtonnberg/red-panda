(async()=>{
 const kind=__ACTUAL_COMMAND__,surface=kind==='independent-surface',started=performance.now();
 return await new Promise(resolve=>{
  let worker,done=false;const finish=value=>{if(done)return;done=true;clearTimeout(timer);worker?.terminate();resolve({name:surface?kind:'original-'+kind,reportBudgetMs:2000,durationMs:performance.now()-started,...value});};
  const timer=setTimeout(()=>finish({status:'report-timeout',observed:false}),2000);
  try{worker=new Worker(new URL(surface?'/surface-worker.js':'/original-worker.js',location.href).href);worker.onmessage=e=>finish({status:'message',observed:true,payload:e.data});worker.onerror=e=>{e.preventDefault();finish({status:'worker-error',observed:false,error:{message:e.message,filename:e.filename,lineno:e.lineno}})};worker.postMessage(surface?{actual:true}:{kind});}catch(e){finish({status:'constructor-error',observed:false,error:{name:e.name,message:e.message}})}
 });
})()
