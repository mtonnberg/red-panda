# R2: reject an already contextified pending carrier

SOURCE ONLY, UNCOMPILED/UNRUN. Exact prerequisite: immutable `/workspace/shared/node-provider-prototype-v1`, manifest `f8828eed1431b22c932877ba417d65cd0a0bf8e73de40276b7a7ffb050c0dcbf`. R1 and the official Node tree remain unchanged.

R1 accepted this invalid transition: `vm.prepareOwnedContext(A)` -> ordinary `vm.createContext(ticket, B)` -> native `CreateOwnedContext(ticket)`. Ordinary creation legitimately replaces the carrier's private HDO with B and installs its real canonical Contextify wrapper, while the new pending flag stays true. R1 then replaced that wrapper, breaking the ordinary Context's lifetime edge.

The narrow R2 production change is solely in `ContextifyContext::NewOwned`: before reading pending/HDO, consuming either ticket/lease or allocating a Context, check the actual Node-private Contextify slot. If occupied, read and unwrap the real canonical wrapper and reject with ERR_INVALID_STATE. Any other occupied private value also rejects. No authored property, public vm.isContext result, tag or prototype grants/revokes authority. Stock MakeContext already treats occupied private authority as non-contextifiable.

Ordinary MakeContext is deliberately unchanged. A prepared ticket may still become an ordinary Context; after that transition it is permanently ineligible for native owned creation. Its ordinary wrapper/HDO B must remain intact. R2 neither resets pending nor rewrites HDO during rejection. A plain unused prepared carrier remains consumable once. A rejected collision must not consume a separate previous owned proxy lease.

`r2-carrier-collision.patch` contains this one changed runtime file and one added C++ test file. New JS controls cover the exact A/B callback sequence, actual ordinary Script/SourceTextModule/closure continuation, preservation of the previous real proxy lease, unused one-shot tickets, DONT_CONTEXTIFY and Proxy controls. The genuine ordinary-context HDO producer is copied as a test contract from pinned Node's `test/parallel/test-vm-module-referrer-realm.mjs:31`; its documented no-JS-stack/CallbackScope condition is preserved, not replaced with another producer to obtain a pass. Separate GC code retains a real module namespace then observes actual carrier collection. The C++ case directly checks original Contextify pointer, Context, canonical wrapper, actual private HDO/pending state and kSandboxObject identity, then genuine Context/carrier/wrapper/cppgc retention and collection. All are UNRUN.

R2 is **not a complete provider fix**. Independent source review confirmed an additional active-owned-public-proxy alias blocker: ordinary `vm.createContext(ownedProxy)` can place its canonical wrapper/HDO on the old owned hidden global. DetachGlobal severs proxy->oldGlobal and can break the retained ordinary context's required wrapper chain. This occurs before any assumption about proxy reinitialization. R2 does not address it; R3 must handle exact raw-proxy eligibility before ordinary MakeContext writes private state. No private marker on the public proxy can solve this storage/lifetime issue.

Source audit anchors for that separate blocker, under the full verified official Node tree:

- `deps/v8/src/api/api.cc:4576`: SetPrivate -> DefineOwnPropertyIgnoreAttributes.
- `deps/v8/src/objects/lookup-inl.h:394`: active JSGlobalProxy store target is hidden JSGlobalObject.
- `deps/v8/src/objects/lookup.cc:1241`: private lookup still follows JSGlobalProxy's prototype.
- `deps/v8/src/execution/isolate.cc:7153`: DetachGlobal removes proxy->oldGlobal.

DONT_CONTEXTIFY itself takes a sentinel, creates its own distinct global/private wrapper/HDO, and cannot directly consume the prepared ticket. Its resulting raw proxy is not a pending Host ticket and must reject native owned creation. Ordinary contextifying the genuine owned public proxy is a separate eligibility problem, now queued for R3. Authored JS Proxy wrappers are different values and private storage rules; do not conflate them with V8's raw JSGlobalProxy or reject every Proxy by type.

No build/runtime/network/Root/toolchain change occurred. Do not build/promote this packet as a complete provider; first compose the independently reviewed R3. Existing GC, snapshot, token/Promise, Document/Page/Frame, module-deadline, utility/error/graph and other-SDK bounds remain unproved.
