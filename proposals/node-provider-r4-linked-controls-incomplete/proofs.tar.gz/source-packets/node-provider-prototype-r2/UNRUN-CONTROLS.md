# Prepared controls, not outcomes

After an exclusive build/runtime grant and after R3 composition, build a new matching custom Node+cctest+generic addon in its own source/build root. Preserve the original R1 packet and its artifact identities. R2 adds a C++ source file, so configure must enumerate it before building cctest; an older configured source list cannot be assumed to include it.

Under custom Node `--experimental-vm-modules` with OWNED_PROVIDER_ADDON pointing to the freshly built R1-compatible generic test addon, run `harness/carrier-collision-controls.mjs` (3 groups). Then run `harness/carrier-collision-gc.mjs` with `--expose-gc --experimental-vm-modules` (12 actual GC turns per cohort), and cctest `--gtest_filter=OwnedContextCollisionTest.*` (one actual canonical-wrapper/cppgc case; eight low-memory requests for final collection). Each requires a separately declared administrative watchdog; do not change20ms/1000ms API budgets or8/12 GC counts from the prepared generic suite.

Keep stdout/stderr, exact source/binary/addon hashes, callback/referrer observations, child exits/signals/admin timeouts, and remaining UNRUN stages. A callback producer mismatch, unavailable SourceTextModule, assertion failure, unobserved GC or crash remains distinct. Existing R1 eleven generic groups, two C++ cases and other capability files remain independent UNRUN prerequisites, not passes established by these new controls.

R1 counterfactual should reject this test's rejection assertion because its owned creation incorrectly succeeds. That counterfactual has not been executed. The public-proxy lifetime alias is an independently sourced blocker, not covered by the carrier guard or an accepted runtime result here.
