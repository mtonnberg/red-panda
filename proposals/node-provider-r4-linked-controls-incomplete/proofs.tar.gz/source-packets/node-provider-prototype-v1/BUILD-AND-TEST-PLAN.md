# Controlled offline build and generic runtime plan

All commands below are **NOT RUN**. No current runtime/build/network lease is held. Review the exact source patch first; a substantive compiler/runtime failure stops promotion and is preserved. The original verified source remains immutable.

## Resources and ownership

Use only a fresh build root `/workspace/shared/node-provider-build-v1/source` and an addon-local build under `/workspace/shared/node-provider-build-v1/harness/build`. All generated logs, artifacts and harness copies live under `/workspace/shared/node-provider-build-v1`; the frozen prototype packet is never an output directory. No installs into Root, shared rea-tools, system locations, current SDKs, npm globals or live service. No source/toolchain configuration changed yet. Keep the exact source archive hash and patch manifest with all custom artifacts. Node's public version/ABI137 alone does **not** authorize reusing any Root addon; custom API/header/binary identities are mandatory.

Conservative planning estimate on the stated 4 CPU/32 GiB machine: configure under 2 minutes; clean full Release Node+cctest build roughly 20–90 minutes depending on cache/compiler/disk; two compiler jobs initially, potentially 4–10 GiB peak resident memory, and reserve at least25 GiB free disk for source/output/logs. These are estimates, not measurements. Full build needs a dedicated long lease, not a tiny-addon slot. Bound the initial build at90 minutes, retain partial logs/output and stop on error/deadline. Do not silently increase jobs or deadlines. All dependencies required for this plan are present in the full official archive (bundled V8, OpenSSL, googletest, npm's node-gyp). Missing OS/compiler requirements cause a stop, not a package install or download.

Before grant only static planning/hashes are allowed. After a grant, materialize a fresh complete source copy with `python3 helpers/materialize.py`; that helper verifies all seven original base hashes and official-source input readback, copies the full tree into the dedicated absent build directory (with a separate exact harness copy outside the immutable source packet), then overlays only exact candidate leaves. It does not run configuration, compilation, Node or tests.

From the fresh build directory, future reviewed commands are:

```
./configure --without-npm --without-corepack
make -j2 node cctest
```

Use inherited managed environment and normal TLS policy, with **no network acquisition**. Source archive includes bundled dependencies. Do not use ccache/current build outputs or Root SDK headers to claim a fresh extension build. Default Node snapshots are deliberately preserved; disabling snapshots would only prove a narrower configuration. Log actual configure options, compiler versions/flags, source/archive/patch identities, binary SHA and process.versions. Do not deploy. If an administrator sets an outer90-minute watchdog, that does not alter any Node API/test deadline.

The source configure enumerates `test/cctest/*.{cc,h}` (`configure.py:1625`), so the new C++ test is genuinely included without an invented build target. Actual target availability and source compilation are unproved until this build runs.

## Addon and controls after a separate runtime grant

Build the **test addon** with the newly built Node and its bundled node-gyp, using its exact source build headers/config. `--nodedir` and local `--devdir` avoid header acquisition. No package manager installation:

```
BUILD_SOURCE/out/Release/node BUILD_SOURCE/deps/npm/node_modules/node-gyp/bin/node-gyp.js configure build --nodedir=BUILD_SOURCE --directory=BUILD_ROOT/harness --devdir=BUILD_ROOT/gyp-cache --jobs=1
```

Replace BUILD_SOURCE and BUILD_ROOT with literal absolute owned paths, not Root. Record both Node and addon binary hashes. The custom Node providerVersion and genuine exported Create/Get/Detach symbols must match the compiled public header. Stop if node-gyp tries network or lacks a dependency.

The prepared `helpers/run-controls.py --node ABS_CUSTOM_NODE --cctest ABS_CUSTOM_CCTEST` executes each stage serially under a declared45-second administrative watchdog and captures actual stdout/stderr/exit/timeout separately, stopping at the first nonzero/timeout. It never builds. Test/native budgets remain20ms (watchdog cases),1000ms (module evaluation), eight native GC requests and twelve JS GC turns per declared cohort. A collection not observed within its bounded cohort is a failed/unobserved lifetime proof, never a filtered result. Execute with no competing browser/heap/deadline jobs.

Stages:

1. Eleven generic JS groups through real proposed APIs: pending/fake authority; stock Node contexts/deadline; actual realm allocations/contextExtensions; exact raw proxy reuse/retained closures; genuine lease rejections; real module/meta/static dependency; different-context link rejection despite equal proxy; actual old/new context HDO import namespace/referrer; real module/script/function custom callbacks and missing callback; unowned Node module/meta/import preservation; owned native deadline recovery/authored error identity.
2. JS GC cohorts: a retained old closure, a real module namespace and an actual context-HDO callback/namespace registry cohort independently keep actual Context+carrier alive, then all collect after all roots drop. An actual reused proxy cohort separately requires both released contexts to collect. Native observers use only weak original Context/carrier handles. Host template caches are explicitly released before collection.
3. Two C++ tests: one rejects a genuine ticket from another Environment; one directly observes genuine canonical Contextify wrapper and `cppgc::WeakPersistent<ContextifyContext>`, first retained by a real old function then released. It uses ordinary low-memory GC requests and drains tasks; no untraced External roots or fake wrapper classifications.
4. Separate actual-token control: preserves a real Symbol token distinct from Host and attempts genuine namespace import through a Host callback. Any failure is captured as the unresolved token/Promise capability, not hidden behind shared-token success. This is not an access-checked Window SOP test.
5. Actual Node `--build-snapshot` ticket rejection plus an ordinary snapshot build/load control in fresh owned output directories. Existing build snapshots/Node startup are independent controls. Direct trusted V8 SnapshotCreator use outside Node's snapshot-building mode remains unsupported/unvalidated.

Runtime success here would establish only the measured generic boundary. Next coherent application tranche must inject genuine immutable Context authority into the frozen OwnedDocumentRuntime/canonical factory chain and prove real retained oldDocument.createElement, fresh current Document, actual Page/Frame/CDP lifecycle and old public prototype graphs. The real Document test is presently **not implemented or executed** in this generic harness. It must not be replaced with a JS object that merely has a document-like name.
