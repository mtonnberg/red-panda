#!/usr/bin/env python3
"""UNRUN runtime controller; never builds, downloads or edits Root."""
import argparse, datetime, hashlib, json, os, pathlib, signal, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--node',required=True);p.add_argument('--cctest',required=True)
a=p.parse_args();node=str(pathlib.Path(a.node).resolve());cctest=str(pathlib.Path(a.cctest).resolve())
BUILD=pathlib.Path('/workspace/shared/node-provider-build-v1')
expected=BUILD/'source/out/Release'
assert pathlib.Path(node)==expected/'node', 'Use only this proposal custom Node'
assert pathlib.Path(cctest)==expected/'cctest', 'Use only matching custom cctest'
addon=BUILD/'harness/build/Release/provider.node'
assert addon.is_file()
out=BUILD/'runtime-evidence'
assert not out.exists(), 'Preserve each runtime epoch; do not overwrite it'
out.mkdir()
env=os.environ.copy();env['OWNED_PROVIDER_ADDON']=str(addon)
commands=[
('identity',[node,'-p','JSON.stringify({execPath:process.execPath,versions:process.versions,config:process.config.variables})'],out),
('generic',[node,'--experimental-vm-modules',str(BUILD/'harness/generic-controls.mjs')],out),
('js-gc',[node,'--expose-gc','--experimental-vm-modules',str(BUILD/'harness/gc-controls.mjs')],out),
('cppgc',[cctest,'--gtest_filter=OwnedContextProviderTest.*'],out),
('tokens',[node,'--experimental-vm-modules',str(BUILD/'harness/token-controls.mjs')],out),
('snapshot-reject',[node,'--snapshot-blob=reject.blob','--build-snapshot',str(BUILD/'harness/snapshot-rejection.cjs')],out),
('snapshot-normal-build',[node,'--snapshot-blob=normal.blob','--build-snapshot',str(BUILD/'harness/ordinary-snapshot.cjs')],out),
('snapshot-normal-load',[node,'--snapshot-blob=normal.blob','-e',"require('node:assert/strict').equal(genericSnapshotProof.answer,42)"],out),
]
guard_paths=list((ROOT/'candidate').rglob('*'))+list((ROOT/'harness').rglob('*'))
guard_paths=[x for x in guard_paths if x.is_file() and 'build' not in x.relative_to(ROOT).parts]
for row in json.loads((ROOT/'source-base.json').read_text())['leaves']:
    build_leaf=BUILD/'source'/row['path']
    assert hashlib.sha256(build_leaf.read_bytes()).hexdigest()==row['candidateSHA256'],str(build_leaf)
    guard_paths.append(build_leaf)
for original in (ROOT/'harness').rglob('*'):
    if original.is_file():
        copied=BUILD/'harness'/original.relative_to(ROOT/'harness')
        assert hashlib.sha256(copied.read_bytes()).digest()==hashlib.sha256(original.read_bytes()).digest(),str(copied)
        guard_paths.append(copied)
guard_paths += [pathlib.Path(node),pathlib.Path(cctest),addon,ROOT/'source-base.json',ROOT/'node-owned-provider.patch']
def snapshot():
    return {str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in guard_paths}
before=snapshot()
def interrupted(signum,frame):
    raise KeyboardInterrupt(f'Controller signal {signum}')
signal.signal(signal.SIGTERM,interrupted)
record={'status':'started','inputsBefore':before,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'binarySHA256':{str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in [pathlib.Path(node),pathlib.Path(cctest),addon]},'stages':[]}
for name,cmd,cwd in commands:
    timed=False;pid=None;child=None
    try:
        with (out/(name+'.log')).open('wb') as log:
            child=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            pid=child.pid
            try:code=child.wait(timeout=45)
            except subprocess.TimeoutExpired:
                timed=True
                try:os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:code=child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    code=child.wait()
    except OSError as error:
        code=None;(out/(name+'.error')).write_text(repr(error))
    finally:
        if child is not None and child.poll() is None:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait()
    record['stages'].append({'name':name,'command':cmd,'ownedPid':pid,'returnCode':code,
                             'signal':-code if code is not None and code<0 else None,
                             'administrativeTimeout':timed,
                             'status':'timeout' if timed else 'pass' if code==0 else 'failure'})
    (out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record['stages'][-1]),flush=True)
    if code!=0 or timed:
        record['status']='stopped-first-nonzero';break
else:record['status']='all-declared-generic-stages-returned-zero'
record['unrunStages']=[row[0] for row in commands[len(record['stages']):]]
record['inputsAfter']=snapshot()
record['inputsStable']=record['inputsBefore']==record['inputsAfter']
if not record['inputsStable']:record['status']='input-mismatch'
(out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'stagesCompleted':len(record['stages']),'report':str(out/'report.json')}))
sys.exit(0 if record['status']=='all-declared-generic-stages-returned-zero' else 1)
