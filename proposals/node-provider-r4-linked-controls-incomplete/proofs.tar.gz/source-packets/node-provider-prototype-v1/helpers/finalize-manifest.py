from pathlib import Path
from hashlib import sha256
import ast,json,datetime
root=Path(__file__).resolve().parents[1]
def digest(path):return sha256(path.read_bytes()).hexdigest()
for p in (root/'helpers').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
proof={'status':'SOURCE ONLY; no native compile or runtime executed',
 'patchApplyCheck':{'command':['git','apply','--check',str(root/'node-owned-provider.patch')],
                    'workingDirectory':str(root/'evidence/apply-base'),'exitCode':0,
                    'scope':'Seven exact original file copies and absent new cctest path; no official source mutation'},
 'PythonHelpersAST':'Parsed only; runtime/materialization/build controllers NOT invoked',
 'compileChecks':'UNRUN','JSsyntaxChecks':'UNRUN','runtimeTests':'UNRUN','NodeExecution':False,
 'network':False,'configurationOrBuild':False,'RootOrToolchainEdits':False,
 'allControlClaims':'Proposed assertions, not accepted outcomes',
 'preparedBuildRoot':'/workspace/shared/node-provider-build-v1 (not created)',
 'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'evidence/final-static-status.json').write_text(json.dumps(proof,indent=2)+'\n')
rows=[]
for p in sorted(root.rglob('*')):
 if p.is_file() and p.name!='manifest.json':
  rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest(p)})
manifest={'kind':'Immutable source-only genuine Node provider prototype; not production/parity',
          'sourcePatchSHA256':digest(root/'node-owned-provider.patch'),
          'sourceBaseSHA256':digest(root/'source-base.json'),
          'files':rows,'runtime':'UNRUN','build':'UNRUN'}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifestSHA256':digest(root/'manifest.json'),'files':len(rows),
                  'bytes':sum(r['bytes'] for r in rows),
                  'patchSHA256':manifest['sourcePatchSHA256'],'patchBytes':(root/'node-owned-provider.patch').stat().st_size}))
