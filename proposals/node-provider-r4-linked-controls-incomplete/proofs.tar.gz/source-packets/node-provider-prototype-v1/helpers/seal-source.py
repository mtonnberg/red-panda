from pathlib import Path
from hashlib import sha256
import ast, datetime, difflib, json, re, shutil
base=Path(__file__).resolve().parents[1]
source=Path('/workspace/shared/node-provider-source-v24.22.1/source/node-v24.22.1')
def digest(path):return sha256(path.read_bytes()).hexdigest()
def put(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
leaves=[];patch=[]
check=base/'evidence/apply-base'
check.mkdir(exist_ok=True)
for target in sorted((base/'candidate').rglob('*')):
    if not target.is_file():continue
    rel=str(target.relative_to(base/'candidate'));original=source/rel
    old=original.read_text() if original.exists() else ''
    new=target.read_text()
    leaves.append({'path':rel,'baseSHA256':digest(original) if original.exists() else None,
                   'candidateSHA256':digest(target),'candidateBytes':target.stat().st_size})
    patch.append(f'diff --git a/{rel} b/{rel}\n')
    if not original.exists():patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
        fromfile=f'a/{rel}' if original.exists() else '/dev/null',tofile=f'b/{rel}',n=3))
    if original.exists():
        dest=check/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,dest)
(base/'node-owned-provider.patch').write_text(''.join(patch))
put(base/'source-base.json',{'kind':'Source-only prototype; no compilation or runtime validation',
    'officialNode':'24.22.1','officialArchiveSHA256':'4f5379796280cdaeb0c2f358fd04b6a16cc4fb7dfa83b5a8c91a9d963b435231',
    'sourceRoot':str(source),'leaves':leaves,'patchSHA256':digest(base/'node-owned-provider.patch')})
for path in (base/'helpers').glob('*.py'):ast.parse(path.read_text(),filename=str(path))
old_review=Path('/workspace/shared/node-provider-source-v24.22.1/review/source-map.json')
rows=json.loads(old_review.read_text())['files']
guards=[{'path':r['absolutePath'],'sha256':digest(Path(r['absolutePath'])),
          'unchanged':digest(Path(r['absolutePath']))==r['sha256']} for r in rows]
assert all(r['unchanged'] for r in guards)
generic=(base/'harness/generic-controls.mjs').read_text()
cpp=(base/'candidate/test/cctest/test_owned_context_provider.cc').read_text()
cases=[{'kind':'Node JS generic','name':s,'status':'UNRUN'} for s in re.findall(r"await test\('([^']+)'",generic)]
cases += [{'kind':'C++ cctest','name':s,'status':'UNCOMPILED/UNRUN'} for s in re.findall(r'TEST_F\(OwnedContextProviderTest, ([^)]+)\)',cpp)]
for path in ['harness/gc-controls.mjs','harness/token-controls.mjs','harness/snapshot-rejection.cjs','harness/ordinary-snapshot.cjs']:
    cases.append({'kind':'Separate generic capability file','path':path,'status':'UNRUN'})
put(base/'evidence/static-readback.json',{'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'officialReviewSourceMapSHA256':digest(old_review),'priorSelectedInputsUnchanged':len(guards),'guards':guards,
    'NodeChangedFiles':sum(r['baseSHA256'] is not None for r in leaves),'NodeAddedFiles':sum(r['baseSHA256'] is None for r in leaves),
    'PythonHelperAST':'parsed only; no build/runtime controller invoked',
    'compileChecks':'UNRUN','JSsyntaxChecks':'UNRUN','runtimeControls':'UNRUN','network':'NONE',
    'RootEdits':'NONE','genericCases':cases,
    'realDocumentControl':'UNIMPLEMENTED; ordinary JS value explicitly not a Document',
    'runtimeLimitsRemaining':['snapshot external trusted V8 use','GC/cppgc','distinct-token Promise adoption','Page/Frame/Document canonical composition','nested abandonment','custom slot macros','Node26 port']})
print(json.dumps({'patchSHA256':digest(base/'node-owned-provider.patch'),'leaves':len(leaves),
                  'genericGroups':len(re.findall(r'await test\(',generic)),'cppgcCases':len(re.findall(r'TEST_F\(',cpp)),
                  'selectedOfficialInputsUnchanged':len(guards)}))
