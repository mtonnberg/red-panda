#!/usr/bin/env python3
"""Prepare a complete OWNED build copy ONLY AFTER a source/build lease.
No configure/build/Node/test/network operation is performed by this helper.
"""
from pathlib import Path
from hashlib import sha256
import json, shutil
base=Path(__file__).resolve().parents[1]
source=Path('/workspace/shared/node-provider-source-v24.22.1/source/node-v24.22.1')
manifest=json.loads((base/'source-base.json').read_text())
for row in manifest['leaves']:
    path=source/row['path']
    if row['baseSHA256'] is None:
        assert not path.exists(),str(path)
    else:
        assert sha256(path.read_bytes()).hexdigest()==row['baseSHA256'],str(path)
    assert sha256((base/'candidate'/row['path']).read_bytes()).hexdigest()==row['candidateSHA256']
archive=source.parents[1]/'downloads/node-v24.22.1.tar.xz'
assert sha256(archive.read_bytes()).hexdigest()==manifest['officialArchiveSHA256']
build_root=Path('/workspace/shared/node-provider-build-v1')
assert not build_root.exists()
target=build_root/'source'
assert not target.exists(), 'Never overwrite an earlier build/source epoch'
assert shutil.disk_usage(base).free >=25*1024**3, 'Reserve at least25 GiB free disk'
build_root.mkdir()
shutil.copytree(source,target,symlinks=False)
shutil.copytree(base/'harness',build_root/'harness')
for row in manifest['leaves']:
    dest=target/row['path'];dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(base/'candidate'/row['path'],dest)
(target/'OWNED-PROVIDER-SOURCE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'preparedSource':str(target),'configuration':'NOT RUN','build':'NOT RUN'}))
