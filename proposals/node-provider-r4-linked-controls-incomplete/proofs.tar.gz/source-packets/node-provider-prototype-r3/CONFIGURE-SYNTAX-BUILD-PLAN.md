# Offline staged acceptance plan — NOT EXECUTED

No runtime/build/network lease is currently held. Review exact R1/R2/R3 sources and metadata before any execution. Original source and frozen packets remain immutable. Only the new separate `/workspace/shared/node-provider-build-r3` may contain generated copies/artifacts; Root, shared SDKs and live service remain untouched. No implicit addon/SDK/ABI reuse or deployment.

## First grant: materialization, configure and syntax only

Resource planning for 4 CPU/32 GiB: reserve25 GiB free disk; initially one compiler for syntax, then at most two jobs for a separately granted full build. The prepared materializer checks all twelve official base/candidate identities and complete verified archive SHA, refuses an existing build root, copies the complete pinned official source to `.../source` and exact harness to `.../harness`, and overlays only the listed leaves. It does not configure, compile or run Node. Invoke `python3 helpers/materialize.py` only after the source/configure lease.

Future configure command from that fresh source copy:

```
./configure --ninja --without-npm --without-corepack
```

This is offline using bundled source dependencies; OS compiler/Python/Ninja must already exist. Missing tools/dependencies stop the stage; no install/download. Configure may execute compiler/version probes and its pinned gyp helpers. It must not silently build Node or replace Root configuration. Default Node snapshot settings stay enabled. Administrative configure cap:120s, then retain failure/partial output if exceeded. The actual compiler, defines, target/include settings and flags are evidence, not assumptions from stock ABI137.

After configure, derive exact commands from generated Ninja metadata:

```
ninja -C out/Release -t compdb
```

Save complete JSON and actual working-directory semantics. The prepared `helpers/syntax-metadata.py --compdb ABS_JSON` only normalizes metadata and emits its exact SHA; it does not execute a compiler. After reviewing that file, a separately authorized `--execute --metadata-sha EXACT_SHA` runs only its preserved syntax argv. It requires all six TUs, rejects unknown compiler/shell wrappers or unresolved response files, retains all distinct actual variants (maximum12 pending review), and stops at the first actual compiler failure. The worst-case envelope must use the actual reviewed variant count rather than assuming six commands.  Select the genuine C++ compile entries for `src/env.cc`, `src/node_contextify.cc`, `src/module_wrap.cc`, `test/cctest/test_owned_context_provider.cc`, `test/cctest/test_owned_context_collision.cc`, and `test/cctest/test_owned_proxy_reservations.cc`. Review their argv, preserve every include/define/architecture option, remove only object/dependency output options (`-c`, `-o`, `-MD/-MMD`, `-MF/-MT/-MQ`) and append `-fsyntax-only`. Run serially,60s administrative cap per translation unit, saving exact argv/working directory/stdout/stderr/exit/signal/timeout and source hashes before/after.

The exact generated compiler commands are **not yet available**. Do not substitute an invented SDK invocation, claim those commands have run, or add private V8/Node offset hacks to suppress errors. If a required generated header/response file does not exist after configure, record the precise missing generated-input/target and stop. A separately reviewed minimal generator target may follow; do not promote this into an undeclared full build. Configure+six syntax entries has an8-minute worst-case administrative envelope plus bounded metadata/IO; actual duration is unmeasured. No Node/browser/API/deadline/heap control executes during this stage.

A syntax pass establishes only parsing/type consistency for these TUs with actual metadata. It does not establish linkage, initialization/GC/destructor/snapshot safety or real module/runtime behavior.

## Separate full build grant

Only after syntax review and a distinct exclusive long lease, use the same generated Ninja configuration:

```
ninja -C out/Release -j2 node cctest
```

Verify target aliases from actual generated metadata first. Estimated clean Release build20–90 minutes, possibly4–10 GiB resident memory and5–20 GiB artifacts; unmeasured. Bound initial full build at90 minutes, preserve partial logs on failure, and do not silently increase jobs/deadline. All dependencies, including V8/OpenSSL/googletest and npm's node-gyp, exist in the pinned archive. Do not run npm/install/download or reuse current Node/native binaries. Record full source/archive/R1/R2/R3 patches, compiler/configuration, actual custom Node/cctest binary hashes and process.versions once Node execution is separately granted.

Build the test addon only with that custom Node and its bundled node-gyp and exact new source/config headers, using local --nodedir/--devdir. The public API extension version1 alone is insufficient identity. Prepared command shape:

```
BUILD/source/out/Release/node BUILD/source/deps/npm/node_modules/node-gyp/bin/node-gyp.js configure build --nodedir=BUILD/source --directory=BUILD/harness --devdir=BUILD/gyp-cache --jobs=1
```

Replace BUILD with literal `/workspace/shared/node-provider-build-r3`. No package-manager installation/network and no Root addon reuse. This remains unexecuted.

## Separate quiet generic runtime grant

`python3 helpers/run-controls.py --node BUILD/source/out/Release/node --cctest BUILD/source/out/Release/cctest` is prepared, **not run**. It requires actual matching composed source/harness/binary identities, uses fresh external runtime-evidence, runs eleven stages serially, preserves actual direct child return codes/signals versus explicit administrative TimeoutExpired, kills only its owned process groups, stops after the first failed stage and records remaining stages UNRUN. Its45s per-stage outer watchdog does not modify20ms native script watchdogs,1000ms module evaluation or8/12 GC cohort counts. Actual runtime cost is unknown; worst-case outer envelope approaches9 minutes for all stages. No competing runtime/deadline/heaps/jobs.

Stages are identity; exact R2 collision; R3 proxy eligibility; preserved R1 generic11; preserved R1 JS GC; R2 real namespace GC; only five new provider cctest cases (`OwnedContextProviderTest.*:OwnedContextCollisionTest.*:OwnedProxyReservationsTest.*`); separate distinct-token import; actual snapshot rejection; ordinary snapshot build; ordinary snapshot load. No original Root broad suite/Native13/PureScript/WPT/performance result is implied. Module producer mismatches, cross-token failures, unavailable setup, source changes, nonzero assertions, unobserved GC, timeout and crashes remain distinct.

A successful generic checkpoint still requires a new genuine application tranche: same raw WindowProxy with real Node/Document/Event factory authority, retained oldDocument.createElement and fresh current Document; actual Page/Frame/CDP navigation and protocol lifecycle; current canonical prototype/utility/error/heap/module deadlines; full caller-origin policy and continuous-lifetime limitations. No ordinary JS object substitutes for those producers.
