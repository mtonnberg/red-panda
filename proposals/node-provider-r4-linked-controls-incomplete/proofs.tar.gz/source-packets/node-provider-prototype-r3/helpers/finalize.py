from pathlib import Path
from hashlib import sha256
import ast,json,datetime
root=Path(__file__).resolve().parents[1]
def h(p):return sha256(p.read_bytes()).hexdigest()
for p in (root/'helpers').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
(root/'evidence/final-static-status.json').write_text(json.dumps({
 'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'fullApplyCheck':{'exitCode':0,'base':'exact official original-file copies'},
 'deltaApplyCheck':{'exitCode':0,'base':'exact R1+R2 composition copies'},
 'firstFullApplySetupFailurePreserved':'apply-check-first.json; missing fixture files corrected without changing patch/source',
 'allCppCompile':'UNRUN','JSsyntax':'UNRUN','allRuntime':'UNRUN','buildConfigureMaterialize':'NOT INVOKED',
 'PythonAST':'helpers parsed only','RootToolchainOfficialSourceNetworkChanges':'NONE',
 'acceptedGenericPreconditions':['continuous live IsolateData','correct isolate thread/Locker','last Data release before Isolate disposal'],
 'remaining':'No browser/realm parity or installed-runtime acceptance; exact README bounds apply'},indent=2)+'\n')
rows=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':h(p)} for p in sorted(root.rglob('*')) if p.is_file() and p.name!='manifest.json']
(root/'manifest.json').write_text(json.dumps({'kind':'Frozen SOURCE ONLY R3 composed genuine Node provider','fullPatchSHA256':h(root/'r3-full-provider.patch'),'deltaPatchSHA256':h(root/'r3-reservations-delta.patch'),'files':rows,'allCompilationRuntime':'UNRUN'},indent=2)+'\n')
print(json.dumps({'manifestSHA256':h(root/'manifest.json'),'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'fullPatchSHA256':h(root/'r3-full-provider.patch'),'deltaPatchSHA256':h(root/'r3-reservations-delta.patch')}))
