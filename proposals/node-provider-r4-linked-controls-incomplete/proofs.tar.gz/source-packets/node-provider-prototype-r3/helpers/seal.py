from pathlib import Path
from hashlib import sha256
import ast,difflib,json,re,shutil,datetime
root=Path(__file__).resolve().parents[1]
r1=Path('/workspace/shared/node-provider-prototype-v1');r2=Path('/workspace/shared/node-provider-prototype-r2')
source=Path('/workspace/shared/node-provider-source-v24.22.1/source/node-v24.22.1')
def h(p):return sha256(p.read_bytes()).hexdigest()
def put(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
prior=[]
for packet,expected in [(r1,'f8828eed1431b22c932877ba417d65cd0a0bf8e73de40276b7a7ffb050c0dcbf'),(r2,'b1b1e6a245447e00e902853bde319b0dc3dddb90fe8d71617c7022f01b791687')]:
 assert h(packet/'manifest.json')==expected
 rows=json.loads((packet/'manifest.json').read_text())['files']
 assert all(h(packet/row['path'])==row['sha256'] for row in rows)
 prior.append({'packet':str(packet),'manifestSHA256':expected,'filesUnchanged':len(rows)})
full=[];delta=[];leaves=[];delta_rows=[]
def diff(before,after,rel):
 out=[f'diff --git a/{rel} b/{rel}\n']
 if before is None:out.append('new file mode 100644\n')
 out.extend(difflib.unified_diff([] if before is None else before.read_text().splitlines(True),after.read_text().splitlines(True),
  fromfile='/dev/null' if before is None else f'a/{rel}',tofile=f'b/{rel}',n=3))
 return out
for p in sorted((root/'candidate').rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(root/'candidate'));old=source/rel
 old=old if old.exists() else None
 leaves.append({'path':rel,'baseSHA256':None if old is None else h(old),'candidateSHA256':h(p)})
 full.extend(diff(old,p,rel))
 if old is not None:
  target=root/'evidence/full-apply-base'/rel
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old,target)
 base=next((candidate for candidate in [r2/'candidate'/rel,r1/'candidate'/rel,source/rel] if candidate.exists()),None)
 if base is not None and h(base)==h(p):continue
 delta.extend(diff(base,p,rel));delta_rows.append({'path':rel,'composedBaseSHA256':None if base is None else h(base),'R3SHA256':h(p)})
 for name,before in [('full-apply-base',old),('delta-apply-base',base)]:
  if name=='delta-apply-base' and not any(x['path']==rel for x in delta_rows):continue
  if before is not None:
   target=root/'evidence'/name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(before,target)
(root/'r3-full-provider.patch').write_text(''.join(full));(root/'r3-reservations-delta.patch').write_text(''.join(delta))
put(root/'source-base.json',{'kind':'SOURCE ONLY composed R1+R2+R3 over official Node24.22.1','officialArchiveSHA256':'4f5379796280cdaeb0c2f358fd04b6a16cc4fb7dfa83b5a8c91a9d963b435231','leaves':leaves,'patchSHA256':h(root/'r3-full-provider.patch')})
for p in (root/'helpers').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
cases=[]
for p in sorted((root/'harness').glob('*.mjs')):
 for name in re.findall(r"await test\('([^']+)'",p.read_text()):cases.append({'file':str(p.relative_to(root)),'name':name,'status':'UNRUN'})
cpp=[]
for p in sorted((root/'candidate/test/cctest').glob('*.cc')):
 for c,t in re.findall(r'TEST_F\(([^,]+),\s*([^)]+)\)',p.read_text()):cpp.append({'file':str(p.relative_to(root)),'class':c,'case':t,'status':'UNCOMPILED/UNRUN'})
anchors={
'src/env.h':[135,147,154,251], 'src/env.cc':[334,586,601,641],
'src/node_contextify.cc':[203,237,328,378], 'doc/api/embedding.md':[91,96,103],
'deps/v8/include/v8-persistent-handle.h':[155,507],
'deps/v8/src/api/api.cc':[4576], 'deps/v8/src/objects/lookup-inl.h':[394],
'deps/v8/src/objects/lookup.cc':[1241], 'deps/v8/src/execution/isolate.cc':[7153],
'src/node_main_instance.cc':[80], 'src/node_worker.cc':[239], 'src/api/environment.cc':[423]}
put(root/'evidence/static-readback.json',{'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'priorPackets':prior,
 'fullLeafCount':len(leaves),'R3Delta':delta_rows,'JSgroups':cases,'CppCases':cpp,
 'PythonAST':'parsed only; materialization/metadata/compiler/runtime helpers not invoked',
 'compile':'UNRUN','JSsyntax':'UNRUN','runtime':'UNRUN','RootToolchainConfigurationNetwork':'NONE',
 'sourceAnchors':[{'path':key,'officialSHA256':h(source/key),'lines':value} for key,value in anchors.items()],
 'acceptedPrototypePreconditions':['continuous at-least-one live IsolateData for every usable provider proxy','isolate-thread/Locker V8 handle access','all Data destroyed while isolate alive before disposal'],
 'remaining':['all-Data-free/recreate reservation continuity unsupported','live-provider snapshot unsupported; conservative CHECK','actual compile/link/lifetime/GC/module results unrun','actual Document/Page/Frame/kernel migration unimplemented','distinct-token Promise/SOP/utility/error/heap/prototype graph unproved']})
print(json.dumps({'fullPatchSHA256':h(root/'r3-full-provider.patch'),'fullLeaves':len(leaves),'deltaPatchSHA256':h(root/'r3-reservations-delta.patch'),'deltaLeaves':len(delta_rows),'JSgroups':len(cases),'CppCases':len(cpp),'priorPacketsUnchanged':prior}))
