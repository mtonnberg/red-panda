# R3: composed provider with weak raw-proxy eligibility reservations

**SOURCE ONLY — UNCOMPILED/UNRUN, NOT INSTALLED OR PRODUCTION.** This composes the actual provider implementation from immutable R1, the pending-carrier collision guard from immutable R2, and a separate R3 weak identity reservation. The complete official Node source and Root/toolchain remain unchanged. No compile, Node/browser/test/build/configuration or network operation occurred.

R1 manifest: `f8828eed1431b22c932877ba417d65cd0a0bf8e73de40276b7a7ffb050c0dcbf`.
R2 manifest: `b1b1e6a245447e00e902853bde319b0dc3dddb90fe8d71617c7022f01b791687`.

`r3-full-provider.patch` applies the whole composed overlay to official Node24.22.1. `r3-reservations-delta.patch` is only R3 over the exact R1+R2 composition. The new reservation code changes `src/env.h`, `src/env.cc`, `src/node_contextify.cc`, and adds one C++ test file. No platform/isolate hook replacement is included. The public provider API version remains1; custom source/header/binary identities must still be recorded and no existing Root addon is implicitly compatible.

## Concrete R3 blocker and correction

The real public owned WindowProxy deliberately does not hold the canonical Node Contextify wrapper/HDO. Its genuine carrier does. Unchanged stock `vm.createContext(ownedProxy)` could nevertheless install a second ordinary Context's wrapper/HDO on the old hidden global. V8 private stores on an active JSGlobalProxy redirect there; DetachGlobal removes proxy->oldGlobal, so retaining the ordinary Context's sandbox proxy can lose the required ordinary wrapper ownership edge.

R3 reserves the exact provider-created raw proxy identity before Node base/runtime initialization or publication. Ordinary `MakeContext` rejects that exact identity before writing any wrapper/HDO. Eligibility reservation remains true while the same actual object is active, detached or reused. It does not infer ownership from its current creation Context, a public tag/property/name/prototype or origin metadata. It grants no brand, realm or Context authority; genuine carrier/Contextify records remain authoritative.

The index contains only stable heap-allocated `v8::Global<v8::Object>` cells using parameterless `SetWeak()`. Each cell lives behind a unique_ptr, so vector relocation never moves the slot address V8 will reset. There is no weak callback, callback parameter, raw object address, Context, Environment or template in an entry. Empty cells are pruned before identity comparison. The registry holds only weak_ptrs keyed by actual Isolate; every currently live IsolateData for that isolate shares the actual state. Its shared_ptr is initialized under the existing process mutex. V8 handle operations themselves remain subject to the isolate thread/Locker precondition; the mutex is not a substitute for it.

The last live IsolateData resets the state before Isolate disposal; each weak Global resets with it, then expired weak registry entries are pruned. No process-global V8 handle survives the last Data release. Ordinary Data with no provider reservations has only an empty native state. New state default-constructs empty on ordinary creation and snapshot deserialization. It is not added to snapshot payload.

**Explicit generic-prototype lifetime precondition:** at least one IsolateData must remain continuously alive while any owned raw proxy may be used/reused. Retaining a proxy after **all** Data owners are freed, then creating a new Data on that still-live Isolate, is unsupported and unprotected by this weak_ptr-only registry. This limitation was accepted for the generic prototype, not for browser production. No new whole-platform lifetime architecture is claimed.

## Snapshot and lifecycle bounds

Owned ticket/Context creation remains rejected during Node snapshot building. `IsolateData::Serialize` prunes empty cells and CHECKs that the shared index is empty. This is an explicit fail-fast unsupported-live-provider boundary, not a graceful JS API error or proof that unreachable proxies have already collected. An uncollected weak entry can conservatively reject snapshotting. Live provider serialization and direct trusted V8 SnapshotCreator use remain unsupported. Ordinary snapshots must be built/tested with this complete matching source; no old SDK snapshot is reused.

FreeIsolateData with provider cells must run while the isolate is alive and under its correct thread/Locker scope. Standard main/worker teardown source does this before DisposeIsolate; generic embedder teardown remains a test obligation. Multiple simultaneous Data owners on one isolate are supported by the shared reservation state, including independent Environments/uv_loops; no Environment pointer is retained by the index.

## Prepared real controls — all UNRUN

New two-group JS file covers createContext and heldout runInNewContext on active/detached/reused exact raw proxy, actual old/new HDO namespace/referrer separation, actual retained closures/constructors, and preserved ordinary plain/Proxy-wrapped-object contextification (including a plain object genuinely created in an owned realm). No fake Window objects or public-marker filters implement rejection.

New two-case C++ file covers (1) two distinct simultaneous IsolateData and real Environments with separate uv_loops on the same actual Isolate, testing reservations/private-write rejection in active/detached/reused phases and survival when one Data is freed; (2) actual retained Context/carrier/wrapper/raw proxy/cppgc lifetime and full collection with the reservation state still alive. The cross-Data case deliberately shares Host security tokens to isolate eligibility from an earlier SOP denial; it proves no distinct-origin policy. The weak-root test uses eight bounded low-memory requests and actual weak handles, not guessed object addresses or hidden query filters.

R1 eleven generic JS groups, two C++ cases, GC/token/snapshot files and R2 three JS groups, one C++ case and real-module-namespace GC file remain preserved in this composition and unrun. The combined controller selects only the five new provider C++ cases, not the full Node suite.

Compilation/linking, all runtime positives, GC, shared-state/snapshot/destructor correctness, actual tokens/Promise adoption, genuine Document/Page/Frame/canonical factory integration, current browser deadlines, utility/error/heap/graph contracts and other SDKs remain unproved. The old JS object control explicitly remains an ordinary object, never a stand-in for real Document acceptance.
