#!/usr/bin/env python3
"""UNRUN until Root go. Owned current-Ninja pause only; no tests/build/source edits."""
from pathlib import Path
from hashlib import sha256
import json,os,signal,time,sys,datetime
PID=790713;TICKS=9843284;CAP=300
OUT=Path('/workspace/shared/node-provider-r4-pause-probes-r24')
LOG=Path('/workspace/shared/node-provider-r4-full-build-continuation3-evidence/build.log')
ARGV=['/workspace/shared/node-provider-ninja-1.13.0/wheel/ninja-1.13.0.data/scripts/ninja','-j4','node','cctest']
assert not OUT.exists(),'Preserve earlier quiet evidence; never overwrite'
OUT.mkdir();captured={};sent=[];resumed=[];skipped=[];started=None;proved=False
record={'status':'SETUP','capSeconds':CAP,'currentBuildClockContinues':True,'sourceConfigFlagsChanged':False,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(name,obj):
 temp=OUT/(name+'.tmp');temp.write_text(json.dumps(obj,indent=2)+'\n');temp.replace(OUT/name)
def read(pid,include_argv=True):
 try:
  root=Path('/proc')/str(pid);raw=(root/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
  return {'pid':int(pid),'name':raw[raw.find('(')+1:raw.rfind(')')],'state':f[0],'ppid':int(f[1]),'pgrp':int(f[2]),'session':int(f[3]),'startTicks':int(f[19]),'argv':(root/'cmdline').read_bytes().rstrip(b'\0').decode(errors='replace').split('\0') if include_argv else None}
 except (FileNotFoundError,ProcessLookupError):return None
def same(expected):
 current=read(expected['pid'])
 return current if current and current['startTicks']==expected['startTicks'] and current['session']==PID else None
def cohort():
 result={}
 for root in Path('/proc').iterdir():
  if not root.name.isdigit():continue
  value=read(int(root.name),False)
  if value and value['session']==PID:result[str(value['pid'])]=read(value['pid']) or value
 return result
def log_identity():return {'bytes':LOG.stat().st_size,'sha256':sha256(LOG.read_bytes()).hexdigest()}
def stop(expected):
 current=same(expected)
 if not current or current['state']=='Z':return
 captured[str(current['pid'])]=current
 if current['state']!='T':
  os.kill(current['pid'],signal.SIGSTOP);sent.append({'pid':current['pid'],'startTicks':current['startTicks'],'signal':int(signal.SIGSTOP)})
def interrupted(n,f):raise InterruptedError('quiet controller signal '+str(n))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 leader=read(PID);assert leader and leader['startTicks']==TICKS and leader['pgrp']==PID and leader['session']==PID and leader['argv']==ARGV,leader
 record['leader']=leader;started=time.monotonic();record['firstStopMonotonic']=started
 # Freeze scheduler first, then repeatedly capture any in-flight compiler descendants.
 stop(leader);deadline=started+CAP;proofDeadline=min(deadline,started+10)
 while time.monotonic()<proofDeadline:
  before=cohort();assert str(PID) in before and before[str(PID)]['startTicks']==TICKS,'Owned leader disappeared'
  for value in before.values():stop(value)
  time.sleep(.05)
  first=cohort();live={k:v for k,v in first.items() if v['state']!='Z'}
  if not live or not all(v['state']=='T' for v in live.values()):continue
  identity1={k:v['startTicks'] for k,v in live.items()};log1=log_identity();time.sleep(.2)
  second=cohort();live2={k:v for k,v in second.items() if v['state']!='Z'}
  identity2={k:v['startTicks'] for k,v in live2.items()};log2=log_identity()
  if identity1!=identity2 or not all(v['state']=='T' for v in live2.values()) or log1!=log2:continue
  for key,value in live2.items():captured[key]=value
  record.update(status='PAUSED',members=live2,terminatedZombieEntries={k:v for k,v in second.items() if v['state']=='Z'},allActualNonZombieMembersT=True,stableLog=log2,stableLogIntervalSeconds=.2,actualMemberCount=len(live2),stopSignals=sent)
  save('paused.json',record);save('report.json',record);proved=True
  print(json.dumps({'status':'PAUSED','actualMemberCount':len(live2),'leaderPid':PID,'leaderStartTicks':TICKS,'capSeconds':CAP,'proof':str(OUT/'paused.json'),'resumeRequest':str(OUT/'resume.request'),'elapsedSeconds':time.monotonic()-started}),flush=True)
  break
 assert proved,'Could not establish entire actual owned session T and stable log within10s; no runtime admitted'
 # No task is launched here. Parent admits only its bounded serial jobs after proof.
 while time.monotonic()<deadline and not (OUT/'resume.request').exists():time.sleep(min(.1,max(0,deadline-time.monotonic())))
 record['resumeReason']='explicit-request' if (OUT/'resume.request').exists() else 'automatic-watchdog'
except BaseException as error:
 record['error']={'type':type(error).__name__,'message':str(error)};record['resumeReason']='controller-exception-finally'
finally:
 # Only captured real PID/startTick/session identities; never broad process-group signals.
 for key,expected in captured.items():
  try:
   current=same(expected)
   if not current or current['state']=='Z':skipped.append({'pid':expected['pid'],'reason':'terminated-or-identity-changed'});continue
   os.kill(current['pid'],signal.SIGCONT);resumed.append({'pid':current['pid'],'startTicks':current['startTicks'],'signal':int(signal.SIGCONT)})
  except (ProcessLookupError,FileNotFoundError):skipped.append({'pid':expected['pid'],'reason':'terminated-during-resume'})
  except BaseException as error:skipped.append({'pid':expected['pid'],'reason':'resume-error','error':str(error)})
 try:
  remaining=cohort();stillStopped=[v for v in remaining.values() if v['state']=='T']
 except BaseException as error:
  remaining={};stillStopped=[];skipped.append({'reason':'resume-error','error':'Final cohort audit: '+str(error)})
 record.update(status='RESUMED' if proved and not stillStopped and not any(v.get('reason')=='resume-error' for v in skipped) else 'PAUSE_FAILED_OR_RESUME_INCOMPLETE',actualStoppedSeconds=time.monotonic()-started if started is not None else 0,resumed=resumed,resumeSkipped=skipped,stillStopped=stillStopped,finalMembers=remaining,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
 save('report.json',record);print(json.dumps({'status':record['status'],'resumedCount':len(resumed),'actualStoppedSeconds':record['actualStoppedSeconds'],'report':str(OUT/'report.json')}),flush=True)
sys.exit(0 if record['status']=='RESUMED' else 1)
