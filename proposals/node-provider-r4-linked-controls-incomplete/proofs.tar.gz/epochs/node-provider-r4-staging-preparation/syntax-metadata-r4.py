#!/usr/bin/env python3
"""UNRUN: normalize real Ninja C++ metadata; execute only with --execute."""
import argparse, hashlib, json, os, pathlib, re, shlex, signal, subprocess, sys
ROOT=pathlib.Path('/workspace/shared/node-provider-prototype-r3')
R4=pathlib.Path('/workspace/shared/node-provider-namespace-r4')
BUILD=pathlib.Path('/workspace/shared/node-provider-build-r4')
SOURCE=BUILD/'source'
OUT=BUILD/'syntax-evidence'
UNITS=['src/env.cc','src/node_contextify.cc','src/module_wrap.cc',
       'test/cctest/test_owned_context_provider.cc','test/cctest/test_owned_context_collision.cc',
       'test/cctest/test_owned_proxy_reservations.cc','test/cctest/test_owned_module_namespace.cc']
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def guards():
    rows=json.loads((ROOT/'source-base.json').read_text())['leaves']
    actual={}
    for row in rows:
        path=SOURCE/row['path']
        actual[str(path)]=digest(path)
        expected=hashlib.sha256((R4/'candidate/src/module_wrap.cc').read_bytes()).hexdigest() if row['path']=='src/module_wrap.cc' else row['candidateSHA256']
        assert actual[str(path)]==expected,str(path)
    path=SOURCE/'test/cctest/test_owned_module_namespace.cc'
    actual[str(path)]=digest(path)
    assert actual[str(path)]==digest(R4/'candidate/test/cctest/test_owned_module_namespace.cc')
    return actual
p=argparse.ArgumentParser();p.add_argument('--compdb');p.add_argument('--execute',action='store_true');p.add_argument('--metadata-sha')
a=p.parse_args()
if not a.execute:
    assert a.compdb,'Use exact saved Ninja compdb JSON'
    database=pathlib.Path(a.compdb).resolve()
    assert database.is_relative_to(BUILD)
    assert not OUT.exists(),'Preserve existing metadata epochs'
    OUT.mkdir()
    commands=[];seen=set();found=set()
    for row in json.loads(database.read_text()):
        cwd=pathlib.Path(row['directory']).resolve()
        assert cwd.is_relative_to(SOURCE)
        unit=(cwd/row['file']).resolve()
        if not unit.is_relative_to(SOURCE):continue
        rel=str(unit.relative_to(SOURCE))
        if rel not in UNITS:continue
        argv=shlex.split(row['command'])
        assert argv and re.fullmatch(r'(?:[^/]*-)?(?:g\+\+|clang\+\+|c\+\+)(?:-\d+)?',pathlib.Path(argv[0]).name),argv[0]
        assert '-c' in argv,'Expected actual C++ compile rule'
        assert not any(x.startswith('@') for x in argv),'Response file must be reviewed/expanded first'
        result=[];i=0
        while i<len(argv):
            arg=argv[i]
            if arg in ['-o','-MF','-MT','-MQ']:
                assert i+1<len(argv);i+=2;continue
            if arg in ['-c','-MD','-MMD','-MP']:
                i+=1;continue
            assert arg not in ['&&','||',';','|'],'No shell wrappers in syntax invocation'
            result.append(arg);i+=1
        result.append('-fsyntax-only')
        identity=(str(cwd),tuple(result))
        if identity in seen:continue
        seen.add(identity);found.add(rel)
        commands.append({'unit':rel,'directory':str(cwd),'original':row['command'],'argv':result,'status':'UNRUN'})
    assert found==set(UNITS),{'missing':sorted(set(UNITS)-found)}
    assert len(commands)<=12,'Review extra compiler variants before execution'
    data={'status':'METADATA ONLY; no compiler executed','database':str(database),'databaseSHA256':digest(database),
          'sourceBefore':guards(),'commands':commands,'perCommandAdministrativeSeconds':60}
    (OUT/'commands.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'status':data['status'],'commands':len(commands),'path':str(OUT/'commands.json'),'sha256':digest(OUT/'commands.json')}));sys.exit(0)
assert not a.compdb,'Execute exact preserved metadata; no replacement database'
metadata=OUT/'commands.json'
assert a.metadata_sha and digest(metadata)==a.metadata_sha,'Use the exact reviewed metadata SHA'
data=json.loads(metadata.read_text())
assert digest(pathlib.Path(data['database']))==data['databaseSHA256']
assert guards()==data['sourceBefore']
report=OUT/'compiler-report.json';assert not report.exists(),'Preserve earlier actual compiler epoch'
results=[]
def interrupted(signum,frame):raise KeyboardInterrupt(f'signal {signum}')
signal.signal(signal.SIGTERM,interrupted)
for index,row in enumerate(data['commands']):
    child=None;timed=False
    try:
        with (OUT/f'compiler-{index}.log').open('wb') as log:
            child=subprocess.Popen(row['argv'],cwd=row['directory'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:code=child.wait(timeout=60)
            except subprocess.TimeoutExpired:
                timed=True
                try:os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:code=child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    code=child.wait()
    finally:
        if child is not None and child.poll() is None:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait()
    results.append({'unit':row['unit'],'argv':row['argv'],'ownedPid':child.pid,'returnCode':code,
                    'signal':-code if code<0 else None,'administrativeTimeout':timed})
    report.write_text(json.dumps({'status':'PARTIAL','results':results},indent=2)+'\n')
    print(json.dumps(results[-1]),flush=True)
    if code!=0 or timed:break
stable=guards()==data['sourceBefore']
status='syntax-zero-only' if len(results)==len(data['commands']) and all(r['returnCode']==0 and not r['administrativeTimeout'] for r in results) and stable else 'FAILED_OR_UNRUN'
report.write_text(json.dumps({'status':status,'results':results,'sourcesStable':stable,
    'unrun':data['commands'][len(results):],'nativeLink':'UNRUN','NodeRuntime':'UNRUN'},indent=2)+'\n')
sys.exit(0 if status=='syntax-zero-only' else 1)
