#!/usr/bin/env python3
"""UNRUN. Exclusive build lease required. Build node+cctest only, never install/test.
Generators and build-time helper binaries are genuine upstream prerequisites.
"""
from pathlib import Path
from hashlib import sha256
import datetime,json,os,shutil,signal,subprocess,sys,time
BASE=Path('/workspace/shared');BUILD=BASE/'node-provider-build-r4';SOURCE=BUILD/'source'
OUT=BASE/'node-provider-r4-full-build-evidence';PREP=Path(__file__).resolve().parent
CAP=90*60;RESERVE=25*1024**3
def digest(p):
 h=sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def verify(mapping):
 actual={str(p):digest(p) for p in mapping};assert actual==mapping,'Guarded source/tool/config changed';return actual
assert not OUT.exists(),'Never overwrite a build epoch';OUT.mkdir()
record={'status':'STARTED','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exclusive offline -j2 node+cctest build; no install/custom runtime/browser/test invocation','capSeconds':CAP,'reserveBytes':RESERVE,'commands':[],'tests':'UNRUN','installation':'NOT REQUESTED','RootChanges':'NONE'}
active=None
class Interrupted(Exception):pass
def interrupted(n,f):raise Interrupted('controller signal '+str(n))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
def cleanup_group(pid):
 try:os.killpg(pid,0)
 except ProcessLookupError:return False
 try:os.killpg(pid,signal.SIGTERM)
 except ProcessLookupError:return False
 deadline=time.monotonic()+3
 while time.monotonic()<deadline:
  try:os.killpg(pid,0)
  except ProcessLookupError:return True
  time.sleep(.05)
 try:os.killpg(pid,signal.SIGKILL)
 except ProcessLookupError:pass
 return True
def run(name,argv,cwd,cap,heartbeat=False):
 global active
 started=time.monotonic();timed=False;stoppedForDisk=False
 with (OUT/(name+'.log')).open('wb') as log:
  active=subprocess.Popen(argv,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  pid=active.pid;save('active-child.json',{'stage':name,'pid':pid,'processGroup':pid,'argv':argv,'cwd':str(cwd)})
  while active.poll() is None:
   remaining=cap-(time.monotonic()-started)
   if remaining<=0:timed=True;break
   try:active.wait(timeout=min(30,remaining))
   except subprocess.TimeoutExpired:
    disk=shutil.disk_usage(BASE).free
    info={'stage':name,'elapsedSeconds':time.monotonic()-started,'ownedPid':pid,'logBytes':(OUT/(name+'.log')).stat().st_size,'diskFreeBytes':disk}
    save('progress.json',info)
    if heartbeat:print(json.dumps(info),flush=True)
    if disk<RESERVE:stoppedForDisk=True;break
  if active.poll() is None:cleanup_group(pid)
  try:code=active.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(pid,signal.SIGKILL);code=active.wait()
  unexpectedGroup=cleanup_group(pid)
  row={'stage':name,'argv':argv,'cwd':str(cwd),'ownedPid':pid,'returnCode':code,'signal':-code if code<0 else None,'administrativeTimeout':timed,'reserveBreach':stoppedForDisk,'postLeaderDescendantCleanup':unexpectedGroup,'elapsedSeconds':time.monotonic()-started}
  record['commands'].append(row);save('report.json',record);active=None;print(json.dumps(row),flush=True)
  assert code==0 and not timed and not stoppedForDisk and not unexpectedGroup,'Stop first failed stage'
try:
 assert shutil.disk_usage(BASE).free>=RESERVE,'Reserve25GiB before build'
 syntax=BUILD/'syntax-evidence/compiler-report.json';assert digest(syntax)=='75561e7191f6a9237162a53c923a340e75599ef48202ab6f78d8d1f2ac62aeb5'
 checks=json.loads(syntax.read_text());assert checks['status']=='syntax-zero-only' and checks['sourcesStable'] and len(checks['results'])==7
 metadata=BUILD/'syntax-evidence/commands.json';assert digest(metadata)=='e2470545b24c71fcc88d18c47d43e16ada8dbc2a99c5fa6349e48b720dcfb0dc'
 commands=json.loads(metadata.read_text());assert digest(commands['database'])==commands['databaseSHA256']
 guards=json.loads((BASE/'node-provider-r4-compdb-evidence/inputs-after.json').read_text())
 guards.update(commands['sourceBefore']);guards[str(metadata)]=digest(metadata);guards[str(syntax)]=digest(syntax);guards[commands['database']]=commands['databaseSHA256']
 for rel in ['config.gypi','config.status','out/Release/build.ninja']:
  p=SOURCE/rel;assert p.is_file();guards[str(p)]=digest(p)
 graph={str(p):digest(p) for p in sorted((SOURCE/'out/Release').rglob('*.ninja'))};assert graph
 guards.update(graph)
 provenancePath=BASE/'node-provider-ninja-1.13.0/provenance.json';provenance=json.loads(provenancePath.read_text());ninja=Path(provenance['binary']);assert digest(ninja)==provenance['binarySHA256']
 guards[str(provenancePath)]=digest(provenancePath);guards[str(ninja)]=digest(ninja)
 compilers={Path(row['argv'][0]).name for row in commands['commands']};assert compilers=={'c++'}
 compiler=Path(shutil.which('c++')).resolve();guards[str(compiler)]=digest(compiler)
 save('inputs-before.json',verify(guards));save('ninja-graph-before.json',graph)
 save('toolchain-identities.json',{'ninja':{'path':str(ninja),'sha256':digest(ninja)},'compiler':{'invokedName':'c++','resolvedPath':str(compiler),'sha256':digest(compiler)},'NodeSourceVersion':'24.22.1','ABI':137,'customBuildIdentity':'R3provider+R4namespace; isolated source, not Root SDK','configPath':str(SOURCE/'config.gypi'),'configSHA256':digest(SOURCE/'config.gypi'),'RootAddonABIReuse':'FORBIDDEN; matching addon must be separately rebuilt/validated','environment':{key:os.environ.get(key) for key in ['PATH','LANG','LC_ALL','CC','CXX']},'upstreamBuildTimePrograms':'Expected real prerequisite generators/mksnapshot; no custom runtime application/test execution'})
 run('ninja-version',[str(ninja),'--version'],OUT,5)
 run('compiler-version',[str(compiler),'--version'],OUT,5)
 run('build',[str(ninja),'-j2','node','cctest'],SOURCE/'out/Release',CAP,True)
 save('inputs-after.json',verify(guards))
 outputs={}
 for name in ['node','cctest']:
  p=SOURCE/'out/Release'/name;assert p.is_file();outputs[name]={'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
 save('outputs.json',outputs);record.update(status='BUILT_LINKED_ONLY_TESTS_UNRUN',guardsStable=True,outputs=outputs)
except BaseException as error:
 record.update(status='STOPPED',error={'type':type(error).__name__,'message':str(error)},partialOutputsPreserved=True)
finally:
 if active is not None:
  cleanup_group(active.pid)
  if active.poll() is None:active.kill()
  active.wait()
 record['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('report.json',record)
print(json.dumps({'status':record['status'],'report':str(OUT/'report.json')}),flush=True)
sys.exit(0 if record['status']=='BUILT_LINKED_ONLY_TESTS_UNRUN' else 1)
