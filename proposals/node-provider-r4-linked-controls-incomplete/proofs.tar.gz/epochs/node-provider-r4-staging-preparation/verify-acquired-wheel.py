#!/usr/bin/env python3
"""Data-only recovery for the actual RECORD-listed wheel executable path."""
from pathlib import Path
import base64,csv,hashlib,json,os
B=Path('/workspace/shared');T=B/'node-provider-ninja-1.13.0';E=B/'node-provider-r4-acquire-verified-evidence'
assert not E.exists();E.mkdir()
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
data=json.loads((T/'pypi-ninja-1.13.0.json').read_text());assert data['info']['version']=='1.13.0'
wheel=next(T.glob('*.whl'));rows=[r for r in data['urls'] if r['filename']==wheel.name];assert len(rows)==1;row=rows[0]
assert digest(wheel)==row['digests']['sha256'] and wheel.stat().st_size==row['size']
target=T/'wheel';records=list(target.glob('*.dist-info/RECORD'));assert len(records)==1
for rel,check,size in csv.reader(records[0].read_text().splitlines()):
 p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
 actual=target/p;assert actual.is_file()
 if size:assert actual.stat().st_size==int(size)
 if check:
  kind,wanted=check.split('=',1);assert kind=='sha256'
  assert base64.urlsafe_b64encode(bytes.fromhex(digest(actual))).decode().rstrip('=')==wanted
binary=target/'ninja-1.13.0.data/scripts/ninja';head=binary.read_bytes()[:20]
assert head[:6]==b'\x7fELF\x02\x01' and int.from_bytes(head[18:20],'little')==62
binary.chmod(0o755)
before=json.loads((B/'node-provider-r4-acquire-evidence/inputs-before.json').read_text())
after={p:digest(p) for p in before};assert before==after;save(E/'inputs-after.json',after)
facts=[]
for name in ['pypi-metadata','wheel']:
 fact=json.loads((B/'node-provider-r4-acquire-evidence'/f'{name}-http.json').read_text());assert fact['http_code']==200 and fact['ssl_verify_result']==0;facts.append({'url':fact['url_effective'],'httpStatus':fact['http_code'],'TLSverify':fact['ssl_verify_result']})
for pid in [712570,712572]:
 try:os.kill(pid,0)
 except ProcessLookupError:pass
 else:raise AssertionError('Owned curl process remains '+str(pid))
provenance={'status':'ACQUIRED_VERIFIED_DATA_ONLY','version':'1.13.0','metadataURL':'https://pypi.org/pypi/ninja/1.13.0/json','metadataSHA256':digest(T/'pypi-ninja-1.13.0.json'),'wheel':str(wheel),'wheelSHA256':digest(wheel),'wheelSize':wheel.stat().st_size,'url':row['url'],'binary':str(binary),'binarySHA256':digest(binary),'binaryBytes':binary.stat().st_size,'ELF':'64-bit little-endian x86_64','allRECORDEntries':'verified','HTTP':facts,'TLS':'inherited managed proxy/CA; verified; no insecure flag','signatureVerification':'not performed; official metadata SHA over verified HTTPS','licensesAndCompleteWheel':'retained','globalInstall':False,'binaryExecution':'UNRUN','compilation':'UNRUN','R4configure':'UNRUN','actualCompdb':'UNRUN','guardsStable':len(after),'ownedCurlPidsAbsent':[712570,712572],'priorFailedEpochPreserved':str(B/'node-provider-r4-acquire-evidence/report.json')}
save(T/'provenance.json',provenance);save(E/'report.json',provenance);print(json.dumps(provenance,indent=2))
