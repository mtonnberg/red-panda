#!/usr/bin/env python3
"""LEASE REQUIRED. Separate offline composition, network acquisition and compdb stages.
Never invokes a compiler, Node, pip, configure implicitly, or a build target.
"""
from pathlib import Path
from hashlib import sha256
import argparse,base64,csv,datetime,io,json,os,re,shlex,shutil,signal,stat,subprocess,sys,time,urllib.parse,zipfile
BASE=Path('/workspace/shared')
R3=BASE/'node-provider-prototype-r3'
R4=BASE/'node-provider-namespace-r4'
B3=BASE/'node-provider-build-r3'
B4=BASE/'node-provider-build-r4'
TOOL=BASE/'node-provider-ninja-1.13.0'
UNITS=['src/env.cc','src/node_contextify.cc','src/module_wrap.cc','test/cctest/test_owned_context_provider.cc','test/cctest/test_owned_context_collision.cc','test/cctest/test_owned_proxy_reservations.cc','test/cctest/test_owned_module_namespace.cc']
def digest(p):
 h=sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(path,obj):Path(path).write_text(json.dumps(obj,indent=2)+'\n')
def frozen():
 result={}
 for root,expected in [(R3,'699496fa0e637d8071e7c90ca87b1cdbbd485ab8a8e6cbb90a9bd42c64a1435d'),(R4,'1431510983da96f5172724018f5c6963e8eb4fa2ee8bbfb2ebd8ac9c8d976650')]:
  manifest=root/'manifest.json';assert digest(manifest)==expected;result[str(manifest)]=expected
  rows=json.loads(manifest.read_text())['files']
  pairs=rows.items() if isinstance(rows,dict) else [(r['path'],r['sha256']) for r in rows]
  for rel,wanted in pairs:
   p=root/rel;assert digest(p)==wanted,str(p);result[str(p)]=wanted
 for row in json.loads((R3/'source-base.json').read_text())['leaves']:
  p=B3/'source'/row['path'];assert digest(p)==row['candidateSHA256'],str(p);result[str(p)]=digest(p)
 return result
def composed():
 result={}
 for row in json.loads((R3/'source-base.json').read_text())['leaves']:
  rel=row['path'];wanted=row['candidateSHA256']
  if rel=='src/module_wrap.cc':wanted=digest(R4/'candidate'/rel)
  p=B4/'source'/rel;assert digest(p)==wanted,str(p);result[str(p)]=wanted
 p=B4/'source/test/cctest/test_owned_module_namespace.cc';assert digest(p)==digest(R4/'candidate/test/cctest/test_owned_module_namespace.cc');result[str(p)]=digest(p)
 return result
parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['acquire','compose-configure','compdb'])
a=parser.parse_args();out=BASE/('node-provider-r4-'+a.stage+'-evidence');assert not out.exists(),'Preserve every earlier epoch';out.mkdir()
record={'status':'STARTED','stage':a.stage,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'compilation':'UNRUN','NodeRuntime':'UNRUN','tests':'UNRUN'}
active=None
def interrupted(n,f):raise InterruptedError('signal '+str(n))
signal.signal(signal.SIGTERM,interrupted)
def run(name,argv,cwd,cap,stdout=None):
 global active
 started=time.monotonic();timed=False
 with Path(stdout or out/(name+'.log')).open('wb') as log:
  active=subprocess.Popen(argv,cwd=cwd,stdout=log,stderr=(out/(name+'.stderr.log')).open('wb'),start_new_session=True)
  pid=active.pid;save(out/'active-child.json',{'pid':pid,'argv':argv,'cwd':str(cwd),'capSeconds':cap})
  try:
   try:code=active.wait(timeout=cap)
   except subprocess.TimeoutExpired:
    timed=True;os.killpg(pid,signal.SIGTERM)
    try:code=active.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(pid,signal.SIGKILL);code=active.wait()
  finally:
   if active.poll() is None:
    os.killpg(pid,signal.SIGKILL);active.wait()
  row={'name':name,'argv':argv,'cwd':str(cwd),'ownedPid':pid,'returnCode':code,'timeout':timed,'elapsedSeconds':time.monotonic()-started}
  record['commands'].append(row);save(out/'report.json',record);print(json.dumps(row),flush=True);active=None
  assert code==0 and not timed,name+' failed; preserve logs'
def fetch(name,url,destination,maxsize,host):
 assert urllib.parse.urlparse(url).scheme=='https' and urllib.parse.urlparse(url).hostname==host
 status=out/(name+'-http.json')
 run(name,['curl','--fail','--show-error','--silent','--proto','=https','--max-redirs','0','--connect-timeout','10','--max-time','30','--max-filesize',str(maxsize),'--dump-header',str(out/(name+'-headers.txt')),'--output',str(destination),'--write-out','%{json}',url],out,35,status)
 facts=json.loads(status.read_text());assert facts['http_code']==200 and facts['ssl_verify_result']==0 and facts['url_effective']==url,facts
 assert destination.stat().st_size<=maxsize
 return facts
try:
 before=frozen();save(out/'inputs-before.json',before)
 if a.stage=='acquire':
  assert not TOOL.exists();TOOL.mkdir()
  metadata=TOOL/'pypi-ninja-1.13.0.json';fetch('pypi-metadata','https://pypi.org/pypi/ninja/1.13.0/json',metadata,2*1024*1024,'pypi.org')
  data=json.loads(metadata.read_text());assert data['info']['name'].lower()=='ninja' and data['info']['version']=='1.13.0'
  choices=[r for r in data['urls'] if r['packagetype']=='bdist_wheel' and re.fullmatch(r'ninja-1\.13\.0-py3-none-(?=.*(?:manylinux2014|manylinux_2_17))[^/]*x86_64[^/]*\.whl',r['filename']) and 'musllinux' not in r['filename']]
  assert len(choices)==1,[(r['filename'],r['url']) for r in choices]
  row=choices[0];assert not row.get('yanked',False);wheel=TOOL/row['filename'];fetch('wheel',row['url'],wheel,8*1024*1024,'files.pythonhosted.org')
  assert wheel.stat().st_size==row['size'] and digest(wheel)==row['digests']['sha256']
  target=TOOL/'wheel';target.mkdir();seen=set();total=0
  with zipfile.ZipFile(wheel) as z:
   members=z.infolist();assert len(members)<=1000
   for m in members:
    p=Path(m.filename);assert not p.is_absolute() and '..' not in p.parts and '.git' not in p.parts and m.filename not in seen
    seen.add(m.filename);mode=m.external_attr>>16;assert stat.S_IFMT(mode) in [0,stat.S_IFREG,stat.S_IFDIR]
    total+=m.file_size;assert total<=32*1024*1024
   for m in members:
    dest=target/m.filename
    if m.is_dir():dest.mkdir(parents=True,exist_ok=True)
    else:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(m))
  dist=list(target.glob('*.dist-info'));assert len(dist)==1
  info=(dist[0]/'METADATA').read_text();assert '\nName: ninja\n' in '\n'+info and '\nVersion: 1.13.0\n' in '\n'+info
  for rel,check,size in csv.reader((dist[0]/'RECORD').read_text().splitlines()):
   p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
   actual=target/p;assert actual.is_file()
   if size:assert actual.stat().st_size==int(size)
   if check:
    kind,wanted=check.split('=',1);assert kind=='sha256'
    assert base64.urlsafe_b64encode(bytes.fromhex(digest(actual))).decode().rstrip('=')==wanted
  binary=target/'ninja/data/bin/ninja';head=binary.read_bytes()[:20];assert head[:6]==b'\x7fELF\x02\x01' and int.from_bytes(head[18:20],'little')==62
  binary.chmod(0o755)
  save(TOOL/'provenance.json',{'version':'1.13.0','metadataURL':'https://pypi.org/pypi/ninja/1.13.0/json','metadataSHA256':digest(metadata),'wheel':str(wheel),'wheelSHA256':digest(wheel),'url':row['url'],'binary':str(binary),'binarySHA256':digest(binary),'binaryExecution':'UNRUN','TLS':'inherited managed proxy/CA; verified; no insecure option','signatureVerification':'not performed; official metadata hash over verified HTTPS','licensesAndCompleteWheel':'retained','globalInstall':False})
  record['status']='ACQUIRED_DATA_ONLY_NO_BINARY_EXECUTION'
 elif a.stage=='compose-configure':
  assert not B4.exists();assert shutil.disk_usage(BASE).free>=25*1024**3
  assert digest(B3/'source/src/module_wrap.cc')==json.loads((R4/'manifest.json').read_text())['baseModuleWrapSHA256']
  B4.mkdir();shutil.copytree(B3/'source',B4/'source',symlinks=False);shutil.copytree(B3/'harness',B4/'harness')
  for rel in ['src/module_wrap.cc','test/cctest/test_owned_module_namespace.cc']:
   dest=B4/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R4/'candidate'/rel,dest)
  shutil.copy2(R4/'harness/namespace-controls.mjs',B4/'harness/namespace-controls.mjs')
  state=composed();save(out/'composed-before.json',state)
  run('configure',[str(B4/'source/configure'),'--ninja','--without-npm','--without-corepack','-C','--download=none'],B4/'source',120)
  metadata=B4/'metadata';metadata.mkdir();shutil.copy2(B4/'source/out/Release/compile_commands.json',metadata/'gyp-compile-commands.json')
  # Provisional generator has known omissions; never used as actual syntax argv.
  rows=json.loads((metadata/'gyp-compile-commands.json').read_text());found={u:[] for u in UNITS}
  for row in rows:
   p=Path(row['file']);p=p if p.is_absolute() else B4/'source'/p;p=p.resolve()
   if p.is_relative_to(B4/'source') and str(p.relative_to(B4/'source')) in found:found[str(p.relative_to(B4/'source'))].append(row)
  save(out/'provisional-seven-units.json',{'status':'GYP PROVISIONAL ONLY','allEntries':len(rows),'units':found});assert all(found.values())
  assert composed()==state;save(out/'composed-after.json',composed());record['status']='R4_CONFIGURED_PROVISIONAL_ONLY'
 else:
  state=composed();save(out/'composed-before.json',state)
  provenance=json.loads((TOOL/'provenance.json').read_text());binary=Path(provenance['binary']);assert digest(binary)==provenance['binarySHA256']
  run('version',[str(binary),'--version'],out,5)
  version=(out/'version.log').read_text().strip();assert re.match(r'^1\.13\.0(?:$|[. -])',version),version
  cwd=B4/'source/out/Release';database=B4/'metadata/ninja-compile-commands.json';assert not database.exists()
  run('targets',[str(binary),'-t','targets','all'],cwd,15)
  run('compdb',[str(binary),'-t','compdb'],cwd,30,database)
  rows=json.loads(database.read_text());found={u:[] for u in UNITS}
  for row in rows:
   directory=Path(row['directory']);directory=directory if directory.is_absolute() else cwd/directory
   p=(directory/row['file']).resolve()
   if p.is_relative_to(B4/'source'):
    rel=str(p.relative_to(B4/'source'))
    if rel in found:found[rel].append(row)
  save(out/'actual-seven-unit-review.json',{'kind':'ACTUAL Ninja compdb; no compiler invoked','database':str(database),'sha256':digest(database),'entries':len(rows),'units':found,'syntax':'UNRUN; review exact variants and generated prerequisites first','cctests':'UNRUN; R3five+R4two','JS':'UNRUN; R3suite+R4three separate'})
  assert all(found.values()),[u for u,v in found.items() if not v]
  assert sum(len(v) for v in found.values())<=12,'Review extra variants; do not silently select'
  assert composed()==state;save(out/'composed-after.json',composed());record['status']='AUTHENTIC_COMPD B_SEVEN_TUS_METADATA_ONLY'.replace(' ','')
 after=frozen();save(out/'inputs-after.json',after);assert after==before;record['guardsStable']=True
except BaseException as error:
 record.update(status='STOPPED',error={'type':type(error).__name__,'message':str(error)},partialOutputsPreserved=True)
finally:
 if active is not None and active.poll() is None:
  os.killpg(active.pid,signal.SIGKILL);active.wait()
 record['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(out/'report.json',record)
print(json.dumps({'status':record['status'],'report':str(out/'report.json')}),flush=True)
sys.exit(1 if record['status']=='STOPPED' else 0)
