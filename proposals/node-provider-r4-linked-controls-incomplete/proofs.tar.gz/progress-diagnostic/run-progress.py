#!/usr/bin/env python3
"""UNRUN until separate lease. One progress-only original proxy stage; never builds."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,signal,time
D=Path(__file__).resolve().parent
A=Path('/workspace/shared/node-provider-r4-acceptance-root57-c3-harness-r2')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--epoch',required=True);a=p.parse_args()
assert a.epoch and all(c.isalnum()or c in '-_'for c in a.epoch)
assert sha(D/'manifest.json')==a.manifest_sha,'Use exact separately reviewed diagnostic manifest'
manifest=json.loads((D/'manifest.json').read_text())
for name,wanted in manifest['files'].items():assert sha(D/name)==wanted,name
out=D/'evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False)
record={'status':'SETUP','kind':'Progress-only diagnostic; never replaces original controls-1 timeout','stages':[],'NodeBuild':'NONE','scriptBehaviorChanges':'Synchronous Host writeSync phase markers only','processCapSeconds':45,'moduleTimeoutMilliseconds':1000,'originalRuntimeStatus':'STOPPED at proxy45s timeout; later10UNRUN','RootWrites':'NONE'}
paths=None;protected=None;start=time.monotonic()
def interrupted(n,f):raise InterruptedError('controller signal '+str(n))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 assert sha(A/'harness-r2-manifest.json')==manifest['approvedAcceptanceManifestSHA256']
 spec=importlib.util.spec_from_file_location('approved_provider_acceptance_common',A/'common.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 outputs=m.matching_linked_outputs();builtPath=A/'build-evidence/addon-1/report.json';assert sha(builtPath)==manifest['addonBuildReportSHA256'];built=json.loads(builtPath.read_text())
 assert built['status']=='OWN_ADDON_BUILT_RUNTIME_UNRUN'and built['inputsStable']and built['protectedRootAnd18SDKArtifactsStable']
 addon=Path(built['addon']['path']);assert sha(addon)==built['addon']['sha256']==manifest['addonSHA256'];assert built['actualNodeOutputs']==outputs
 paths=m.guards();paths[str(addon)]=sha(addon);paths[str(builtPath)]=sha(builtPath)
 paths.update({str(D/name):wanted for name,wanted in manifest['files'].items()});paths[str(D/'manifest.json')]=a.manifest_sha
 protected=m.protected_root();(out/'inputs-before.json').write_text(json.dumps(paths,indent=2)+'\n');(out/'protected-root-before.json').write_text(json.dumps(protected,indent=2)+'\n')
 env=os.environ.copy();env['OWNED_PROVIDER_ADDON']=str(addon)
 command=[str(m.CONTRACT['customNode']),'--experimental-vm-modules',str(D/'proxy-progress.mjs')]
 row=m.run_owned('proxy-progress',command,out,out,env,45);record['stages'].append(row)
 markers=[]
 for line in (out/'proxy-progress.log').read_text(errors='replace').splitlines():
  try:value=json.loads(line)
  except json.JSONDecodeError:continue
  if isinstance(value,dict)and value.get('diagnostic')=='owned-proxy-progress-r1':markers.append(value)
 record['markers']=markers;record['lastObservedPhase']=markers[-1]['phase']if markers else'UNOBSERVED';record['actualNodeOutputs']=outputs;record['actualAddon']=built['addon']
 record['status']='DIAGNOSTIC_TIMEOUT_OR_FAILURE_ORIGINAL_UNCHANGED'if row['administrativeTimeout']or row['returnCode']!=0 else'DIAGNOSTIC_RETURNED_ZERO_ORIGINAL_EPOCH_NOT_RECLASSIFIED'
 if row['returnCode']==0 and not any(x['phase']=='case2:test-complete'for x in markers):record['status']='DIAGNOSTIC_MISSING_COMPLETION_OBSERVATION'
except BaseException as error:record.update(status='STOPPED_SETUP_OR_CONTROLLER',error={'type':type(error).__name__,'message':str(error)},partialOutputsPreserved=True)
finally:
 if paths is not None:
  after={name:sha(name)for name in paths};record['inputsStable']=after==paths;(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
 if protected is not None:
  after=m.protected_root();record['protectedRootAnd18Stable']=after==protected;(out/'protected-root-after.json').write_text(json.dumps(after,indent=2)+'\n')
 if record.get('inputsStable')is False or record.get('protectedRootAnd18Stable')is False:record['status']='GUARD_FAILURE'
 record['elapsedSeconds']=time.monotonic()-start;(out/'report.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':record['status'],'stages':record['stages'],'lastObservedPhase':record.get('lastObservedPhase','UNOBSERVED'),'report':str(out/'report.json')}),flush=True)
raise SystemExit(0 if record['status']=='DIAGNOSTIC_RETURNED_ZERO_ORIGINAL_EPOCH_NOT_RECLASSIFIED'else 1)
