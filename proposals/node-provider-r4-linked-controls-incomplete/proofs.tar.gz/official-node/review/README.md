# Pinned Node cooperative-provider source review

Status: source acquisition and static review only. No Node execution, browser, test, build, project configuration, installation or Root mutation occurred in this acquisition/review. No cooperative provider is implemented. This is a possible project-runtime dependency extension, not a Lightpanda engine fork or an accepted browser parity claim.

The complete official Node v24.22.1 archive is retained at `../downloads/node-v24.22.1.tar.xz`, SHA-256 `4f5379796280cdaeb0c2f358fd04b6a16cc4fb7dfa83b5a8c91a9d963b435231`. It matches the exact official `SHASUMS256.txt` entry, acquired separately from the same official release over inherited managed proxy/CA and normal verified TLS. Each URL required one request; HTTP 200 and TLS verification result 0 are recorded. No detached-signature verification is claimed. URLs:

- https://nodejs.org/dist/v24.22.1/SHASUMS256.txt
- https://nodejs.org/dist/v24.22.1/node-v24.22.1.tar.xz

All 37,246 archive entries were preflighted and the complete tree extracted to `../source/node-v24.22.1`: 33,486 files, 3,760 directories, 594,700,215 uncompressed regular-file bytes; no links, special entries, traversal, duplicate paths or .git. Acquisition and extraction evidence is under `../evidence`. The extracted version is Node 24.22.1 with V8 base 13.6.233.17; the retained SDK manifest identifies V8 13.6.233.17-node.58 and ABI 137. Five retained source snapshots and five selected SDK/public headers match the official source byte for byte. Full-tree extraction coverage includes Node internal headers, V8 headers and V8 source, closing the previous missing-source coverage gap. This does not close any build or behavior gap.

The network/source acquisition lease was released after verification. All following review is static, without additional downloads. Earlier frozen packets remain untouched, including `/workspace/shared/cooperative-node-provider-static` and `/workspace/shared/owned-current-root-integration-handoff/static1`.

Read `BINDING-SLOT.md` for the corrected slot-35 premise; `SURFACE-AND-PLAN.md` for the smallest proposed source boundary and unrun acceptance plan. `source-map.json` pins cited input files and line anchors. `seal.json` records bounded input readback. The archive remains complete; the manifest hashes review/evidence documents and selected source files, not a claimed hash census of every extracted file.
