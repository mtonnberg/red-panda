from pathlib import Path
from hashlib import sha256
import json, datetime

base=Path('/workspace/shared/node-provider-source-v24.22.1')
source=base/'source/node-v24.22.1'
def digest(p):
    h=sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def write(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
anchors={
'src/node_context_data.h':[27,43,92],
'src/node_contextify.h':[16,24,59,87,188],
'src/node_contextify.cc':[112,140,145,203,237,254,303,316,328,436,457,1197,1386],
'src/node_realm.h':[25,40],
'src/node_realm-inl.h':[91,138],
'src/node_realm.cc':[226],
'src/cppgc_helpers.h':[79],
'src/cppgc_helpers-inl.h':[12,58],
'src/cppgc_helpers.cc':[6],
'src/env.cc':[238,704],
'src/api/environment.cc':[1102],
'src/node_snapshotable.cc':[856,1191,1340,1363],
'src/module_wrap.h':[1],
'src/module_wrap.cc':[150,221,305,491,738,1090,1115,1171,1186,1230],
'src/node.h':[1],
'src/node_version.h':[1],
'lib/vm.js':[78,229,260],
'lib/internal/vm.js':[48,60,97],
'lib/internal/vm/module.js':[120,141,169,314,354,522],
'lib/internal/modules/esm/utils.js':[138,146,169,203,253,294],
'deps/v8/include/v8-context.h':[66,82,200,279],
'deps/v8/include/v8-isolate.h':[1],
'deps/v8/include/v8-version.h':[1],
'deps/v8/src/api/api.cc':[917,6827,7260,10199],
'deps/v8/src/objects/objects-body-descriptors-inl.h':[1389],
'deps/v8/src/snapshot/context-serializer.cc':[333],
'deps/v8/src/execution/isolate.h':[2614,2635],
}
rows=[{'source':key,'absolutePath':str(source/key),'sha256':digest(source/key),'citedLines':val} for key,val in anchors.items()]
write(base/'review/source-map.json',{'kind':'Static source anchors; all proposed controls UNRUN','officialNodeVersion':'24.22.1','sourceRoot':str(source),'files':rows})
prior=json.loads((base/'evidence/review-inputs-before.json').read_text())['files']
checks=[{'relative':r['relative'],'before':r['sha256'],'after':digest(Path(r['path'])),'unchanged':r['sha256']==digest(Path(r['path']))} for r in prior]
archive=base/'downloads/node-v24.22.1.tar.xz'
archive_sha=digest(archive)
assert archive_sha=='4f5379796280cdaeb0c2f358fd04b6a16cc4fb7dfa83b5a8c91a9d963b435231'
assert all(r['unchanged'] for r in checks)
slot=(base/'evidence/reserved-binding-index-search.txt').read_text().splitlines()
assert len(slot)==2
write(base/'review/seal.json',{
'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'status':'STATIC DESIGN ONLY; no provider source implementation or runtime acceptance',
'archiveSHA256':archive_sha,'archiveBytes':archive.stat().st_size,
'reservedMacroOccurrences':slot,'priorSelectedSourceReadback':checks,
'priorSelectedInputsUnchanged':len(checks),
'newSourceMapEntries':len(rows),
'noOperations':['Node execution','browser','test','build','installation','project configuration','Root mutation','post-acquisition network'],
'untested':['new provider API','slot reservation use','proxy reuse through genuine Contextify','real SourceTextModule provider integration','GC/cppgc lifetime','snapshot exclusion','distinct security tokens','Host Promise adoption','browser Page/Frame integration'],
'unchangedPriorPackets':['/workspace/shared/cooperative-node-provider-static','/workspace/shared/owned-current-root-integration-handoff/static1']})
files=[]
for dirname in ('evidence','review'):
    for p in sorted((base/dirname).rglob('*')):
        if p.is_file():files.append({'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':digest(p)})
for p in sorted((base/'downloads').iterdir()):
    if p.is_file():files.append({'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':digest(p)})
manifest={'kind':'Immutable acquisition/static source review packet; extracted source citations pinned by source-map.json','files':files,'selectedSourceMapSHA256':digest(base/'review/source-map.json')}
write(base/'manifest.json',manifest)
print(json.dumps({'manifestSHA256':digest(base/'manifest.json'),'manifestFiles':len(files),'sourceMapEntries':len(rows),'priorInputsUnchanged':len(checks),'reviewDocuments':3,'providerImplemented':False,'runtimeControlsRun':0}))
