from pathlib import Path
import json,hashlib,os,signal,time,subprocess
ROOT=Path(__file__).resolve().parent;CONTRACT=json.loads((ROOT/'contract.json').read_text());BUILD=Path(CONTRACT['buildRoot']);SOURCE=Path(CONTRACT['sourceRoot']);OUTPUTS=Path(CONTRACT['futureOutputsManifest']);REPORT=Path(CONTRACT['futureBuildReport']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def matching_linked_outputs():
 assert OUTPUTS.is_file()and REPORT.is_file(),'R4 link evidence unavailable; future stage UNRUN, never use old SDK/partial binary'
 outputs=json.loads(OUTPUTS.read_text());report=json.loads(REPORT.read_text());assert report['status']=='BUILT_LINKED_ONLY_TESTS_UNRUN'and report['guardsStable']is True,report.get('status')
 for name,expected in [('node',CONTRACT['customNode']),('cctest',CONTRACT['customCctest'])]:
  row=outputs[name];assert row['path']==expected;assert sha(expected)==row['sha256'],name
 return outputs

def guards():
 values={}
 for name,wanted in CONTRACT['source13'].items():assert sha(name)==wanted,('actual R4 composed13 source mismatch',name);values[name]=wanted
 for name,row in CONTRACT['harness'].items():
  for file in [ROOT/'harness'/name,BUILD/'harness'/name]:assert sha(file)==row['sha256'],str(file);values[str(file)]=row['sha256']
 graph=json.loads((ROOT/'reference/actual-r4-ninja-graph.json').read_text())
 for name,wanted in graph.items():assert sha(name)==wanted,('actual Ninja graph drift',name);values[name]=wanted
 metadata=CONTRACT['syntaxMetadata'];assert sha(metadata['path'])==metadata['sha256'];assert sha(metadata['database'])==metadata['databaseSHA256'];values[metadata['path']]=metadata['sha256'];values[metadata['database']]=metadata['databaseSHA256']
 for name in ['config.gypi','config.status','common.gypi','node.gyp','node.gypi']:
  file=SOURCE/name
  if file.is_file():values[str(file)]=sha(file)
 # Capture actual public and generated header inputs only AFTER successful link.
 # Do not freeze an active generator's partial output or substitute stock SDK headers.
 for directory in [SOURCE/'src',SOURCE/'deps/v8/include',SOURCE/'deps/uv/include',SOURCE/'out/Release/gen',SOURCE/'out/Release/obj/gen']:
  for file in directory.rglob('*.h'):
   if file.is_file():values[str(file)]=sha(file)
 for file in (SOURCE/'deps/npm/node_modules/node-gyp').rglob('*'):
  if file.is_file():values[str(file)]=sha(file)
 for file in list((ROOT/'reference').rglob('*'))+[ROOT/'contract.json',ROOT/'common.py',ROOT/'build-addon.py',ROOT/'run-controls-r4.py',OUTPUTS,REPORT]:
  if file.is_file():values[str(file)]=sha(file)
 tools=json.loads((ROOT/'reference/actual-r4-toolchain.json').read_text());compiler=tools['compiler'];assert sha(compiler['resolvedPath'])==compiler['sha256'];values[compiler['resolvedPath']]=compiler['sha256']
 for name in ['node','cctest']:file=Path(CONTRACT['customNode']if name=='node'else CONTRACT['customCctest']);values[str(file)]=sha(file)
 return values

def protected_root():
 app=Path('/workspace/red-panda');files=[p for folder in ['src','bin']for p in(app/folder).rglob('*')if p.is_file()];files.extend(p for p in(app/'native').rglob('*')if p.is_file()and('build'in p.parts or p.suffix in ['.cc','.json','.mjs','.py']));files.extend([app/'package.json',app/'package-lock.json']);artifacts=[p for p in(app/'native/build').rglob('*')if p.is_file()and(p.name.endswith('.node')or p.name.endswith('.node.json'))];assert len(artifacts)==18,len(artifacts)
 return{str(file):sha(file)for file in sorted(set(files))}

def snapshot(paths):return{name:sha(name)for name in paths}
def run_owned(name,command,cwd,out,env,cap):
 start=time.monotonic();child=None;timed=False;code=None
 try:
  with(out/(name+'.log')).open('xb')as log:
   child=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
   try:code=child.wait(timeout=cap)
   except subprocess.TimeoutExpired:
    timed=True
    try:os.killpg(child.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:code=child.wait(timeout=3)
    except subprocess.TimeoutExpired:
     try:os.killpg(child.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     code=child.wait()
 finally:
  if child is not None and child.poll()is None:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait()
 return{'name':name,'command':command,'cwd':str(cwd),'ownedPid':child.pid if child else None,'returnCode':code,'signal':-code if code is not None and code<0 else None,'administrativeTimeout':timed,'capSeconds':cap,'elapsedSeconds':time.monotonic()-start,'status':'timeout'if timed else'pass'if code==0 else'failure'}
