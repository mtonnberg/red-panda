R3 is a separate STATIC acceptance copy after the explicitly authorized manual -j2→-j4 build-resource continuation. Older R1/R2 remain immutable. No controller code, source13, config/flags, actual gen/objgen header guards, harness/assertions,13-stage commands,7 C++ cases or original limits changed.

Only acceptance CONTRACT paths now point to /workspace/shared/node-provider-r4-full-build-j4-evidence/{outputs,report}.json. They remain unavailable/unaccepted until genuine successful link. Existing matching-link gate still requires BUILT_LINKED_ONLY_TESTS_UNRUN,guardsStable and actual node/cctest path+binarySHA. No source/ABI/oldSDK output is substituted.

reference/manual-continuation-provenance.json and added raw reference inputs are guarded by the existing common.py reference-file scan. Original j2 report remains STOPPED: manually sentSIGTERM after1130.763306895s, actual Ninja return0 caught the signal, but node output absent. That is intentional resource adjustment with missing link, not an observed compiler diagnostic or accepted link. The original5400s total allowance retains4269.236693105s for j4, same cache/source/config/flags. Actual old/new generated Ninja maps are equal. Oldreport/resource-adjustment/controller hashes and original bytes are preserved, without relabeling the first epoch.

Future separate addon-build lease:
python3 /workspace/shared/node-provider-r4-acceptance-r3/build-addon.py --epoch addon-1
Future SEPARATE runtime lease only after actual addon report review:
python3 /workspace/shared/node-provider-r4-acceptance-r3/run-controls-r4.py --addon-build-report /workspace/shared/node-provider-r4-acceptance-r3/build-evidence/addon-1/report.json --epoch controls-1

Dynamic ROOT only selects this new own harness/cache/evidence. Custom R4node/bundledgyp/source--nodedir/jobs1/offline and all protectedRoot18artifact checks remain intact. Existing README/R2 metadata describe older preserved setup; current authority is r3-manifest.json/r3-inventory.sha256. No runtime/build/network/Root edits occurred in this derivative; pending future stages remain UNRUN.
