{
  'targets': [
    {
      'target_name': 'provider',
      'sources': ['provider.cc'],
      'cflags_cc': ['-std=c++20'],
    },
  ],
}
