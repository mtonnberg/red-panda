// SOURCE ONLY, UNRUN. Genuine exact raw proxy eligibility; no public markers.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { test } from 'node:test';
const binding = createRequire(import.meta.url)(process.env.OWNED_PROVIDER_ADDON);
async function namespace(owner) {
  const carrier=vm.prepareOwnedContext();binding.create(carrier);
  const module=new vm.SourceTextModule(`export const owner=${JSON.stringify(owner)}`,{context:carrier});
  await module.link(()=>{});await module.evaluate({timeout:1000});return module.namespace;
}

await test('active/detached/reused raw proxy cannot become ordinary sandbox; old/new real HDO remain separate',async()=>{
  const depA=await namespace('A'),depB=await namespace('B');
  const calls=[];
  let a,b;
  a=vm.prepareOwnedContext({importModuleDynamically(specifier,referrer){
    assert.equal(specifier,'dep');assert.equal(referrer,a);calls.push('A');return depA;
  }});
  const proxy=binding.create(a);
  const saved=binding.run(a,'globalThis.marker="A"; ({Object,read:()=>marker,load:()=>import("dep")})');
  assert.equal(vm.isContext(proxy),false);
  assert.throws(()=>vm.createContext(proxy),{code:'ERR_INVALID_STATE'});
  assert.throws(()=>vm.runInNewContext('1',proxy),{code:'ERR_INVALID_STATE'});
  assert.equal(vm.runInContext('Object',a),saved.Object);
  assert.equal((await saved.load()).owner,'A');
  assert.equal(binding.detach(a),proxy);
  assert.throws(()=>vm.createContext(proxy),{code:'ERR_INVALID_STATE'});
  assert.throws(()=>vm.runInNewContext('1',proxy),{code:'ERR_INVALID_STATE'});
  assert.equal(saved.read(),'A');
  assert.equal((await saved.load()).owner,'A');
  b=vm.prepareOwnedContext({importModuleDynamically(specifier,referrer){
    assert.equal(specifier,'dep');assert.equal(referrer,b);calls.push('B');return depB;
  }});
  assert.equal(binding.create(b,a),proxy);
  vm.runInContext('globalThis.marker="B"',b);
  assert.throws(()=>vm.createContext(proxy),{code:'ERR_INVALID_STATE'});
  assert.throws(()=>vm.runInNewContext('1',proxy),{code:'ERR_INVALID_STATE'});
  assert.equal(vm.runInContext('Object',a),saved.Object);
  assert.equal(saved.read(),'A');
  assert.equal((await saved.load()).owner,'A');
  assert.equal((await binding.run(b,'import("dep")')).owner,'B');
  assert.deepEqual(calls,['A','A','A','B']);
  console.log(JSON.stringify({case:'reserved actual proxy',phases:['active','detached','reused'],
    sameRawIdentity:true,actualCallbackOwners:calls}));
});

await test('ordinary plain objects and authored Proxy objects retain actual Node contextification',()=>{
  const carrier=vm.prepareOwnedContext();const raw=binding.create(carrier);
  const plain=vm.runInContext('({answer:40})',carrier);
  const ordinary=vm.createContext(plain);
  assert.equal(ordinary,plain);
  assert.equal(vm.runInContext('answer+=2;answer',ordinary),42);
  const proxy=new Proxy({answer:5},{});
  assert.equal(vm.createContext(proxy),proxy);
  assert.equal(vm.runInContext('answer+=1;answer',proxy),6);
  const lookalike={answer:7,[Symbol.toStringTag]:'GenericOwnedWindow'};
  assert.equal(vm.createContext(lookalike),lookalike);
  assert.equal(vm.runInContext('answer',lookalike),7);
  binding.detach(carrier);
  const fresh=vm.prepareOwnedContext();assert.equal(binding.create(fresh,carrier),raw);
  assert.equal(vm.runInContext('answer',ordinary),42);
  assert.equal(vm.runInContext('answer',proxy),6);
});
