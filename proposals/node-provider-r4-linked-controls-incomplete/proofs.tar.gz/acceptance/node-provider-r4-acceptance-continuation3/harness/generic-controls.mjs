// UNRUN source harness. Requires this exact custom Node build and addon.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { test } from 'node:test';
const require = createRequire(import.meta.url);
assert.ok(process.env.OWNED_PROVIDER_ADDON, 'Set actual built OWNED_PROVIDER_ADDON');
const binding = require(process.env.OWNED_PROVIDER_ADDON);
assert.equal(binding.providerVersion, 1);
assert.equal(typeof vm.prepareOwnedContext, 'function');
const ticket = options => vm.prepareOwnedContext(options);
const make = options => {
  const carrier = ticket(options);
  return { carrier, proxy: binding.create(carrier) };
};
const snapshots = [];
function observe(name, facts) {
  snapshots.push({ name, facts });
  process.stdout.write(JSON.stringify({ name, facts }) + '\n');
}
async function evaluated(carrier, source, identifier = 'owned:test') {
  const module = new vm.SourceTextModule(source, { context: carrier, identifier });
  await module.link(() => { throw new Error('Unexpected static dependency'); });
  await module.evaluate({ timeout: 1000 });
  return module;
}

await test('pending ticket is not a context; public lookalikes cannot create one', () => {
  const pending = ticket();
  assert.equal(Object.getPrototypeOf(pending), null);
  assert.equal(vm.isContext(pending), false);
  assert.deepEqual(Reflect.ownKeys(pending), []);
  assert.throws(() => vm.runInContext('1', pending), { code: 'ERR_INVALID_ARG_TYPE' });
  assert.throws(() => binding.create({ pending: true }), { code: 'ERR_INVALID_STATE' });
  assert.throws(() => binding.create(new Proxy(pending, {})), { code: 'ERR_INVALID_STATE' });
  binding.create(pending);
  assert.equal(vm.isContext(pending), true);
  assert.throws(() => binding.create(pending), { code: 'ERR_INVALID_STATE' });
  observe('ticket-authenticity', { pendingNotContext: true, authenticAfterCreate: true });
});

await test('stock contexts, DONT_CONTEXTIFY and native deadlines retain their paths', () => {
  const normal = vm.createContext({ answer: 41 });
  assert.equal(vm.runInContext('answer + 1', normal), 42);
  const vanilla = vm.createContext(vm.constants.DONT_CONTEXTIFY);
  assert.equal(vm.runInContext('globalThis', vanilla), vanilla);
  assert.throws(() => vm.runInContext('while(true){}', normal, { timeout: 20 }),
    { code: 'ERR_SCRIPT_EXECUTION_TIMEOUT' });
  const run = vm.compileFunction('return hostNumber + value', ['value'], {
    parsingContext: normal, contextExtensions: [{ hostNumber: 3 }],
  });
  assert.equal(run(4), 7);
  observe('ordinary-vm', { normal: true, vanilla: true, nativeDeadline: true });
});

await test('genuine owned carrier compiles real VM allocations and contextExtensions', () => {
  const { carrier, proxy } = make();
  assert.notEqual(carrier, proxy);
  assert.equal(vm.runInContext('globalThis', carrier), proxy);
  const original = vm.runInContext('({object: Object, array: Array, eval, value: [], fn:()=>42})', carrier);
  for (const value of Object.values(original)) assert.equal(binding.sameRealm(value, carrier), true);
  const fn = vm.compileFunction('return [host, arg, this.marker]', ['arg'], {
    parsingContext: carrier, contextExtensions: [{ host: 5 }],
  });
  assert.deepEqual(Array.from(fn.call({ marker: 9 }, 7)), [5, 7, 9]);
  assert.equal(binding.sameRealm(fn, carrier), true);
  vm.runInContext('globalThis.Array = function(){throw new Error("authored")}', carrier);
  const literal = binding.run(carrier, '[]');
  assert.equal(binding.sameRealm(literal, carrier), true);
  Object.setPrototypeOf(original.fn, null);
  assert.equal(binding.sameRealm(original.fn, carrier), true);
  observe('physical-allocation', { genuineAllocations: true, afterNullPrototype: true });
});

await test('actual proxy reuse preserves old closure state and fresh intrinsic realms', () => {
  const a = make();
  const old = vm.runInContext('globalThis.marker="A"; ({Object,Array,eval,fn:()=>marker, value:({owner:"A"})})', a.carrier);
  assert.equal(binding.detach(a.carrier), a.proxy);
  assert.throws(() => binding.detach(a.carrier), { code: 'ERR_INVALID_STATE' });
  const bCarrier = ticket();
  const bProxy = binding.create(bCarrier, a.carrier);
  assert.equal(bProxy, a.proxy);
  const fresh = vm.runInContext('globalThis.marker="B"; ({Object,Array,eval,fn:()=>marker})', bCarrier);
  for (const key of ['Object', 'Array', 'eval', 'fn']) {
    assert.notEqual(old[key], fresh[key]);
    assert.equal(binding.sameRealm(old[key], a.carrier), true);
    assert.equal(binding.sameRealm(fresh[key], bCarrier), true);
  }
  assert.equal(old.fn(), 'A');
  assert.equal(fresh.fn(), 'B');
  assert.equal(old.value.owner, 'A');
  assert.equal(binding.sameRealm(old.value, a.carrier), true);
  assert.throws(() => binding.create(ticket(), a.carrier), { code: 'ERR_INVALID_STATE' });
  observe('proxy-reuse', { exactProxyIdentity: true, actualFreshIntrinsics: true, retainedClosure: true,
    documentControl: 'NOT A DOCUMENT: ordinary old object only; real Document chain remains unrun' });
});

await test('reuse requires an actual detached owned carrier', () => {
  const active = make();
  assert.throws(() => binding.create(ticket(), active.carrier), { code: 'ERR_INVALID_STATE' });
  assert.throws(() => binding.detach(vm.createContext({})), { code: 'ERR_INVALID_STATE' });
});

await test('real SourceTextModule/meta/namespace and static import retain canonical identities', async () => {
  const { carrier } = make();
  let actualMeta, actualReferrer;
  const dep = await evaluated(carrier, 'export const value = 7', 'owned:dependency');
  const source = new vm.SourceTextModule('import {value} from "dep"; export const answer=value+1; export const meta=import.meta', {
    context: carrier, identifier: 'owned:entry',
    initializeImportMeta(meta, referrer) {
      actualMeta = meta; actualReferrer = referrer;
      Object.defineProperty(meta, 'realOwner', { value: 'owned:entry', enumerable: true });
    },
  });
  await source.link(specifier => { assert.equal(specifier, 'dep'); return dep; });
  await source.evaluate({ timeout: 1000 });
  assert.equal(source.namespace.answer, 8);
  assert.equal(source.namespace.meta, actualMeta);
  assert.equal(actualReferrer, source);
  assert.equal(binding.sameRealm(actualMeta, carrier), true);
  assert.equal(source.context, carrier);
  observe('genuine-module', { exports: 8, canonicalReferrer: true, actualMetaRealm: true });
});

await test('equal proxy identity does not permit cross-document module linking', async () => {
  const a = make();
  const dependency = await evaluated(a.carrier, 'export const value=1');
  binding.detach(a.carrier);
  const b = ticket();
  assert.equal(binding.create(b, a.carrier), a.proxy);
  const entry = new vm.SourceTextModule('import "a"', { context: b });
  await assert.rejects(entry.link(() => dependency), { code: 'ERR_VM_MODULE_DIFFERENT_CONTEXT' });
});

await test('authentic context HDO fallback follows actual old Context after proxy reuse', async () => {
  const calls = [];
  let aCarrier, bCarrier;
  const aDepCarrier = ticket(); binding.create(aDepCarrier);
  const bDepCarrier = ticket(); binding.create(bDepCarrier);
  const aDep = await evaluated(aDepCarrier, 'export const owner="A"');
  const bDep = await evaluated(bDepCarrier, 'export const owner="B"');
  aCarrier = ticket({ importModuleDynamically(specifier, referrer, attributes, phase) {
    calls.push({ owner: 'A', specifier, referrer, attributes, phase }); return aDep.namespace;
  } });
  const proxy = binding.create(aCarrier);
  const saved = binding.run(aCarrier, '()=>import("dep")');
  assert.equal((await saved()).owner, 'A');
  binding.detach(aCarrier);
  bCarrier = ticket({ importModuleDynamically(specifier, referrer, attributes, phase) {
    calls.push({ owner: 'B', specifier, referrer, attributes, phase }); return bDep.namespace;
  } });
  assert.equal(binding.create(bCarrier, aCarrier), proxy);
  assert.equal((await saved()).owner, 'A');
  assert.equal((await binding.run(bCarrier, 'import("dep")')).owner, 'B');
  assert.deepEqual(calls.map(row => row.owner), ['A', 'A', 'B']);
  assert.equal(calls[0].referrer, aCarrier);
  assert.equal(calls[1].referrer, aCarrier);
  assert.equal(calls[2].referrer, bCarrier);
  for (const call of calls) {
    assert.equal(call.specifier, 'dep');
    assert.equal(call.phase, 'evaluation');
    assert.equal(Object.getPrototypeOf(call.attributes), null);
  }
  observe('owned-context-HDO', { actualCallbacks: calls.map(row => row.owner), realNamespace: true });
});

await test('module/script/compileFunction dynamic import registrations remain genuine', async () => {
  const { carrier } = make();
  const dep = await evaluated(carrier, 'export const value=19');
  const refs = [];
  const callback = (specifier, referrer) => { assert.equal(specifier, 'dep'); refs.push(referrer); return dep; };
  const module = new vm.SourceTextModule('export const value=(await import("dep")).value', {
    context: carrier, importModuleDynamically: callback,
  });
  await module.link(() => {});
  await module.evaluate({ timeout: 1000 });
  assert.equal(module.namespace.value, 19);
  assert.equal(refs.shift(), module);
  const script = new vm.Script('import("dep")', { importModuleDynamically: callback });
  assert.equal((await script.runInContext(carrier)).value, 19);
  assert.equal(refs.shift(), script);
  const fn = vm.compileFunction('return import("dep")', [], {
    parsingContext: carrier, importModuleDynamically: callback,
  });
  assert.equal((await fn()).value, 19);
  assert.equal(refs.shift(), fn);
  await assert.rejects(binding.run(carrier, 'import("none")'), { code: 'ERR_VM_DYNAMIC_IMPORT_CALLBACK_MISSING' });
});

await test('ordinary Node module/import/meta callbacks still operate after owned imports', async () => {
  const ordinary = vm.createContext({});
  const dep = await evaluated(ordinary, 'export const ordinary=31');
  let metaCalls = 0;
  const m = new vm.SourceTextModule('export const x=import.meta.x; export const y=(await import("dep")).ordinary', {
    context: ordinary,
    initializeImportMeta(meta) { ++metaCalls; meta.x = 30; },
    importModuleDynamically() { return dep; },
  });
  await m.link(() => {});
  await m.evaluate({ timeout: 1000 });
  assert.equal(m.namespace.x, 30);
  assert.equal(m.namespace.y, 31);
  assert.equal(metaCalls, 1);
  assert.equal((await import('node:path')).basename('/a/b'), 'b');
  observe('ordinary-modules-after-owned', { ordinaryCallbacks: true, normalNodeImport: true });
});

await test('owned script native timeout preserves ordinary exception identity and later execution', () => {
  const { carrier } = make();
  const authored = vm.runInContext('new Error("authored")', carrier);
  const thrower = vm.runInContext('(value)=>{throw value}', carrier);
  assert.throws(() => thrower(authored), error => error === authored);
  assert.throws(() => vm.runInContext('while(true){}', carrier, { timeout: 20 }),
    { code: 'ERR_SCRIPT_EXECUTION_TIMEOUT' });
  assert.equal(vm.runInContext('6*7', carrier), 42);
});

process.stdout.write(JSON.stringify({ status: 'reached end; node:test verdict is authoritative', controlGroups: 11, observationRows: snapshots.length,
  remaining: ['real Document/Page/Frame composition', 'GC cohort file', 'distinct-token adoption file',
    'snapshot rejection invocation', 'allocation failure injection', 'custom slot-macro builds'] }) + '\n');
