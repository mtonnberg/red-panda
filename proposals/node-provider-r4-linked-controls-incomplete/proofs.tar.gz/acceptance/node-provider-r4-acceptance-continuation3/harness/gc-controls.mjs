// UNRUN. Only native weak handles observe original actual Context/carrier.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { createRequire } from 'node:module';
const binding = createRequire(import.meta.url)(process.env.OWNED_PROVIDER_ADDON);
assert.equal(typeof global.gc, 'function', 'Run with --expose-gc');
const roots = [];
const observations = [];
const immediate = () => new Promise(resolve => setImmediate(resolve));
async function collect() {
  for (let i = 0; i < 12; i++) { global.gc(); await immediate(); }
}
function setupClosure() {
  const carrier = vm.prepareOwnedContext();
  binding.create(carrier);
  const id = binding.watch(carrier);
  roots.push(vm.runInContext('()=>({answer:42})', carrier));
  return id;
}
async function setupNamespace() {
  const carrier = vm.prepareOwnedContext();
  binding.create(carrier);
  const id = binding.watch(carrier);
  const module = new vm.SourceTextModule('export function answer(){return 42}', { context: carrier });
  await module.link(() => {});
  await module.evaluate({ timeout: 1000 });
  roots.push(module.namespace);
  return id;
}
async function setupContextHdo() {
  let dependency;
  const carrier = vm.prepareOwnedContext({ importModuleDynamically() {
    return dependency.namespace;
  } });
  binding.create(carrier);
  dependency = new vm.SourceTextModule('export const fromHdo=43', { context: carrier });
  await dependency.link(() => {});
  await dependency.evaluate({ timeout: 1000 });
  const id = binding.watch(carrier);
  roots.push(binding.run(carrier, '()=>import("held")'));
  return id;
}
async function checkHeldImport() {
  assert.equal((await roots[2]()).fromHdo, 43);
}
function setupReused() {
  const a = vm.prepareOwnedContext();
  const proxy = binding.create(a);
  const first = binding.watch(a);
  binding.detach(a);
  const b = vm.prepareOwnedContext();
  assert.equal(binding.create(b, a), proxy);
  return [first, binding.watch(b)];
}
const closureId = setupClosure();
const namespaceId = await setupNamespace();
const hdoId = await setupContextHdo();
const reused = setupReused();
// Generic template is an explicit Host service root. Drop it before GC so its
// caches cannot accidentally make this a false lifetime demonstration.
binding.releaseTemplate();
await collect();
for (const [id, producer] of [[closureId, 'retained-closure'], [namespaceId, 'real-namespace'], [hdoId, 'context-HDO-registry']]) {
  const actual = binding.watchState(id);
  observations.push({ producer, actual });
  assert.deepEqual(actual, { contextCollected: false, carrierCollected: false });
}
assert.equal(roots[0]().answer, 42);
assert.equal(roots[1].answer(), 42);
await checkHeldImport();
roots.length = 0;
await collect();
for (const id of [closureId, namespaceId, hdoId, ...reused]) {
  const actual = binding.watchState(id);
  observations.push({ producer: 'all-roots-released', id, actual });
  assert.deepEqual(actual, { contextCollected: true, carrierCollected: true });
}
console.log(JSON.stringify({ status: 'bounded actual collection observed', observations,
  bounds: '12 explicit GC turns per cohort; cctest separately observes real cppgc wrapper' }));
