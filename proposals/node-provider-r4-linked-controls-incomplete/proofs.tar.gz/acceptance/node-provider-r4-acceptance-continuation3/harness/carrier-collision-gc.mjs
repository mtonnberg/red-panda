// SOURCE ONLY, UNRUN. Actual retained real module namespace/ordinary carrier.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { createRequire } from 'node:module';
const binding = createRequire(import.meta.url)(process.env.OWNED_PROVIDER_ADDON);
assert.equal(typeof global.gc, 'function');
const immediate = () => new Promise(resolve => setImmediate(resolve));
async function collect() {
  for (let i=0;i<12;i++) { global.gc(); await immediate(); }
}
async function setup() {
  const calls = [];
  const carrier = vm.prepareOwnedContext({ importModuleDynamically() {
    calls.push('A'); throw new Error('Prepared A must not win');
  } });
  let dependency;
  vm.createContext(carrier, { importModuleDynamically(specifier, referrer) {
    calls.push('B'); assert.equal(specifier,'dep'); assert.equal(referrer,carrier);
    return dependency;
  } });
  dependency = new vm.SourceTextModule('export const owner="ordinary-B"', { context: carrier });
  await dependency.link(() => {});
  await dependency.evaluate({ timeout: 1000 });
  vm.runInContext('globalThis.marker=29',carrier);
  const module = new vm.SourceTextModule('export const read=()=>marker', { context: carrier });
  await module.link(() => {});
  assert.throws(() => binding.create(carrier), { code: 'ERR_INVALID_STATE' });
  await module.evaluate({ timeout: 1000 });
  const script = new vm.Script('Promise.resolve("import(\'dep\')").then(eval)', {
    importModuleDynamically() { throw new Error('Script callback must not win'); },
  });
  assert.equal(await script.runInContext(carrier), dependency.namespace);
  assert.deepEqual(calls,['B']);
  return { weakCarrier: new WeakRef(carrier), namespace: module.namespace };
}
const held = await setup();
await collect();
function checkHeld() {
  assert.ok(held.weakCarrier.deref());
  assert.equal(held.namespace.read(),29);
}
checkHeld();
held.namespace=null;
await immediate(); // End the job that dereferenced the carrier.
await collect();
assert.equal(held.weakCarrier.deref(),undefined);
console.log(JSON.stringify({ retained:'real module namespace', ordinaryBImport:true,
  carrierCollectedAfterRelease:true, bounds:'12 actual GC turns per cohort; cppgc observed in separate cctest' }));
