// Generic test addon for the NEW Node source API. Not linked/built/run yet.
#include <node.h>
#include <v8.h>
#include <memory>
#include <vector>

namespace {
using namespace v8;
struct Watch {
  Global<Context> context;
  Global<Object> carrier;
};
struct State {
  node::Environment* env;
  Global<ObjectTemplate> global_template;
  std::vector<std::unique_ptr<Watch>> watches;
};
Local<String> Text(Isolate* isolate, const char* text) {
  return String::NewFromUtf8(isolate, text).ToLocalChecked();
}
State* Data(const FunctionCallbackInfo<Value>& args) {
  return static_cast<State*>(args.Data().As<External>()->Value());
}
void Bad(const FunctionCallbackInfo<Value>& args, const char* text) {
  args.GetIsolate()->ThrowException(Exception::TypeError(Text(args.GetIsolate(), text)));
}
MaybeLocal<Context> Owner(const FunctionCallbackInfo<Value>& args, int index) {
  if (args.Length() <= index || !args[index]->IsObject()) {
    Bad(args, "Expected genuine owned carrier");
    return {};
  }
  return node::GetOwnedContext(Data(args)->env, args[index].As<Object>());
}
void Create(const FunctionCallbackInfo<Value>& args) {
  auto* state = Data(args);
  auto* isolate = args.GetIsolate();
  if (args.Length() < 1 || !args[0]->IsObject()) return Bad(args, "Expected ticket");
  if (state->global_template.IsEmpty()) return Bad(args, "Template released");
  Local<Object> previous;
  if (args.Length() > 1 && !args[1]->IsUndefined()) {
    if (!args[1]->IsObject()) return Bad(args, "Expected previous carrier");
    previous = args[1].As<Object>();
  }
  node::OwnedContextOptions options;
  options.name = Text(isolate, "Generic owned provider");
  if (args.Length() > 3 && args[3]->IsTrue()) options.own_microtask_queue = true;
  Local<Value> token = isolate->GetCurrentContext()->GetSecurityToken();
  if (args.Length() > 2 && !args[2]->IsUndefined()) token = args[2];
  Local<Context> owned;
  if (!node::CreateOwnedContext(state->env,
                                 args[0].As<Object>(),
                                 state->global_template.Get(isolate),
                                 token,
                                 options,
                                 previous).ToLocal(&owned)) return;
  args.GetReturnValue().Set(owned->Global());
}
void Detach(const FunctionCallbackInfo<Value>& args) {
  if (args.Length() < 1 || !args[0]->IsObject()) return Bad(args, "Expected carrier");
  Local<Object> proxy;
  if (node::DetachOwnedContext(Data(args)->env, args[0].As<Object>()).ToLocal(&proxy)) {
    args.GetReturnValue().Set(proxy);
  }
}
void Run(const FunctionCallbackInfo<Value>& args) {
  Local<Context> owned;
  if (!Owner(args, 0).ToLocal(&owned)) return;
  if (args.Length() != 2 || !args[1]->IsString()) return Bad(args, "Expected source");
  Context::Scope scope(owned);
  ScriptOrigin origin(args.GetIsolate(), Text(args.GetIsolate(), "owned-empty-hdo.js"));
  ScriptCompiler::Source source(args[1].As<String>(), origin);
  Local<Script> script;
  Local<Value> result;
  if (ScriptCompiler::Compile(owned, &source).ToLocal(&script) &&
      script->Run(owned).ToLocal(&result)) args.GetReturnValue().Set(result);
}
void SameRealm(const FunctionCallbackInfo<Value>& args) {
  Local<Context> owned, actual;
  if (!Owner(args, 1).ToLocal(&owned)) return;
  args.GetReturnValue().Set(args[0]->IsObject() &&
      args[0].As<Object>()->GetCreationContext().ToLocal(&actual) && actual == owned);
}
void Token(const FunctionCallbackInfo<Value>& args) {
  Local<Context> owned;
  if (!Owner(args, 0).ToLocal(&owned)) return;
  args.GetReturnValue().Set(args.Length() > 1 &&
      owned->GetSecurityToken()->StrictEquals(args[1]));
}
void WatchOwner(const FunctionCallbackInfo<Value>& args) {
  Local<Context> owned;
  if (!Owner(args, 0).ToLocal(&owned)) return;
  auto watch = std::make_unique<Watch>();
  watch->context.Reset(args.GetIsolate(), owned);
  watch->context.SetWeak();
  watch->carrier.Reset(args.GetIsolate(), args[0].As<Object>());
  watch->carrier.SetWeak();
  auto* state = Data(args);
  state->watches.push_back(std::move(watch));
  args.GetReturnValue().Set(static_cast<uint32_t>(state->watches.size() - 1));
}
void WatchState(const FunctionCallbackInfo<Value>& args) {
  auto* state = Data(args);
  if (args.Length() != 1 || !args[0]->IsUint32() ||
      args[0].As<Uint32>()->Value() >= state->watches.size()) return Bad(args, "Unknown watch");
  auto* watch = state->watches[args[0].As<Uint32>()->Value()].get();
  auto isolate = args.GetIsolate();
  auto context = isolate->GetCurrentContext();
  Local<Object> result = Object::New(isolate);
  result->CreateDataProperty(context, Text(isolate,"contextCollected"),
      Boolean::New(isolate,watch->context.IsEmpty())).Check();
  result->CreateDataProperty(context, Text(isolate,"carrierCollected"),
      Boolean::New(isolate,watch->carrier.IsEmpty())).Check();
  args.GetReturnValue().Set(result);
}
void ReleaseTemplate(const FunctionCallbackInfo<Value>& args) {
  Data(args)->global_template.Reset();
}
void Set(Local<Object> exports, Local<Context> context, State* state,
         const char* name, FunctionCallback callback) {
  exports->CreateDataProperty(context, Text(context->GetIsolate(), name),
      Function::New(context, callback, External::New(context->GetIsolate(), state))
          .ToLocalChecked()).Check();
}
}  // namespace

NODE_MODULE_INIT() {
  auto isolate = context->GetIsolate();
  auto* state = new State;
  state->env = node::GetCurrentEnvironment(context);
  auto function_template = FunctionTemplate::New(isolate);
  function_template->SetClassName(Text(isolate, "GenericOwnedWindow"));
  state->global_template.Reset(isolate, function_template->InstanceTemplate());
  node::AddEnvironmentCleanupHook(isolate, [](void* value) {
    delete static_cast<State*>(value);
  }, state);
  Set(exports, context, state, "create", Create);
  Set(exports, context, state, "detach", Detach);
  Set(exports, context, state, "run", Run);
  Set(exports, context, state, "sameRealm", SameRealm);
  Set(exports, context, state, "tokenMatches", Token);
  Set(exports, context, state, "watch", WatchOwner);
  Set(exports, context, state, "watchState", WatchState);
  Set(exports, context, state, "releaseTemplate", ReleaseTemplate);
  exports->CreateDataProperty(context, Text(isolate,"providerVersion"),
      Integer::NewFromUnsigned(isolate, node::kOwnedContextProviderVersion)).Check();
}
