// UNRUN normal Node snapshot control, unrelated to an owned Window facade.
'use strict';
globalThis.genericSnapshotProof = Object.freeze({ answer: 42 });
