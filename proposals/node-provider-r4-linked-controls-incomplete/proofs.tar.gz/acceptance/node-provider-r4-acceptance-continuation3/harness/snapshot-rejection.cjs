// UNRUN; invoke custom Node --build-snapshot with this entry under its own
// output directory. Successful snapshotting of ordinary Node is a separate gate.
'use strict';
const assert = require('node:assert/strict');
const vm = require('node:vm');
assert.throws(() => vm.prepareOwnedContext(), { code: 'ERR_INVALID_STATE' });
console.log('owned-ticket creation rejected during actual snapshot build');
