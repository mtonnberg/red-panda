// SOURCE ONLY, UNRUN. Apply the R2 Node delta over exact frozen R1 first.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { test } from 'node:test';
const binding = createRequire(import.meta.url)(process.env.OWNED_PROVIDER_ADDON);

async function dependency(context) {
  const module = new vm.SourceTextModule('export const from="ordinary-B"', { context });
  await module.link(() => { throw new Error('Unexpected dependency'); });
  await module.evaluate({ timeout: 1000 });
  return module;
}

await test('ordinary contextification of prepared A rejects owned creation and preserves real B imports/module/closure', async () => {
  const calls = [];
  let dep;
  const prepared = vm.prepareOwnedContext({ name: 'prepared-A', importModuleDynamically() {
    calls.push('A'); throw new Error('Prepared A must not replace ordinary B');
  } });
  assert.equal(vm.isContext(prepared), false);
  const ordinary = vm.createContext(prepared, { name: 'ordinary-B', importModuleDynamically(specifier, referrer) {
    calls.push('B'); assert.equal(specifier, 'dep'); assert.equal(referrer, ordinary); return dep;
  } });
  assert.equal(ordinary, prepared);
  assert.equal(vm.isContext(prepared), true);
  const old = vm.runInContext('globalThis.marker=17; ({Object, fn:()=>marker})', ordinary);
  dep = await dependency(ordinary);
  // Exact upstream Node context-HDO producer from
  // test/parallel/test-vm-module-referrer-realm.mjs:31. Its documented
  // no-JS-stack microtask constraint remains an actual test requirement.
  const script = new vm.Script('Promise.resolve("import(\'dep\')").then(eval)', {
    importModuleDynamically() { throw new Error('Script referrer must not win'); },
  });
  assert.equal(await script.runInContext(ordinary), dep.namespace);
  const heldModule = new vm.SourceTextModule('export const read=()=>marker; export const meta=import.meta', {
    context: ordinary, initializeImportMeta(meta) { meta.owner = 'ordinary-B'; },
  });
  await heldModule.link(() => { throw new Error('Unexpected dependency'); });
  // This must reject before any pending/HDO/proxy-lease mutation or allocation.
  assert.throws(() => binding.create(prepared), { code: 'ERR_INVALID_STATE' });
  assert.equal(vm.runInContext('Object', ordinary), old.Object);
  assert.equal(old.fn(), 17);
  vm.runInContext('marker=18', ordinary);
  assert.equal(old.fn(), 18);
  await heldModule.evaluate({ timeout: 1000 });
  assert.equal(heldModule.namespace.read(), 18);
  assert.equal(heldModule.namespace.meta.owner, 'ordinary-B');
  assert.equal(await script.runInContext(ordinary), dep.namespace);
  assert.deepEqual(calls, ['B', 'B']);
  assert.equal(vm.createContext(prepared), ordinary);
  assert.throws(() => binding.detach(prepared), { code: 'ERR_INVALID_STATE' });
  console.log(JSON.stringify({ case: 'carrier collision', ordinaryHdoCalls: calls,
    realModuleContinues: true, actualOldClosureContinues: true }));
});

await test('rejecting the contextified ticket preserves a previous owned proxy lease', () => {
  const previous = vm.prepareOwnedContext();
  const proxy = binding.create(previous);
  assert.equal(binding.detach(previous), proxy);
  const collision = vm.createContext(vm.prepareOwnedContext());
  assert.throws(() => binding.create(collision, previous), { code: 'ERR_INVALID_STATE' });
  const fresh = vm.prepareOwnedContext();
  assert.equal(binding.create(fresh, previous), proxy);
  assert.equal(vm.runInContext('globalThis', fresh), proxy);
  assert.throws(() => binding.create(fresh), { code: 'ERR_INVALID_STATE' });
});

await test('stock DONT_CONTEXTIFY and ordinary objects do not acquire pending ownership', () => {
  const vanilla = vm.createContext(vm.constants.DONT_CONTEXTIFY);
  assert.equal(vm.runInContext('globalThis', vanilla), vanilla);
  assert.throws(() => binding.create(vanilla), { code: 'ERR_INVALID_STATE' });
  assert.throws(() => binding.create(vm.constants.DONT_CONTEXTIFY), TypeError);
  const untouched = vm.prepareOwnedContext();
  const otherVanilla = vm.createContext(vm.constants.DONT_CONTEXTIFY);
  assert.notEqual(untouched, otherVanilla);
  const proxy = binding.create(untouched);
  assert.equal(vm.runInContext('globalThis', untouched), proxy);
  assert.throws(() => binding.create(new Proxy(untouched, {})), { code: 'ERR_INVALID_STATE' });
});
