// UNRUN separate capability. Failure is retained and must not be hidden by
// shared-token generic module positives. This is not a complete SOP policy.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { createRequire } from 'node:module';
const binding = createRequire(import.meta.url)(process.env.OWNED_PROVIDER_ADDON);
const token = Symbol('genuine owned origin');
const ticket = vm.prepareOwnedContext();
const proxy = binding.create(ticket, undefined, token);
assert.equal(binding.tokenMatches(ticket, token), true);
assert.equal(vm.runInContext('globalThis', ticket), proxy);
const dependency = new vm.SourceTextModule('export const actual=42', { context: ticket });
await dependency.link(() => {});
await dependency.evaluate({ timeout: 1000 });
const calls = [];
const importTicket = vm.prepareOwnedContext({ importModuleDynamically(specifier, referrer) {
  calls.push({ specifier, referrer }); return dependency.namespace;
} });
binding.create(importTicket, undefined, token);
assert.equal(binding.tokenMatches(importTicket, token), true);
assert.equal((await binding.run(importTicket, 'import("dep")')).actual, 42);
assert.equal(calls.length, 1);
assert.equal(calls[0].referrer, importTicket);
console.log(JSON.stringify({ status: 'distinct-from-Host token import observed',
  limitations: ['not an access-checked Window SOP test', 'does not prove arbitrary Host Promise adoption'] }));
