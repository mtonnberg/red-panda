"""Build only this owned test addon against actually linked matching R4. No tests/install/network."""
from pathlib import Path
import argparse,json,os,time,signal
from common import ROOT,SOURCE,CONTRACT,OUTPUTS,REPORT,sha,matching_linked_outputs,guards,protected_root,snapshot,run_owned
p=argparse.ArgumentParser();p.add_argument('--epoch',required=True);a=p.parse_args();assert a.epoch and all(c.isalnum()or c in '-_'for c in a.epoch);out=ROOT/'build-evidence'/a.epoch;out.mkdir(parents=True,exist_ok=False);record={'status':'SETUP','stages':[],'tests':'UNRUN','installation':'NONE','futureRuntimeLeaseRequired':True};paths=None;protected=None;start=time.monotonic()
def interrupted(n,f):raise InterruptedError('Controller signal '+str(n))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 outputs=matching_linked_outputs();paths=guards();protected=protected_root();(out/'inputs-before.json').write_text(json.dumps(paths,indent=2)+'\n');(out/'protected-root-before.json').write_text(json.dumps(protected,indent=2)+'\n');addon=ROOT/'harness/build/Release/provider.node';assert not addon.exists(),'No prior addon reuse/rebuild without separate owned epoch';node=CONTRACT['customNode'];gyp=SOURCE/'deps/npm/node_modules/node-gyp/bin/node-gyp.js';assert gyp.is_file();assert not os.environ.get('NODE_OPTIONS'),'Unexpected NODE_OPTIONS injection; stop, do not silently mutate canonical environment';env=os.environ.copy();env.update(npm_config_offline='true',npm_config_audit='false',npm_config_fund='false',npm_config_update_notifier='false');compiler=json.loads((ROOT/'reference/actual-r4-toolchain.json').read_text())['compiler']['resolvedPath'];env['CXX']=compiler
 command=[node,str(gyp),'configure','build','--nodedir='+str(SOURCE),'--directory='+str(ROOT/'harness'),'--devdir='+str(ROOT/'gyp-cache'),'--jobs=1'];record['buildCommand']=command;record['offlineBasis']='actual bundled configure.js nodedir branch skips header-install/download; owncache/jobs1/no package manager or SDK fallback';row=run_owned('addon-configure-build',command,ROOT/'harness',out,env,300);record['stages'].append(row)
 if row['returnCode']!=0 or row['administrativeTimeout']:raise RuntimeError('actual addon configure/build failure; runtime UNRUN')
 assert addon.is_file();record['addon']={'path':str(addon),'sha256':sha(addon),'bytes':addon.stat().st_size};record['actualNodeOutputs']=outputs;record['status']='OWN_ADDON_BUILT_RUNTIME_UNRUN'
except BaseException as error:record.update(status='STOPPED',error={'type':type(error).__name__,'message':str(error)},partialOutputsPreserved=True)
finally:
 if paths is not None:after=snapshot(paths);record['inputsStable']=after==paths;(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
 if protected is not None:after=protected_root();record['protectedRootAnd18SDKArtifactsStable']=after==protected;(out/'protected-root-after.json').write_text(json.dumps(after,indent=2)+'\n')
 if record.get('inputsStable')is False or record.get('protectedRootAnd18SDKArtifactsStable')is False:record['status']='GUARD_FAILURE'
 record['elapsedSeconds']=time.monotonic()-start;(out/'report.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

raise SystemExit(0 if record['status']=='OWN_ADDON_BUILT_RUNTIME_UNRUN' else 1)
