R2 is a separate owned copy of sealed R1. The only code change adds actual SOURCE/out/Release/gen to the existing post-link header guard, retaining obj/gen if present. Actual Ninja compdb uses -Igen,-Igen/include,-Igen/src from out/Release; exact examples/hash are in r2-manifest.json. Header capture still occurs only after successful actual link, with no active generator output relabeling.

All original commands, flags,45s stage boundaries,20ms/1000ms/8GC/12turn/R4microtask limits,13-stage order,7case checks and source/config/Ninja/output/addon identity gates remain unchanged. No Node/build/network or Root/source mutation occurred. Copied README.md and static-inventory.sha256 describe historical R1; new R2 authority is r2-manifest.json and r2-inventory.sha256.

Future separately granted commands use this NEW own directory:
python3 /workspace/shared/node-provider-r4-acceptance-r2/build-addon.py --epoch addon-1
Then, after successful actual addon review and separate runtime lease:
python3 /workspace/shared/node-provider-r4-acceptance-r2/run-controls-r4.py --addon-build-report /workspace/shared/node-provider-r4-acceptance-r2/build-evidence/addon-1/report.json --epoch controls-1

Existing dynamic ROOT paths select only this own R2 harness/cache/evidence; actual custom R4 source/node/cctest paths are unchanged. Matching outputs.json remains unavailable until genuine link and is never assumed. Sealed R1 and all18 Root SDK artifacts remain untouched.
