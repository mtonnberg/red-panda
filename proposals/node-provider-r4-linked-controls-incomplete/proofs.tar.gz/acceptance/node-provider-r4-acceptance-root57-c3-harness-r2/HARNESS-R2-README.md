This is a NEW, STATIC addon-harness correction after the actual first addon build failed. No compiler, custom Node, cctest, browser or acceptance controller ran while preparing this derivative. The failed root57-c3-r1 packet, its addon-1 build log/report/closure and partial generated build directory remain unchanged. This new directory contains no copied object files, addon, build-evidence or gyp cache.

The C++ patch makes exactly two mechanical corrections against the actual matching V8 headers:

- `ScriptOrigin` takes the resource name as its first argument in V8 13.6. The obsolete isolate argument is removed. The same `owned-empty-hdo.js` resource name and default empty host-defined options are preserved.
- The free helper `Set` is renamed `ExportMethod`, including its eight calls. JavaScript export names and native callbacks are unchanged. This avoids ambiguity with the genuine `v8::Set` class.

Original provider SHA: e609c9b6223025c5230024cf7150d329990bf7277febe1db9b9637d1e7f474f0.
Corrected own provider SHA: 4c57369df9e2dbbbbe3b87f78d132fdc2ac9157079d99cca86b0e6a6f70be308.
The exact C++ delta is harness-compile-only.patch. Actual node.h, v8-message.h and v8-container.h are copied under reference/harness-compile-fix-r2 with unchanged before/after header hashes in harness-r2-static-review.json. No SDK/header switch, warning suppression or compiler-option change was made.

The new contract and common.py distinguish the corrected own provider from the unchanged original R3 source and B4 harness. Both are checked against their own exact hashes. All ten other harness files and both build/runtime controller files are byte-identical. Existing C3 binary/report/output pins and exact applied Root645/18 pins are preserved. The guarded raw failed epoch is retained under reference/harness-compile-fix-r2. Other copied READMEs/manifests remain historical; current authority is harness-r2-manifest.json and harness-r2-inventory.sha256.

The thirteen runtime stages, seven exact cctest names, JavaScript assertions, snapshot/GC controls and all budgets are unchanged. The 300-second addon-build limit and 45-second runtime stage limits remain. Runtime controls and cctest are not automatically chained to the addon build. Original source-nodedir config and NODE_MODULE_INIT cast warnings are retained rather than suppressed.

Future SEPARATELY GRANTED own-addon build:

`timeout --signal=TERM --kill-after=5s 360s python3 /workspace/shared/node-provider-r4-acceptance-root57-c3-harness-r2/build-addon.py --epoch addon-1`

It uses only the pinned custom C3 Node, bundled node-gyp, actual source/public/generated headers via --nodedir, recorded compiler, this directory's fresh cache/harness and jobs=1. No Root or stock ABI-only addon is reused.

Only after the real successful own-addon report/hash is reviewed and a separate quiet runtime lease is granted:

`python3 /workspace/shared/node-provider-r4-acceptance-root57-c3-harness-r2/run-controls-r4.py --addon-build-report /workspace/shared/node-provider-r4-acceptance-root57-c3-harness-r2/build-evidence/addon-1/report.json --epoch controls-1`

The first failed addon attempt establishes genuine compiler diagnostics and stable guards, not provider runtime success. The corrected harness remains uncompiled/unrun at sealing. No Node provider implementation, Root source/native artifact, test assertion, service or deployment changed.
