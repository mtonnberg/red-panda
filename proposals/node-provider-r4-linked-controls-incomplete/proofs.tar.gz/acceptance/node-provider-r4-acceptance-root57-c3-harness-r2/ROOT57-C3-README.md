This is a NEW, STATIC, guard-only acceptance derivative. No Node, addon compiler, cctest, browser or acceptance controller ran in preparing it. All earlier acceptance packets remain unchanged. The incomplete static review directory is retained with its missing-input assumption recorded; it is not a runtime or build failure.

Actual C3 now provides linked custom Node and cctest binaries, not provider or browser acceptance:

- C3 report SHA: 5d741a449aeb96077eef37c58d6d4c7092eb550a8303f49b28c7da59b4f1651c.
- C3 outputs manifest SHA: 6a12b61589a6744ae9f1be520158343f473a14c5beec6f6a21aefa5c2a3e9ad8.
- Node SHA: 0593334590d0ad0c253bb4ae884daec9e4058d80e7b03afca5650172918a06a0.
- Cctest SHA: 9535d9c7d791648581d390a45de9d77ee2728fd588a2b5a25f33c2addfcb0a5b.

The application journal at /workspace/shared/root2342-feature57-before-r1/journal.json was copied immutably while its actual state was APPLIED_EXACT57_FULL_ROOT_VALIDATION_STILL_UNRUN. Its SHA is 149951e87259b49815fa2d2f341c786e38dc4d6ad37a6c89829f167b5d3ed3c0. This records an installed source/artifact identity; it does not assert the full workflow passed. Root's full workflow owns the runtime lease and was still running at capture.

The new reference/root57-c3/epoch-pins.json binds all 645 actual RootAfter paths and all eighteen installed native artifact/manifest leaves to that journal and C3 output identities. Six runtime binary/manifest leaves changed; twelve collection/heap leaves were preserved. The new Root runtime.cc SHA is 95bba30f4013139999dc9b843b45bdb5ddc1802145431fc6386bddc85975cd36. No old cb235 runtime binary is substituted for this installed epoch.

Only contract.json and common.py changed as controller inputs/code. The narrow patch adds expected C3 report/output hashes and output rows, plus explicit approved Root source/artifact epoch checks before any future child launch. Existing per-stage before/after Root protection remains. The two build/runtime controllers, eleven original harness files, thirteen ordered process stages, seven exact cctest names and original budgets remain byte-identical. No assertion, fixture, interpreter/compiler option or timeout changed.

The current authority is root57-c3-manifest.json and root57-c3-inventory.sha256. Copied older READMEs/manifests remain historical. The external original application journal may later gain validation results; the immutable copied journal and actual pinned Root source/artifact bytes remain the authority here. Any later change to those approved bytes fails the guard and requires a fresh versioned derivative.

After Root's full workflow outcome is reviewed and a SEPARATE addon-build lease is granted:

`python3 /workspace/shared/node-provider-r4-acceptance-root57-c3-r1/build-addon.py --epoch addon-1`

This builds only the own test addon using the actual C3 Node, its bundled node-gyp, its exact source/public/generated header tree via --nodedir, the recorded compiler, this derivative's own cache/harness and jobs=1. It keeps the original 300-second administrative cap and offline configuration. Root artifacts are protected and are never loaded as the custom provider addon. The addon build does not automatically start runtime acceptance.

Only after the real matching addon bytes/hash and its guards are reviewed, and a SEPARATE quiet runtime lease is granted:

`python3 /workspace/shared/node-provider-r4-acceptance-root57-c3-r1/run-controls-r4.py --addon-build-report /workspace/shared/node-provider-r4-acceptance-root57-c3-r1/build-evidence/addon-1/report.json --epoch controls-1`

All thirteen original process stages and seven actual RUN/OK cctest observations remain required. The 20ms script watchdog, 1000ms module evaluation limit, eight C++ low-memory requests, twelve JavaScript GC turns, sixteen namespace microtask checkpoints and 45-second process limits remain unchanged. The bounded original collision, reservation, context lifetime, ordinary Node, module/meta/dynamic import, namespace and snapshot controls are not browser parity claims. Cross-token behavior, continuous-live-IsolateData/thread/Locker assumptions and unsupported live-provider snapshot boundaries remain explicit.

Quiet25 and conditional continuation4 remain unrun. Successful C3 prevents continuation4's required prior-timeout/no-output precondition. No Root source, native artifact, deployment or service was changed by this work.
