from pathlib import Path
import json,hashlib,subprocess,time,os,signal,re
paths={str(p) for folder in ['src','test','scripts','bin','native','oracle','docs/reference'] for p in Path(folder).rglob('*') if p.is_file()}|{'package.json','package-lock.json'};before={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(paths)};Path('evidence/focused-before.json').write_text(json.dumps(before,indent=2)+'\n')
command=['/workspace/shared/rea-tools/node_modules/node/bin/node','--experimental-vm-modules','--test','--test-concurrency=1','test/sync-http-lazy.test.js','test/window-sync-xhr.test.js','test/window-viewport-parity.test.js'];start=time.monotonic();terminated=False
with open('evidence/focused.log','xb') as output:
 child=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=child.wait(timeout=58)
 except subprocess.TimeoutExpired:
  terminated=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=1)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
status={'command':command,'exit':code,'seconds':time.monotonic()-start,'outerResourceTermination':terminated,'inputs':len(before),'changed':[p for p,h in before.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h],'summary':{n:int(v) for n,v in re.findall(r'ℹ (tests|pass|fail|cancelled|skipped) (\d+)',Path('evidence/focused.log').read_text())}};Path('evidence/focused-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status))
