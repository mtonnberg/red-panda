from pathlib import Path
import json,hashlib,difflib,tarfile,gzip,io,re
root=Path('/workspace/red-panda');work=Path.cwd();primary=Path('/workspace/shared/red-panda-phase22-preparation');out=root/'proposals/sync-http-lazy';out.mkdir(exist_ok=False);base=json.loads(Path('evidence/base-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();names=['src/sync-http.js','src/sync-http-thread.js','test/window-viewport-parity.test.js','test/sync-http-lazy.test.js'];manifest={};patch=''
for n in names:
 before=(primary/n).read_bytes() if n in base else b'';after=Path(n).read_bytes();assert not before or sha(before)==base[n],n;manifest[n]={'before':sha(before) if before else None,'after':sha(after)};p=out/'candidate'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(after);patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+n if before else '/dev/null',tofile='b/'+n))
(out/'integration.patch').write_text(patch);(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');entries=[]
for label,directory in [('candidate',work/'evidence'),('baseline',Path('/workspace/shared/sync-http-baseline-trace-recovery/evidence'))]:
 for p in sorted(directory.iterdir()):
  if p.is_file():entries.append((label+'/'+p.name,p.read_bytes()))
for n in ['source-before.json','source-after.json','24.22.1.log','status.json']:
 p=primary/'integration-evidence/final-composition'/n
 if p.exists():entries.append(('prior-rejected-root/'+n,p.read_bytes()))
with open(out/'evidence.tar.gz','wb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for n,b in sorted(entries):
    info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o444;info.mtime=0;tar.addfile(info,io.BytesIO(b))
(out/'evidence-manifest.json').write_text(json.dumps({n:sha(b)for n,b in sorted(entries)},indent=2)+'\n');namesMatched=re.findall(r'^✔ (.*?) \([\d.]+ms\)$',Path('evidence/focused.log').read_text(),re.M);(out/'test-names.json').write_text(json.dumps(namesMatched,indent=2)+'\n');metadata={'status':'Frozen independent lazy transport proposal; Root composition/all SDK/full pending','runtimeLeaves':2,'existingFixtureCleanupLeaves':1,'newTestLeaves':1,'node':'v24.22.1','baseline':'One successful actual async-only Browser/Page navigation;0syncfetchcalls yet original threadcreated; child entry90.404ms/ready90.452ms; originalwait2000ms returned90.558ms. Prior2s failure not reproduced or explained.','focused':{'pass':32,'fail':0,'cancelled':0,'seconds':18.000602813001024,'inputCount':1850,'changed':[]},'budgets':'No request/page timeout or VM80/200ms changed. First actual worker startup now counts inside existing synchronous request deadline, not a separate Browser startup prerequisite.','provenance':'6579 shared deps post-compared to earlier frozen Root final-composition guard;0differences/new. Explicit postrun limitation; no invented independentbefore hash.','unrun':['Other SDKs for this packet','Root composed/full suite','No Native engine run required/claimed for internal Node transport startup; Native viewport controls retained from prioractualoracles'],'artifacts':{n:sha((out/n).read_bytes())for n in ['integration.patch','source-manifest.json','evidence.tar.gz','evidence-manifest.json','test-names.json']}};(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata['artifacts'],indent=2))
