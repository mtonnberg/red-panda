import http from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {startReference} from '../scripts/reference-server.mjs';
import {connect} from '../test/cdp-client.js';
const binary='/workspace/shared/lightpanda-reference/lightpanda-x86_64-linux';
const sha=value=>createHash('sha256').update(value).digest('hex');
const binaryHash=sha(await readFile(binary));if(binaryHash!=='9dec394124212f796724d4d32737ba66fdf0319ae6faaf8a1df8cccb4a70e23f')throw Error('Native digest mismatch');
const server=http.createServer((req,res)=>{res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><body></body>')});await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser,client;
try{browser=await startReference(binary,{args:['--load-resources','iframe','--load-resources','worker']});client=await connect(browser.endpoint);const{targetId}=await client.send('Target.createTarget',{url:'about:blank'});const{sessionId}=await client.send('Target.attachToTarget',{targetId,flatten:true});await client.send('Page.navigate',{url:`http://127.0.0.1:${server.address().port}/`},sessionId);const expression=await readFile(process.argv[2],'utf8'),result=await client.send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},sessionId,{timeout:15000});if(result.exceptionDetails)throw Error(JSON.stringify(result.exceptionDetails));await writeFile(process.argv[3],JSON.stringify({binary,binarySHA256:binaryHash,probeSHA256:sha(await readFile(new URL(import.meta.url))),expressionSHA256:sha(expression),observations:result.result.value},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result.result.value,null,2));}finally{await client?.close();await browser?.close();server.closeAllConnections();await new Promise(r=>server.close(r))}
